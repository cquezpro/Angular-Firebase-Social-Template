<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once('basemodel.php');

class Membersettings_model extends BaseModel{
	
	protected $_table = 'member_settings';
	protected $_id_column = 'id';
	
	public function save(){
		
		if ($this->getId() == ''){
			
			$now = date("Y-m-d H:i:s");
			
			$this->setCreatedDate($now);
			$this->setUpdatedDate($now);
			
			if (!$this->db->insert($this->_table, $this->getData())){
				log_message("error", "Unable to insert member settings information to db.");
				return false;
			}
			
			$new_id = $this->db->insert_id();
			$this->setId($new_id);
			
			return $this;
		}
		else{
			
			$now = date("Y-m-d H:i:s");
			
			$this->setUpdatedDate($now);
			
			$data_array = $this->getData();
			
			unset($data_array['id']);
			
			$this->db->where("id", $this->getId());
			
			if (!$this->db->update($this->_table, $data_array))
				return false;
						
			return true;
			
		}
		
	}
		
		
	public function loadByMemberId($member_id){
		
		$sql = "SELECT * FROM " . $this->_table . " WHERE member_id = ?";
		
		$query = $this->db->query($sql, array($member_id));
		
		if (!$query) return false;
		
		$row = $query->row_array();
		
		if (!$row) return false;
		
		$this->setData($row);
		
		return $this;
	}
	
	public function loadDefaultSettings(){
		
		$this->setPasswordPrompt(1);
		$this->setBrowsingFilterEnabled(0);
		$this->setBrowsingFilterAgeMin(18);
		$this->setBrowsingFilterAgeMax(100);
		$this->setBrowsingFilterDistanceMin(0);
		$this->setBrowsingFilterDistanceMax(1000);
		$this->setNotificationMessageStatus(1);
		$this->setNotificationMessageSound(0);
		$this->setNotificationWoofsStatus(1);
		$this->setNotificationWoofsSound(0);
		$this->setNotificationHotStatus(1);
		$this->setNotificationHotSound(0);
		$this->setNotificationGiftsStatus(1);
		$this->setNotificationGiftsSound(0);
		$this->setNotificationTracksStatus(0);
		$this->setNotificationTracksSound(0);
		$this->setMeasurementsUnits('all');
		$this->setHideMyDistance(0);
		$this->setMenuOrder('mnu-nearby, mnu-global, mnu-online, mnu-looking, mnu-favorites, mnu-chats, mnu-woofs, mnu-tracks, mnu-hot');
	}
	
}