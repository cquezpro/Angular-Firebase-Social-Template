<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-05 06:02:02 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:02 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:02 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Database Driver Class Initialized
ERROR - 2014-02-05 06:02:02 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 06:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:02 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:02 --> A session cookie was not found.
DEBUG - 2014-02-05 06:02:02 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:02 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:02 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:02 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Database Driver Class Initialized
ERROR - 2014-02-05 06:02:02 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 06:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:02 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:02 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:02 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-05 06:02:02 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:02 --> Total execution time: 0.0120
DEBUG - 2014-02-05 06:02:09 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:09 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:09 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:09 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:09 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:09 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:14 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:14 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:14 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Database Driver Class Initialized
ERROR - 2014-02-05 06:02:14 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 06:02:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:14 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:14 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:14 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:14 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:14 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:15 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:15 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:15 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 06:02:15 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:15 --> Total execution time: 0.0190
DEBUG - 2014-02-05 06:02:15 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:15 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:15 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:15 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:15 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:15 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:15 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:15 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:15 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:15 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:15 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:15 --> Total execution time: 0.0150
DEBUG - 2014-02-05 06:02:15 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:15 --> Total execution time: 0.0250
DEBUG - 2014-02-05 06:02:20 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:20 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:20 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:20 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:20 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:20 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:20 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:20 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:20 --> Total execution time: 0.0250
DEBUG - 2014-02-05 06:02:20 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:20 --> Total execution time: 0.0340
DEBUG - 2014-02-05 06:02:25 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:25 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:25 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:25 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:25 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:25 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:25 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:25 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:25 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:25 --> Total execution time: 0.0280
DEBUG - 2014-02-05 06:02:44 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:44 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:44 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:44 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:44 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:44 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:44 --> Total execution time: 0.0270
DEBUG - 2014-02-05 06:02:46 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:46 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:46 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:46 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:46 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:46 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:46 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:46 --> Total execution time: 0.0270
DEBUG - 2014-02-05 06:02:51 --> Config Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:02:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:02:51 --> URI Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Router Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Output Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Security Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Input Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:02:51 --> Language Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Loader Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Controller Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:02:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:02:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:51 --> Session Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:02:51 --> Session routines successfully run
DEBUG - 2014-02-05 06:02:51 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:02:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:02:51 --> Final output sent to browser
DEBUG - 2014-02-05 06:02:51 --> Total execution time: 0.0250
DEBUG - 2014-02-05 06:03:10 --> Config Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:03:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:03:10 --> URI Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Router Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Output Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Security Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Input Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:03:10 --> Language Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Loader Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Controller Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:03:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:03:10 --> Model Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Model Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Model Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:03:10 --> Session Class Initialized
DEBUG - 2014-02-05 06:03:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:03:10 --> Session routines successfully run
DEBUG - 2014-02-05 06:03:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:03:10 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:03:10 --> Final output sent to browser
DEBUG - 2014-02-05 06:03:10 --> Total execution time: 0.0230
DEBUG - 2014-02-05 06:04:44 --> Config Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:04:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:04:44 --> URI Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Router Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Output Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Security Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Input Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:04:44 --> Language Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Loader Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Controller Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:04:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:04:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Model Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:04:44 --> Session Class Initialized
DEBUG - 2014-02-05 06:04:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:04:44 --> Session routines successfully run
DEBUG - 2014-02-05 06:04:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:04:44 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:04:44 --> Final output sent to browser
DEBUG - 2014-02-05 06:04:44 --> Total execution time: 0.0240
DEBUG - 2014-02-05 06:04:50 --> Config Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:04:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:04:50 --> URI Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Router Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Output Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Security Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Input Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:04:50 --> Language Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Loader Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Controller Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:04:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:04:50 --> Model Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Model Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Model Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:04:50 --> Session Class Initialized
DEBUG - 2014-02-05 06:04:50 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:04:50 --> Session routines successfully run
DEBUG - 2014-02-05 06:04:50 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:04:50 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:04:50 --> Final output sent to browser
DEBUG - 2014-02-05 06:04:50 --> Total execution time: 0.0230
DEBUG - 2014-02-05 06:05:54 --> Config Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:05:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:05:54 --> URI Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Router Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Output Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Security Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Input Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:05:54 --> Language Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Loader Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Controller Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:05:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:05:54 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:54 --> Session Class Initialized
DEBUG - 2014-02-05 06:05:54 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:05:54 --> Session routines successfully run
DEBUG - 2014-02-05 06:05:54 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:05:59 --> Config Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:05:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:05:59 --> URI Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Router Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Output Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Security Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Input Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:05:59 --> Language Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Loader Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Controller Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Session Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:05:59 --> Session routines successfully run
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:05:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 06:05:59 --> Final output sent to browser
DEBUG - 2014-02-05 06:05:59 --> Total execution time: 0.0210
DEBUG - 2014-02-05 06:05:59 --> Config Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:05:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:05:59 --> URI Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Config Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Router Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:05:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:05:59 --> Config Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Output Class Initialized
DEBUG - 2014-02-05 06:05:59 --> URI Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Router Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Security Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:05:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:05:59 --> Input Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Output Class Initialized
DEBUG - 2014-02-05 06:05:59 --> URI Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Security Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:05:59 --> Router Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Input Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Language Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Output Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:05:59 --> Loader Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Security Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Controller Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Language Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Input Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:05:59 --> Loader Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:05:59 --> Language Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Controller Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Loader Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:05:59 --> Controller Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:05:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Session Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:05:59 --> Session routines successfully run
DEBUG - 2014-02-05 06:05:59 --> Session Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Session routines successfully run
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:05:59 --> Session Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Session routines successfully run
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:05:59 --> Final output sent to browser
DEBUG - 2014-02-05 06:05:59 --> Total execution time: 0.0140
DEBUG - 2014-02-05 06:05:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:05:59 --> Final output sent to browser
DEBUG - 2014-02-05 06:05:59 --> Total execution time: 0.0160
DEBUG - 2014-02-05 06:05:59 --> Final output sent to browser
DEBUG - 2014-02-05 06:05:59 --> Total execution time: 0.0280
DEBUG - 2014-02-05 06:06:04 --> Config Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:06:04 --> URI Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Router Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Output Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Security Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Input Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:06:04 --> Language Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Loader Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Controller Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:06:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:06:04 --> Model Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Model Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Model Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:06:04 --> Session Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:06:04 --> Session routines successfully run
DEBUG - 2014-02-05 06:06:04 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:06:04 --> Model Class Initialized
DEBUG - 2014-02-05 06:06:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:06:04 --> Final output sent to browser
DEBUG - 2014-02-05 06:06:04 --> Total execution time: 0.0290
DEBUG - 2014-02-05 06:07:40 --> Config Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:07:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:07:40 --> URI Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Router Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Output Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Security Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Input Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:07:40 --> Language Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Loader Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Controller Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:07:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:07:40 --> Model Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Model Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Model Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:07:40 --> Session Class Initialized
DEBUG - 2014-02-05 06:07:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:07:40 --> Session routines successfully run
DEBUG - 2014-02-05 06:07:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:07:40 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:07:40 --> Final output sent to browser
DEBUG - 2014-02-05 06:07:40 --> Total execution time: 0.0250
DEBUG - 2014-02-05 06:09:17 --> Config Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:09:17 --> URI Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Router Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Output Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Security Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Input Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:09:17 --> Language Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Loader Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Controller Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:09:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:09:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:09:17 --> Session Class Initialized
DEBUG - 2014-02-05 06:09:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:09:17 --> Session routines successfully run
DEBUG - 2014-02-05 06:09:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:09:17 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:09:17 --> Final output sent to browser
DEBUG - 2014-02-05 06:09:17 --> Total execution time: 0.0250
DEBUG - 2014-02-05 06:09:32 --> Config Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:09:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:09:32 --> URI Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Router Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Output Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Security Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Input Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:09:32 --> Language Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Loader Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Controller Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:09:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:09:32 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:09:32 --> Session Class Initialized
DEBUG - 2014-02-05 06:09:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:09:32 --> Session routines successfully run
DEBUG - 2014-02-05 06:09:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:09:32 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:09:32 --> Final output sent to browser
DEBUG - 2014-02-05 06:09:32 --> Total execution time: 0.0150
DEBUG - 2014-02-05 06:09:57 --> Config Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:09:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:09:57 --> URI Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Router Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Output Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Security Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Input Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:09:57 --> Language Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Loader Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Controller Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:09:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:09:57 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Model Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:09:57 --> Session Class Initialized
DEBUG - 2014-02-05 06:09:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:09:57 --> Session routines successfully run
DEBUG - 2014-02-05 06:09:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:09:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:09:57 --> Final output sent to browser
DEBUG - 2014-02-05 06:09:57 --> Total execution time: 0.0140
DEBUG - 2014-02-05 06:12:06 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:06 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:06 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:06 --> Session Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:12:06 --> Session routines successfully run
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:12:06 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:06 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:06 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:06 --> Session Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:12:06 --> Session routines successfully run
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:12:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 06:12:06 --> Final output sent to browser
DEBUG - 2014-02-05 06:12:06 --> Total execution time: 0.0170
DEBUG - 2014-02-05 06:12:06 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:06 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:06 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:06 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:06 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Session Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:12:06 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Session routines successfully run
DEBUG - 2014-02-05 06:12:06 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:06 --> Session Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:12:06 --> Session routines successfully run
DEBUG - 2014-02-05 06:12:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:12:06 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:06 --> Final output sent to browser
DEBUG - 2014-02-05 06:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:06 --> Total execution time: 0.0150
DEBUG - 2014-02-05 06:12:06 --> Final output sent to browser
DEBUG - 2014-02-05 06:12:06 --> Total execution time: 0.0170
DEBUG - 2014-02-05 06:12:11 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:11 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:11 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:11 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:11 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:11 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:11 --> Session Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Session Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:12:11 --> Session routines successfully run
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:12:11 --> Session routines successfully run
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:12:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:11 --> Final output sent to browser
DEBUG - 2014-02-05 06:12:11 --> Total execution time: 0.0240
DEBUG - 2014-02-05 06:12:11 --> Final output sent to browser
DEBUG - 2014-02-05 06:12:11 --> Total execution time: 0.0360
DEBUG - 2014-02-05 06:12:30 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:30 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:30 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:33 --> Final output sent to browser
DEBUG - 2014-02-05 06:12:33 --> Total execution time: 2.4761
DEBUG - 2014-02-05 06:12:56 --> Config Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:12:56 --> URI Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Router Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Output Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Security Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Input Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:12:56 --> Language Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Loader Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Controller Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:12:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:12:56 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:12:56 --> Upload Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Image Lib Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Model Class Initialized
DEBUG - 2014-02-05 06:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:13:00 --> Final output sent to browser
DEBUG - 2014-02-05 06:13:00 --> Total execution time: 3.9442
DEBUG - 2014-02-05 06:13:16 --> Config Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:13:16 --> URI Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Router Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Output Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Security Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Input Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:13:16 --> Language Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Loader Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Controller Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:13:16 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:13:16 --> Upload Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Image Lib Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:13:18 --> Final output sent to browser
DEBUG - 2014-02-05 06:13:18 --> Total execution time: 2.3531
DEBUG - 2014-02-05 06:13:30 --> Config Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:13:30 --> URI Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Router Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Output Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Security Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Input Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:13:30 --> Language Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Loader Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Controller Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:13:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:13:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:13:30 --> Upload Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Image Lib Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:13:32 --> Final output sent to browser
DEBUG - 2014-02-05 06:13:32 --> Total execution time: 2.1281
DEBUG - 2014-02-05 06:21:43 --> Config Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:21:43 --> URI Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Router Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Output Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Security Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Input Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:21:43 --> Language Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Loader Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Controller Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:21:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:21:43 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:21:43 --> Final output sent to browser
DEBUG - 2014-02-05 06:21:43 --> Total execution time: 0.0180
DEBUG - 2014-02-05 06:21:50 --> Config Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:21:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:21:50 --> URI Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Router Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Output Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Security Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Input Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:21:50 --> Language Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Loader Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Controller Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:21:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:21:50 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:21:50 --> Final output sent to browser
DEBUG - 2014-02-05 06:21:50 --> Total execution time: 0.0150
DEBUG - 2014-02-05 06:21:59 --> Config Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:21:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:21:59 --> URI Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Router Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Output Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Security Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Input Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:21:59 --> Language Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Loader Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Controller Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:21:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:21:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Model Class Initialized
DEBUG - 2014-02-05 06:21:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:21:59 --> Final output sent to browser
DEBUG - 2014-02-05 06:21:59 --> Total execution time: 0.0170
DEBUG - 2014-02-05 06:22:15 --> Config Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:22:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:22:15 --> URI Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Router Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Output Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Security Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Input Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:22:15 --> Language Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Loader Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Controller Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:22:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:22:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:22:15 --> Final output sent to browser
DEBUG - 2014-02-05 06:22:15 --> Total execution time: 0.0130
DEBUG - 2014-02-05 06:22:27 --> Config Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:22:27 --> URI Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Router Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Output Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Security Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Input Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:22:27 --> Language Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Loader Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Controller Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:22:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:22:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:22:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:22:32 --> Final output sent to browser
DEBUG - 2014-02-05 06:22:32 --> Total execution time: 5.2473
DEBUG - 2014-02-05 06:22:45 --> Config Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:22:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:22:45 --> URI Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Router Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Output Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Security Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Input Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:22:45 --> Language Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Loader Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Controller Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:22:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:22:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:22:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:22:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:22:47 --> Final output sent to browser
DEBUG - 2014-02-05 06:22:47 --> Total execution time: 2.0411
DEBUG - 2014-02-05 06:23:05 --> Config Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:23:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:23:05 --> URI Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Router Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Output Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Security Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Input Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:23:05 --> Language Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Loader Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Controller Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:23:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:23:05 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:23:05 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:23:08 --> Final output sent to browser
DEBUG - 2014-02-05 06:23:08 --> Total execution time: 3.0312
DEBUG - 2014-02-05 06:23:17 --> Config Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:23:17 --> URI Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Router Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Output Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Security Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Input Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:23:17 --> Language Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Loader Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Controller Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:23:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:23:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:23:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:23:19 --> Final output sent to browser
DEBUG - 2014-02-05 06:23:19 --> Total execution time: 2.0471
DEBUG - 2014-02-05 06:23:30 --> Config Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:23:30 --> URI Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Router Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Output Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Security Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Input Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:23:30 --> Language Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Loader Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Controller Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:23:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:23:30 --> Model Class Initialized
DEBUG - 2014-02-05 06:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:23:32 --> Final output sent to browser
DEBUG - 2014-02-05 06:23:32 --> Total execution time: 2.0181
DEBUG - 2014-02-05 06:27:55 --> Config Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:27:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:27:55 --> URI Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Router Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Output Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Security Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Input Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:27:55 --> Language Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Loader Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Controller Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:27:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:27:55 --> Model Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Model Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Model Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:27:55 --> Session Class Initialized
DEBUG - 2014-02-05 06:27:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:27:55 --> Session routines successfully run
DEBUG - 2014-02-05 06:27:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:27:55 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:27:55 --> Final output sent to browser
DEBUG - 2014-02-05 06:27:55 --> Total execution time: 0.0150
DEBUG - 2014-02-05 06:29:52 --> Config Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:29:52 --> URI Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Router Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Output Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Security Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Input Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:29:52 --> Language Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Loader Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Controller Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:29:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:29:52 --> Model Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Model Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Model Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:29:52 --> Session Class Initialized
DEBUG - 2014-02-05 06:29:52 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:29:52 --> Session routines successfully run
DEBUG - 2014-02-05 06:29:52 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:29:52 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:29:52 --> Final output sent to browser
DEBUG - 2014-02-05 06:29:52 --> Total execution time: 0.0180
DEBUG - 2014-02-05 06:30:24 --> Config Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:30:24 --> URI Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Router Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Output Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Security Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Input Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:30:24 --> Language Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Loader Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Controller Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:30:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:30:24 --> Session Class Initialized
DEBUG - 2014-02-05 06:30:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:30:24 --> Session routines successfully run
DEBUG - 2014-02-05 06:30:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:30:24 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:30:24 --> Final output sent to browser
DEBUG - 2014-02-05 06:30:24 --> Total execution time: 0.0130
DEBUG - 2014-02-05 06:32:27 --> Config Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:32:27 --> URI Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Router Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Output Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Security Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Input Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:32:27 --> Language Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Loader Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Controller Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:32:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:32:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Model Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:32:27 --> Session Class Initialized
DEBUG - 2014-02-05 06:32:27 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:32:27 --> Session routines successfully run
DEBUG - 2014-02-05 06:32:27 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:32:27 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:32:27 --> Final output sent to browser
DEBUG - 2014-02-05 06:32:27 --> Total execution time: 0.0140
DEBUG - 2014-02-05 06:46:26 --> Config Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:46:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:46:26 --> URI Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Router Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Output Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Security Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Input Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:46:26 --> Language Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Loader Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Controller Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:46:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:46:26 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:46:26 --> Session Class Initialized
DEBUG - 2014-02-05 06:46:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:46:26 --> Session routines successfully run
DEBUG - 2014-02-05 06:46:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:46:26 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:46:26 --> Final output sent to browser
DEBUG - 2014-02-05 06:46:26 --> Total execution time: 0.0190
DEBUG - 2014-02-05 06:46:46 --> Config Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:46:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:46:46 --> URI Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Router Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Output Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Security Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Input Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:46:46 --> Language Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Loader Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Controller Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:46:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:46:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:46:46 --> Session Class Initialized
DEBUG - 2014-02-05 06:46:46 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:46:46 --> Session routines successfully run
DEBUG - 2014-02-05 06:46:46 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:46:46 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:46:46 --> Final output sent to browser
DEBUG - 2014-02-05 06:46:46 --> Total execution time: 0.0230
DEBUG - 2014-02-05 06:46:51 --> Config Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:46:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:46:51 --> URI Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Router Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Output Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Security Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Input Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:46:51 --> Language Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Loader Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Controller Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:46:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:46:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Model Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:46:51 --> Session Class Initialized
DEBUG - 2014-02-05 06:46:51 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:46:51 --> Session routines successfully run
DEBUG - 2014-02-05 06:46:51 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:46:51 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:46:51 --> Final output sent to browser
DEBUG - 2014-02-05 06:46:51 --> Total execution time: 0.0220
DEBUG - 2014-02-05 06:47:13 --> Config Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:47:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:47:13 --> URI Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Router Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Output Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Security Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Input Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:47:13 --> Language Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Loader Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Controller Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:47:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:47:13 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:47:13 --> Session Class Initialized
DEBUG - 2014-02-05 06:47:13 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:47:13 --> Session routines successfully run
DEBUG - 2014-02-05 06:47:13 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:47:13 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:47:13 --> Final output sent to browser
DEBUG - 2014-02-05 06:47:13 --> Total execution time: 0.0260
DEBUG - 2014-02-05 06:47:33 --> Config Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:47:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:47:33 --> URI Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Router Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Output Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Security Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Input Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:47:33 --> Language Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Loader Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Controller Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:47:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:47:33 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:47:33 --> Session Class Initialized
DEBUG - 2014-02-05 06:47:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:47:33 --> Session routines successfully run
DEBUG - 2014-02-05 06:47:33 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:47:33 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:47:33 --> Final output sent to browser
DEBUG - 2014-02-05 06:47:33 --> Total execution time: 0.0190
DEBUG - 2014-02-05 06:47:45 --> Config Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:47:45 --> URI Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Router Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Output Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Security Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Input Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:47:45 --> Language Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Loader Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Controller Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:47:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:47:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:47:45 --> Session Class Initialized
DEBUG - 2014-02-05 06:47:45 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:47:45 --> Session routines successfully run
DEBUG - 2014-02-05 06:47:45 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:47:45 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:47:45 --> Final output sent to browser
DEBUG - 2014-02-05 06:47:45 --> Total execution time: 0.0140
DEBUG - 2014-02-05 06:47:52 --> Config Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:47:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:47:52 --> URI Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Router Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Output Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Security Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Input Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:47:52 --> Language Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Loader Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Controller Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:47:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:47:52 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Model Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:47:52 --> Session Class Initialized
DEBUG - 2014-02-05 06:47:52 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:47:52 --> Session routines successfully run
DEBUG - 2014-02-05 06:47:52 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:47:52 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:47:52 --> Final output sent to browser
DEBUG - 2014-02-05 06:47:52 --> Total execution time: 0.0140
DEBUG - 2014-02-05 06:48:57 --> Config Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:48:57 --> URI Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Router Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Output Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Security Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Input Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:48:57 --> Language Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Loader Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Controller Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:48:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:48:57 --> Model Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Model Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Model Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:48:57 --> Session Class Initialized
DEBUG - 2014-02-05 06:48:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:48:57 --> Session routines successfully run
DEBUG - 2014-02-05 06:48:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:48:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:48:57 --> Final output sent to browser
DEBUG - 2014-02-05 06:48:57 --> Total execution time: 0.0130
DEBUG - 2014-02-05 06:49:17 --> Config Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:49:17 --> URI Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Router Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Output Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Security Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Input Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:49:17 --> Language Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Loader Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Controller Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:49:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:49:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Model Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:49:17 --> Session Class Initialized
DEBUG - 2014-02-05 06:49:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:49:17 --> Session routines successfully run
DEBUG - 2014-02-05 06:49:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:49:17 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:49:17 --> Final output sent to browser
DEBUG - 2014-02-05 06:49:17 --> Total execution time: 0.0140
DEBUG - 2014-02-05 06:49:41 --> Config Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:49:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:49:41 --> URI Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Router Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Output Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Security Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Input Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:49:41 --> Language Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Loader Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Controller Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:49:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:49:41 --> Model Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Model Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Model Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:49:41 --> Session Class Initialized
DEBUG - 2014-02-05 06:49:41 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:49:41 --> Session routines successfully run
DEBUG - 2014-02-05 06:49:41 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:49:41 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:49:41 --> Final output sent to browser
DEBUG - 2014-02-05 06:49:41 --> Total execution time: 0.0130
DEBUG - 2014-02-05 06:50:01 --> Config Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:50:01 --> URI Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Router Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Output Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Security Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Input Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:50:01 --> Language Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Loader Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Controller Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:50:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:50:01 --> Model Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Model Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Model Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:50:01 --> Session Class Initialized
DEBUG - 2014-02-05 06:50:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:50:01 --> Session routines successfully run
DEBUG - 2014-02-05 06:50:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:50:01 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:50:01 --> Final output sent to browser
DEBUG - 2014-02-05 06:50:01 --> Total execution time: 0.0180
DEBUG - 2014-02-05 06:50:34 --> Config Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:50:34 --> URI Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Router Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Output Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Security Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Input Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:50:34 --> Language Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Loader Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Controller Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:50:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:50:34 --> Model Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Model Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Model Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:50:34 --> Session Class Initialized
DEBUG - 2014-02-05 06:50:34 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:50:34 --> Session routines successfully run
DEBUG - 2014-02-05 06:50:34 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:50:34 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:50:34 --> Final output sent to browser
DEBUG - 2014-02-05 06:50:34 --> Total execution time: 0.0230
DEBUG - 2014-02-05 06:51:14 --> Config Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:51:14 --> URI Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Router Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Output Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Security Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Input Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:51:14 --> Language Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Loader Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Controller Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:51:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:51:14 --> Session Class Initialized
DEBUG - 2014-02-05 06:51:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:51:14 --> Session routines successfully run
DEBUG - 2014-02-05 06:51:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:51:14 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:51:14 --> Final output sent to browser
DEBUG - 2014-02-05 06:51:14 --> Total execution time: 0.0210
DEBUG - 2014-02-05 06:56:09 --> Config Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:56:09 --> URI Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Router Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Output Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Security Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Input Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:56:09 --> Language Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Loader Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Controller Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:56:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:56:09 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:56:09 --> Session Class Initialized
DEBUG - 2014-02-05 06:56:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:56:09 --> Session routines successfully run
DEBUG - 2014-02-05 06:56:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:56:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:56:09 --> Final output sent to browser
DEBUG - 2014-02-05 06:56:09 --> Total execution time: 0.0130
DEBUG - 2014-02-05 06:56:28 --> Config Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:56:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:56:28 --> URI Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Router Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Output Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Security Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Input Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:56:28 --> Language Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Loader Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Controller Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:56:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:56:28 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:56:28 --> Session Class Initialized
DEBUG - 2014-02-05 06:56:28 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:56:28 --> Session routines successfully run
DEBUG - 2014-02-05 06:56:28 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:56:28 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:56:28 --> Final output sent to browser
DEBUG - 2014-02-05 06:56:28 --> Total execution time: 0.0210
DEBUG - 2014-02-05 06:56:40 --> Config Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:56:40 --> URI Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Router Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Output Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Security Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Input Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:56:40 --> Language Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Loader Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Controller Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:56:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:56:40 --> Session Class Initialized
DEBUG - 2014-02-05 06:56:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:56:40 --> Session routines successfully run
DEBUG - 2014-02-05 06:56:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:56:40 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 06:56:40 --> Final output sent to browser
DEBUG - 2014-02-05 06:56:40 --> Total execution time: 0.0240
DEBUG - 2014-02-05 06:57:14 --> Config Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:57:14 --> URI Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Router Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Output Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Security Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Input Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:57:14 --> Language Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Loader Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Controller Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:57:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:57:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:14 --> Session Class Initialized
DEBUG - 2014-02-05 06:57:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:57:14 --> Session routines successfully run
DEBUG - 2014-02-05 06:57:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:57:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 06:57:14 --> Final output sent to browser
DEBUG - 2014-02-05 06:57:14 --> Total execution time: 0.0170
DEBUG - 2014-02-05 06:57:15 --> Config Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:57:15 --> URI Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Router Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Output Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Security Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Input Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:57:15 --> Language Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Loader Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Controller Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:15 --> Session Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:57:15 --> Session routines successfully run
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:15 --> Final output sent to browser
DEBUG - 2014-02-05 06:57:15 --> Total execution time: 0.0250
DEBUG - 2014-02-05 06:57:15 --> Config Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:57:15 --> URI Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Router Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Output Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Security Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Input Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:57:15 --> Language Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Loader Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Controller Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:15 --> Session Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:57:15 --> Session routines successfully run
DEBUG - 2014-02-05 06:57:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:57:15 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:15 --> Final output sent to browser
DEBUG - 2014-02-05 06:57:15 --> Total execution time: 0.0130
DEBUG - 2014-02-05 06:57:20 --> Config Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:57:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:57:20 --> URI Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Router Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Output Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Security Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Input Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:57:20 --> Language Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Loader Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Controller Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:20 --> Session Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:57:20 --> Session routines successfully run
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:20 --> Final output sent to browser
DEBUG - 2014-02-05 06:57:20 --> Total execution time: 0.0220
DEBUG - 2014-02-05 06:57:20 --> Config Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 06:57:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 06:57:20 --> URI Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Router Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Output Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Security Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Input Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 06:57:20 --> Language Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Loader Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Controller Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:20 --> Session Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 06:57:20 --> Session routines successfully run
DEBUG - 2014-02-05 06:57:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 06:57:20 --> Model Class Initialized
DEBUG - 2014-02-05 06:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 06:57:20 --> Final output sent to browser
DEBUG - 2014-02-05 06:57:20 --> Total execution time: 0.0310
DEBUG - 2014-02-05 07:00:31 --> Config Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:00:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:00:31 --> URI Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Router Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Output Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Security Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Input Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:00:31 --> Language Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Loader Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Controller Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:00:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:00:31 --> Model Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Model Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Model Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:00:31 --> Session Class Initialized
DEBUG - 2014-02-05 07:00:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:00:31 --> Session routines successfully run
DEBUG - 2014-02-05 07:00:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:00:31 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:00:31 --> Final output sent to browser
DEBUG - 2014-02-05 07:00:31 --> Total execution time: 0.0230
DEBUG - 2014-02-05 07:03:36 --> Config Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:03:36 --> URI Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Router Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Output Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Security Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Input Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:03:36 --> Language Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Loader Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Controller Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:03:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:03:36 --> Session Class Initialized
DEBUG - 2014-02-05 07:03:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:03:36 --> Session routines successfully run
DEBUG - 2014-02-05 07:03:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:03:36 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:03:36 --> Final output sent to browser
DEBUG - 2014-02-05 07:03:36 --> Total execution time: 0.0280
DEBUG - 2014-02-05 07:03:41 --> Config Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:03:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:03:41 --> URI Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Router Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Output Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Security Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Input Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:03:41 --> Language Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Loader Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Controller Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:03:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:03:41 --> Model Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Model Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Model Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:03:41 --> Session Class Initialized
DEBUG - 2014-02-05 07:03:41 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:03:41 --> Session routines successfully run
DEBUG - 2014-02-05 07:03:41 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:03:41 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:03:41 --> Final output sent to browser
DEBUG - 2014-02-05 07:03:41 --> Total execution time: 0.0250
DEBUG - 2014-02-05 07:04:09 --> Config Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:04:09 --> URI Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Router Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Output Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Security Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Input Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:04:09 --> Language Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Loader Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Controller Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:04:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:04:09 --> Session Class Initialized
DEBUG - 2014-02-05 07:04:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:04:09 --> Session routines successfully run
DEBUG - 2014-02-05 07:04:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:04:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:04:09 --> Final output sent to browser
DEBUG - 2014-02-05 07:04:09 --> Total execution time: 0.0200
DEBUG - 2014-02-05 07:04:18 --> Config Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:04:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:04:18 --> URI Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Router Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Output Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Security Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Input Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:04:18 --> Language Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Loader Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Controller Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:04:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:04:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:04:18 --> Session Class Initialized
DEBUG - 2014-02-05 07:04:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:04:18 --> Session routines successfully run
DEBUG - 2014-02-05 07:04:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:04:18 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:04:18 --> Final output sent to browser
DEBUG - 2014-02-05 07:04:18 --> Total execution time: 0.0230
DEBUG - 2014-02-05 07:05:02 --> Config Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:05:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:05:02 --> URI Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Router Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Output Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Security Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Input Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:05:02 --> Language Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Loader Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Controller Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:05:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:05:02 --> Model Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Model Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Model Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:05:02 --> Session Class Initialized
DEBUG - 2014-02-05 07:05:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:05:02 --> Session routines successfully run
DEBUG - 2014-02-05 07:05:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:05:02 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:05:02 --> Final output sent to browser
DEBUG - 2014-02-05 07:05:02 --> Total execution time: 0.0230
DEBUG - 2014-02-05 07:05:18 --> Config Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:05:18 --> URI Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Router Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Output Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Security Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Input Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:05:18 --> Language Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Loader Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Controller Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:05:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:05:18 --> Session Class Initialized
DEBUG - 2014-02-05 07:05:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:05:18 --> Session routines successfully run
DEBUG - 2014-02-05 07:05:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:05:18 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:05:18 --> Final output sent to browser
DEBUG - 2014-02-05 07:05:18 --> Total execution time: 0.0230
DEBUG - 2014-02-05 07:08:22 --> Config Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:08:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:08:22 --> URI Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Router Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Output Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Security Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Input Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:08:22 --> Language Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Loader Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Controller Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:08:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:08:22 --> Model Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Model Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Model Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:08:22 --> Session Class Initialized
DEBUG - 2014-02-05 07:08:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:08:22 --> Session routines successfully run
DEBUG - 2014-02-05 07:08:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:08:22 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:08:22 --> Final output sent to browser
DEBUG - 2014-02-05 07:08:22 --> Total execution time: 0.0220
DEBUG - 2014-02-05 07:08:57 --> Config Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:08:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:08:57 --> URI Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Router Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Output Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Security Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Input Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:08:57 --> Language Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Loader Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Controller Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:08:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:08:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:08:57 --> Session Class Initialized
DEBUG - 2014-02-05 07:08:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:08:57 --> Session routines successfully run
DEBUG - 2014-02-05 07:08:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:08:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:08:57 --> Final output sent to browser
DEBUG - 2014-02-05 07:08:57 --> Total execution time: 0.0130
DEBUG - 2014-02-05 07:09:24 --> Config Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:09:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:09:24 --> URI Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Router Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Output Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Security Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Input Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:09:24 --> Language Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Loader Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Controller Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:09:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:09:24 --> Model Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Model Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Model Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:09:24 --> Session Class Initialized
DEBUG - 2014-02-05 07:09:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:09:24 --> Session routines successfully run
DEBUG - 2014-02-05 07:09:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:09:24 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:09:24 --> Final output sent to browser
DEBUG - 2014-02-05 07:09:24 --> Total execution time: 0.0240
DEBUG - 2014-02-05 07:09:31 --> Config Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:09:31 --> URI Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Router Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Output Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Security Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Input Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:09:31 --> Language Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Loader Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Controller Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:09:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:09:31 --> Model Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Model Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Model Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:09:31 --> Session Class Initialized
DEBUG - 2014-02-05 07:09:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:09:31 --> Session routines successfully run
DEBUG - 2014-02-05 07:09:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:09:31 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:09:31 --> Final output sent to browser
DEBUG - 2014-02-05 07:09:31 --> Total execution time: 0.0210
DEBUG - 2014-02-05 07:10:20 --> Config Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:10:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:10:20 --> URI Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Router Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Output Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Security Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Input Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:10:20 --> Language Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Loader Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Controller Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:10:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:10:20 --> Model Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Model Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Model Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:10:20 --> Session Class Initialized
DEBUG - 2014-02-05 07:10:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:10:20 --> Session routines successfully run
DEBUG - 2014-02-05 07:10:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:10:20 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:10:20 --> Final output sent to browser
DEBUG - 2014-02-05 07:10:20 --> Total execution time: 0.0240
DEBUG - 2014-02-05 07:12:21 --> Config Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:12:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:12:21 --> URI Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Router Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Output Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Security Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Input Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:12:21 --> Language Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Loader Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Controller Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:12:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:12:21 --> Model Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Model Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Model Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:12:21 --> Session Class Initialized
DEBUG - 2014-02-05 07:12:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:12:21 --> Session routines successfully run
DEBUG - 2014-02-05 07:12:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:12:21 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:12:21 --> Final output sent to browser
DEBUG - 2014-02-05 07:12:21 --> Total execution time: 0.0140
DEBUG - 2014-02-05 07:12:57 --> Config Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:12:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:12:57 --> URI Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Router Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Output Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Security Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Input Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:12:57 --> Language Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Loader Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Controller Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:12:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:12:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:12:57 --> Session Class Initialized
DEBUG - 2014-02-05 07:12:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:12:57 --> Session routines successfully run
DEBUG - 2014-02-05 07:12:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:12:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:12:57 --> Final output sent to browser
DEBUG - 2014-02-05 07:12:57 --> Total execution time: 0.0220
DEBUG - 2014-02-05 07:13:42 --> Config Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:13:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:13:42 --> URI Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Router Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Output Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Security Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Input Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:13:42 --> Language Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Loader Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Controller Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:13:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:13:42 --> Model Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Model Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Model Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:13:42 --> Session Class Initialized
DEBUG - 2014-02-05 07:13:42 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:13:42 --> Session routines successfully run
DEBUG - 2014-02-05 07:13:42 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:13:42 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:13:42 --> Final output sent to browser
DEBUG - 2014-02-05 07:13:42 --> Total execution time: 0.0140
DEBUG - 2014-02-05 07:13:57 --> Config Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:13:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:13:57 --> URI Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Router Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Output Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Security Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Input Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:13:57 --> Language Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Loader Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Controller Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:13:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:13:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Model Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:13:57 --> Session Class Initialized
DEBUG - 2014-02-05 07:13:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:13:57 --> Session routines successfully run
DEBUG - 2014-02-05 07:13:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:13:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:13:57 --> Final output sent to browser
DEBUG - 2014-02-05 07:13:57 --> Total execution time: 0.0190
DEBUG - 2014-02-05 07:14:32 --> Config Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:14:32 --> URI Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Router Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Output Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Security Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Input Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:14:32 --> Language Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Loader Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Controller Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:14:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:14:32 --> Model Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Model Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Model Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:14:32 --> Session Class Initialized
DEBUG - 2014-02-05 07:14:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:14:32 --> Session routines successfully run
DEBUG - 2014-02-05 07:14:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:14:32 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:14:32 --> Final output sent to browser
DEBUG - 2014-02-05 07:14:32 --> Total execution time: 0.0450
DEBUG - 2014-02-05 07:14:54 --> Config Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:14:54 --> URI Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Router Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Output Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Security Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Input Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:14:54 --> Language Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Loader Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Controller Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:14:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:14:54 --> Model Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Model Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Model Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:14:54 --> Session Class Initialized
DEBUG - 2014-02-05 07:14:54 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:14:54 --> Session routines successfully run
DEBUG - 2014-02-05 07:14:54 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:14:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:14:54 --> Final output sent to browser
DEBUG - 2014-02-05 07:14:54 --> Total execution time: 0.0200
DEBUG - 2014-02-05 07:16:16 --> Config Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:16:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:16:16 --> URI Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Router Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Output Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Security Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Input Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:16:16 --> Language Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Loader Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Controller Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:16:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:16:16 --> Model Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Model Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Model Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:16:16 --> Session Class Initialized
DEBUG - 2014-02-05 07:16:16 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:16:16 --> Session routines successfully run
DEBUG - 2014-02-05 07:16:16 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:16:16 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:16:16 --> Final output sent to browser
DEBUG - 2014-02-05 07:16:16 --> Total execution time: 0.0250
DEBUG - 2014-02-05 07:16:30 --> Config Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:16:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:16:30 --> URI Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Router Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Output Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Security Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Input Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:16:30 --> Language Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Loader Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Controller Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:16:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:16:30 --> Model Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Model Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Model Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:16:30 --> Session Class Initialized
DEBUG - 2014-02-05 07:16:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:16:30 --> Session routines successfully run
DEBUG - 2014-02-05 07:16:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:16:30 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:16:30 --> Final output sent to browser
DEBUG - 2014-02-05 07:16:30 --> Total execution time: 0.0230
DEBUG - 2014-02-05 07:17:35 --> Config Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:17:35 --> URI Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Router Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Output Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Security Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Input Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:17:35 --> Language Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Loader Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Controller Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:17:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:17:35 --> Model Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Model Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Model Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:17:35 --> Session Class Initialized
DEBUG - 2014-02-05 07:17:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:17:35 --> Session routines successfully run
DEBUG - 2014-02-05 07:17:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:17:35 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:17:35 --> Final output sent to browser
DEBUG - 2014-02-05 07:17:35 --> Total execution time: 0.0130
DEBUG - 2014-02-05 07:19:36 --> Config Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:19:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:19:36 --> URI Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Router Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Output Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Security Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Input Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:19:36 --> Language Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Loader Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Controller Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:19:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:19:36 --> Model Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Model Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Model Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:19:36 --> Session Class Initialized
DEBUG - 2014-02-05 07:19:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:19:36 --> Session routines successfully run
DEBUG - 2014-02-05 07:19:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:19:36 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:19:36 --> Final output sent to browser
DEBUG - 2014-02-05 07:19:36 --> Total execution time: 0.0170
DEBUG - 2014-02-05 07:23:12 --> Config Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:23:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:23:12 --> URI Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Router Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Output Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Security Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Input Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:23:12 --> Language Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Loader Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Controller Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:23:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:23:12 --> Model Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Model Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Model Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:23:12 --> Session Class Initialized
DEBUG - 2014-02-05 07:23:12 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:23:12 --> Session routines successfully run
DEBUG - 2014-02-05 07:23:12 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:23:12 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:23:12 --> Final output sent to browser
DEBUG - 2014-02-05 07:23:12 --> Total execution time: 0.0240
DEBUG - 2014-02-05 07:24:03 --> Config Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:24:03 --> URI Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Router Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Output Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Security Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Input Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:24:03 --> Language Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Loader Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Controller Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:24:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:24:03 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:24:03 --> Session Class Initialized
DEBUG - 2014-02-05 07:24:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:24:03 --> Session routines successfully run
DEBUG - 2014-02-05 07:24:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:24:03 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:24:03 --> Final output sent to browser
DEBUG - 2014-02-05 07:24:03 --> Total execution time: 0.0130
DEBUG - 2014-02-05 07:24:18 --> Config Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:24:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:24:18 --> URI Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Router Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Output Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Security Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Input Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:24:18 --> Language Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Loader Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Controller Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:24:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:24:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:24:18 --> Session Class Initialized
DEBUG - 2014-02-05 07:24:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:24:18 --> Session routines successfully run
DEBUG - 2014-02-05 07:24:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:24:18 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:24:18 --> Final output sent to browser
DEBUG - 2014-02-05 07:24:18 --> Total execution time: 0.0240
DEBUG - 2014-02-05 07:24:54 --> Config Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:24:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:24:54 --> URI Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Router Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Output Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Security Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Input Class Initialized
DEBUG - 2014-02-05 07:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:24:55 --> Language Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Loader Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Controller Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:24:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:24:55 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Model Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:24:55 --> Session Class Initialized
DEBUG - 2014-02-05 07:24:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:24:55 --> Session routines successfully run
DEBUG - 2014-02-05 07:24:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:24:55 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:24:55 --> Final output sent to browser
DEBUG - 2014-02-05 07:24:55 --> Total execution time: 0.0250
DEBUG - 2014-02-05 07:26:05 --> Config Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:26:05 --> URI Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Router Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Output Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Security Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Input Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:26:05 --> Language Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Loader Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Controller Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:26:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:26:05 --> Model Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Model Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Model Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:26:05 --> Session Class Initialized
DEBUG - 2014-02-05 07:26:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:26:05 --> Session routines successfully run
DEBUG - 2014-02-05 07:26:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:26:05 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:26:05 --> Final output sent to browser
DEBUG - 2014-02-05 07:26:05 --> Total execution time: 0.0240
DEBUG - 2014-02-05 07:26:51 --> Config Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:26:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:26:51 --> URI Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Router Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Output Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Security Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Input Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:26:51 --> Language Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Loader Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Controller Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:26:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:26:51 --> Model Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Model Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Model Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:26:51 --> Session Class Initialized
DEBUG - 2014-02-05 07:26:51 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:26:51 --> Session routines successfully run
DEBUG - 2014-02-05 07:26:51 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:26:51 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:26:51 --> Final output sent to browser
DEBUG - 2014-02-05 07:26:51 --> Total execution time: 0.0140
DEBUG - 2014-02-05 07:27:55 --> Config Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:27:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:27:55 --> URI Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Router Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Output Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Security Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Input Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:27:55 --> Language Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Loader Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Controller Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:27:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:27:55 --> Model Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Model Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Model Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:27:55 --> Session Class Initialized
DEBUG - 2014-02-05 07:27:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:27:55 --> Session routines successfully run
DEBUG - 2014-02-05 07:27:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:27:55 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:27:55 --> Final output sent to browser
DEBUG - 2014-02-05 07:27:55 --> Total execution time: 0.0250
DEBUG - 2014-02-05 07:28:16 --> Config Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:28:16 --> URI Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Router Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Output Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Security Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Input Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:28:16 --> Language Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Loader Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Controller Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:28:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:28:16 --> Model Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Model Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Model Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:28:16 --> Session Class Initialized
DEBUG - 2014-02-05 07:28:16 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:28:16 --> Session routines successfully run
DEBUG - 2014-02-05 07:28:16 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:28:16 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:28:16 --> Final output sent to browser
DEBUG - 2014-02-05 07:28:16 --> Total execution time: 0.0130
DEBUG - 2014-02-05 07:28:59 --> Config Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:28:59 --> URI Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Router Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Output Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Security Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Input Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:28:59 --> Language Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Loader Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Controller Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:28:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:28:59 --> Model Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Model Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Model Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:28:59 --> Session Class Initialized
DEBUG - 2014-02-05 07:28:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:28:59 --> Session routines successfully run
DEBUG - 2014-02-05 07:28:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:28:59 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:28:59 --> Final output sent to browser
DEBUG - 2014-02-05 07:28:59 --> Total execution time: 0.0220
DEBUG - 2014-02-05 07:29:08 --> Config Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Hooks Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Utf8 Class Initialized
DEBUG - 2014-02-05 07:29:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 07:29:08 --> URI Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Router Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Output Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Security Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Input Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 07:29:08 --> Language Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Loader Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Controller Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 07:29:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 07:29:08 --> Model Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Model Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Database Driver Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Model Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 07:29:08 --> Session Class Initialized
DEBUG - 2014-02-05 07:29:08 --> Helper loaded: string_helper
DEBUG - 2014-02-05 07:29:08 --> Session routines successfully run
DEBUG - 2014-02-05 07:29:08 --> Helper loaded: url_helper
DEBUG - 2014-02-05 07:29:08 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 07:29:08 --> Final output sent to browser
DEBUG - 2014-02-05 07:29:08 --> Total execution time: 0.0210
DEBUG - 2014-02-05 17:15:57 --> Config Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:15:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:15:57 --> URI Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Router Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Output Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Security Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Input Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:15:57 --> Language Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Loader Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Controller Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:15:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:15:57 --> Model Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Model Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Database Driver Class Initialized
ERROR - 2014-02-05 17:15:57 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 17:15:57 --> Model Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:15:57 --> Session Class Initialized
DEBUG - 2014-02-05 17:15:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:15:57 --> A session cookie was not found.
DEBUG - 2014-02-05 17:15:57 --> Session routines successfully run
DEBUG - 2014-02-05 17:15:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:15:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:15:57 --> Final output sent to browser
DEBUG - 2014-02-05 17:15:57 --> Total execution time: 0.0270
DEBUG - 2014-02-05 17:16:06 --> Config Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:16:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:16:06 --> URI Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Router Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Output Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Security Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Input Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:16:06 --> Language Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Loader Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Controller Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:16:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:16:06 --> Model Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Model Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Database Driver Class Initialized
ERROR - 2014-02-05 17:16:06 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 17:16:06 --> Model Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:16:06 --> Session Class Initialized
DEBUG - 2014-02-05 17:16:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:16:06 --> Session routines successfully run
DEBUG - 2014-02-05 17:16:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:16:06 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:16:06 --> Final output sent to browser
DEBUG - 2014-02-05 17:16:06 --> Total execution time: 0.0260
DEBUG - 2014-02-05 17:34:01 --> Config Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:34:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:34:01 --> URI Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Router Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Output Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Security Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Input Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:34:01 --> Language Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Loader Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Controller Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:34:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:34:01 --> Model Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Model Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Model Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:34:01 --> Session Class Initialized
DEBUG - 2014-02-05 17:34:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:34:01 --> Session routines successfully run
DEBUG - 2014-02-05 17:34:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:34:01 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:34:01 --> Final output sent to browser
DEBUG - 2014-02-05 17:34:01 --> Total execution time: 0.0220
DEBUG - 2014-02-05 17:34:40 --> Config Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:34:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:34:40 --> URI Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Router Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Output Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Security Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Input Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:34:40 --> Language Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Loader Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Controller Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:34:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:34:40 --> Model Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Model Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Database Driver Class Initialized
ERROR - 2014-02-05 17:34:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 17:34:40 --> Model Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:34:40 --> Session Class Initialized
DEBUG - 2014-02-05 17:34:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:34:40 --> Session routines successfully run
DEBUG - 2014-02-05 17:34:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:34:40 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:34:40 --> Final output sent to browser
DEBUG - 2014-02-05 17:34:40 --> Total execution time: 0.0270
DEBUG - 2014-02-05 17:35:03 --> Config Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:35:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:35:03 --> URI Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Router Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Output Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Security Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Input Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:35:03 --> Language Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Loader Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Controller Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:35:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:35:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:35:03 --> Session Class Initialized
DEBUG - 2014-02-05 17:35:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:35:03 --> Session routines successfully run
DEBUG - 2014-02-05 17:35:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:35:03 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:35:03 --> Final output sent to browser
DEBUG - 2014-02-05 17:35:03 --> Total execution time: 0.0190
DEBUG - 2014-02-05 17:35:39 --> Config Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:35:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:35:39 --> URI Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Router Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Output Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Security Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Input Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:35:39 --> Language Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Loader Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Controller Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:35:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:35:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:35:39 --> Session Class Initialized
DEBUG - 2014-02-05 17:35:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:35:39 --> Session routines successfully run
DEBUG - 2014-02-05 17:35:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:35:39 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:35:39 --> Final output sent to browser
DEBUG - 2014-02-05 17:35:39 --> Total execution time: 0.0230
DEBUG - 2014-02-05 17:36:10 --> Config Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:36:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:36:10 --> URI Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Router Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Output Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Security Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Input Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:36:10 --> Language Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Loader Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Controller Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:36:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:36:10 --> Model Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Model Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Model Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:36:10 --> Session Class Initialized
DEBUG - 2014-02-05 17:36:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:36:10 --> Session routines successfully run
DEBUG - 2014-02-05 17:36:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:36:10 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:36:10 --> Final output sent to browser
DEBUG - 2014-02-05 17:36:10 --> Total execution time: 0.0230
DEBUG - 2014-02-05 17:38:23 --> Config Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:38:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:38:23 --> URI Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Router Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Output Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Security Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Input Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:38:23 --> Language Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Loader Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Controller Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:38:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:38:23 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:38:23 --> Session Class Initialized
DEBUG - 2014-02-05 17:38:23 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:38:23 --> Session routines successfully run
DEBUG - 2014-02-05 17:38:23 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:38:23 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:38:23 --> Final output sent to browser
DEBUG - 2014-02-05 17:38:23 --> Total execution time: 0.0160
DEBUG - 2014-02-05 17:38:46 --> Config Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:38:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:38:46 --> URI Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Router Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Output Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Security Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Input Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:38:46 --> Language Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Loader Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Controller Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:38:46 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:38:46 --> Session Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:38:46 --> Session routines successfully run
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:38:46 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:38:46 --> Final output sent to browser
DEBUG - 2014-02-05 17:38:46 --> Total execution time: 0.0200
DEBUG - 2014-02-05 17:38:46 --> Config Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:38:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:38:46 --> URI Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Router Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Output Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Security Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Input Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:38:46 --> Language Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Loader Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Controller Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:38:46 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:38:46 --> Session Class Initialized
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:38:46 --> Session routines successfully run
DEBUG - 2014-02-05 17:38:46 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:38:46 --> Final output sent to browser
DEBUG - 2014-02-05 17:38:47 --> Total execution time: 0.0090
DEBUG - 2014-02-05 17:38:50 --> Config Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:38:50 --> URI Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Router Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Output Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Security Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Input Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:38:50 --> Language Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Loader Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Controller Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:38:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:38:50 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:38:50 --> Session Class Initialized
DEBUG - 2014-02-05 17:38:50 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:38:50 --> Session routines successfully run
DEBUG - 2014-02-05 17:38:50 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:38:50 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:38:50 --> Final output sent to browser
DEBUG - 2014-02-05 17:38:50 --> Total execution time: 0.0230
DEBUG - 2014-02-05 17:38:55 --> Config Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:38:55 --> URI Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Router Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Output Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Security Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Input Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:38:55 --> Language Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Loader Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Controller Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:38:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:38:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:38:55 --> Session Class Initialized
DEBUG - 2014-02-05 17:38:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:38:55 --> Session routines successfully run
DEBUG - 2014-02-05 17:38:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:38:55 --> Final output sent to browser
DEBUG - 2014-02-05 17:38:55 --> Total execution time: 0.0170
DEBUG - 2014-02-05 17:39:03 --> Config Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:39:03 --> URI Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Router Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Output Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Security Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Input Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:39:03 --> Language Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Loader Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Controller Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:39:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:39:03 --> Session Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:39:03 --> Session routines successfully run
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:39:03 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:39:03 --> Final output sent to browser
DEBUG - 2014-02-05 17:39:03 --> Total execution time: 0.0200
DEBUG - 2014-02-05 17:39:03 --> Config Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:39:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:39:03 --> URI Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Router Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Output Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Security Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Input Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:39:03 --> Language Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Loader Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Controller Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:39:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:39:03 --> Session Class Initialized
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:39:03 --> Session routines successfully run
DEBUG - 2014-02-05 17:39:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:39:03 --> Final output sent to browser
DEBUG - 2014-02-05 17:39:03 --> Total execution time: 0.0090
DEBUG - 2014-02-05 17:42:31 --> Config Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:42:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:42:31 --> URI Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Router Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Output Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Security Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Input Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:42:31 --> Language Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Loader Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Controller Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:42:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:42:31 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:42:31 --> Session Class Initialized
DEBUG - 2014-02-05 17:42:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:42:31 --> Session routines successfully run
DEBUG - 2014-02-05 17:42:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:42:31 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:42:31 --> Final output sent to browser
DEBUG - 2014-02-05 17:42:31 --> Total execution time: 0.0150
DEBUG - 2014-02-05 17:42:32 --> Config Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:42:32 --> URI Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Router Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Output Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Security Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Input Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:42:32 --> Language Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Loader Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Controller Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:42:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:42:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:42:32 --> Session Class Initialized
DEBUG - 2014-02-05 17:42:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:42:32 --> Session routines successfully run
DEBUG - 2014-02-05 17:42:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:42:32 --> Final output sent to browser
DEBUG - 2014-02-05 17:42:32 --> Total execution time: 0.0100
DEBUG - 2014-02-05 17:42:39 --> Config Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:42:39 --> URI Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Router Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Output Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Security Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Input Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:42:39 --> Language Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Loader Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Controller Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:42:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:42:39 --> Session Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:42:39 --> Session routines successfully run
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:42:39 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:42:39 --> Final output sent to browser
DEBUG - 2014-02-05 17:42:39 --> Total execution time: 0.0160
DEBUG - 2014-02-05 17:42:39 --> Config Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:42:39 --> URI Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Router Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Output Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Security Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Input Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:42:39 --> Language Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Loader Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Controller Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:42:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Model Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:42:39 --> Session Class Initialized
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:42:39 --> Session routines successfully run
DEBUG - 2014-02-05 17:42:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:42:39 --> Final output sent to browser
DEBUG - 2014-02-05 17:42:39 --> Total execution time: 0.0090
DEBUG - 2014-02-05 17:44:12 --> Config Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:44:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:44:12 --> URI Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Router Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Output Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Security Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Input Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:44:12 --> Language Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Loader Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Controller Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:44:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:44:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:44:12 --> Session Class Initialized
DEBUG - 2014-02-05 17:44:12 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:44:12 --> Session routines successfully run
DEBUG - 2014-02-05 17:44:12 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:44:12 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:44:12 --> Final output sent to browser
DEBUG - 2014-02-05 17:44:12 --> Total execution time: 0.0180
DEBUG - 2014-02-05 17:44:18 --> Config Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:44:18 --> URI Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Router Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Output Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Security Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Input Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:44:18 --> Language Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Loader Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Controller Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:44:18 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:44:18 --> Session Class Initialized
DEBUG - 2014-02-05 17:44:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:44:18 --> Session routines successfully run
DEBUG - 2014-02-05 17:44:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:44:18 --> Final output sent to browser
DEBUG - 2014-02-05 17:44:18 --> Total execution time: 0.0200
DEBUG - 2014-02-05 17:44:35 --> Config Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:44:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:44:35 --> URI Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Router Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Output Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Security Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Input Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:44:35 --> Language Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Loader Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Controller Class Initialized
DEBUG - 2014-02-05 17:44:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:44:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:44:36 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:36 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:44:36 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:44:36 --> Session Class Initialized
DEBUG - 2014-02-05 17:44:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:44:36 --> Session routines successfully run
DEBUG - 2014-02-05 17:44:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:44:36 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:44:36 --> Final output sent to browser
DEBUG - 2014-02-05 17:44:36 --> Total execution time: 0.0720
DEBUG - 2014-02-05 17:44:41 --> Config Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:44:41 --> URI Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Router Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Output Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Security Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Input Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:44:41 --> Language Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Loader Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Controller Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:44:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:44:41 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:44:41 --> Session Class Initialized
DEBUG - 2014-02-05 17:44:41 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:44:41 --> Session routines successfully run
DEBUG - 2014-02-05 17:44:41 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:44:41 --> Final output sent to browser
DEBUG - 2014-02-05 17:44:41 --> Total execution time: 0.0190
DEBUG - 2014-02-05 17:44:53 --> Config Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:44:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:44:53 --> URI Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Router Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Output Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Security Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Input Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:44:53 --> Language Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Loader Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Controller Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:44:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:44:53 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Model Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:44:53 --> Session Class Initialized
DEBUG - 2014-02-05 17:44:53 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:44:53 --> Session routines successfully run
DEBUG - 2014-02-05 17:44:53 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:44:53 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:44:53 --> Final output sent to browser
DEBUG - 2014-02-05 17:44:53 --> Total execution time: 0.0220
DEBUG - 2014-02-05 17:45:03 --> Config Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:45:03 --> URI Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Router Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Output Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Security Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Input Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:45:03 --> Language Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Loader Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Controller Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:45:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:45:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:45:03 --> Session Class Initialized
DEBUG - 2014-02-05 17:45:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:45:03 --> Session routines successfully run
DEBUG - 2014-02-05 17:45:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:45:03 --> Final output sent to browser
DEBUG - 2014-02-05 17:45:03 --> Total execution time: 0.0110
DEBUG - 2014-02-05 17:45:05 --> Config Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:45:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:45:05 --> URI Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Router Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Output Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Security Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Input Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:45:05 --> Language Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Loader Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Controller Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:45:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:45:05 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:45:05 --> Session Class Initialized
DEBUG - 2014-02-05 17:45:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:45:05 --> Session routines successfully run
DEBUG - 2014-02-05 17:45:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:45:05 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:45:05 --> Final output sent to browser
DEBUG - 2014-02-05 17:45:05 --> Total execution time: 0.0200
DEBUG - 2014-02-05 17:45:17 --> Config Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:45:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:45:17 --> URI Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Router Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Output Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Security Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Input Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:45:17 --> Language Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Loader Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Controller Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:45:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:45:17 --> Session Class Initialized
DEBUG - 2014-02-05 17:45:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:45:17 --> Session routines successfully run
DEBUG - 2014-02-05 17:45:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:45:17 --> Final output sent to browser
DEBUG - 2014-02-05 17:45:17 --> Total execution time: 0.0150
DEBUG - 2014-02-05 17:45:25 --> Config Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:45:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:45:25 --> URI Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Router Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Output Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Security Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Input Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:45:25 --> Language Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Loader Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Controller Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:45:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:45:25 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:45:25 --> Session Class Initialized
DEBUG - 2014-02-05 17:45:25 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:45:25 --> Session routines successfully run
DEBUG - 2014-02-05 17:45:25 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:45:25 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 17:45:25 --> Final output sent to browser
DEBUG - 2014-02-05 17:45:25 --> Total execution time: 0.0210
DEBUG - 2014-02-05 17:45:30 --> Config Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:45:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:45:30 --> URI Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Router Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Output Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Security Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Input Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:45:30 --> Language Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Loader Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Controller Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:45:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:45:30 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:45:30 --> Session Class Initialized
DEBUG - 2014-02-05 17:45:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:45:30 --> Session routines successfully run
DEBUG - 2014-02-05 17:45:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:45:30 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:45:30 --> Final output sent to browser
DEBUG - 2014-02-05 17:45:30 --> Total execution time: 0.0170
DEBUG - 2014-02-05 17:45:35 --> Config Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:45:35 --> URI Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Router Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Output Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Security Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Input Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:45:35 --> Language Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Loader Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Controller Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:45:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:45:35 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Model Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:45:35 --> Session Class Initialized
DEBUG - 2014-02-05 17:45:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:45:35 --> Session routines successfully run
DEBUG - 2014-02-05 17:45:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:45:35 --> Final output sent to browser
DEBUG - 2014-02-05 17:45:35 --> Total execution time: 0.0190
DEBUG - 2014-02-05 17:46:02 --> Config Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:46:02 --> URI Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Router Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Output Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Security Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Input Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:46:02 --> Language Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Loader Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Controller Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:02 --> Session Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:46:02 --> Session routines successfully run
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:46:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 17:46:02 --> Final output sent to browser
DEBUG - 2014-02-05 17:46:02 --> Total execution time: 0.0210
DEBUG - 2014-02-05 17:46:02 --> Config Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:46:02 --> URI Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Router Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Output Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Security Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Input Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:46:02 --> Language Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Loader Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Controller Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:02 --> Session Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:46:02 --> Session routines successfully run
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:02 --> Final output sent to browser
DEBUG - 2014-02-05 17:46:02 --> Total execution time: 0.0240
DEBUG - 2014-02-05 17:46:02 --> Config Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:46:02 --> URI Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Router Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Output Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Security Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Input Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:46:02 --> Language Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Loader Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Controller Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:02 --> Session Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:46:02 --> Session routines successfully run
DEBUG - 2014-02-05 17:46:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:46:02 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:02 --> Final output sent to browser
DEBUG - 2014-02-05 17:46:02 --> Total execution time: 0.0190
DEBUG - 2014-02-05 17:46:05 --> Config Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:46:05 --> URI Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Router Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Output Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Security Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Input Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:46:05 --> Language Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Loader Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Controller Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:46:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:46:05 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:05 --> Session Class Initialized
DEBUG - 2014-02-05 17:46:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:46:05 --> Session routines successfully run
DEBUG - 2014-02-05 17:46:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:46:05 --> Final output sent to browser
DEBUG - 2014-02-05 17:46:05 --> Total execution time: 0.0110
DEBUG - 2014-02-05 17:46:07 --> Config Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:46:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:46:07 --> URI Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Router Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Output Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Security Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Input Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:46:07 --> Language Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Loader Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Controller Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:07 --> Session Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:46:07 --> Session routines successfully run
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:07 --> Final output sent to browser
DEBUG - 2014-02-05 17:46:07 --> Total execution time: 0.0170
DEBUG - 2014-02-05 17:46:07 --> Config Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:46:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:46:07 --> URI Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Router Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Output Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Security Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Input Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:46:07 --> Language Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Loader Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Controller Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:07 --> Session Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:46:07 --> Session routines successfully run
DEBUG - 2014-02-05 17:46:07 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:46:07 --> Model Class Initialized
DEBUG - 2014-02-05 17:46:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:46:07 --> Final output sent to browser
DEBUG - 2014-02-05 17:46:07 --> Total execution time: 0.0130
DEBUG - 2014-02-05 17:48:21 --> Config Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:48:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:48:21 --> URI Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Router Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Output Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Security Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Input Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:48:21 --> Language Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Loader Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Controller Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:48:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:48:21 --> Model Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Model Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Model Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:48:21 --> Session Class Initialized
DEBUG - 2014-02-05 17:48:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:48:21 --> Session routines successfully run
DEBUG - 2014-02-05 17:48:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:48:21 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:48:21 --> Final output sent to browser
DEBUG - 2014-02-05 17:48:21 --> Total execution time: 0.0230
DEBUG - 2014-02-05 17:48:22 --> Config Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:48:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:48:22 --> URI Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Router Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Output Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Security Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Input Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:48:22 --> Language Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Loader Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Controller Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:48:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:48:22 --> Model Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Model Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Model Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:48:22 --> Session Class Initialized
DEBUG - 2014-02-05 17:48:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:48:22 --> Session routines successfully run
DEBUG - 2014-02-05 17:48:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:48:22 --> Final output sent to browser
DEBUG - 2014-02-05 17:48:22 --> Total execution time: 0.0100
DEBUG - 2014-02-05 17:59:24 --> Config Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:59:24 --> URI Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Router Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Output Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Security Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Input Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:59:24 --> Language Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Loader Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Controller Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:59:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:59:24 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:59:24 --> Session Class Initialized
DEBUG - 2014-02-05 17:59:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:59:24 --> Session routines successfully run
DEBUG - 2014-02-05 17:59:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:59:24 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 17:59:24 --> Final output sent to browser
DEBUG - 2014-02-05 17:59:24 --> Total execution time: 0.0250
DEBUG - 2014-02-05 17:59:29 --> Config Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:59:29 --> URI Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Router Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Output Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Security Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Input Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:59:29 --> Language Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Loader Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Controller Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:59:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:59:29 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:59:29 --> Session Class Initialized
DEBUG - 2014-02-05 17:59:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:59:29 --> Session routines successfully run
DEBUG - 2014-02-05 17:59:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:59:29 --> Final output sent to browser
DEBUG - 2014-02-05 17:59:29 --> Total execution time: 0.0150
DEBUG - 2014-02-05 17:59:36 --> Config Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:59:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:59:36 --> URI Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Router Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Output Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Security Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Input Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:59:36 --> Language Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Loader Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Controller Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 17:59:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 17:59:36 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Model Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 17:59:36 --> Session Class Initialized
DEBUG - 2014-02-05 17:59:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:59:36 --> Session routines successfully run
DEBUG - 2014-02-05 17:59:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:59:36 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 17:59:36 --> Final output sent to browser
DEBUG - 2014-02-05 17:59:36 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:01:35 --> Config Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:01:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:01:35 --> URI Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Router Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Output Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Security Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Input Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:01:35 --> Language Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Loader Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Controller Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:01:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:01:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:01:35 --> Session Class Initialized
DEBUG - 2014-02-05 18:01:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:01:35 --> Session routines successfully run
DEBUG - 2014-02-05 18:01:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:01:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 18:01:35 --> Final output sent to browser
DEBUG - 2014-02-05 18:01:35 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:01:36 --> Config Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:01:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:01:36 --> URI Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Router Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Output Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Security Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Input Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:01:36 --> Language Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Loader Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Controller Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:01:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:01:36 --> Model Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Model Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Model Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:01:36 --> Session Class Initialized
DEBUG - 2014-02-05 18:01:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:01:36 --> Session routines successfully run
DEBUG - 2014-02-05 18:01:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:01:36 --> Final output sent to browser
DEBUG - 2014-02-05 18:01:36 --> Total execution time: 0.0100
DEBUG - 2014-02-05 18:02:00 --> Config Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:02:00 --> URI Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Router Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Output Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Security Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Input Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:02:00 --> Language Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Loader Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Controller Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:02:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:02:00 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:00 --> Session Class Initialized
DEBUG - 2014-02-05 18:02:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:02:00 --> Session routines successfully run
DEBUG - 2014-02-05 18:02:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:02:00 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:02:00 --> Final output sent to browser
DEBUG - 2014-02-05 18:02:00 --> Total execution time: 0.0110
DEBUG - 2014-02-05 18:02:38 --> Config Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:02:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:02:38 --> URI Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Router Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Output Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Security Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Input Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:02:38 --> Language Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Loader Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Controller Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:38 --> Session Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:02:38 --> Session routines successfully run
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:02:38 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 18:02:38 --> Final output sent to browser
DEBUG - 2014-02-05 18:02:38 --> Total execution time: 0.0120
DEBUG - 2014-02-05 18:02:38 --> Config Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:02:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:02:38 --> URI Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Router Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Output Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Security Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Input Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:02:38 --> Language Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Loader Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Controller Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:38 --> Session Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:02:38 --> Session routines successfully run
DEBUG - 2014-02-05 18:02:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:02:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:38 --> Final output sent to browser
DEBUG - 2014-02-05 18:02:38 --> Total execution time: 0.0260
DEBUG - 2014-02-05 18:02:39 --> Config Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:02:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:02:39 --> URI Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Router Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Output Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Security Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Input Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:02:39 --> Language Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Loader Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Controller Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:02:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:02:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:39 --> Session Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:02:39 --> Session routines successfully run
DEBUG - 2014-02-05 18:02:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:02:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:39 --> Final output sent to browser
DEBUG - 2014-02-05 18:02:39 --> Total execution time: 0.0130
DEBUG - 2014-02-05 18:02:43 --> Config Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:02:43 --> URI Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Router Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Output Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Security Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Input Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:02:43 --> Language Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Loader Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Controller Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:43 --> Session Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:02:43 --> Session routines successfully run
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:43 --> Final output sent to browser
DEBUG - 2014-02-05 18:02:43 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:02:43 --> Config Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:02:43 --> URI Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Router Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Output Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Security Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Input Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:02:43 --> Language Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Loader Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Controller Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:43 --> Session Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:02:43 --> Session routines successfully run
DEBUG - 2014-02-05 18:02:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:02:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:02:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:02:43 --> Final output sent to browser
DEBUG - 2014-02-05 18:02:43 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:04:29 --> Config Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:04:29 --> URI Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Router Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Output Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Security Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Input Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:04:29 --> Language Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Loader Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Controller Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:04:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:04:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:04:29 --> Session Class Initialized
DEBUG - 2014-02-05 18:04:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:04:29 --> Session routines successfully run
DEBUG - 2014-02-05 18:04:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:04:29 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:04:29 --> Final output sent to browser
DEBUG - 2014-02-05 18:04:29 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:05:20 --> Config Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:05:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:05:20 --> URI Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Router Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Output Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Security Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Input Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:05:20 --> Language Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Loader Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Controller Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:05:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:05:20 --> Model Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Model Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Model Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:05:20 --> Session Class Initialized
DEBUG - 2014-02-05 18:05:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:05:20 --> Session routines successfully run
DEBUG - 2014-02-05 18:05:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:05:20 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:05:20 --> Final output sent to browser
DEBUG - 2014-02-05 18:05:20 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:05:53 --> Config Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:05:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:05:53 --> URI Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Router Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Output Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Security Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Input Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:05:53 --> Language Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Loader Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Controller Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:05:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:05:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:05:53 --> Session Class Initialized
DEBUG - 2014-02-05 18:05:53 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:05:53 --> Session routines successfully run
DEBUG - 2014-02-05 18:05:53 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:05:53 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:05:53 --> Final output sent to browser
DEBUG - 2014-02-05 18:05:53 --> Total execution time: 0.0180
DEBUG - 2014-02-05 18:06:43 --> Config Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:06:43 --> URI Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Router Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Output Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Security Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Input Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:06:43 --> Language Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Loader Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Controller Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:06:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:06:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Model Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:06:43 --> Session Class Initialized
DEBUG - 2014-02-05 18:06:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:06:43 --> Session routines successfully run
DEBUG - 2014-02-05 18:06:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:06:43 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:06:43 --> Final output sent to browser
DEBUG - 2014-02-05 18:06:43 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:07:10 --> Config Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:07:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:07:10 --> URI Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Router Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Output Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Security Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Input Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:07:10 --> Language Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Loader Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Controller Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:07:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:07:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:07:10 --> Session Class Initialized
DEBUG - 2014-02-05 18:07:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:07:10 --> Session routines successfully run
DEBUG - 2014-02-05 18:07:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:07:10 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:07:10 --> Final output sent to browser
DEBUG - 2014-02-05 18:07:10 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:07:51 --> Config Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:07:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:07:51 --> URI Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Router Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Output Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Security Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Input Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:07:51 --> Language Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Loader Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Controller Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:07:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:07:51 --> Model Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Model Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Model Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:07:51 --> Session Class Initialized
DEBUG - 2014-02-05 18:07:51 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:07:51 --> Session routines successfully run
DEBUG - 2014-02-05 18:07:51 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:07:51 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:07:51 --> Final output sent to browser
DEBUG - 2014-02-05 18:07:51 --> Total execution time: 0.0140
DEBUG - 2014-02-05 18:08:23 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:23 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:23 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:23 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:23 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:23 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:23 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:23 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:23 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 18:08:23 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:23 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:08:28 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:28 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:28 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:28 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:28 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:28 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:28 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:28 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:28 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:28 --> Total execution time: 0.0150
DEBUG - 2014-02-05 18:08:38 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:38 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:38 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:38 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:38 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:38 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 18:08:38 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:38 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:08:39 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:39 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:39 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:39 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:39 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:39 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:39 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:39 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:39 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:39 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:08:39 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:39 --> Total execution time: 0.0330
DEBUG - 2014-02-05 18:08:40 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:40 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:40 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:40 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:40 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:40 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:08:40 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:40 --> Total execution time: 0.0170
DEBUG - 2014-02-05 18:08:44 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:44 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:44 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:44 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:44 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:44 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:44 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:08:44 --> Config Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:08:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:08:44 --> URI Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Router Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Output Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Security Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Input Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:08:44 --> Language Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Loader Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Controller Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:44 --> Session Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:08:44 --> Session routines successfully run
DEBUG - 2014-02-05 18:08:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:08:44 --> Model Class Initialized
DEBUG - 2014-02-05 18:08:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:08:44 --> Final output sent to browser
DEBUG - 2014-02-05 18:08:44 --> Total execution time: 0.0250
DEBUG - 2014-02-05 18:10:33 --> Config Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:10:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:10:33 --> URI Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Router Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Output Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Security Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Input Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:10:33 --> Language Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Loader Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Controller Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:10:33 --> Session Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:10:33 --> Session routines successfully run
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:10:33 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:10:33 --> Final output sent to browser
DEBUG - 2014-02-05 18:10:33 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:10:33 --> Config Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:10:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:10:33 --> URI Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Router Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Output Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Security Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Input Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Config Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:10:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Language Class Initialized
DEBUG - 2014-02-05 18:10:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:10:33 --> URI Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Loader Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Router Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Controller Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:10:33 --> Output Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Security Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Input Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:10:33 --> Language Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Loader Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Controller Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:10:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Session Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:10:33 --> Session routines successfully run
DEBUG - 2014-02-05 18:10:33 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:10:33 --> Session Class Initialized
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:10:33 --> Session routines successfully run
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: url_helper
ERROR - 2014-02-05 18:10:33 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-05 18:10:33 --> Helper loaded: url_helper
ERROR - 2014-02-05 18:10:33 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-05 18:10:38 --> Config Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Config Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:10:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:10:38 --> URI Class Initialized
DEBUG - 2014-02-05 18:10:38 --> URI Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Router Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Router Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Output Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Output Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Security Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Security Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Input Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Input Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:10:38 --> Language Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Language Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Loader Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Loader Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Controller Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Controller Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:10:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:10:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:10:38 --> Session Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Session Class Initialized
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:10:38 --> Session routines successfully run
DEBUG - 2014-02-05 18:10:38 --> Session routines successfully run
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:10:38 --> Helper loaded: url_helper
ERROR - 2014-02-05 18:10:38 --> 404 Page Not Found --> admin/img
ERROR - 2014-02-05 18:10:38 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-05 18:10:53 --> Config Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:10:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:10:53 --> URI Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Router Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Output Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Security Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Input Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:10:53 --> Language Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Loader Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Controller Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:10:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:10:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:10:53 --> Session Class Initialized
DEBUG - 2014-02-05 18:10:53 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:10:53 --> Session routines successfully run
DEBUG - 2014-02-05 18:10:53 --> Helper loaded: url_helper
ERROR - 2014-02-05 18:10:53 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-05 18:33:00 --> Config Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:33:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:33:00 --> URI Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Router Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Output Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Security Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Input Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:33:00 --> Language Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Loader Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Controller Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:33:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:33:00 --> Model Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Model Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Model Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:33:00 --> Session Class Initialized
DEBUG - 2014-02-05 18:33:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:33:00 --> Session routines successfully run
DEBUG - 2014-02-05 18:33:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:33:00 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:33:00 --> Final output sent to browser
DEBUG - 2014-02-05 18:33:00 --> Total execution time: 0.0170
DEBUG - 2014-02-05 18:35:01 --> Config Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:35:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:35:01 --> URI Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Router Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Output Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Security Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Input Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:35:01 --> Language Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Loader Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Controller Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:35:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:35:01 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:35:01 --> Session Class Initialized
DEBUG - 2014-02-05 18:35:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:35:01 --> Session routines successfully run
DEBUG - 2014-02-05 18:35:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:35:01 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:35:01 --> Final output sent to browser
DEBUG - 2014-02-05 18:35:01 --> Total execution time: 0.0120
DEBUG - 2014-02-05 18:35:21 --> Config Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:35:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:35:21 --> URI Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Router Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Output Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Security Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Input Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:35:21 --> Language Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Loader Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Controller Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:35:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:35:21 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:35:21 --> Session Class Initialized
DEBUG - 2014-02-05 18:35:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:35:21 --> Session routines successfully run
DEBUG - 2014-02-05 18:35:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:35:21 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:35:21 --> Final output sent to browser
DEBUG - 2014-02-05 18:35:21 --> Total execution time: 0.0230
DEBUG - 2014-02-05 18:35:42 --> Config Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:35:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:35:42 --> URI Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Router Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Output Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Security Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Input Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:35:42 --> Language Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Loader Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Controller Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:35:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:35:42 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Model Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:35:42 --> Session Class Initialized
DEBUG - 2014-02-05 18:35:42 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:35:42 --> Session routines successfully run
DEBUG - 2014-02-05 18:35:42 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:35:42 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:35:42 --> Final output sent to browser
DEBUG - 2014-02-05 18:35:42 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:37:10 --> Config Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:37:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:37:10 --> URI Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Router Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Output Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Security Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Input Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:37:10 --> Language Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Loader Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Controller Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:37:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:37:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:37:10 --> Session Class Initialized
DEBUG - 2014-02-05 18:37:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:37:10 --> Session routines successfully run
DEBUG - 2014-02-05 18:37:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:37:10 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:37:10 --> Final output sent to browser
DEBUG - 2014-02-05 18:37:10 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:40:10 --> Config Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:40:10 --> URI Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Router Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Output Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Security Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Input Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:40:10 --> Language Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Loader Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Controller Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:40:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:40:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:40:10 --> Session Class Initialized
DEBUG - 2014-02-05 18:40:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:40:10 --> Session routines successfully run
DEBUG - 2014-02-05 18:40:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:40:10 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:40:10 --> Final output sent to browser
DEBUG - 2014-02-05 18:40:10 --> Total execution time: 0.0230
DEBUG - 2014-02-05 18:40:29 --> Config Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:40:29 --> URI Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Router Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Output Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Security Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Input Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:40:29 --> Language Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Loader Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Controller Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:40:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:40:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:40:29 --> Session Class Initialized
DEBUG - 2014-02-05 18:40:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:40:29 --> Session routines successfully run
DEBUG - 2014-02-05 18:40:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:40:29 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:40:29 --> Final output sent to browser
DEBUG - 2014-02-05 18:40:29 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:40:53 --> Config Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:40:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:40:53 --> URI Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Router Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Output Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Security Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Input Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:40:53 --> Language Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Loader Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Controller Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:40:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:40:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Model Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:40:53 --> Session Class Initialized
DEBUG - 2014-02-05 18:40:53 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:40:53 --> Session routines successfully run
DEBUG - 2014-02-05 18:40:53 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:40:53 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:40:53 --> Final output sent to browser
DEBUG - 2014-02-05 18:40:53 --> Total execution time: 0.0180
DEBUG - 2014-02-05 18:42:06 --> Config Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:42:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:42:06 --> URI Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Router Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Output Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Security Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Input Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:42:06 --> Language Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Loader Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Controller Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:42:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:42:06 --> Model Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Model Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Model Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:42:06 --> Session Class Initialized
DEBUG - 2014-02-05 18:42:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:42:06 --> Session routines successfully run
DEBUG - 2014-02-05 18:42:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:42:06 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:42:06 --> Final output sent to browser
DEBUG - 2014-02-05 18:42:06 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:42:42 --> Config Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:42:42 --> URI Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Router Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Output Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Security Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Input Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:42:42 --> Language Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Loader Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Controller Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:42:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:42:42 --> Session Class Initialized
DEBUG - 2014-02-05 18:42:42 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:42:42 --> Session routines successfully run
DEBUG - 2014-02-05 18:42:42 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:42:42 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:42:42 --> Final output sent to browser
DEBUG - 2014-02-05 18:42:42 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:43:13 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:13 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:13 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:13 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:13 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:13 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:13 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:13 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 18:43:13 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:13 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:43:14 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:14 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:14 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:14 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:14 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:14 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:14 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:14 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:14 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:14 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:14 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:43:14 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:14 --> Total execution time: 0.0250
DEBUG - 2014-02-05 18:43:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:14 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:14 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:14 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:14 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:14 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:14 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:14 --> Total execution time: 0.0130
DEBUG - 2014-02-05 18:43:17 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:17 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:17 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:17 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:17 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:17 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 18:43:17 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:17 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:43:18 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:18 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:18 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:18 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:18 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:18 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:18 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:18 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:18 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:43:24 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:24 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:24 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:24 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:24 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:24 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:24 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 18:43:24 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:24 --> Total execution time: 0.0280
DEBUG - 2014-02-05 18:43:29 --> Config Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:43:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:43:29 --> URI Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Router Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Output Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Security Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Input Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:43:29 --> Language Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Loader Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Controller Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:43:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:43:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Model Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:43:29 --> Session Class Initialized
DEBUG - 2014-02-05 18:43:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:43:29 --> Session routines successfully run
DEBUG - 2014-02-05 18:43:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:43:29 --> Final output sent to browser
DEBUG - 2014-02-05 18:43:29 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:45:03 --> Config Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:45:03 --> URI Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Router Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Output Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Security Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Input Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:45:03 --> Language Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Loader Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Controller Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:45:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:45:03 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:03 --> Session Class Initialized
DEBUG - 2014-02-05 18:45:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:45:03 --> Session routines successfully run
DEBUG - 2014-02-05 18:45:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:45:03 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 18:45:03 --> Final output sent to browser
DEBUG - 2014-02-05 18:45:03 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:45:39 --> Config Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:45:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:45:39 --> URI Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Router Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Output Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Security Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Input Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:45:39 --> Language Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Loader Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Controller Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:45:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:45:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:39 --> Session Class Initialized
DEBUG - 2014-02-05 18:45:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:45:39 --> Session routines successfully run
DEBUG - 2014-02-05 18:45:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:45:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 18:45:39 --> Final output sent to browser
DEBUG - 2014-02-05 18:45:39 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:45:40 --> Config Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:45:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:45:40 --> URI Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Router Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Output Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Security Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Input Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:45:40 --> Language Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Loader Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Controller Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:40 --> Session Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:45:40 --> Session routines successfully run
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:40 --> Final output sent to browser
DEBUG - 2014-02-05 18:45:40 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:45:40 --> Config Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:45:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:45:40 --> URI Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Router Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Output Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Security Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Input Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:45:40 --> Language Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Loader Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Controller Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:40 --> Session Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:45:40 --> Session routines successfully run
DEBUG - 2014-02-05 18:45:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:45:40 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:40 --> Final output sent to browser
DEBUG - 2014-02-05 18:45:40 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:45:45 --> Config Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:45:45 --> URI Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Router Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Output Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Security Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Input Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:45:45 --> Language Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Loader Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Controller Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:45 --> Session Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:45:45 --> Session routines successfully run
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:45 --> Final output sent to browser
DEBUG - 2014-02-05 18:45:45 --> Total execution time: 0.0180
DEBUG - 2014-02-05 18:45:45 --> Config Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:45:45 --> URI Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Router Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Output Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Security Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Input Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:45:45 --> Language Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Loader Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Controller Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:45 --> Session Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:45:45 --> Session routines successfully run
DEBUG - 2014-02-05 18:45:45 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:45:45 --> Model Class Initialized
DEBUG - 2014-02-05 18:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:45:45 --> Final output sent to browser
DEBUG - 2014-02-05 18:45:45 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:53:30 --> Config Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:53:30 --> URI Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Router Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Output Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Security Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Input Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:53:30 --> Language Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Loader Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Controller Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:30 --> Session Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:53:30 --> Session routines successfully run
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:53:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 18:53:30 --> Final output sent to browser
DEBUG - 2014-02-05 18:53:30 --> Total execution time: 0.0250
DEBUG - 2014-02-05 18:53:30 --> Config Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:53:30 --> URI Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Router Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Output Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Security Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Input Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:53:30 --> Language Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Loader Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Controller Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:30 --> Session Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:53:30 --> Session routines successfully run
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:30 --> Final output sent to browser
DEBUG - 2014-02-05 18:53:30 --> Total execution time: 0.0340
DEBUG - 2014-02-05 18:53:30 --> Config Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:53:30 --> URI Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Router Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Output Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Security Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Input Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:53:30 --> Language Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Loader Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Controller Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:30 --> Session Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:53:30 --> Session routines successfully run
DEBUG - 2014-02-05 18:53:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:53:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:30 --> Final output sent to browser
DEBUG - 2014-02-05 18:53:30 --> Total execution time: 0.0180
DEBUG - 2014-02-05 18:53:34 --> Config Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:53:34 --> URI Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Router Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Output Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Security Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Input Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:53:34 --> Language Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Loader Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Controller Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:53:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:53:34 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:34 --> Session Class Initialized
DEBUG - 2014-02-05 18:53:34 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:53:34 --> Session routines successfully run
DEBUG - 2014-02-05 18:53:34 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:53:34 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-05 18:53:34 --> Final output sent to browser
DEBUG - 2014-02-05 18:53:34 --> Total execution time: 0.0180
DEBUG - 2014-02-05 18:53:35 --> Config Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:53:35 --> URI Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Router Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Output Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Security Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Input Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:53:35 --> Language Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Loader Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Controller Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:35 --> Session Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:53:35 --> Session routines successfully run
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:35 --> Final output sent to browser
DEBUG - 2014-02-05 18:53:35 --> Total execution time: 0.0180
DEBUG - 2014-02-05 18:53:35 --> Config Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:53:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:53:35 --> URI Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Router Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Output Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Security Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Input Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:53:35 --> Language Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Loader Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Controller Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:35 --> Session Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:53:35 --> Session routines successfully run
DEBUG - 2014-02-05 18:53:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:53:35 --> Model Class Initialized
DEBUG - 2014-02-05 18:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:53:35 --> Final output sent to browser
DEBUG - 2014-02-05 18:53:35 --> Total execution time: 0.0230
DEBUG - 2014-02-05 18:54:11 --> Config Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:54:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:54:11 --> URI Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Router Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Output Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Security Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Input Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:54:11 --> Language Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Loader Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Controller Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:11 --> Session Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:54:11 --> Session routines successfully run
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:54:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 18:54:11 --> Final output sent to browser
DEBUG - 2014-02-05 18:54:11 --> Total execution time: 0.0150
DEBUG - 2014-02-05 18:54:11 --> Config Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:54:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:54:11 --> URI Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Router Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Output Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Security Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Input Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:54:11 --> Language Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Loader Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Controller Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:11 --> Session Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:54:11 --> Session routines successfully run
DEBUG - 2014-02-05 18:54:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:54:11 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:11 --> Final output sent to browser
DEBUG - 2014-02-05 18:54:11 --> Total execution time: 0.0120
DEBUG - 2014-02-05 18:54:12 --> Config Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:54:12 --> URI Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Router Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Output Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Security Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Input Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:54:12 --> Language Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Config Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Loader Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Controller Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:54:12 --> URI Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Router Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Output Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Security Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Input Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Language Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:12 --> Loader Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Session Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Controller Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:54:12 --> Session routines successfully run
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:12 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:12 --> Session Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:54:12 --> Session routines successfully run
DEBUG - 2014-02-05 18:54:12 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:54:12 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:12 --> Final output sent to browser
DEBUG - 2014-02-05 18:54:12 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:54:12 --> Final output sent to browser
DEBUG - 2014-02-05 18:54:12 --> Total execution time: 0.0220
DEBUG - 2014-02-05 18:54:15 --> Config Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:54:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:54:15 --> URI Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Router Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Output Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Security Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Input Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:54:15 --> Language Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Loader Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Controller Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:54:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:54:15 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:15 --> Session Class Initialized
DEBUG - 2014-02-05 18:54:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:54:15 --> Session routines successfully run
DEBUG - 2014-02-05 18:54:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:54:15 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-05 18:54:15 --> Final output sent to browser
DEBUG - 2014-02-05 18:54:15 --> Total execution time: 0.0210
DEBUG - 2014-02-05 18:54:16 --> Config Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:54:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:54:16 --> URI Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Router Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Output Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Security Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Input Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:54:16 --> Language Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Loader Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Controller Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:54:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:54:16 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:16 --> Session Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:54:16 --> Session routines successfully run
DEBUG - 2014-02-05 18:54:16 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:54:16 --> Model Class Initialized
DEBUG - 2014-02-05 18:54:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:54:16 --> Final output sent to browser
DEBUG - 2014-02-05 18:54:16 --> Total execution time: 0.0390
DEBUG - 2014-02-05 18:59:23 --> Config Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:59:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:59:23 --> URI Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Router Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Output Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Security Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Input Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:59:23 --> Language Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Loader Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Controller Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:59:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:59:23 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:59:23 --> Session Class Initialized
DEBUG - 2014-02-05 18:59:23 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:59:23 --> Session routines successfully run
DEBUG - 2014-02-05 18:59:23 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:59:23 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 18:59:23 --> Final output sent to browser
DEBUG - 2014-02-05 18:59:23 --> Total execution time: 0.0200
DEBUG - 2014-02-05 18:59:28 --> Config Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:59:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:59:28 --> URI Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Router Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Output Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Security Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Input Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:59:28 --> Language Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Loader Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Controller Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:59:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:59:28 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:59:28 --> Session Class Initialized
DEBUG - 2014-02-05 18:59:28 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:59:28 --> Session routines successfully run
DEBUG - 2014-02-05 18:59:28 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:59:28 --> Final output sent to browser
DEBUG - 2014-02-05 18:59:28 --> Total execution time: 0.0190
DEBUG - 2014-02-05 18:59:30 --> Config Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 18:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 18:59:30 --> URI Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Router Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Output Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Security Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Input Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 18:59:30 --> Language Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Loader Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Controller Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 18:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 18:59:30 --> Session Class Initialized
DEBUG - 2014-02-05 18:59:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 18:59:30 --> Session routines successfully run
DEBUG - 2014-02-05 18:59:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 18:59:30 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 18:59:30 --> Final output sent to browser
DEBUG - 2014-02-05 18:59:30 --> Total execution time: 0.0200
DEBUG - 2014-02-05 19:00:33 --> Config Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:00:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:00:33 --> URI Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Router Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Output Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Security Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Input Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:00:33 --> Language Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Loader Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Controller Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:00:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:00:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:00:33 --> Session Class Initialized
DEBUG - 2014-02-05 19:00:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:00:33 --> Session routines successfully run
DEBUG - 2014-02-05 19:00:33 --> Helper loaded: url_helper
ERROR - 2014-02-05 19:00:33 --> Severity: Notice  --> Undefined variable: member F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\common\member_profile.php 14
DEBUG - 2014-02-05 19:03:11 --> Config Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:03:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:03:11 --> URI Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Router Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Output Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Security Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Input Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:03:11 --> Language Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Loader Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Controller Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:03:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:03:11 --> Model Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Model Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Model Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:03:11 --> Session Class Initialized
DEBUG - 2014-02-05 19:03:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:03:11 --> Session routines successfully run
DEBUG - 2014-02-05 19:03:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:03:11 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:03:11 --> Final output sent to browser
DEBUG - 2014-02-05 19:03:11 --> Total execution time: 0.0250
DEBUG - 2014-02-05 19:03:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:03:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:03:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:03:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:03:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:03:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:03:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:03:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:03:26 --> Helper loaded: url_helper
ERROR - 2014-02-05 19:03:26 --> Severity: Notice  --> Undefined variable: no_member F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\flaggedMembers.php 11
ERROR - 2014-02-05 19:03:26 --> Severity: Notice  --> Undefined variable: member F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\common\member_profile.php 14
DEBUG - 2014-02-05 19:16:27 --> Config Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:16:27 --> URI Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Router Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Output Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Security Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Input Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:16:27 --> Language Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Loader Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Controller Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:16:27 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:16:27 --> Session Class Initialized
DEBUG - 2014-02-05 19:16:27 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:16:27 --> Session routines successfully run
DEBUG - 2014-02-05 19:16:27 --> Helper loaded: url_helper
ERROR - 2014-02-05 19:16:27 --> Severity: Notice  --> Undefined variable: no_member F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\flaggedMembers.php 11
DEBUG - 2014-02-05 19:16:27 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:16:27 --> Final output sent to browser
DEBUG - 2014-02-05 19:16:27 --> Total execution time: 0.0310
DEBUG - 2014-02-05 19:16:31 --> Config Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:16:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:16:31 --> URI Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Router Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Output Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Security Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Input Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:16:31 --> Language Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Loader Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Controller Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:16:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:16:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:16:31 --> Session Class Initialized
DEBUG - 2014-02-05 19:16:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:16:31 --> Session routines successfully run
DEBUG - 2014-02-05 19:16:31 --> Helper loaded: url_helper
ERROR - 2014-02-05 19:16:31 --> Severity: Notice  --> Undefined variable: no_member F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\flaggedMembers.php 11
DEBUG - 2014-02-05 19:16:31 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:16:31 --> Final output sent to browser
DEBUG - 2014-02-05 19:16:31 --> Total execution time: 0.0200
DEBUG - 2014-02-05 19:16:56 --> Config Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:16:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:16:56 --> URI Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Router Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Output Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Security Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Input Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:16:56 --> Language Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Loader Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Controller Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:16:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:16:56 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Model Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:16:56 --> Session Class Initialized
DEBUG - 2014-02-05 19:16:56 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:16:56 --> Session routines successfully run
DEBUG - 2014-02-05 19:16:56 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:16:56 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:16:56 --> Final output sent to browser
DEBUG - 2014-02-05 19:16:56 --> Total execution time: 0.0180
DEBUG - 2014-02-05 19:17:57 --> Config Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:17:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:17:57 --> URI Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Router Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Output Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Security Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Input Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:17:57 --> Language Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Loader Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Controller Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:17:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:17:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:17:57 --> Session Class Initialized
DEBUG - 2014-02-05 19:17:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:17:57 --> Session routines successfully run
DEBUG - 2014-02-05 19:17:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:17:57 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:17:57 --> Final output sent to browser
DEBUG - 2014-02-05 19:17:57 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:21:21 --> Config Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:21:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:21:21 --> URI Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Router Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Output Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Security Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Input Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:21:21 --> Language Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Loader Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Controller Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:21:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:21:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:21:21 --> Session Class Initialized
DEBUG - 2014-02-05 19:21:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:21:21 --> Session routines successfully run
DEBUG - 2014-02-05 19:21:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:21:21 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:21:21 --> Final output sent to browser
DEBUG - 2014-02-05 19:21:21 --> Total execution time: 0.0140
DEBUG - 2014-02-05 19:23:00 --> Config Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:23:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:23:00 --> URI Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Router Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Output Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Security Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Input Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:23:00 --> Language Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Loader Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Controller Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:23:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:23:00 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:23:00 --> Session Class Initialized
DEBUG - 2014-02-05 19:23:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:23:00 --> Session routines successfully run
DEBUG - 2014-02-05 19:23:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:23:00 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:23:00 --> Final output sent to browser
DEBUG - 2014-02-05 19:23:00 --> Total execution time: 0.0140
DEBUG - 2014-02-05 19:23:43 --> Config Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:23:43 --> URI Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Router Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Output Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Security Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Input Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:23:43 --> Language Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Loader Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Controller Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:23:43 --> Session Class Initialized
DEBUG - 2014-02-05 19:23:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:23:43 --> Session routines successfully run
DEBUG - 2014-02-05 19:23:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:23:43 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:23:43 --> Final output sent to browser
DEBUG - 2014-02-05 19:23:43 --> Total execution time: 0.0240
DEBUG - 2014-02-05 19:23:57 --> Config Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:23:57 --> URI Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Router Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Output Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Security Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Input Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:23:57 --> Language Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Loader Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Controller Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:23:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:23:57 --> Session Class Initialized
DEBUG - 2014-02-05 19:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:23:57 --> Session routines successfully run
DEBUG - 2014-02-05 19:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:23:57 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:23:57 --> Final output sent to browser
DEBUG - 2014-02-05 19:23:57 --> Total execution time: 0.0200
DEBUG - 2014-02-05 19:24:11 --> Config Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:24:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:24:11 --> URI Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Router Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Output Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Security Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Input Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:24:11 --> Language Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Loader Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Controller Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:24:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:24:11 --> Model Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Model Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Model Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:24:11 --> Session Class Initialized
DEBUG - 2014-02-05 19:24:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:24:11 --> Session routines successfully run
DEBUG - 2014-02-05 19:24:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:24:11 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:24:11 --> Final output sent to browser
DEBUG - 2014-02-05 19:24:11 --> Total execution time: 0.0120
DEBUG - 2014-02-05 19:24:21 --> Config Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:24:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:24:21 --> URI Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Router Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Output Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Security Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Input Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:24:21 --> Language Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Loader Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Controller Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:24:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:24:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:24:21 --> Session Class Initialized
DEBUG - 2014-02-05 19:24:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:24:21 --> Session routines successfully run
DEBUG - 2014-02-05 19:24:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:24:21 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:24:21 --> Final output sent to browser
DEBUG - 2014-02-05 19:24:21 --> Total execution time: 0.0150
DEBUG - 2014-02-05 19:25:28 --> Config Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:25:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:25:28 --> URI Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Router Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Output Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Security Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Input Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:25:28 --> Language Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Loader Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Controller Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:25:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:25:28 --> Model Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Model Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Model Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:25:28 --> Session Class Initialized
DEBUG - 2014-02-05 19:25:28 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:25:28 --> Session routines successfully run
DEBUG - 2014-02-05 19:25:28 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:25:28 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:25:28 --> Final output sent to browser
DEBUG - 2014-02-05 19:25:28 --> Total execution time: 0.0240
DEBUG - 2014-02-05 19:27:12 --> Config Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:27:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:27:12 --> URI Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Router Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Output Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Security Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Input Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:27:12 --> Language Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Loader Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Controller Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:27:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:27:12 --> Model Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Model Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Model Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:27:12 --> Session Class Initialized
DEBUG - 2014-02-05 19:27:12 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:27:12 --> Session routines successfully run
DEBUG - 2014-02-05 19:27:12 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:27:12 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:27:12 --> Final output sent to browser
DEBUG - 2014-02-05 19:27:12 --> Total execution time: 0.0140
DEBUG - 2014-02-05 19:28:14 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:14 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:14 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:14 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:14 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:14 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:14 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:14 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:14 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:28:18 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:18 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:18 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:18 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:18 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:18 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:18 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:18 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:28:20 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:20 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:20 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:20 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:20 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:20 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:20 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:20 --> Total execution time: 0.0140
DEBUG - 2014-02-05 19:28:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:26 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:26 --> Total execution time: 0.0130
DEBUG - 2014-02-05 19:28:32 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:32 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:32 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:32 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:32 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:32 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:32 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:32 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:32 --> Total execution time: 0.0180
DEBUG - 2014-02-05 19:28:34 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:34 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:34 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:34 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:34 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:34 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:34 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:34 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:34 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:34 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:34 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:28:38 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:38 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:38 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:38 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:38 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:38 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:38 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:38 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:38 --> Total execution time: 0.0150
DEBUG - 2014-02-05 19:28:51 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:51 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:51 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:51 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:51 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:51 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:51 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:51 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:51 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:51 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:51 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:28:54 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:54 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:54 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:54 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:54 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:54 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:54 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:54 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:54 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:28:54 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:54 --> Total execution time: 0.0130
DEBUG - 2014-02-05 19:28:55 --> Config Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:28:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:28:55 --> URI Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Router Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Output Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Security Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Input Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:28:55 --> Language Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Loader Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Controller Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:28:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:28:55 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Model Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:28:55 --> Session Class Initialized
DEBUG - 2014-02-05 19:28:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:28:55 --> Session routines successfully run
DEBUG - 2014-02-05 19:28:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:28:55 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 19:28:55 --> Final output sent to browser
DEBUG - 2014-02-05 19:28:55 --> Total execution time: 0.0130
DEBUG - 2014-02-05 19:29:05 --> Config Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:29:05 --> URI Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Router Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Output Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Security Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Input Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:29:05 --> Language Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Loader Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Controller Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:29:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:29:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:29:05 --> Session Class Initialized
DEBUG - 2014-02-05 19:29:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:29:05 --> Session routines successfully run
DEBUG - 2014-02-05 19:29:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:29:05 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:29:05 --> Final output sent to browser
DEBUG - 2014-02-05 19:29:05 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:29:14 --> Config Class Initialized
DEBUG - 2014-02-05 19:29:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:29:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:29:15 --> URI Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Router Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Output Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Security Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Input Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:29:15 --> Language Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Loader Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Controller Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:29:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:29:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:29:15 --> Session Class Initialized
DEBUG - 2014-02-05 19:29:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:29:15 --> Session routines successfully run
DEBUG - 2014-02-05 19:29:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:29:15 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-05 19:29:15 --> Final output sent to browser
DEBUG - 2014-02-05 19:29:15 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:33:13 --> Config Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:33:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:33:13 --> URI Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Router Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Output Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Security Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Input Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:33:13 --> Language Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Loader Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Controller Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:33:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:33:13 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:33:13 --> Final output sent to browser
DEBUG - 2014-02-05 19:33:13 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:33:23 --> Config Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:33:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:33:23 --> URI Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Router Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Output Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Security Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Input Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:33:23 --> Language Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Loader Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Controller Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:33:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:33:23 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:33:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:33:26 --> Total execution time: 2.7582
DEBUG - 2014-02-05 19:33:33 --> Config Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:33:33 --> URI Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Router Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Output Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Security Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Input Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:33:33 --> Language Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Loader Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Controller Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:33:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:33:33 --> Upload Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:33:37 --> Final output sent to browser
DEBUG - 2014-02-05 19:33:37 --> Total execution time: 3.3302
DEBUG - 2014-02-05 19:34:19 --> Config Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:34:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:34:19 --> URI Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Router Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Output Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Security Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Input Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:34:19 --> Language Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Loader Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Controller Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:34:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:34:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:34:19 --> Upload Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:34:22 --> Final output sent to browser
DEBUG - 2014-02-05 19:34:22 --> Total execution time: 2.3961
DEBUG - 2014-02-05 19:34:42 --> Config Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:34:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:34:42 --> URI Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Router Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Output Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Security Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Input Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:34:42 --> Language Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Loader Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Controller Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:34:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:34:42 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Model Class Initialized
DEBUG - 2014-02-05 19:34:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:34:46 --> Final output sent to browser
DEBUG - 2014-02-05 19:34:46 --> Total execution time: 3.3852
DEBUG - 2014-02-05 19:35:06 --> Config Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:35:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:35:06 --> URI Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Router Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Output Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Security Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Input Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:35:06 --> Language Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Loader Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Controller Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:35:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:35:06 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:35:06 --> Upload Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:35:09 --> Final output sent to browser
DEBUG - 2014-02-05 19:35:09 --> Total execution time: 2.3441
DEBUG - 2014-02-05 19:35:39 --> Config Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:35:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:35:39 --> URI Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Router Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Output Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Security Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Input Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:35:39 --> Language Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Loader Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Controller Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:35:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:35:39 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:35:39 --> Final output sent to browser
DEBUG - 2014-02-05 19:35:39 --> Total execution time: 0.0170
DEBUG - 2014-02-05 19:35:47 --> Config Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:35:47 --> URI Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Router Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Output Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Security Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Input Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:35:47 --> Language Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Loader Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Controller Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:35:47 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Model Class Initialized
DEBUG - 2014-02-05 19:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:35:47 --> Final output sent to browser
DEBUG - 2014-02-05 19:35:47 --> Total execution time: 0.0170
DEBUG - 2014-02-05 19:36:03 --> Config Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:36:03 --> URI Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Router Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Output Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Security Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Input Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:36:03 --> Language Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Loader Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Controller Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:36:06 --> Final output sent to browser
DEBUG - 2014-02-05 19:36:06 --> Total execution time: 2.2731
DEBUG - 2014-02-05 19:36:18 --> Config Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:36:18 --> URI Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Router Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Output Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Security Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Input Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:36:18 --> Language Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Loader Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Controller Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:36:18 --> Upload Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:36:23 --> Final output sent to browser
DEBUG - 2014-02-05 19:36:23 --> Total execution time: 5.3973
DEBUG - 2014-02-05 19:36:49 --> Config Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:36:49 --> URI Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Router Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Output Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Security Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Input Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:36:49 --> Language Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Loader Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Controller Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:36:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:36:49 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Model Class Initialized
DEBUG - 2014-02-05 19:36:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:36:53 --> Final output sent to browser
DEBUG - 2014-02-05 19:36:53 --> Total execution time: 3.8852
DEBUG - 2014-02-05 19:37:05 --> Config Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:37:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:37:05 --> URI Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Router Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Output Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Security Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Input Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:37:05 --> Language Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Loader Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Controller Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:37:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:37:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:37:05 --> Upload Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:37:07 --> Final output sent to browser
DEBUG - 2014-02-05 19:37:07 --> Total execution time: 2.3371
DEBUG - 2014-02-05 19:37:32 --> Config Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:37:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:37:32 --> URI Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Router Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Output Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Security Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Input Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:37:32 --> Language Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Loader Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Controller Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:37:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:37:32 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:37:35 --> Final output sent to browser
DEBUG - 2014-02-05 19:37:35 --> Total execution time: 2.3331
DEBUG - 2014-02-05 19:37:50 --> Config Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:37:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:37:50 --> URI Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Router Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Output Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Security Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Input Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:37:50 --> Language Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Loader Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Controller Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:37:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:37:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:37:50 --> Upload Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:37:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:37:52 --> Final output sent to browser
DEBUG - 2014-02-05 19:37:52 --> Total execution time: 2.3431
DEBUG - 2014-02-05 19:38:14 --> Config Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:38:14 --> URI Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Router Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Output Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Security Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Input Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:38:14 --> Language Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Loader Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Controller Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:38:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:38:14 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:38:17 --> Final output sent to browser
DEBUG - 2014-02-05 19:38:17 --> Total execution time: 2.2821
DEBUG - 2014-02-05 19:38:31 --> Config Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:38:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:38:31 --> URI Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Router Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Output Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Security Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Input Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:38:31 --> Language Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Loader Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Controller Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:38:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:38:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:38:31 --> Upload Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:38:34 --> Final output sent to browser
DEBUG - 2014-02-05 19:38:34 --> Total execution time: 2.4081
DEBUG - 2014-02-05 19:38:55 --> Config Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:38:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:38:55 --> URI Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Router Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Output Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Security Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Input Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:38:55 --> Language Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Loader Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Controller Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:38:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:38:55 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Model Class Initialized
DEBUG - 2014-02-05 19:38:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:39:00 --> Final output sent to browser
DEBUG - 2014-02-05 19:39:00 --> Total execution time: 5.2643
DEBUG - 2014-02-05 19:39:17 --> Config Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:39:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:39:17 --> URI Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Router Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Output Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Security Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Input Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:39:17 --> Language Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Loader Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Controller Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:39:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:39:17 --> Upload Class Initialized
DEBUG - 2014-02-05 19:39:17 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:39:18 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:39:20 --> Final output sent to browser
DEBUG - 2014-02-05 19:39:20 --> Total execution time: 2.4471
DEBUG - 2014-02-05 19:39:45 --> Config Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:39:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:39:45 --> URI Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Router Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Output Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Security Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Input Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:39:45 --> Language Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Loader Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Controller Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:39:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:39:45 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:39:47 --> Final output sent to browser
DEBUG - 2014-02-05 19:39:47 --> Total execution time: 2.2821
DEBUG - 2014-02-05 19:39:58 --> Config Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:39:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:39:58 --> URI Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Router Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Output Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Security Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Input Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:39:58 --> Language Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Loader Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Controller Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:39:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:39:58 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:39:58 --> Upload Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Model Class Initialized
DEBUG - 2014-02-05 19:39:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:40:00 --> Final output sent to browser
DEBUG - 2014-02-05 19:40:00 --> Total execution time: 2.4411
DEBUG - 2014-02-05 19:40:23 --> Config Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:40:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:40:23 --> URI Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Router Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Output Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Security Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Input Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:40:23 --> Language Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Loader Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Controller Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:40:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:40:23 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:40:25 --> Final output sent to browser
DEBUG - 2014-02-05 19:40:25 --> Total execution time: 2.2641
DEBUG - 2014-02-05 19:40:33 --> Config Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:40:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:40:33 --> URI Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Router Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Output Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Security Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Input Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:40:33 --> Language Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Loader Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Controller Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:40:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:40:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:40:33 --> Upload Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Image Lib Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:40:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:40:35 --> Final output sent to browser
DEBUG - 2014-02-05 19:40:35 --> Total execution time: 2.3391
DEBUG - 2014-02-05 19:41:20 --> Config Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:41:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:41:20 --> URI Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Router Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Output Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Security Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Input Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:41:20 --> Language Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Loader Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Controller Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:41:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:41:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:20 --> Session Class Initialized
DEBUG - 2014-02-05 19:41:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:41:20 --> Session routines successfully run
DEBUG - 2014-02-05 19:41:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:41:20 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 19:41:20 --> Final output sent to browser
DEBUG - 2014-02-05 19:41:20 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:41:21 --> Config Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:41:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:41:21 --> URI Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Router Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Output Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Security Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Input Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:41:21 --> Language Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Loader Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Controller Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:21 --> Session Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:41:21 --> Session routines successfully run
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:21 --> Final output sent to browser
DEBUG - 2014-02-05 19:41:21 --> Total execution time: 0.0110
DEBUG - 2014-02-05 19:41:21 --> Config Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:41:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:41:21 --> URI Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Router Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Output Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Security Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Input Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:41:21 --> Language Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Loader Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Controller Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:21 --> Session Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:41:21 --> Session routines successfully run
DEBUG - 2014-02-05 19:41:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:41:21 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:21 --> Final output sent to browser
DEBUG - 2014-02-05 19:41:21 --> Total execution time: 0.0300
DEBUG - 2014-02-05 19:41:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:41:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:41:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:41:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:41:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:41:26 --> Total execution time: 0.0410
DEBUG - 2014-02-05 19:41:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:41:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:41:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:41:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:41:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:41:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:41:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:41:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:41:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:41:26 --> Total execution time: 0.0180
DEBUG - 2014-02-05 19:42:17 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:17 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:17 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:17 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:17 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:17 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:17 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 19:42:17 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:17 --> Total execution time: 0.0200
DEBUG - 2014-02-05 19:42:19 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:19 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:19 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:19 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:19 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:19 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:19 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:19 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:19 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:19 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:19 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:19 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:19 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:19 --> Total execution time: 0.0120
DEBUG - 2014-02-05 19:42:19 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:19 --> Total execution time: 0.0180
DEBUG - 2014-02-05 19:42:24 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:24 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:24 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:24 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:24 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:24 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:24 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:24 --> Total execution time: 0.0200
DEBUG - 2014-02-05 19:42:24 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:24 --> Total execution time: 0.0340
DEBUG - 2014-02-05 19:42:35 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:35 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:35 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:35 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:35 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:35 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 19:42:35 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:35 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:42:45 --> Config Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:42:45 --> URI Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Router Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Output Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Security Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Input Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:42:45 --> Language Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Loader Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Controller Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:42:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:42:45 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Model Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:42:45 --> Session Class Initialized
DEBUG - 2014-02-05 19:42:45 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:42:45 --> Session routines successfully run
DEBUG - 2014-02-05 19:42:45 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:42:45 --> Final output sent to browser
DEBUG - 2014-02-05 19:42:45 --> Total execution time: 0.0190
DEBUG - 2014-02-05 19:43:04 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:04 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:04 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:04 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:04 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:04 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:04 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:04 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:04 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-05 19:43:04 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:04 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:43:15 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:15 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:15 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:15 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:15 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:15 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:43:15 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:15 --> Total execution time: 0.0230
DEBUG - 2014-02-05 19:43:20 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:20 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:20 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:20 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:20 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:20 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:43:20 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:20 --> Total execution time: 0.0220
DEBUG - 2014-02-05 19:43:24 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:24 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:24 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:24 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:24 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:24 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:43:24 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:24 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:43:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 19:43:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:26 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:43:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:26 --> Total execution time: 0.0100
DEBUG - 2014-02-05 19:43:27 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:27 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:27 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:27 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:27 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:27 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:27 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:27 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:27 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:43:27 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:27 --> Total execution time: 0.0230
DEBUG - 2014-02-05 19:43:28 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:28 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:28 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:28 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:28 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:28 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:28 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:28 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:28 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 19:43:28 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:28 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:43:30 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:30 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:30 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:30 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:30 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:30 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:30 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 19:43:30 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:30 --> Total execution time: 0.0200
DEBUG - 2014-02-05 19:43:31 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:31 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:31 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:31 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:31 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:31 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:31 --> Total execution time: 0.0110
DEBUG - 2014-02-05 19:43:37 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:37 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:37 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:37 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:37 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:37 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:37 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:37 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:37 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 19:43:37 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:37 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:43:44 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:44 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:44 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:44 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:44 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:44 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:44 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 19:43:44 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:44 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:43:50 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:50 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:50 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:50 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:50 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:50 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:50 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:50 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:50 --> Total execution time: 0.0190
DEBUG - 2014-02-05 19:43:57 --> Config Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:43:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:43:57 --> URI Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Router Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Output Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Security Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Input Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:43:57 --> Language Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Loader Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Controller Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:43:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:43:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Model Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:43:57 --> Session Class Initialized
DEBUG - 2014-02-05 19:43:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:43:57 --> Session routines successfully run
DEBUG - 2014-02-05 19:43:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:43:57 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 19:43:57 --> Final output sent to browser
DEBUG - 2014-02-05 19:43:57 --> Total execution time: 0.0170
DEBUG - 2014-02-05 19:44:25 --> Config Class Initialized
DEBUG - 2014-02-05 19:44:25 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:44:25 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:44:25 --> URI Class Initialized
DEBUG - 2014-02-05 19:44:25 --> Router Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:44:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:44:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:44:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:44:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:44:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 19:44:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:44:26 --> Total execution time: 0.0460
DEBUG - 2014-02-05 19:44:26 --> Config Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:44:26 --> URI Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Router Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Output Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Security Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Input Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:44:26 --> Language Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Loader Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Controller Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:44:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:44:26 --> Session Class Initialized
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:44:26 --> Session routines successfully run
DEBUG - 2014-02-05 19:44:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:44:26 --> Final output sent to browser
DEBUG - 2014-02-05 19:44:26 --> Total execution time: 0.0100
DEBUG - 2014-02-05 19:44:33 --> Config Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:44:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:44:33 --> URI Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Router Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Output Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Security Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Input Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:44:33 --> Language Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Loader Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Controller Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:44:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:44:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:44:33 --> Session Class Initialized
DEBUG - 2014-02-05 19:44:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:44:33 --> Session routines successfully run
DEBUG - 2014-02-05 19:44:33 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:44:33 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-05 19:44:33 --> Final output sent to browser
DEBUG - 2014-02-05 19:44:33 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:44:42 --> Config Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:44:42 --> URI Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Router Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Output Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Security Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Input Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:44:42 --> Language Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Loader Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Controller Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:44:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:44:42 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:44:42 --> Session Class Initialized
DEBUG - 2014-02-05 19:44:42 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:44:42 --> Session routines successfully run
DEBUG - 2014-02-05 19:44:42 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:44:42 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:44:42 --> Final output sent to browser
DEBUG - 2014-02-05 19:44:42 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:44:49 --> Config Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:44:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:44:49 --> URI Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Router Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Output Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Security Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Input Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:44:49 --> Language Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Loader Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Controller Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:44:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:44:49 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:44:49 --> Session Class Initialized
DEBUG - 2014-02-05 19:44:49 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:44:49 --> Session routines successfully run
DEBUG - 2014-02-05 19:44:49 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:44:49 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:44:49 --> Final output sent to browser
DEBUG - 2014-02-05 19:44:49 --> Total execution time: 0.0210
DEBUG - 2014-02-05 19:44:50 --> Config Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:44:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:44:50 --> URI Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Router Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Output Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Security Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Input Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:44:50 --> Language Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Loader Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Controller Class Initialized
DEBUG - 2014-02-05 19:44:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:44:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:44:51 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:51 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:51 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:44:51 --> Model Class Initialized
DEBUG - 2014-02-05 19:44:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:44:51 --> Session Class Initialized
DEBUG - 2014-02-05 19:44:51 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:44:51 --> Session routines successfully run
DEBUG - 2014-02-05 19:44:51 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:44:51 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-05 19:44:51 --> Final output sent to browser
DEBUG - 2014-02-05 19:44:51 --> Total execution time: 0.0180
DEBUG - 2014-02-05 19:45:00 --> Config Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:45:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:45:00 --> URI Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Router Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Output Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Security Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Input Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:45:00 --> Language Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Loader Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Controller Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:45:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:45:00 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:00 --> Session Class Initialized
DEBUG - 2014-02-05 19:45:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:45:00 --> Session routines successfully run
DEBUG - 2014-02-05 19:45:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:45:00 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-05 19:45:00 --> Final output sent to browser
DEBUG - 2014-02-05 19:45:00 --> Total execution time: 0.0120
DEBUG - 2014-02-05 19:45:10 --> Config Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:45:10 --> URI Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Router Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Output Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Security Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Input Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:45:10 --> Language Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Loader Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Controller Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:10 --> Session Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:45:10 --> Session routines successfully run
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:45:10 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 19:45:10 --> Final output sent to browser
DEBUG - 2014-02-05 19:45:10 --> Total execution time: 0.0160
DEBUG - 2014-02-05 19:45:10 --> Config Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:45:10 --> URI Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Config Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Router Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:45:10 --> URI Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Output Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Router Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Security Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Input Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Output Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:45:10 --> Security Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Language Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Input Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Loader Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:45:10 --> Controller Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Language Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:45:10 --> Loader Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:45:10 --> Controller Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:10 --> Session Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:45:10 --> Session Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Session routines successfully run
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:45:10 --> Session routines successfully run
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:45:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:10 --> Final output sent to browser
DEBUG - 2014-02-05 19:45:10 --> Total execution time: 0.0130
DEBUG - 2014-02-05 19:45:10 --> Final output sent to browser
DEBUG - 2014-02-05 19:45:10 --> Total execution time: 0.0230
DEBUG - 2014-02-05 19:45:15 --> Config Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:45:15 --> URI Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Router Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Output Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Security Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Input Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:45:15 --> Language Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Loader Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Controller Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:15 --> Session Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:45:15 --> Session routines successfully run
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:45:15 --> Config Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 19:45:15 --> URI Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Router Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Output Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Security Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Input Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 19:45:15 --> Language Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Loader Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Controller Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:15 --> Session Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 19:45:15 --> Session routines successfully run
DEBUG - 2014-02-05 19:45:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 19:45:15 --> Model Class Initialized
DEBUG - 2014-02-05 19:45:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 19:45:15 --> Final output sent to browser
DEBUG - 2014-02-05 19:45:15 --> Total execution time: 0.0175
DEBUG - 2014-02-05 19:45:15 --> Final output sent to browser
DEBUG - 2014-02-05 19:45:15 --> Total execution time: 0.0455
DEBUG - 2014-02-05 20:02:17 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:17 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:17 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:17 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:17 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 20:02:17 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:17 --> Total execution time: 0.0250
DEBUG - 2014-02-05 20:02:17 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:17 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:17 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:17 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:17 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:17 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:17 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:17 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:17 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:17 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:17 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:17 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:17 --> Total execution time: 0.0140
DEBUG - 2014-02-05 20:02:17 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:17 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:17 --> Total execution time: 0.0170
DEBUG - 2014-02-05 20:02:17 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:17 --> Total execution time: 0.0240
DEBUG - 2014-02-05 20:02:22 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:22 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:22 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:22 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:22 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:22 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:22 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:22 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:22 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:22 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:22 --> Total execution time: 0.0350
DEBUG - 2014-02-05 20:02:22 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:22 --> Total execution time: 0.0420
DEBUG - 2014-02-05 20:02:59 --> Config Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:02:59 --> URI Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Router Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Output Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Security Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Input Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:02:59 --> Language Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Loader Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Controller Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:02:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:02:59 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Model Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:02:59 --> Session Class Initialized
DEBUG - 2014-02-05 20:02:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:02:59 --> Session routines successfully run
DEBUG - 2014-02-05 20:02:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:02:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 20:02:59 --> Final output sent to browser
DEBUG - 2014-02-05 20:02:59 --> Total execution time: 0.0190
DEBUG - 2014-02-05 20:03:01 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:01 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:01 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:01 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:01 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:01 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:01 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:01 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:01 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:01 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:01 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:01 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:01 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:01 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:01 --> Total execution time: 0.0140
DEBUG - 2014-02-05 20:03:01 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:01 --> Total execution time: 0.0180
DEBUG - 2014-02-05 20:03:01 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:01 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:01 --> Total execution time: 0.0280
DEBUG - 2014-02-05 20:03:06 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:06 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:06 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:06 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:06 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:06 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:06 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:06 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:06 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:06 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:06 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:06 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:06 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:06 --> Total execution time: 0.0210
DEBUG - 2014-02-05 20:03:06 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:06 --> Total execution time: 0.0310
DEBUG - 2014-02-05 20:03:30 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:30 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:30 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:30 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:30 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:30 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:30 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:30 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:30 --> Total execution time: 0.0320
DEBUG - 2014-02-05 20:03:32 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:32 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:32 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:32 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:32 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:32 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:32 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:32 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:32 --> Total execution time: 0.0220
DEBUG - 2014-02-05 20:03:47 --> Config Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:03:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:03:47 --> URI Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Router Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Output Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Security Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Input Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:03:47 --> Language Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Loader Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Controller Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:03:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:03:47 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:47 --> Session Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:03:47 --> Session routines successfully run
DEBUG - 2014-02-05 20:03:47 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:03:47 --> Model Class Initialized
DEBUG - 2014-02-05 20:03:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:03:47 --> Final output sent to browser
DEBUG - 2014-02-05 20:03:47 --> Total execution time: 0.0260
DEBUG - 2014-02-05 20:04:00 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:00 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:00 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:00 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:00 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:00 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:00 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:00 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:00 --> Total execution time: 0.0190
DEBUG - 2014-02-05 20:04:02 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:02 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:02 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:02 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:02 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:02 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:02 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:02 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:02 --> Total execution time: 0.0170
DEBUG - 2014-02-05 20:04:37 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:37 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:37 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:37 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:37 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:37 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:37 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:37 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:37 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 20:04:37 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:37 --> Total execution time: 0.0200
DEBUG - 2014-02-05 20:04:38 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:38 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:38 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:38 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:38 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:38 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:38 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:38 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:38 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:38 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:38 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:38 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:38 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:38 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:38 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:38 --> Total execution time: 0.0235
DEBUG - 2014-02-05 20:04:38 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:38 --> Total execution time: 0.0235
DEBUG - 2014-02-05 20:04:38 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:38 --> Total execution time: 0.0320
DEBUG - 2014-02-05 20:04:43 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Config Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:04:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:04:43 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:43 --> URI Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Router Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Output Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Security Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Input Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:04:43 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Language Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Loader Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Controller Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:43 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Session Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:04:43 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:43 --> Session routines successfully run
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:04:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:04:43 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:43 --> Total execution time: 0.0210
DEBUG - 2014-02-05 20:04:43 --> Final output sent to browser
DEBUG - 2014-02-05 20:04:43 --> Total execution time: 0.0310
DEBUG - 2014-02-05 20:06:35 --> Config Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:06:35 --> URI Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Router Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Output Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Security Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Input Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:06:35 --> Language Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Loader Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Controller Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Session Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:06:35 --> Session routines successfully run
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:06:35 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 20:06:35 --> Final output sent to browser
DEBUG - 2014-02-05 20:06:35 --> Total execution time: 0.0140
DEBUG - 2014-02-05 20:06:35 --> Config Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:06:35 --> URI Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Config Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Router Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Config Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Output Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:06:35 --> Security Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:06:35 --> URI Class Initialized
DEBUG - 2014-02-05 20:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:06:35 --> Input Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:06:35 --> Language Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Loader Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Controller Class Initialized
DEBUG - 2014-02-05 20:06:35 --> URI Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:06:35 --> Router Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:06:35 --> Router Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Output Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Security Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Input Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Output Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Security Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Input Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:06:35 --> Language Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Loader Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Controller Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:06:35 --> Session Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Language Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:06:35 --> Session routines successfully run
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:06:35 --> Loader Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Controller Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Session Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:06:35 --> Session Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Session routines successfully run
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:06:35 --> Session routines successfully run
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:06:35 --> Final output sent to browser
DEBUG - 2014-02-05 20:06:35 --> Total execution time: 0.0180
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Config Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:06:35 --> URI Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Router Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Output Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Security Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Input Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:06:35 --> Language Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Loader Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Controller Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Final output sent to browser
DEBUG - 2014-02-05 20:06:35 --> Total execution time: 0.0320
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Session Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:06:35 --> Session routines successfully run
DEBUG - 2014-02-05 20:06:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:06:35 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:35 --> Final output sent to browser
DEBUG - 2014-02-05 20:06:35 --> Total execution time: 0.0240
DEBUG - 2014-02-05 20:06:35 --> Final output sent to browser
DEBUG - 2014-02-05 20:06:35 --> Total execution time: 0.0475
DEBUG - 2014-02-05 20:06:40 --> Config Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:06:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:06:40 --> URI Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Router Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Output Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Security Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Input Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:06:40 --> Language Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Loader Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Controller Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:06:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:06:40 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:40 --> Session Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:06:40 --> Session routines successfully run
DEBUG - 2014-02-05 20:06:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:06:40 --> Model Class Initialized
DEBUG - 2014-02-05 20:06:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:06:40 --> Final output sent to browser
DEBUG - 2014-02-05 20:06:40 --> Total execution time: 0.0180
DEBUG - 2014-02-05 20:07:57 --> Config Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:07:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:07:57 --> URI Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Router Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Output Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Security Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Input Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:07:57 --> Language Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Loader Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Controller Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:07:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:07:57 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:57 --> Session Class Initialized
DEBUG - 2014-02-05 20:07:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:07:57 --> Session routines successfully run
DEBUG - 2014-02-05 20:07:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:07:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-05 20:07:57 --> Final output sent to browser
DEBUG - 2014-02-05 20:07:57 --> Total execution time: 0.0210
DEBUG - 2014-02-05 20:07:58 --> Config Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:07:58 --> Config Class Initialized
DEBUG - 2014-02-05 20:07:58 --> URI Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Router Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:07:58 --> URI Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Router Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Output Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Output Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Security Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Input Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Security Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Config Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Input Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:07:58 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Language Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Language Class Initialized
DEBUG - 2014-02-05 20:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:07:58 --> Loader Class Initialized
DEBUG - 2014-02-05 20:07:58 --> URI Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Loader Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Controller Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Controller Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Router Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:07:58 --> Output Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Security Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Input Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:07:58 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Language Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Loader Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Controller Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:07:58 --> Session Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Session routines successfully run
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:07:58 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:58 --> Session Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:07:58 --> Session routines successfully run
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:58 --> Session Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:07:58 --> Session routines successfully run
DEBUG - 2014-02-05 20:07:58 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:07:58 --> Model Class Initialized
DEBUG - 2014-02-05 20:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:07:58 --> Final output sent to browser
DEBUG - 2014-02-05 20:07:58 --> Total execution time: 0.0200
DEBUG - 2014-02-05 20:07:58 --> Final output sent to browser
DEBUG - 2014-02-05 20:07:58 --> Total execution time: 0.0190
DEBUG - 2014-02-05 20:07:58 --> Final output sent to browser
DEBUG - 2014-02-05 20:07:58 --> Total execution time: 0.0270
DEBUG - 2014-02-05 20:08:03 --> Config Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:08:03 --> URI Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Router Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Output Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Security Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Input Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:08:03 --> Language Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Config Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Loader Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Controller Class Initialized
DEBUG - 2014-02-05 20:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:08:03 --> URI Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:08:03 --> Router Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Output Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Security Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Input Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:08:03 --> Language Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Loader Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:08:03 --> Controller Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:08:03 --> Session Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:08:03 --> Session routines successfully run
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:08:03 --> Session Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:08:03 --> Session routines successfully run
DEBUG - 2014-02-05 20:08:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:08:03 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:08:03 --> Final output sent to browser
DEBUG - 2014-02-05 20:08:03 --> Total execution time: 0.0250
DEBUG - 2014-02-05 20:08:03 --> Final output sent to browser
DEBUG - 2014-02-05 20:08:03 --> Total execution time: 0.0240
DEBUG - 2014-02-05 20:08:42 --> Config Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:08:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:08:42 --> URI Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Router Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Output Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Security Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Input Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:08:42 --> Language Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Loader Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Controller Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:08:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:08:42 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:08:42 --> Session Class Initialized
DEBUG - 2014-02-05 20:08:42 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:08:42 --> Session routines successfully run
DEBUG - 2014-02-05 20:08:42 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:08:42 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-05 20:08:42 --> Final output sent to browser
DEBUG - 2014-02-05 20:08:42 --> Total execution time: 0.0200
DEBUG - 2014-02-05 20:08:43 --> Config Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 20:08:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 20:08:43 --> URI Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Router Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Output Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Security Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Input Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 20:08:43 --> Language Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Loader Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Controller Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-05 20:08:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-05 20:08:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Model Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-05 20:08:43 --> Session Class Initialized
DEBUG - 2014-02-05 20:08:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 20:08:43 --> Session routines successfully run
DEBUG - 2014-02-05 20:08:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 20:08:43 --> Final output sent to browser
DEBUG - 2014-02-05 20:08:43 --> Total execution time: 0.0100
