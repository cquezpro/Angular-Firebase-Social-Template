<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-23 22:48:33 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-23 22:48:33 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:33 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:33 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:33 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:33 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:33 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:34 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:34 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:34 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:34 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:34 --> Total execution time: 0.6700
DEBUG - 2014-03-23 22:48:34 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:34 --> Total execution time: 0.6790
DEBUG - 2014-03-23 22:48:34 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:34 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:34 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:34 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:34 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:34 --> Total execution time: 0.0220
DEBUG - 2014-03-23 22:48:34 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:34 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:34 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:34 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:34 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:34 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:34 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:34 --> Total execution time: 0.0160
DEBUG - 2014-03-23 22:48:34 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:34 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:34 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:34 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:34 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:34 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:34 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:34 --> Total execution time: 0.0230
DEBUG - 2014-03-23 22:48:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:34 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:34 --> Total execution time: 0.0460
DEBUG - 2014-03-23 22:48:39 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:39 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:39 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:39 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:39 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:39 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:39 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:39 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:39 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:39 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:39 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:39 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:39 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:39 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:39 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:39 --> Total execution time: 0.0130
DEBUG - 2014-03-23 22:48:39 --> Total execution time: 0.0140
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:39 --> Session Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:48:39 --> A session cookie was not found.
DEBUG - 2014-03-23 22:48:39 --> Session routines successfully run
DEBUG - 2014-03-23 22:48:39 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:48:39 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:39 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:39 --> Total execution time: 0.0280
DEBUG - 2014-03-23 22:48:47 --> Config Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:48:47 --> URI Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Router Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Output Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Security Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Input Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:48:47 --> Language Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Loader Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Controller Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:48:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:48:47 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Model Class Initialized
DEBUG - 2014-03-23 22:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:48:48 --> Final output sent to browser
DEBUG - 2014-03-23 22:48:48 --> Total execution time: 1.0651
DEBUG - 2014-03-23 22:59:16 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:16 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:16 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:16 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:16 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:16 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:16 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:16 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:16 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:16 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:16 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:16 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:16 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:16 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:16 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:16 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:16 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:16 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:16 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:16 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:16 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:16 --> Total execution time: 0.0150
DEBUG - 2014-03-23 22:59:16 --> Total execution time: 0.0130
DEBUG - 2014-03-23 22:59:16 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:16 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:16 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:16 --> Total execution time: 0.0170
DEBUG - 2014-03-23 22:59:17 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:17 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:17 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:17 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:17 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:17 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:17 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:17 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:17 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:17 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:17 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:17 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:17 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Total execution time: 0.0120
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:17 --> Total execution time: 0.0130
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:17 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:17 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:17 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:17 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:17 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:17 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:17 --> Total execution time: 0.0140
DEBUG - 2014-03-23 22:59:20 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:20 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:20 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:20 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:20 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:20 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:20 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:20 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:20 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:20 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:20 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:20 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:20 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:20 --> Session Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:20 --> Total execution time: 0.0140
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: string_helper
DEBUG - 2014-03-23 22:59:20 --> A session cookie was not found.
DEBUG - 2014-03-23 22:59:20 --> Session routines successfully run
DEBUG - 2014-03-23 22:59:20 --> Helper loaded: url_helper
DEBUG - 2014-03-23 22:59:20 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:20 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:20 --> Total execution time: 0.0150
DEBUG - 2014-03-23 22:59:20 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:20 --> Total execution time: 0.0160
DEBUG - 2014-03-23 22:59:26 --> Config Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Hooks Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Utf8 Class Initialized
DEBUG - 2014-03-23 22:59:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 22:59:26 --> URI Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Router Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Output Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Security Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Input Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 22:59:26 --> Language Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Loader Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Controller Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 22:59:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 22:59:26 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Database Driver Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Model Class Initialized
DEBUG - 2014-03-23 22:59:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 22:59:27 --> Final output sent to browser
DEBUG - 2014-03-23 22:59:27 --> Total execution time: 0.9481
DEBUG - 2014-03-23 23:01:06 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:06 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:06 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:06 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:06 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:06 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:06 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:06 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:06 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:06 --> Session Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:01:06 --> Session Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:06 --> A session cookie was not found.
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:01:06 --> Session routines successfully run
DEBUG - 2014-03-23 23:01:06 --> A session cookie was not found.
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:01:06 --> Session Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Session routines successfully run
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:06 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:06 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:01:06 --> A session cookie was not found.
DEBUG - 2014-03-23 23:01:06 --> Session routines successfully run
DEBUG - 2014-03-23 23:01:06 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:01:06 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:06 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:01:06 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:06 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:06 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:01:07 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:07 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:07 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:07 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:07 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:07 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:07 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:07 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:07 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:07 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:07 --> Session Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> A session cookie was not found.
DEBUG - 2014-03-23 23:01:07 --> Session routines successfully run
DEBUG - 2014-03-23 23:01:07 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Session Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:07 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:01:07 --> A session cookie was not found.
DEBUG - 2014-03-23 23:01:07 --> Session Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Session routines successfully run
DEBUG - 2014-03-23 23:01:07 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:01:07 --> A session cookie was not found.
DEBUG - 2014-03-23 23:01:07 --> Session routines successfully run
DEBUG - 2014-03-23 23:01:07 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:07 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:01:07 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:01:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:07 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:07 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:01:15 --> Config Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:01:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:01:15 --> URI Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Router Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Output Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Security Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Input Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:01:15 --> Language Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Loader Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Controller Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:01:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:01:15 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Model Class Initialized
DEBUG - 2014-03-23 23:01:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:01:16 --> Final output sent to browser
DEBUG - 2014-03-23 23:01:16 --> Total execution time: 0.9451
DEBUG - 2014-03-23 23:27:40 --> Config Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:27:40 --> URI Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Router Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Output Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Config Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Security Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Input Class Initialized
DEBUG - 2014-03-23 23:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:27:40 --> URI Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Config Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Router Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Language Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:27:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:27:40 --> Output Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Loader Class Initialized
DEBUG - 2014-03-23 23:27:40 --> URI Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Controller Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Security Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Router Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Input Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:27:40 --> Language Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Output Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Loader Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Security Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Controller Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:27:40 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Input Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:27:40 --> Language Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:27:40 --> Loader Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Session Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Controller Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:27:40 --> A session cookie was not found.
DEBUG - 2014-03-23 23:27:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:27:40 --> Session routines successfully run
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Session Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:27:40 --> A session cookie was not found.
DEBUG - 2014-03-23 23:27:40 --> Session routines successfully run
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Final output sent to browser
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:27:40 --> Total execution time: 0.0100
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Final output sent to browser
DEBUG - 2014-03-23 23:27:40 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:27:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:27:40 --> Session Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:27:40 --> A session cookie was not found.
DEBUG - 2014-03-23 23:27:40 --> Session routines successfully run
DEBUG - 2014-03-23 23:27:40 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:27:40 --> Model Class Initialized
DEBUG - 2014-03-23 23:27:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:27:40 --> Final output sent to browser
DEBUG - 2014-03-23 23:27:40 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:30:02 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:02 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:02 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:02 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:02 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:02 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:02 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:02 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:02 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:02 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:02 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:02 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:02 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:02 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:02 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:30:02 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:02 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:02 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:02 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:02 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:30:02 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:02 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:30:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:45 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:45 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:45 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:45 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:45 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:45 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:45 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:30:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:45 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:30:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:45 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:30:49 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:49 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:49 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:49 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:49 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:49 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:49 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:49 --> Session Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:49 --> A session cookie was not found.
DEBUG - 2014-03-23 23:30:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:49 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:49 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Session routines successfully run
DEBUG - 2014-03-23 23:30:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:49 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:30:49 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:30:49 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:49 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:49 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:30:49 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:49 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:30:57 --> Config Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:30:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:30:57 --> URI Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Router Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Output Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Security Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Input Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:30:57 --> Language Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Loader Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Controller Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:30:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:30:57 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Model Class Initialized
DEBUG - 2014-03-23 23:30:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:30:58 --> Final output sent to browser
DEBUG - 2014-03-23 23:30:58 --> Total execution time: 0.9571
DEBUG - 2014-03-23 23:32:42 --> Config Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:32:42 --> URI Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Router Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Output Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Config Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Config Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:32:42 --> Input Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:32:42 --> URI Class Initialized
DEBUG - 2014-03-23 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:32:42 --> Router Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Language Class Initialized
DEBUG - 2014-03-23 23:32:42 --> URI Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Router Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Output Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Loader Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Controller Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Input Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:32:42 --> Output Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Language Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:32:42 --> Security Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Input Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Loader Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Controller Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:32:42 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:32:42 --> Language Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Loader Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Controller Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:42 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Session Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> A session cookie was not found.
DEBUG - 2014-03-23 23:32:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:42 --> Session routines successfully run
DEBUG - 2014-03-23 23:32:42 --> Session Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:32:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Session Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:32:42 --> A session cookie was not found.
DEBUG - 2014-03-23 23:32:42 --> A session cookie was not found.
DEBUG - 2014-03-23 23:32:42 --> Final output sent to browser
DEBUG - 2014-03-23 23:32:42 --> Session routines successfully run
DEBUG - 2014-03-23 23:32:42 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:32:42 --> Session routines successfully run
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:32:42 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:42 --> Final output sent to browser
DEBUG - 2014-03-23 23:32:42 --> Final output sent to browser
DEBUG - 2014-03-23 23:32:42 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:32:42 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:32:44 --> Config Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Config Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:32:44 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:32:44 --> URI Class Initialized
DEBUG - 2014-03-23 23:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:32:44 --> Router Class Initialized
DEBUG - 2014-03-23 23:32:44 --> URI Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Router Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Output Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Output Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Security Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Config Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Input Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Security Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:32:44 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Input Class Initialized
DEBUG - 2014-03-23 23:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:32:44 --> Language Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:32:44 --> URI Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Language Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Loader Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Router Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Controller Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Loader Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Controller Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:32:44 --> Output Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:32:44 --> Security Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Input Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Language Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Loader Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Controller Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Session Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:32:44 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:32:44 --> A session cookie was not found.
DEBUG - 2014-03-23 23:32:44 --> Session routines successfully run
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:44 --> Session Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:32:44 --> Final output sent to browser
DEBUG - 2014-03-23 23:32:44 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:32:44 --> Session Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:32:44 --> A session cookie was not found.
DEBUG - 2014-03-23 23:32:44 --> A session cookie was not found.
DEBUG - 2014-03-23 23:32:44 --> Session routines successfully run
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:32:44 --> Session routines successfully run
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:32:44 --> Final output sent to browser
DEBUG - 2014-03-23 23:32:44 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:32:44 --> Final output sent to browser
DEBUG - 2014-03-23 23:32:44 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:34:44 --> Config Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:34:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:34:44 --> URI Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Router Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Output Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Security Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Input Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:34:44 --> Language Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Loader Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Controller Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:34:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:34:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:34:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:34:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:34:45 --> Total execution time: 1.0691
DEBUG - 2014-03-23 23:46:34 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:34 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:34 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:34 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:34 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:34 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:34 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:34 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:34 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:34 --> Session Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Session Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> A session cookie was not found.
DEBUG - 2014-03-23 23:46:34 --> A session cookie was not found.
DEBUG - 2014-03-23 23:46:34 --> Session routines successfully run
DEBUG - 2014-03-23 23:46:34 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Session routines successfully run
DEBUG - 2014-03-23 23:46:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:34 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:46:34 --> Session Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:46:34 --> A session cookie was not found.
DEBUG - 2014-03-23 23:46:34 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:34 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:46:34 --> Session routines successfully run
DEBUG - 2014-03-23 23:46:34 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:46:34 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:34 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:34 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:46:36 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:36 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:36 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:36 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:36 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:36 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:36 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:36 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:36 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:36 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:36 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:36 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:36 --> Session Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:46:36 --> A session cookie was not found.
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:36 --> Session routines successfully run
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:36 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:36 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:36 --> Session Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Session Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:46:36 --> A session cookie was not found.
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:46:36 --> A session cookie was not found.
DEBUG - 2014-03-23 23:46:36 --> Session routines successfully run
DEBUG - 2014-03-23 23:46:36 --> Session routines successfully run
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:46:36 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:36 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:36 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:36 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:46:36 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:46:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:45 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:46:56 --> Config Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:46:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:46:56 --> URI Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Router Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Output Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Security Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Input Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:46:56 --> Language Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Loader Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Controller Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:46:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:46:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:46:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:46:57 --> Final output sent to browser
DEBUG - 2014-03-23 23:46:57 --> Total execution time: 1.1321
DEBUG - 2014-03-23 23:49:08 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:08 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:08 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:08 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:08 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:08 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:08 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:08 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:08 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:08 --> Session Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Session Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:49:08 --> A session cookie was not found.
DEBUG - 2014-03-23 23:49:08 --> A session cookie was not found.
DEBUG - 2014-03-23 23:49:08 --> Session routines successfully run
DEBUG - 2014-03-23 23:49:08 --> Session routines successfully run
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:08 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:08 --> Session Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:49:08 --> A session cookie was not found.
DEBUG - 2014-03-23 23:49:08 --> Session routines successfully run
DEBUG - 2014-03-23 23:49:08 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:49:08 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:08 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:08 --> Total execution time: 0.0180
DEBUG - 2014-03-23 23:49:08 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:08 --> Total execution time: 0.0200
DEBUG - 2014-03-23 23:49:08 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:08 --> Total execution time: 0.0280
DEBUG - 2014-03-23 23:49:09 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:09 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:09 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:09 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:09 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:09 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:09 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:09 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:09 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Session Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> A session cookie was not found.
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:09 --> Session routines successfully run
DEBUG - 2014-03-23 23:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:49:09 --> Session Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:49:09 --> A session cookie was not found.
DEBUG - 2014-03-23 23:49:09 --> Session routines successfully run
DEBUG - 2014-03-23 23:49:09 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:09 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:49:09 --> Total execution time: 0.0110
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:09 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:09 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:09 --> Session Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:49:09 --> A session cookie was not found.
DEBUG - 2014-03-23 23:49:09 --> Session routines successfully run
DEBUG - 2014-03-23 23:49:09 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:49:09 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:09 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:09 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:49:24 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:24 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:24 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:24 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:24 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:24 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:49:42 --> Config Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:49:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:49:42 --> URI Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Router Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Output Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Security Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Input Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:49:42 --> Language Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Loader Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Controller Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:49:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:49:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Helper loaded: email_helper
DEBUG - 2014-03-23 23:49:42 --> Model Class Initialized
DEBUG - 2014-03-23 23:49:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:49:44 --> Final output sent to browser
DEBUG - 2014-03-23 23:49:44 --> Total execution time: 1.8621
DEBUG - 2014-03-23 23:50:23 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:23 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:23 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Image Lib Class Initialized
DEBUG - 2014-03-23 23:50:23 --> Final output sent to browser
DEBUG - 2014-03-23 23:50:23 --> Total execution time: 0.1670
DEBUG - 2014-03-23 23:50:25 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:25 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:25 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:25 --> Image Lib Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:26 --> Final output sent to browser
DEBUG - 2014-03-23 23:50:26 --> Total execution time: 0.9781
DEBUG - 2014-03-23 23:50:26 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:26 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:26 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:26 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:30 --> Final output sent to browser
DEBUG - 2014-03-23 23:50:30 --> Total execution time: 3.8992
DEBUG - 2014-03-23 23:50:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:45 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:45 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:45 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Session Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:50:45 --> A session cookie was not found.
DEBUG - 2014-03-23 23:50:45 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:45 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Session routines successfully run
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:50:45 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:50:45 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:50:45 --> Session Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:50:45 --> A session cookie was not found.
DEBUG - 2014-03-23 23:50:45 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Session routines successfully run
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:45 --> Session Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:50:45 --> A session cookie was not found.
DEBUG - 2014-03-23 23:50:45 --> Session routines successfully run
DEBUG - 2014-03-23 23:50:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:50:45 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:50:45 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:50:45 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:50:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:50:45 --> Total execution time: 0.0180
DEBUG - 2014-03-23 23:50:56 --> Config Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:50:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:50:56 --> URI Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Router Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Output Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Security Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Input Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:50:56 --> Language Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Loader Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Controller Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:50:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:50:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Helper loaded: email_helper
DEBUG - 2014-03-23 23:50:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:50:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:07 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:07 --> Total execution time: 11.0346
DEBUG - 2014-03-23 23:51:12 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:12 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:12 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:12 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Image Lib Class Initialized
DEBUG - 2014-03-23 23:51:12 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:12 --> Total execution time: 0.1390
DEBUG - 2014-03-23 23:51:20 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:20 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:20 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:20 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:20 --> Image Lib Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:21 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:21 --> Total execution time: 1.0021
DEBUG - 2014-03-23 23:51:21 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:21 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:21 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:21 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:22 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:22 --> Total execution time: 0.9651
DEBUG - 2014-03-23 23:51:41 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:41 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:41 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:41 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:41 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:41 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:41 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:41 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:41 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:41 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Session Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:51:41 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:41 --> A session cookie was not found.
DEBUG - 2014-03-23 23:51:41 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Session routines successfully run
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:41 --> Session Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Session Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:51:41 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:51:41 --> A session cookie was not found.
DEBUG - 2014-03-23 23:51:41 --> A session cookie was not found.
DEBUG - 2014-03-23 23:51:41 --> Session routines successfully run
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Session routines successfully run
DEBUG - 2014-03-23 23:51:41 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:41 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:41 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:41 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:51:41 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:41 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:51:53 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:53 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:53 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:53 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Helper loaded: email_helper
DEBUG - 2014-03-23 23:51:53 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:51:55 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:55 --> Total execution time: 1.8321
DEBUG - 2014-03-23 23:51:59 --> Config Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:51:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:51:59 --> URI Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Router Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Output Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Security Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Input Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:51:59 --> Language Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Loader Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Controller Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:51:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:51:59 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Model Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Image Lib Class Initialized
DEBUG - 2014-03-23 23:51:59 --> Final output sent to browser
DEBUG - 2014-03-23 23:51:59 --> Total execution time: 0.1380
DEBUG - 2014-03-23 23:52:01 --> Config Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:52:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:52:01 --> URI Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Router Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Output Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Security Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Input Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:52:01 --> Language Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Loader Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Controller Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:52:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:52:01 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:52:01 --> Image Lib Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:52:02 --> Final output sent to browser
DEBUG - 2014-03-23 23:52:02 --> Total execution time: 0.9901
DEBUG - 2014-03-23 23:52:02 --> Config Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:52:02 --> URI Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Router Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Output Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Security Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Input Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:52:02 --> Language Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Loader Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Controller Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:52:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:52:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Model Class Initialized
DEBUG - 2014-03-23 23:52:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:52:03 --> Final output sent to browser
DEBUG - 2014-03-23 23:52:03 --> Total execution time: 0.9261
DEBUG - 2014-03-23 23:57:23 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:23 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:23 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:23 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:23 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:23 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:23 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:23 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:23 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:23 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:23 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:23 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:23 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:23 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:23 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:23 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:23 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:57:23 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:23 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:23 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:23 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:23 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:23 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:23 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:23 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:23 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:57:25 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:25 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:25 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:25 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:25 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:25 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:25 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:25 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:25 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:25 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:25 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:25 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:25 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:25 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:25 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:25 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:25 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:25 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:25 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:25 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:25 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:25 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:25 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:25 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:25 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:25 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:57:28 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:28 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:28 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:28 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:28 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:28 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:28 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:28 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:28 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:28 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:28 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:28 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:28 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:28 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Session Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:28 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:57:28 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:28 --> A session cookie was not found.
DEBUG - 2014-03-23 23:57:28 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:28 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:57:28 --> Session routines successfully run
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:28 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:28 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:28 --> Total execution time: 0.0150
DEBUG - 2014-03-23 23:57:28 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:28 --> Total execution time: 0.0140
DEBUG - 2014-03-23 23:57:44 --> Config Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:57:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:57:44 --> URI Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Router Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Output Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Security Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Input Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:57:44 --> Language Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Loader Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Controller Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:57:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:57:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Model Class Initialized
DEBUG - 2014-03-23 23:57:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:57:45 --> Final output sent to browser
DEBUG - 2014-03-23 23:57:45 --> Total execution time: 0.9641
DEBUG - 2014-03-23 23:58:55 --> Config Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:58:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:58:55 --> Config Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:58:55 --> URI Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Router Class Initialized
DEBUG - 2014-03-23 23:58:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:58:55 --> URI Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Router Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Output Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Config Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Security Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Output Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Security Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Input Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:58:55 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Input Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:58:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:58:55 --> Language Class Initialized
DEBUG - 2014-03-23 23:58:55 --> URI Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Router Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Loader Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Language Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Output Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Loader Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Security Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Controller Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Controller Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Input Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:58:55 --> Language Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Loader Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Controller Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:58:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:58:55 --> Session Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:58:55 --> A session cookie was not found.
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Session routines successfully run
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Session Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:58:55 --> A session cookie was not found.
DEBUG - 2014-03-23 23:58:55 --> Session routines successfully run
DEBUG - 2014-03-23 23:58:55 --> Final output sent to browser
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:58:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:55 --> Final output sent to browser
DEBUG - 2014-03-23 23:58:55 --> Session Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Total execution time: 0.0160
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:58:55 --> A session cookie was not found.
DEBUG - 2014-03-23 23:58:55 --> Session routines successfully run
DEBUG - 2014-03-23 23:58:55 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:58:55 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:55 --> Final output sent to browser
DEBUG - 2014-03-23 23:58:55 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:58:56 --> Config Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Config Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:58:56 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:58:56 --> URI Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Router Class Initialized
DEBUG - 2014-03-23 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:58:56 --> URI Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Output Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Router Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Security Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Config Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Input Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Output Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:58:56 --> Security Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Language Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Input Class Initialized
DEBUG - 2014-03-23 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:58:56 --> URI Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Loader Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:58:56 --> Controller Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Language Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Router Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Loader Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:58:56 --> Output Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Controller Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Security Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:58:56 --> Input Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:58:56 --> Language Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Loader Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Controller Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:58:56 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Session Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:58:56 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:58:56 --> A session cookie was not found.
DEBUG - 2014-03-23 23:58:56 --> Session Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Session routines successfully run
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:56 --> Session Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:58:56 --> A session cookie was not found.
DEBUG - 2014-03-23 23:58:56 --> Session routines successfully run
DEBUG - 2014-03-23 23:58:56 --> Final output sent to browser
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: string_helper
DEBUG - 2014-03-23 23:58:56 --> Total execution time: 0.0130
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:56 --> A session cookie was not found.
DEBUG - 2014-03-23 23:58:56 --> Session routines successfully run
DEBUG - 2014-03-23 23:58:56 --> Helper loaded: url_helper
DEBUG - 2014-03-23 23:58:56 --> Final output sent to browser
DEBUG - 2014-03-23 23:58:56 --> Total execution time: 0.0120
DEBUG - 2014-03-23 23:58:56 --> Model Class Initialized
DEBUG - 2014-03-23 23:58:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:58:56 --> Final output sent to browser
DEBUG - 2014-03-23 23:58:56 --> Total execution time: 0.0170
DEBUG - 2014-03-23 23:59:07 --> Config Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Hooks Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Utf8 Class Initialized
DEBUG - 2014-03-23 23:59:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-23 23:59:07 --> URI Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Router Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Output Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Security Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Input Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-23 23:59:07 --> Language Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Loader Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Controller Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-23 23:59:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-23 23:59:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Database Driver Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Model Class Initialized
DEBUG - 2014-03-23 23:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-23 23:59:08 --> Final output sent to browser
DEBUG - 2014-03-23 23:59:08 --> Total execution time: 0.9631
