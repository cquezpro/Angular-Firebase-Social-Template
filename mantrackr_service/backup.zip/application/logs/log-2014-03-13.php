<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-13 06:00:05 --> Config Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Config Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Hooks Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-13 06:00:05 --> Config Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:00:05 --> URI Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Router Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:00:05 --> Output Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:00:05 --> URI Class Initialized
DEBUG - 2014-03-13 06:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:00:05 --> Security Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Router Class Initialized
DEBUG - 2014-03-13 06:00:05 --> URI Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Input Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:00:05 --> Output Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Language Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Router Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Security Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Input Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Loader Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:00:05 --> Controller Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Language Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Output Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:00:05 --> Loader Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Security Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Controller Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Input Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:00:05 --> Language Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Loader Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Controller Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:05 --> Session Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Session Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:00:05 --> A session cookie was not found.
DEBUG - 2014-03-13 06:00:05 --> A session cookie was not found.
DEBUG - 2014-03-13 06:00:05 --> Session routines successfully run
DEBUG - 2014-03-13 06:00:05 --> Session routines successfully run
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Session Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:00:05 --> A session cookie was not found.
DEBUG - 2014-03-13 06:00:05 --> Session routines successfully run
DEBUG - 2014-03-13 06:00:05 --> Final output sent to browser
DEBUG - 2014-03-13 06:00:05 --> Total execution time: 0.0160
DEBUG - 2014-03-13 06:00:05 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:00:05 --> Final output sent to browser
DEBUG - 2014-03-13 06:00:05 --> Total execution time: 0.0170
DEBUG - 2014-03-13 06:00:05 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:05 --> Final output sent to browser
DEBUG - 2014-03-13 06:00:05 --> Total execution time: 0.0170
DEBUG - 2014-03-13 06:00:25 --> Config Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Config Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Config Class Initialized
DEBUG - 2014-03-13 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:00:25 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:00:25 --> URI Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:00:25 --> URI Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Router Class Initialized
DEBUG - 2014-03-13 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:00:25 --> Router Class Initialized
DEBUG - 2014-03-13 06:00:25 --> URI Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Router Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Output Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Output Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Output Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Security Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Security Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Security Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Input Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Input Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Input Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:00:25 --> Language Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Language Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Language Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Loader Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Loader Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Controller Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Loader Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Controller Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:00:25 --> Controller Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:00:25 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:25 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Session Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:25 --> A session cookie was not found.
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Session routines successfully run
DEBUG - 2014-03-13 06:00:25 --> Session Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:00:25 --> A session cookie was not found.
DEBUG - 2014-03-13 06:00:25 --> Session Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Session routines successfully run
DEBUG - 2014-03-13 06:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:00:25 --> A session cookie was not found.
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:00:25 --> Session routines successfully run
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:00:25 --> Final output sent to browser
DEBUG - 2014-03-13 06:00:25 --> Total execution time: 0.0150
DEBUG - 2014-03-13 06:00:25 --> Model Class Initialized
DEBUG - 2014-03-13 06:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:00:25 --> Final output sent to browser
DEBUG - 2014-03-13 06:00:25 --> Final output sent to browser
DEBUG - 2014-03-13 06:00:25 --> Total execution time: 0.0160
DEBUG - 2014-03-13 06:00:25 --> Total execution time: 0.0150
DEBUG - 2014-03-13 06:09:29 --> Config Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Config Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Config Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Hooks Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:09:29 --> Utf8 Class Initialized
DEBUG - 2014-03-13 06:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-13 06:09:29 --> URI Class Initialized
DEBUG - 2014-03-13 06:09:29 --> URI Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Router Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Router Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Output Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Output Class Initialized
DEBUG - 2014-03-13 06:09:29 --> URI Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Security Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Security Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Input Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Router Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:09:29 --> Input Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:09:29 --> Language Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Language Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Output Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Security Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Loader Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Loader Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Input Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Controller Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Controller Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:09:29 --> Language Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:09:29 --> Loader Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Controller Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-13 06:09:29 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Database Driver Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:09:29 --> Session Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:09:29 --> A session cookie was not found.
DEBUG - 2014-03-13 06:09:29 --> Session routines successfully run
DEBUG - 2014-03-13 06:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:09:29 --> Session Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:09:29 --> Session Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: string_helper
DEBUG - 2014-03-13 06:09:29 --> A session cookie was not found.
DEBUG - 2014-03-13 06:09:29 --> Final output sent to browser
DEBUG - 2014-03-13 06:09:29 --> Session routines successfully run
DEBUG - 2014-03-13 06:09:29 --> Total execution time: 0.0140
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:09:29 --> A session cookie was not found.
DEBUG - 2014-03-13 06:09:29 --> Session routines successfully run
DEBUG - 2014-03-13 06:09:29 --> Final output sent to browser
DEBUG - 2014-03-13 06:09:29 --> Total execution time: 0.0160
DEBUG - 2014-03-13 06:09:29 --> Helper loaded: url_helper
DEBUG - 2014-03-13 06:09:29 --> Model Class Initialized
DEBUG - 2014-03-13 06:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-13 06:09:29 --> Final output sent to browser
DEBUG - 2014-03-13 06:09:29 --> Total execution time: 0.0170
