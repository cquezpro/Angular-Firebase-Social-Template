<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-27 12:52:01 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:01 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:01 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:01 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:01 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:01 --> A session cookie was not found.
DEBUG - 2014-02-27 12:52:01 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:01 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:01 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:01 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:01 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Database Driver Class Initialized
ERROR - 2014-02-27 12:52:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-27 12:52:01 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:01 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:01 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:01 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:01 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-27 12:52:01 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:01 --> Total execution time: 0.0110
DEBUG - 2014-02-27 12:52:02 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:02 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:02 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:02 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:02 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:02 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:02 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:02 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:02 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:02 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:03 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:03 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:03 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:03 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:03 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:03 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:03 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:03 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:03 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 12:52:03 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:03 --> Total execution time: 0.0900
DEBUG - 2014-02-27 12:52:04 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:04 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:04 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:04 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:04 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:04 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:04 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:04 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:04 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:04 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:04 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:04 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:04 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Router Class Initialized
ERROR - 2014-02-27 12:52:04 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-27 12:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:04 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:04 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:04 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:04 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:04 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:04 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:04 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:04 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:04 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:04 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:04 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:04 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:04 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:04 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:04 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:04 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:04 --> Total execution time: 0.1090
DEBUG - 2014-02-27 12:52:04 --> Total execution time: 0.1000
DEBUG - 2014-02-27 12:52:04 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:04 --> Total execution time: 0.1080
DEBUG - 2014-02-27 12:52:04 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:04 --> Total execution time: 0.1130
DEBUG - 2014-02-27 12:52:04 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:04 --> Total execution time: 0.1120
DEBUG - 2014-02-27 12:52:05 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:05 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:05 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:05 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:05 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:05 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:05 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 12:52:05 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:05 --> Total execution time: 0.0280
DEBUG - 2014-02-27 12:52:05 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:05 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:05 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:05 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:05 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:05 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:05 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:05 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:05 --> Total execution time: 0.0120
DEBUG - 2014-02-27 12:52:06 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:06 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:06 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:06 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:06 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:06 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:06 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:06 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 12:52:06 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:06 --> Total execution time: 0.0360
DEBUG - 2014-02-27 12:52:08 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:08 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:08 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:08 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 12:52:08 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:08 --> Total execution time: 0.0180
DEBUG - 2014-02-27 12:52:08 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:08 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:08 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:08 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:08 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:08 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:08 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:08 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:08 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:08 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:08 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:08 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:08 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:08 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:08 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Total execution time: 0.0210
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:08 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:08 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:08 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:08 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:08 --> Total execution time: 0.0280
DEBUG - 2014-02-27 12:52:08 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:08 --> Total execution time: 0.0200
DEBUG - 2014-02-27 12:52:08 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:08 --> Total execution time: 0.0220
DEBUG - 2014-02-27 12:52:08 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:08 --> Total execution time: 0.0310
DEBUG - 2014-02-27 12:52:09 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:09 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:09 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:09 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:09 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:09 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:09 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 12:52:09 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:09 --> Total execution time: 0.0130
DEBUG - 2014-02-27 12:52:09 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:09 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:09 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:09 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:09 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:09 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:09 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:09 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:09 --> Total execution time: 0.0110
DEBUG - 2014-02-27 12:52:21 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:21 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:21 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:21 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:21 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:21 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:21 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:21 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:21 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 12:52:21 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:21 --> Total execution time: 0.0220
DEBUG - 2014-02-27 12:52:25 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:25 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:25 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:25 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:25 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:25 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:25 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:25 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:25 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-27 12:52:25 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:25 --> Total execution time: 0.0420
DEBUG - 2014-02-27 12:52:30 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:30 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:30 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:30 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:30 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:30 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:30 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:30 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:33 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:33 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:33 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:33 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:33 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:33 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:33 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:33 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:33 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-27 12:52:33 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:33 --> Total execution time: 0.0160
DEBUG - 2014-02-27 12:52:35 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:35 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:35 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:35 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:35 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:35 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:35 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:35 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 12:52:35 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:35 --> Total execution time: 0.0190
DEBUG - 2014-02-27 12:52:36 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:36 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:36 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:36 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:36 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:36 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:36 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:36 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:36 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:36 --> Total execution time: 0.0120
DEBUG - 2014-02-27 12:52:43 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:43 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:43 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:43 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:43 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:43 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:43 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:43 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:43 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-27 12:52:43 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:43 --> Total execution time: 0.0180
DEBUG - 2014-02-27 12:52:45 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:45 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:45 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:45 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:45 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:45 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:45 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 12:52:45 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:45 --> Total execution time: 0.0200
DEBUG - 2014-02-27 12:52:45 --> Config Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:52:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:52:45 --> URI Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Router Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Output Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Security Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Input Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:52:45 --> Language Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Loader Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Controller Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:52:45 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Model Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:52:45 --> Session Class Initialized
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:52:45 --> Session routines successfully run
DEBUG - 2014-02-27 12:52:45 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:52:45 --> Final output sent to browser
DEBUG - 2014-02-27 12:52:45 --> Total execution time: 0.0110
DEBUG - 2014-02-27 12:53:03 --> Config Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:53:03 --> URI Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Router Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Output Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Security Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Input Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:53:03 --> Language Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Loader Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Controller Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:53:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:53:03 --> Session Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:53:03 --> Session routines successfully run
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:53:03 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 12:53:03 --> Final output sent to browser
DEBUG - 2014-02-27 12:53:03 --> Total execution time: 0.0220
DEBUG - 2014-02-27 12:53:03 --> Config Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:53:03 --> URI Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Router Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Output Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Security Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Input Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:53:03 --> Language Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Loader Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Controller Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:53:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:53:03 --> Session Class Initialized
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:53:03 --> Session routines successfully run
DEBUG - 2014-02-27 12:53:03 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:53:03 --> Final output sent to browser
DEBUG - 2014-02-27 12:53:03 --> Total execution time: 0.0110
DEBUG - 2014-02-27 12:53:06 --> Config Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:53:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:53:06 --> URI Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Router Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Output Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Security Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Input Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:53:06 --> Language Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Loader Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Controller Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:53:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:53:06 --> Session Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:53:06 --> Session routines successfully run
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:53:06 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 12:53:06 --> Final output sent to browser
DEBUG - 2014-02-27 12:53:06 --> Total execution time: 0.0200
DEBUG - 2014-02-27 12:53:06 --> Config Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Hooks Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Utf8 Class Initialized
DEBUG - 2014-02-27 12:53:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 12:53:06 --> URI Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Router Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Output Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Security Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Input Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 12:53:06 --> Language Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Loader Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Controller Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 12:53:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Database Driver Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Model Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 12:53:06 --> Session Class Initialized
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: string_helper
DEBUG - 2014-02-27 12:53:06 --> Session routines successfully run
DEBUG - 2014-02-27 12:53:06 --> Helper loaded: url_helper
DEBUG - 2014-02-27 12:53:06 --> Final output sent to browser
DEBUG - 2014-02-27 12:53:06 --> Total execution time: 0.0110
DEBUG - 2014-02-27 17:37:31 --> Config Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Hooks Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Utf8 Class Initialized
DEBUG - 2014-02-27 17:37:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 17:37:31 --> URI Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Router Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Output Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Security Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Input Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 17:37:31 --> Language Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Loader Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Controller Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 17:37:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 17:37:31 --> Model Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Model Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Database Driver Class Initialized
DEBUG - 2014-02-27 17:37:31 --> Final output sent to browser
DEBUG - 2014-02-27 17:37:31 --> Total execution time: 0.0120
DEBUG - 2014-02-27 17:37:47 --> Config Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Hooks Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Utf8 Class Initialized
DEBUG - 2014-02-27 17:37:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 17:37:47 --> URI Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Router Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Output Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Security Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Input Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 17:37:47 --> Language Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Loader Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Controller Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 17:37:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 17:37:47 --> Model Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Model Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Database Driver Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Model Class Initialized
DEBUG - 2014-02-27 17:37:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 17:37:50 --> Final output sent to browser
DEBUG - 2014-02-27 17:37:50 --> Total execution time: 3.0042
DEBUG - 2014-02-27 17:38:14 --> Config Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Hooks Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Utf8 Class Initialized
DEBUG - 2014-02-27 17:38:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 17:38:14 --> URI Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Router Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Output Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Security Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Input Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 17:38:14 --> Language Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Loader Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Controller Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 17:38:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 17:38:14 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Database Driver Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 17:38:14 --> Final output sent to browser
DEBUG - 2014-02-27 17:38:14 --> Total execution time: 0.0170
DEBUG - 2014-02-27 17:38:25 --> Config Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Hooks Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Utf8 Class Initialized
DEBUG - 2014-02-27 17:38:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 17:38:25 --> URI Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Router Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Output Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Security Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Input Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 17:38:25 --> Language Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Loader Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Controller Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 17:38:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 17:38:25 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Database Driver Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 17:38:25 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 17:38:25 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 17:38:25 --> Model Class Initialized
DEBUG - 2014-02-27 17:38:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 17:38:30 --> Final output sent to browser
DEBUG - 2014-02-27 17:38:30 --> Total execution time: 4.6053
DEBUG - 2014-02-27 18:16:08 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:08 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:08 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:08 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:08 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:08 --> A session cookie was not found.
DEBUG - 2014-02-27 18:16:08 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:08 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:08 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:08 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:08 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:08 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:08 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:08 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-27 18:16:08 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:08 --> Total execution time: 0.0100
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 18:16:12 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:12 --> Total execution time: 0.0110
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:12 --> Total execution time: 0.0130
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:12 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Total execution time: 0.0220
DEBUG - 2014-02-27 18:16:12 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:12 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:12 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:12 --> Total execution time: 0.0520
DEBUG - 2014-02-27 18:16:12 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:12 --> Total execution time: 0.0270
DEBUG - 2014-02-27 18:16:12 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:12 --> Total execution time: 0.0430
DEBUG - 2014-02-27 18:16:20 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:20 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:20 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:20 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:20 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:20 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:20 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:20 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:20 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:20 --> Total execution time: 0.0330
DEBUG - 2014-02-27 18:16:30 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:30 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:30 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:30 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:30 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:30 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:30 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:30 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:30 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:30 --> Total execution time: 0.0520
DEBUG - 2014-02-27 18:16:31 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:31 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:31 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:31 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:31 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:31 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:31 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:31 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:31 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:31 --> Total execution time: 0.0280
DEBUG - 2014-02-27 18:16:33 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:33 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:33 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:33 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:33 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:33 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:33 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:33 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:33 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-27 18:16:33 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:33 --> Total execution time: 0.0230
DEBUG - 2014-02-27 18:16:44 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:44 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:44 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:44 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:44 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:44 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:44 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 18:16:44 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:44 --> Total execution time: 0.0160
DEBUG - 2014-02-27 18:16:44 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:44 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:44 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:44 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:44 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:44 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:44 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:44 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:44 --> Total execution time: 0.0100
DEBUG - 2014-02-27 18:16:47 --> Config Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Hooks Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Utf8 Class Initialized
DEBUG - 2014-02-27 18:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 18:16:47 --> URI Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Router Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Output Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Security Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Input Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 18:16:47 --> Language Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Loader Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Controller Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 18:16:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 18:16:47 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Database Driver Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Model Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 18:16:47 --> Session Class Initialized
DEBUG - 2014-02-27 18:16:47 --> Helper loaded: string_helper
DEBUG - 2014-02-27 18:16:47 --> Session routines successfully run
DEBUG - 2014-02-27 18:16:47 --> Helper loaded: url_helper
DEBUG - 2014-02-27 18:16:47 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 18:16:47 --> Final output sent to browser
DEBUG - 2014-02-27 18:16:47 --> Total execution time: 0.0210
DEBUG - 2014-02-27 19:18:14 --> Config Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:18:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:18:14 --> URI Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Router Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Output Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Security Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Input Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:18:14 --> Language Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Loader Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Controller Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:18:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:18:14 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:18:14 --> Final output sent to browser
DEBUG - 2014-02-27 19:18:14 --> Total execution time: 0.0270
DEBUG - 2014-02-27 19:18:20 --> Config Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:18:20 --> URI Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Router Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Output Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Security Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Input Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:18:20 --> Language Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Loader Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Controller Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:18:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:18:20 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:20 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:18:21 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:18:21 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:18:21 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:18:21 --> Model Class Initialized
DEBUG - 2014-02-27 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:18:25 --> Final output sent to browser
DEBUG - 2014-02-27 19:18:25 --> Total execution time: 4.0452
DEBUG - 2014-02-27 19:25:40 --> Config Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:25:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:25:40 --> URI Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Router Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Output Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Security Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Input Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:25:40 --> Language Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Loader Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Controller Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:25:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:25:40 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:25:40 --> Session Class Initialized
DEBUG - 2014-02-27 19:25:40 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:25:40 --> Session routines successfully run
DEBUG - 2014-02-27 19:25:40 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:25:40 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 19:25:40 --> Final output sent to browser
DEBUG - 2014-02-27 19:25:40 --> Total execution time: 0.0280
DEBUG - 2014-02-27 19:25:41 --> Config Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:25:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:25:41 --> URI Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Router Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Output Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Security Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Input Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:25:41 --> Language Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Loader Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Controller Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:25:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:25:41 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:25:41 --> Session Class Initialized
DEBUG - 2014-02-27 19:25:41 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:25:41 --> Session routines successfully run
DEBUG - 2014-02-27 19:25:41 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:25:41 --> Final output sent to browser
DEBUG - 2014-02-27 19:25:41 --> Total execution time: 0.0110
DEBUG - 2014-02-27 19:25:43 --> Config Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:25:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:25:43 --> URI Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Router Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Output Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Security Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Input Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:25:43 --> Language Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Loader Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Controller Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:25:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:25:43 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Model Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:25:43 --> Session Class Initialized
DEBUG - 2014-02-27 19:25:43 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:25:43 --> Session routines successfully run
DEBUG - 2014-02-27 19:25:43 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:25:43 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 19:25:43 --> Final output sent to browser
DEBUG - 2014-02-27 19:25:43 --> Total execution time: 0.0220
DEBUG - 2014-02-27 19:27:20 --> Config Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:27:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:27:20 --> URI Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Router Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Output Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Security Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Input Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:27:20 --> Language Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Loader Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Controller Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:27:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:27:20 --> Model Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Model Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Model Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:27:20 --> Session Class Initialized
DEBUG - 2014-02-27 19:27:20 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:27:20 --> Session routines successfully run
DEBUG - 2014-02-27 19:27:20 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:27:20 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 19:27:20 --> Final output sent to browser
DEBUG - 2014-02-27 19:27:20 --> Total execution time: 0.0160
DEBUG - 2014-02-27 19:47:09 --> Config Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:47:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:47:09 --> URI Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Router Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Output Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Security Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Input Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:47:09 --> Language Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Loader Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Controller Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:47:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:47:09 --> Model Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Model Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Model Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:47:09 --> Session Class Initialized
DEBUG - 2014-02-27 19:47:09 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:47:09 --> Session routines successfully run
DEBUG - 2014-02-27 19:47:09 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:47:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 19:47:09 --> Final output sent to browser
DEBUG - 2014-02-27 19:47:09 --> Total execution time: 0.0230
DEBUG - 2014-02-27 19:53:49 --> Config Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:53:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:53:49 --> URI Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Router Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Output Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Security Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Input Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:53:49 --> Language Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Loader Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Controller Class Initialized
DEBUG - 2014-02-27 19:53:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:53:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:53:50 --> Model Class Initialized
DEBUG - 2014-02-27 19:53:50 --> Model Class Initialized
DEBUG - 2014-02-27 19:53:50 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:53:50 --> Model Class Initialized
DEBUG - 2014-02-27 19:53:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:53:50 --> Session Class Initialized
DEBUG - 2014-02-27 19:53:50 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:53:50 --> Session routines successfully run
DEBUG - 2014-02-27 19:53:50 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:54:01 --> Config Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:54:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:54:01 --> URI Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Router Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Output Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Security Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Input Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:54:01 --> Language Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Loader Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Controller Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:54:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:54:01 --> Model Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Model Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Model Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:54:01 --> Session Class Initialized
DEBUG - 2014-02-27 19:54:01 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:54:01 --> Session routines successfully run
DEBUG - 2014-02-27 19:54:01 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:54:01 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 19:54:01 --> Final output sent to browser
DEBUG - 2014-02-27 19:54:01 --> Total execution time: 0.0160
DEBUG - 2014-02-27 19:59:34 --> Config Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:59:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:59:34 --> URI Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Router Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Output Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Security Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Input Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:59:34 --> Language Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Loader Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Controller Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:59:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:59:34 --> Model Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Model Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Model Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:59:34 --> Session Class Initialized
DEBUG - 2014-02-27 19:59:34 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:59:34 --> Session routines successfully run
DEBUG - 2014-02-27 19:59:34 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:59:34 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 19:59:34 --> Final output sent to browser
DEBUG - 2014-02-27 19:59:34 --> Total execution time: 0.0160
DEBUG - 2014-02-27 19:59:47 --> Config Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Hooks Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Utf8 Class Initialized
DEBUG - 2014-02-27 19:59:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 19:59:47 --> URI Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Router Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Output Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Security Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Input Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 19:59:47 --> Language Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Loader Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Controller Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 19:59:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 19:59:47 --> Model Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Model Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Database Driver Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Model Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 19:59:47 --> Session Class Initialized
DEBUG - 2014-02-27 19:59:47 --> Helper loaded: string_helper
DEBUG - 2014-02-27 19:59:47 --> Session routines successfully run
DEBUG - 2014-02-27 19:59:47 --> Helper loaded: url_helper
DEBUG - 2014-02-27 19:59:47 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 19:59:47 --> Final output sent to browser
DEBUG - 2014-02-27 19:59:47 --> Total execution time: 0.0190
DEBUG - 2014-02-27 20:00:00 --> Config Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:00:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:00:00 --> URI Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Router Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Output Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Security Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Input Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:00:00 --> Language Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Loader Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Controller Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:00:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:00:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:00:00 --> Session Class Initialized
DEBUG - 2014-02-27 20:00:00 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:00:00 --> Session routines successfully run
DEBUG - 2014-02-27 20:00:00 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:00:01 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:00:01 --> Final output sent to browser
DEBUG - 2014-02-27 20:00:01 --> Total execution time: 0.0150
DEBUG - 2014-02-27 20:00:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:00:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:00:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:00:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:00:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:00:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:00:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:00:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:00:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:00:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:00:37 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:00:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:00:37 --> Total execution time: 0.0210
DEBUG - 2014-02-27 20:00:41 --> Config Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:00:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:00:41 --> URI Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Router Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Output Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Security Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Input Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:00:41 --> Language Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Loader Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Controller Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:00:41 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:00:41 --> Session Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:00:41 --> Session routines successfully run
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:00:41 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:00:41 --> Final output sent to browser
DEBUG - 2014-02-27 20:00:41 --> Total execution time: 0.0220
DEBUG - 2014-02-27 20:00:41 --> Config Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:00:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:00:41 --> URI Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Router Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Output Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Security Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Input Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:00:41 --> Language Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Loader Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Controller Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:00:41 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:00:41 --> Session Class Initialized
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:00:41 --> Session routines successfully run
DEBUG - 2014-02-27 20:00:41 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:00:41 --> Final output sent to browser
DEBUG - 2014-02-27 20:00:41 --> Total execution time: 0.0110
DEBUG - 2014-02-27 20:00:44 --> Config Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:00:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:00:44 --> URI Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Router Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Output Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Security Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Input Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:00:44 --> Language Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Loader Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Controller Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:00:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:00:44 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Model Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:00:44 --> Session Class Initialized
DEBUG - 2014-02-27 20:00:44 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:00:44 --> Session routines successfully run
DEBUG - 2014-02-27 20:00:44 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:00:44 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:00:44 --> Final output sent to browser
DEBUG - 2014-02-27 20:00:44 --> Total execution time: 0.0210
DEBUG - 2014-02-27 20:07:32 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:32 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:32 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:32 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:32 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:32 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:32 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:32 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 20:07:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:37 --> Total execution time: 0.0110
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Total execution time: 0.0220
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:37 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:37 --> Total execution time: 0.0290
DEBUG - 2014-02-27 20:07:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:37 --> Total execution time: 0.0290
DEBUG - 2014-02-27 20:07:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:37 --> Total execution time: 0.0410
DEBUG - 2014-02-27 20:07:37 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:37 --> Total execution time: 0.0340
DEBUG - 2014-02-27 20:07:39 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:39 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:39 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:39 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:39 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:39 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:39 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:39 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:39 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:07:39 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:39 --> Total execution time: 0.0190
DEBUG - 2014-02-27 20:07:40 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:40 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:40 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:40 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:40 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:40 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:40 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:40 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:40 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:40 --> Total execution time: 0.0120
DEBUG - 2014-02-27 20:07:42 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:42 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:42 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:42 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:42 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:42 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:42 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:42 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:42 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:07:42 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:42 --> Total execution time: 0.0160
DEBUG - 2014-02-27 20:07:54 --> Config Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:07:54 --> URI Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Router Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Output Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Security Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Input Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:07:54 --> Language Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Loader Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Controller Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:07:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:07:54 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Model Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:07:54 --> Session Class Initialized
DEBUG - 2014-02-27 20:07:54 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:07:54 --> Session routines successfully run
DEBUG - 2014-02-27 20:07:54 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:07:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:07:54 --> Final output sent to browser
DEBUG - 2014-02-27 20:07:54 --> Total execution time: 0.0150
DEBUG - 2014-02-27 20:08:05 --> Config Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:08:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:08:05 --> URI Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Router Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Output Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Security Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Input Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:08:05 --> Language Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Loader Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Controller Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:08:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:08:05 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:08:05 --> Session Class Initialized
DEBUG - 2014-02-27 20:08:05 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:08:05 --> Session routines successfully run
DEBUG - 2014-02-27 20:08:05 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:08:05 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:08:05 --> Final output sent to browser
DEBUG - 2014-02-27 20:08:05 --> Total execution time: 0.0180
DEBUG - 2014-02-27 20:08:12 --> Config Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:08:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:08:12 --> URI Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Router Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Output Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Security Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Input Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:08:12 --> Language Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Loader Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Controller Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:08:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:08:12 --> Session Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:08:12 --> Session routines successfully run
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:08:12 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:08:12 --> Final output sent to browser
DEBUG - 2014-02-27 20:08:12 --> Total execution time: 0.0220
DEBUG - 2014-02-27 20:08:12 --> Config Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:08:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:08:12 --> URI Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Router Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Output Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Security Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Input Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:08:12 --> Language Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Loader Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Controller Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:08:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:08:12 --> Session Class Initialized
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:08:12 --> Session routines successfully run
DEBUG - 2014-02-27 20:08:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:08:12 --> Final output sent to browser
DEBUG - 2014-02-27 20:08:12 --> Total execution time: 0.0110
DEBUG - 2014-02-27 20:08:14 --> Config Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:08:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:08:14 --> URI Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Router Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Output Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Security Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Input Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:08:14 --> Language Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Loader Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Controller Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:08:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:08:14 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Model Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:08:14 --> Session Class Initialized
DEBUG - 2014-02-27 20:08:14 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:08:14 --> Session routines successfully run
DEBUG - 2014-02-27 20:08:14 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:08:14 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:08:14 --> Final output sent to browser
DEBUG - 2014-02-27 20:08:14 --> Total execution time: 0.0160
DEBUG - 2014-02-27 20:23:54 --> Config Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:23:54 --> URI Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Router Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Output Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Security Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Input Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:23:54 --> Language Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Loader Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Controller Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:23:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:23:54 --> Session Class Initialized
DEBUG - 2014-02-27 20:23:54 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:23:54 --> Session routines successfully run
DEBUG - 2014-02-27 20:23:54 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:23:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:23:54 --> Final output sent to browser
DEBUG - 2014-02-27 20:23:54 --> Total execution time: 0.0150
DEBUG - 2014-02-27 20:23:59 --> Config Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:23:59 --> URI Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Router Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Output Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Security Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Input Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:23:59 --> Language Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Loader Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Controller Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:23:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:23:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:23:59 --> Session Class Initialized
DEBUG - 2014-02-27 20:23:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:23:59 --> Session routines successfully run
DEBUG - 2014-02-27 20:23:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:23:59 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:23:59 --> Final output sent to browser
DEBUG - 2014-02-27 20:23:59 --> Total execution time: 0.0140
DEBUG - 2014-02-27 20:24:02 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:02 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:02 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:02 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:02 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:02 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:02 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:08 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:08 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:08 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:08 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:08 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:08 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:08 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:08 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:12 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:12 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:12 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:12 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:12 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:12 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-27 20:24:12 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:12 --> Total execution time: 0.0230
DEBUG - 2014-02-27 20:24:15 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:15 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:15 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:15 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 20:24:15 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:15 --> Total execution time: 0.0180
DEBUG - 2014-02-27 20:24:15 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:15 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:15 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:15 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:15 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:15 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:15 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:15 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:15 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:15 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:15 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:15 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:15 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:15 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:15 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:15 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:15 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:15 --> Total execution time: 0.0160
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:15 --> Total execution time: 0.0220
DEBUG - 2014-02-27 20:24:15 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:15 --> Total execution time: 0.0270
DEBUG - 2014-02-27 20:24:15 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:15 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:15 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:15 --> Total execution time: 0.0360
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:15 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:15 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:15 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:15 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:15 --> Total execution time: 0.0190
DEBUG - 2014-02-27 20:24:16 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:16 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:16 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:16 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:16 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:16 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:16 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:16 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:16 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:24:16 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:16 --> Total execution time: 0.0200
DEBUG - 2014-02-27 20:24:17 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:17 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:17 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:17 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:17 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:17 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:17 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:17 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:17 --> Total execution time: 0.0110
DEBUG - 2014-02-27 20:24:19 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:19 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:19 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:19 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:19 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:19 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:24:19 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:19 --> Total execution time: 0.0210
DEBUG - 2014-02-27 20:24:19 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:19 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:19 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:19 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:19 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:19 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:19 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:19 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:19 --> Total execution time: 0.0100
DEBUG - 2014-02-27 20:24:21 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:21 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:21 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:21 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:21 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:21 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:21 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:21 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:21 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:24:21 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:21 --> Total execution time: 0.0220
DEBUG - 2014-02-27 20:24:26 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:26 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:26 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:26 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 20:24:26 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:26 --> Total execution time: 0.0120
DEBUG - 2014-02-27 20:24:26 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:26 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:26 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:26 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:26 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:26 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:26 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:26 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:26 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:26 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:26 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:26 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:26 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:26 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:26 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:26 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:26 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:26 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:26 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:26 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:26 --> Total execution time: 0.0220
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:26 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:26 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:26 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:26 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:26 --> Total execution time: 0.0270
DEBUG - 2014-02-27 20:24:26 --> Total execution time: 0.0260
DEBUG - 2014-02-27 20:24:26 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:26 --> Total execution time: 0.0250
DEBUG - 2014-02-27 20:24:26 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:26 --> Total execution time: 0.0370
DEBUG - 2014-02-27 20:24:27 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:27 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:27 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:27 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:27 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:27 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:27 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:24:27 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:27 --> Total execution time: 0.0140
DEBUG - 2014-02-27 20:24:27 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:27 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:27 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:27 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:27 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:27 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:27 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:27 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:27 --> Total execution time: 0.0110
DEBUG - 2014-02-27 20:24:31 --> Config Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:24:31 --> URI Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Router Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Output Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Security Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Input Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:24:31 --> Language Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Loader Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Controller Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:24:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:24:31 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Model Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:24:31 --> Session Class Initialized
DEBUG - 2014-02-27 20:24:31 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:24:31 --> Session routines successfully run
DEBUG - 2014-02-27 20:24:31 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:24:31 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:24:31 --> Final output sent to browser
DEBUG - 2014-02-27 20:24:31 --> Total execution time: 0.0200
DEBUG - 2014-02-27 20:58:58 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:58 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:58 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:58 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:58 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:58 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:58 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:58 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:58 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:58 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:58 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:58 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:58 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:58 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 20:58:58 --> Final output sent to browser
DEBUG - 2014-02-27 20:58:58 --> Total execution time: 0.0130
DEBUG - 2014-02-27 20:58:59 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:59 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:59 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:59 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:59 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:59 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:59 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:59 --> Config Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:59 --> URI Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:59 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Router Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:59 --> Output Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:59 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:59 --> Security Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Input Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:59 --> Final output sent to browser
DEBUG - 2014-02-27 20:58:59 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Total execution time: 0.0180
DEBUG - 2014-02-27 20:58:59 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:59 --> Language Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Loader Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Controller Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Session Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:58:59 --> Final output sent to browser
DEBUG - 2014-02-27 20:58:59 --> Total execution time: 0.0270
DEBUG - 2014-02-27 20:58:59 --> Session routines successfully run
DEBUG - 2014-02-27 20:58:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:58:59 --> Model Class Initialized
DEBUG - 2014-02-27 20:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:58:59 --> Final output sent to browser
DEBUG - 2014-02-27 20:58:59 --> Total execution time: 0.0340
DEBUG - 2014-02-27 20:58:59 --> Final output sent to browser
DEBUG - 2014-02-27 20:58:59 --> Total execution time: 0.0330
DEBUG - 2014-02-27 20:58:59 --> Final output sent to browser
DEBUG - 2014-02-27 20:58:59 --> Total execution time: 0.0390
DEBUG - 2014-02-27 20:59:00 --> Config Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:59:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:59:00 --> URI Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Router Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Output Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Security Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Input Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:59:00 --> Language Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Loader Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Controller Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:59:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:59:00 --> Session Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:59:00 --> Session routines successfully run
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:59:00 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 20:59:00 --> Final output sent to browser
DEBUG - 2014-02-27 20:59:00 --> Total execution time: 0.0110
DEBUG - 2014-02-27 20:59:00 --> Config Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:59:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:59:00 --> URI Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Router Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Output Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Security Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Input Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:59:00 --> Language Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Loader Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Controller Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:59:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:59:00 --> Session Class Initialized
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:59:00 --> Session routines successfully run
DEBUG - 2014-02-27 20:59:00 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:59:00 --> Final output sent to browser
DEBUG - 2014-02-27 20:59:00 --> Total execution time: 0.0150
DEBUG - 2014-02-27 20:59:22 --> Config Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Hooks Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Utf8 Class Initialized
DEBUG - 2014-02-27 20:59:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 20:59:22 --> URI Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Router Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Output Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Security Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Input Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 20:59:22 --> Language Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Loader Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Controller Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 20:59:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 20:59:22 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Database Driver Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Model Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 20:59:22 --> Session Class Initialized
DEBUG - 2014-02-27 20:59:22 --> Helper loaded: string_helper
DEBUG - 2014-02-27 20:59:22 --> Session routines successfully run
DEBUG - 2014-02-27 20:59:22 --> Helper loaded: url_helper
DEBUG - 2014-02-27 20:59:22 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 20:59:22 --> Final output sent to browser
DEBUG - 2014-02-27 20:59:22 --> Total execution time: 0.0180
DEBUG - 2014-02-27 21:03:42 --> Config Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:03:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:03:42 --> URI Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Router Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Output Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Security Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Input Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:03:42 --> Language Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Loader Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Controller Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:03:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:03:42 --> Model Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Model Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Model Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:03:42 --> Session Class Initialized
DEBUG - 2014-02-27 21:03:42 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:03:42 --> Session routines successfully run
DEBUG - 2014-02-27 21:03:42 --> Helper loaded: url_helper
ERROR - 2014-02-27 21:03:42 --> Severity: Notice  --> Undefined property: Admin::$id F:\ZServer61\Apache2\htdocs\mantrackr_service\system\core\Model.php 51
DEBUG - 2014-02-27 21:03:42 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:03:42 --> Final output sent to browser
DEBUG - 2014-02-27 21:03:42 --> Total execution time: 0.0250
DEBUG - 2014-02-27 21:03:59 --> Config Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:03:59 --> URI Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Router Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Output Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Security Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Input Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:03:59 --> Language Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Loader Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Controller Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:03:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:03:59 --> Model Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Model Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Model Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:03:59 --> Session Class Initialized
DEBUG - 2014-02-27 21:03:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:03:59 --> Session routines successfully run
DEBUG - 2014-02-27 21:03:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:03:59 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:03:59 --> Final output sent to browser
DEBUG - 2014-02-27 21:03:59 --> Total execution time: 0.0150
DEBUG - 2014-02-27 21:04:01 --> Config Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:04:01 --> URI Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Router Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Output Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Security Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Input Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:04:01 --> Language Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Loader Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Controller Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:04:01 --> Model Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Model Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Model Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:04:01 --> Session Class Initialized
DEBUG - 2014-02-27 21:04:01 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:04:01 --> Session routines successfully run
DEBUG - 2014-02-27 21:04:01 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:04:01 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:04:01 --> Final output sent to browser
DEBUG - 2014-02-27 21:04:01 --> Total execution time: 0.0130
DEBUG - 2014-02-27 21:10:35 --> Config Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:10:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:10:35 --> URI Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Router Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Output Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Security Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Input Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:10:35 --> Language Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Loader Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Controller Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:10:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:10:35 --> Model Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Model Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Model Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:10:35 --> Session Class Initialized
DEBUG - 2014-02-27 21:10:35 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:10:35 --> Session routines successfully run
DEBUG - 2014-02-27 21:10:35 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:10:35 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:10:35 --> Final output sent to browser
DEBUG - 2014-02-27 21:10:35 --> Total execution time: 0.0190
DEBUG - 2014-02-27 21:10:57 --> Config Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:10:57 --> URI Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Router Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Output Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Security Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Input Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:10:57 --> Language Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Loader Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Controller Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:10:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:10:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:10:57 --> Session Class Initialized
DEBUG - 2014-02-27 21:10:57 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:10:57 --> Session routines successfully run
DEBUG - 2014-02-27 21:10:57 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:11:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:11:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:11:51 --> Config Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:11:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:11:51 --> URI Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Router Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Output Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Security Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Input Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:11:51 --> Language Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Loader Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Controller Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:11:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:11:51 --> Model Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Model Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Model Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:11:51 --> Session Class Initialized
DEBUG - 2014-02-27 21:11:51 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:11:51 --> Session routines successfully run
DEBUG - 2014-02-27 21:11:51 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:11:51 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:11:51 --> Final output sent to browser
DEBUG - 2014-02-27 21:11:51 --> Total execution time: 0.0200
DEBUG - 2014-02-27 21:12:04 --> Config Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:12:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:12:04 --> URI Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Router Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Output Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Security Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Input Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:12:04 --> Language Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Loader Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Controller Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:12:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:12:04 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:12:04 --> Session Class Initialized
DEBUG - 2014-02-27 21:12:04 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:12:04 --> Session routines successfully run
DEBUG - 2014-02-27 21:12:04 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:12:52 --> Config Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:12:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:12:52 --> URI Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Router Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Output Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Security Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Input Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:12:52 --> Language Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Loader Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Controller Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:12:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:12:52 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:12:52 --> Session Class Initialized
DEBUG - 2014-02-27 21:12:52 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:12:52 --> Session routines successfully run
DEBUG - 2014-02-27 21:12:52 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:12:52 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:12:52 --> Final output sent to browser
DEBUG - 2014-02-27 21:12:52 --> Total execution time: 0.0260
DEBUG - 2014-02-27 21:12:54 --> Config Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:12:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:12:54 --> URI Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Router Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Output Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Security Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Input Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:12:54 --> Language Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Loader Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Controller Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:12:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:12:54 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Model Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:12:54 --> Session Class Initialized
DEBUG - 2014-02-27 21:12:54 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:12:54 --> Session routines successfully run
DEBUG - 2014-02-27 21:12:54 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:12:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:12:54 --> Final output sent to browser
DEBUG - 2014-02-27 21:12:54 --> Total execution time: 0.0170
DEBUG - 2014-02-27 21:13:13 --> Config Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:13:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:13:13 --> URI Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Router Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Output Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Security Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Input Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:13:13 --> Language Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Loader Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Controller Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:13:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:13:13 --> Model Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Model Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Model Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:13:13 --> Session Class Initialized
DEBUG - 2014-02-27 21:13:13 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:13:13 --> Session routines successfully run
DEBUG - 2014-02-27 21:13:13 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:13:17 --> Model Class Initialized
DEBUG - 2014-02-27 21:13:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:14:16 --> Config Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:14:16 --> URI Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Router Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Output Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Security Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Input Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:14:16 --> Language Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Loader Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Controller Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:14:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:14:16 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:14:16 --> Session Class Initialized
DEBUG - 2014-02-27 21:14:16 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:14:16 --> Session routines successfully run
DEBUG - 2014-02-27 21:14:16 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:14:16 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:14:16 --> Final output sent to browser
DEBUG - 2014-02-27 21:14:16 --> Total execution time: 0.0310
DEBUG - 2014-02-27 21:14:23 --> Config Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:14:23 --> URI Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Router Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Output Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Security Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Input Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:14:23 --> Language Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Loader Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Controller Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:14:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:14:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:14:23 --> Session Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:14:23 --> Session routines successfully run
DEBUG - 2014-02-27 21:14:23 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:14:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:02 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:02 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:02 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:02 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:02 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:02 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:02 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:02 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:02 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:15:02 --> Final output sent to browser
DEBUG - 2014-02-27 21:15:02 --> Total execution time: 0.0320
DEBUG - 2014-02-27 21:15:09 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:09 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:09 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:09 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:09 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:09 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:12 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:12 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:12 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:12 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:12 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:23 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:23 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:23 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:23 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:23 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:23 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:23 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:23 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:15:23 --> Final output sent to browser
DEBUG - 2014-02-27 21:15:23 --> Total execution time: 0.0180
DEBUG - 2014-02-27 21:15:57 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:57 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:57 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:57 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:57 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:57 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 21:15:57 --> Final output sent to browser
DEBUG - 2014-02-27 21:15:57 --> Total execution time: 0.0200
DEBUG - 2014-02-27 21:15:57 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:57 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:57 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:57 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:57 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:57 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:57 --> Final output sent to browser
DEBUG - 2014-02-27 21:15:57 --> Total execution time: 0.0110
DEBUG - 2014-02-27 21:15:59 --> Config Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:15:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:15:59 --> URI Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Router Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Output Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Security Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Input Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:15:59 --> Language Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Loader Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Controller Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:15:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:15:59 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Model Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:15:59 --> Session Class Initialized
DEBUG - 2014-02-27 21:15:59 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:15:59 --> Session routines successfully run
DEBUG - 2014-02-27 21:15:59 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:15:59 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:15:59 --> Final output sent to browser
DEBUG - 2014-02-27 21:15:59 --> Total execution time: 0.0250
DEBUG - 2014-02-27 21:16:03 --> Config Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:16:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:16:03 --> URI Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Router Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Output Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Security Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Input Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:16:03 --> Language Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Loader Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Controller Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:16:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:16:03 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:16:03 --> Session Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:16:03 --> Session routines successfully run
DEBUG - 2014-02-27 21:16:03 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:16:03 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:16:03 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:16:03 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:16:05 --> Config Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:16:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:16:05 --> URI Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Router Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Output Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Security Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Input Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:16:05 --> Language Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Loader Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Controller Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:16:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:16:05 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Model Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:16:05 --> Session Class Initialized
DEBUG - 2014-02-27 21:16:05 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:16:05 --> Session routines successfully run
DEBUG - 2014-02-27 21:16:05 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:16:05 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:16:05 --> Final output sent to browser
DEBUG - 2014-02-27 21:16:05 --> Total execution time: 0.0230
DEBUG - 2014-02-27 21:17:23 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:23 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:23 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:23 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:23 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:23 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 21:17:23 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:23 --> Total execution time: 0.0120
DEBUG - 2014-02-27 21:17:23 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:23 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:23 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:23 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:23 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:23 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:23 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:23 --> Total execution time: 0.0110
DEBUG - 2014-02-27 21:17:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:28 --> Helper loaded: url_helper
ERROR - 2014-02-27 21:17:28 --> Severity: Warning  --> include(common/message_list.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\common\member_profile.php 3
ERROR - 2014-02-27 21:17:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'common/message_list.php' for inclusion (include_path='.;F:\ZServer61\ZendServer\share\ZendFramework\library') F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\common\member_profile.php 3
DEBUG - 2014-02-27 21:17:28 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:17:28 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:28 --> Total execution time: 0.0210
DEBUG - 2014-02-27 21:17:40 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:40 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:40 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:40 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:40 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:40 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:40 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:40 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:40 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:17:40 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:40 --> Total execution time: 0.0150
DEBUG - 2014-02-27 21:17:43 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:43 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:43 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:43 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:43 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:43 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:43 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:43 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:43 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 21:17:43 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:43 --> Total execution time: 0.0170
DEBUG - 2014-02-27 21:17:44 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:44 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:44 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:44 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:44 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:44 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:44 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:44 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:44 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:44 --> Total execution time: 0.0120
DEBUG - 2014-02-27 21:17:49 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:49 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:49 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:49 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:49 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:49 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:49 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:49 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:49 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 21:17:49 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:49 --> Total execution time: 0.0200
DEBUG - 2014-02-27 21:17:50 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:50 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:50 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:50 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:50 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:50 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:50 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:50 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:50 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:50 --> Total execution time: 0.0110
DEBUG - 2014-02-27 21:17:52 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:52 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:52 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:52 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:52 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:52 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:52 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:52 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:52 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:17:52 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:52 --> Total execution time: 0.0140
DEBUG - 2014-02-27 21:17:55 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:55 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:55 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:55 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:55 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:55 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:55 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:55 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:55 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:55 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:58 --> Config Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:17:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:17:58 --> URI Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Router Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Output Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Security Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Input Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:17:58 --> Language Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Loader Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Controller Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:17:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:17:58 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Model Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:17:58 --> Session Class Initialized
DEBUG - 2014-02-27 21:17:58 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:17:58 --> Session routines successfully run
DEBUG - 2014-02-27 21:17:58 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:17:58 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:17:58 --> Final output sent to browser
DEBUG - 2014-02-27 21:17:58 --> Total execution time: 0.0140
DEBUG - 2014-02-27 21:25:14 --> Config Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:25:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:25:14 --> URI Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Router Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Output Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Security Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Input Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:25:14 --> Language Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Loader Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Controller Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:25:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:25:14 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:14 --> Session Class Initialized
DEBUG - 2014-02-27 21:25:14 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:25:14 --> Session routines successfully run
DEBUG - 2014-02-27 21:25:14 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:25:14 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:25:14 --> Final output sent to browser
DEBUG - 2014-02-27 21:25:14 --> Total execution time: 0.0190
DEBUG - 2014-02-27 21:25:19 --> Config Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:25:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:25:19 --> URI Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Router Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Output Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Security Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Input Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:25:19 --> Language Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Loader Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Controller Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:25:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:25:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:19 --> Session Class Initialized
DEBUG - 2014-02-27 21:25:19 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:25:19 --> Session routines successfully run
DEBUG - 2014-02-27 21:25:19 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:25:19 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:25:19 --> Final output sent to browser
DEBUG - 2014-02-27 21:25:19 --> Total execution time: 0.0260
DEBUG - 2014-02-27 21:25:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:25:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:25:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:25:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:25:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:25:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:25:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:25:28 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:25:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:32 --> Config Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:25:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:25:32 --> URI Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Router Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Output Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Security Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Input Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:25:32 --> Language Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Loader Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Controller Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:25:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:25:32 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Model Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:25:32 --> Session Class Initialized
DEBUG - 2014-02-27 21:25:32 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:25:32 --> Session routines successfully run
DEBUG - 2014-02-27 21:25:32 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:25:32 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:25:32 --> Final output sent to browser
DEBUG - 2014-02-27 21:25:32 --> Total execution time: 0.0200
DEBUG - 2014-02-27 21:26:07 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:07 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:07 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:07 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:07 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:07 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-27 21:26:07 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:07 --> Total execution time: 0.0220
DEBUG - 2014-02-27 21:26:07 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:07 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:07 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:07 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:07 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:07 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:07 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:07 --> Total execution time: 0.0110
DEBUG - 2014-02-27 21:26:09 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:09 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:09 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:09 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:09 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:09 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:09 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:26:09 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:09 --> Total execution time: 0.0190
DEBUG - 2014-02-27 21:26:12 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:12 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:12 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:12 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:12 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:12 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:12 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:17 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:17 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:17 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:17 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:17 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:17 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:17 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:17 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:17 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:26:17 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:17 --> Total execution time: 0.0180
DEBUG - 2014-02-27 21:26:19 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:19 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:19 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:19 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:19 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:19 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:19 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:23 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:23 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:23 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:23 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:23 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:23 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:23 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:23 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-27 21:26:23 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:23 --> Total execution time: 0.0230
DEBUG - 2014-02-27 21:26:27 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:27 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:27 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:27 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:27 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:27 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:27 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:27 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:27 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-27 21:26:27 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:27 --> Total execution time: 0.0220
DEBUG - 2014-02-27 21:26:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Config Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:28 --> Hooks Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Utf8 Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-27 21:26:28 --> URI Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:28 --> Router Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:28 --> Output Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Security Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Input Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Language Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:28 --> Loader Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:28 --> Controller Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:28 --> Total execution time: 0.0270
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Database Driver Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Session Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: string_helper
DEBUG - 2014-02-27 21:26:28 --> Session routines successfully run
DEBUG - 2014-02-27 21:26:28 --> Helper loaded: url_helper
DEBUG - 2014-02-27 21:26:28 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:28 --> Total execution time: 0.0230
DEBUG - 2014-02-27 21:26:28 --> Model Class Initialized
DEBUG - 2014-02-27 21:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-27 21:26:28 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:28 --> Total execution time: 0.0310
DEBUG - 2014-02-27 21:26:28 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:28 --> Total execution time: 0.0270
DEBUG - 2014-02-27 21:26:28 --> Final output sent to browser
DEBUG - 2014-02-27 21:26:28 --> Total execution time: 0.0450
