<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-10 01:50:55 --> Config Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Hooks Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Utf8 Class Initialized
DEBUG - 2014-05-10 01:50:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-10 01:50:55 --> URI Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Router Class Initialized
DEBUG - 2014-05-10 01:50:55 --> No URI present. Default controller set.
DEBUG - 2014-05-10 01:50:55 --> Output Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Security Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Input Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-10 01:50:55 --> Language Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Loader Class Initialized
DEBUG - 2014-05-10 01:50:55 --> Controller Class Initialized
DEBUG - 2014-05-10 01:50:55 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-10 01:50:55 --> Final output sent to browser
DEBUG - 2014-05-10 01:50:55 --> Total execution time: 0.0026
DEBUG - 2014-05-10 01:50:56 --> Config Class Initialized
DEBUG - 2014-05-10 01:50:56 --> Hooks Class Initialized
DEBUG - 2014-05-10 01:50:56 --> Utf8 Class Initialized
DEBUG - 2014-05-10 01:50:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-10 01:50:56 --> URI Class Initialized
DEBUG - 2014-05-10 01:50:56 --> Router Class Initialized
ERROR - 2014-05-10 01:50:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-10 01:50:57 --> Config Class Initialized
DEBUG - 2014-05-10 01:50:57 --> Hooks Class Initialized
DEBUG - 2014-05-10 01:50:57 --> Utf8 Class Initialized
DEBUG - 2014-05-10 01:50:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-10 01:50:57 --> URI Class Initialized
DEBUG - 2014-05-10 01:50:57 --> Router Class Initialized
ERROR - 2014-05-10 01:50:57 --> 404 Page Not Found --> favicon.ico
