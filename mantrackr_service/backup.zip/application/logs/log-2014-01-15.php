<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-15 16:17:24 --> Config Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Hooks Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Utf8 Class Initialized
DEBUG - 2014-01-15 16:17:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-15 16:17:24 --> URI Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Router Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Output Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Security Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Input Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-15 16:17:24 --> Language Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Loader Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Controller Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-15 16:17:24 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Database Driver Class Initialized
ERROR - 2014-01-15 16:17:24 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-15 16:17:24 --> Helper loaded: email_helper
DEBUG - 2014-01-15 16:17:24 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-15 16:17:30 --> Final output sent to browser
DEBUG - 2014-01-15 16:17:30 --> Total execution time: 6.3584
DEBUG - 2014-01-15 16:17:48 --> Config Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Hooks Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Utf8 Class Initialized
DEBUG - 2014-01-15 16:17:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-15 16:17:48 --> URI Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Router Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Output Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Security Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Input Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-15 16:17:48 --> Language Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Loader Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Controller Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-15 16:17:48 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Database Driver Class Initialized
ERROR - 2014-01-15 16:17:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-15 16:17:48 --> Helper loaded: email_helper
DEBUG - 2014-01-15 16:17:48 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-15 16:17:48 --> Final output sent to browser
DEBUG - 2014-01-15 16:17:48 --> Total execution time: 0.0200
DEBUG - 2014-01-15 16:17:53 --> Config Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Hooks Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Utf8 Class Initialized
DEBUG - 2014-01-15 16:17:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-15 16:17:53 --> URI Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Router Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Output Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Security Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Input Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-15 16:17:53 --> Language Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Loader Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Controller Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-15 16:17:53 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Database Driver Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Helper loaded: email_helper
DEBUG - 2014-01-15 16:17:53 --> Model Class Initialized
DEBUG - 2014-01-15 16:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-15 16:17:58 --> Final output sent to browser
DEBUG - 2014-01-15 16:17:58 --> Total execution time: 5.3263
DEBUG - 2014-01-15 16:35:51 --> Config Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Hooks Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Utf8 Class Initialized
DEBUG - 2014-01-15 16:35:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-15 16:35:51 --> URI Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Router Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Output Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Security Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Input Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-15 16:35:51 --> Language Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Loader Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Controller Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-15 16:35:51 --> Model Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Model Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Database Driver Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Helper loaded: email_helper
DEBUG - 2014-01-15 16:35:51 --> Model Class Initialized
DEBUG - 2014-01-15 16:35:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-15 16:35:57 --> Final output sent to browser
DEBUG - 2014-01-15 16:35:57 --> Total execution time: 6.2414
DEBUG - 2014-01-15 16:44:33 --> Config Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Hooks Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Utf8 Class Initialized
DEBUG - 2014-01-15 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-15 16:44:33 --> URI Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Router Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Output Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Security Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Input Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-15 16:44:33 --> Language Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Loader Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Controller Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-15 16:44:33 --> Model Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Model Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Database Driver Class Initialized
DEBUG - 2014-01-15 16:44:33 --> Final output sent to browser
DEBUG - 2014-01-15 16:44:33 --> Total execution time: 0.0330
DEBUG - 2014-01-15 16:44:42 --> Config Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Hooks Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Utf8 Class Initialized
DEBUG - 2014-01-15 16:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-15 16:44:42 --> URI Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Router Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Output Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Security Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Input Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-15 16:44:42 --> Language Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Loader Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Controller Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-15 16:44:42 --> Model Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Model Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Database Driver Class Initialized
DEBUG - 2014-01-15 16:44:42 --> Final output sent to browser
DEBUG - 2014-01-15 16:44:42 --> Total execution time: 0.0140
