<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-04-01 11:08:44 --> Config Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Config Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:08:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:08:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:08:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:08:44 --> URI Class Initialized
DEBUG - 2014-04-01 11:08:44 --> URI Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Router Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Router Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Output Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Output Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Security Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Security Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Input Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Input Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:08:44 --> Language Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Language Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Loader Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Loader Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Controller Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Controller Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:08:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:08:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:08:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:08:44 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:08:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:08:46 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:46 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:47 --> Session Class Initialized
DEBUG - 2014-04-01 11:08:47 --> Session Class Initialized
DEBUG - 2014-04-01 11:08:47 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:08:47 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:08:47 --> A session cookie was not found.
DEBUG - 2014-04-01 11:08:47 --> A session cookie was not found.
DEBUG - 2014-04-01 11:08:47 --> Session routines successfully run
DEBUG - 2014-04-01 11:08:47 --> Session routines successfully run
DEBUG - 2014-04-01 11:08:47 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:08:47 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:08:47 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:47 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:48 --> Config Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:08:48 --> URI Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Router Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Output Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Security Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Input Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:08:48 --> Language Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Loader Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Controller Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:08:48 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:08:48 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:48 --> Session Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:08:48 --> A session cookie was not found.
DEBUG - 2014-04-01 11:08:48 --> Session routines successfully run
DEBUG - 2014-04-01 11:08:48 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:08:48 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:49 --> Final output sent to browser
DEBUG - 2014-04-01 11:08:49 --> Final output sent to browser
DEBUG - 2014-04-01 11:08:49 --> Final output sent to browser
DEBUG - 2014-04-01 11:08:49 --> Total execution time: 5.3313
DEBUG - 2014-04-01 11:08:49 --> Total execution time: 5.3533
DEBUG - 2014-04-01 11:08:49 --> Total execution time: 1.0181
DEBUG - 2014-04-01 11:08:51 --> Config Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:08:51 --> URI Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Router Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Output Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Security Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Input Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:08:51 --> Language Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Loader Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Config Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:08:51 --> URI Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Router Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Output Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Security Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Config Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:08:51 --> URI Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Router Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Input Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:08:51 --> Language Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Loader Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Controller Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Output Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Security Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Input Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:08:51 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Language Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Loader Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:51 --> Controller Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Session Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:08:51 --> A session cookie was not found.
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:08:51 --> Session routines successfully run
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:51 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Final output sent to browser
DEBUG - 2014-04-01 11:08:51 --> Total execution time: 0.0150
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:51 --> Session Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:08:51 --> A session cookie was not found.
DEBUG - 2014-04-01 11:08:51 --> Session routines successfully run
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:08:51 --> Controller Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:08:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:51 --> Final output sent to browser
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:08:51 --> Total execution time: 0.0140
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:51 --> Session Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:08:51 --> A session cookie was not found.
DEBUG - 2014-04-01 11:08:51 --> Session routines successfully run
DEBUG - 2014-04-01 11:08:51 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:08:51 --> Model Class Initialized
DEBUG - 2014-04-01 11:08:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:08:51 --> Final output sent to browser
DEBUG - 2014-04-01 11:08:51 --> Total execution time: 0.0280
DEBUG - 2014-04-01 11:09:00 --> Config Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:09:00 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:09:00 --> URI Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Router Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Output Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Security Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Input Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:09:00 --> Language Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Loader Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Controller Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:09:00 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:09:00 --> Model Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Model Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Model Class Initialized
DEBUG - 2014-04-01 11:09:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:09:00 --> Final output sent to browser
DEBUG - 2014-04-01 11:09:00 --> Total execution time: 0.0980
DEBUG - 2014-04-01 11:09:10 --> Config Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:09:10 --> URI Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Router Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Output Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Security Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Input Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:09:10 --> Language Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Loader Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Controller Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:09:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:09:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:09:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:09:10 --> Final output sent to browser
DEBUG - 2014-04-01 11:09:10 --> Total execution time: 0.0170
DEBUG - 2014-04-01 11:10:42 --> Config Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:10:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:10:42 --> URI Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Router Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Output Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Security Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Input Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:10:42 --> Language Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Loader Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Controller Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:10:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:10:42 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Helper loaded: email_helper
DEBUG - 2014-04-01 11:10:42 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:10:44 --> Final output sent to browser
DEBUG - 2014-04-01 11:10:44 --> Total execution time: 2.3211
DEBUG - 2014-04-01 11:10:55 --> Config Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:10:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:10:55 --> URI Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Router Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Output Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Security Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Input Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:10:55 --> Language Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Loader Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Controller Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:10:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:10:55 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:10:55 --> Final output sent to browser
DEBUG - 2014-04-01 11:10:55 --> Total execution time: 0.3740
DEBUG - 2014-04-01 11:10:58 --> Config Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:10:58 --> URI Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Router Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Output Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Security Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Input Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:10:58 --> Language Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Loader Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Controller Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:10:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:10:58 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:10:58 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:10:59 --> Final output sent to browser
DEBUG - 2014-04-01 11:10:59 --> Total execution time: 1.2171
DEBUG - 2014-04-01 11:10:59 --> Config Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:10:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:10:59 --> URI Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Router Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Output Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Security Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Input Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:10:59 --> Language Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Loader Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Controller Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:10:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:10:59 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Model Class Initialized
DEBUG - 2014-04-01 11:10:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:11:00 --> Final output sent to browser
DEBUG - 2014-04-01 11:11:00 --> Total execution time: 0.9471
DEBUG - 2014-04-01 11:23:30 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:30 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:30 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:30 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:30 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:30 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:30 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:30 --> Session Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:30 --> A session cookie was not found.
DEBUG - 2014-04-01 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:30 --> Session Class Initialized
DEBUG - 2014-04-01 11:23:30 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Session routines successfully run
DEBUG - 2014-04-01 11:23:30 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:30 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:30 --> A session cookie was not found.
DEBUG - 2014-04-01 11:23:30 --> Session routines successfully run
DEBUG - 2014-04-01 11:23:30 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:30 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:30 --> Session Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:23:30 --> A session cookie was not found.
DEBUG - 2014-04-01 11:23:30 --> Session routines successfully run
DEBUG - 2014-04-01 11:23:30 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:30 --> Total execution time: 0.0360
DEBUG - 2014-04-01 11:23:30 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:30 --> Total execution time: 0.0430
DEBUG - 2014-04-01 11:23:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:23:30 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:30 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:30 --> Total execution time: 0.0780
DEBUG - 2014-04-01 11:23:31 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:31 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:31 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:31 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:31 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:31 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:31 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:31 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:31 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:31 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Session Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:23:31 --> A session cookie was not found.
DEBUG - 2014-04-01 11:23:31 --> Session routines successfully run
DEBUG - 2014-04-01 11:23:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:31 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:31 --> Session Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:31 --> Total execution time: 0.0120
DEBUG - 2014-04-01 11:23:31 --> Session Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:23:31 --> A session cookie was not found.
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:23:31 --> Session routines successfully run
DEBUG - 2014-04-01 11:23:31 --> A session cookie was not found.
DEBUG - 2014-04-01 11:23:31 --> Session routines successfully run
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:23:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:31 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:31 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:31 --> Total execution time: 0.0150
DEBUG - 2014-04-01 11:23:31 --> Total execution time: 0.0150
DEBUG - 2014-04-01 11:23:43 --> Config Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:23:43 --> URI Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Router Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Output Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Security Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Input Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:23:43 --> Language Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Loader Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Controller Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:23:43 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Helper loaded: email_helper
DEBUG - 2014-04-01 11:23:43 --> Model Class Initialized
DEBUG - 2014-04-01 11:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:23:45 --> Final output sent to browser
DEBUG - 2014-04-01 11:23:45 --> Total execution time: 1.8371
DEBUG - 2014-04-01 11:26:11 --> Config Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:26:11 --> URI Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Router Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Output Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Security Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Input Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:26:11 --> Language Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Loader Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Controller Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:26:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:26:11 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:26:11 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:26:12 --> Final output sent to browser
DEBUG - 2014-04-01 11:26:12 --> Total execution time: 0.1530
DEBUG - 2014-04-01 11:26:18 --> Config Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:26:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:26:18 --> URI Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Router Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Output Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Security Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Input Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:26:18 --> Language Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Loader Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Controller Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:26:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:26:18 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:18 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:19 --> Final output sent to browser
DEBUG - 2014-04-01 11:26:19 --> Total execution time: 1.0001
DEBUG - 2014-04-01 11:26:19 --> Config Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:26:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:26:19 --> URI Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Router Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Output Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Security Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Input Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:26:19 --> Language Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Loader Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Controller Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:26:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:26:19 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:20 --> Final output sent to browser
DEBUG - 2014-04-01 11:26:20 --> Total execution time: 0.9401
DEBUG - 2014-04-01 11:26:39 --> Config Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:26:39 --> URI Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Router Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Output Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Security Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Input Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:26:39 --> Language Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Config Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Loader Class Initialized
DEBUG - 2014-04-01 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:26:39 --> URI Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Controller Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Router Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:26:39 --> Output Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Security Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Input Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:26:39 --> Language Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Loader Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Controller Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Session Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:26:39 --> A session cookie was not found.
DEBUG - 2014-04-01 11:26:39 --> Session routines successfully run
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:26:39 --> Config Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Session Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:26:39 --> A session cookie was not found.
DEBUG - 2014-04-01 11:26:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:39 --> Session routines successfully run
DEBUG - 2014-04-01 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:26:39 --> URI Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Router Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:39 --> Output Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Final output sent to browser
DEBUG - 2014-04-01 11:26:39 --> Total execution time: 0.0160
DEBUG - 2014-04-01 11:26:39 --> Security Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Final output sent to browser
DEBUG - 2014-04-01 11:26:39 --> Input Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Total execution time: 0.0140
DEBUG - 2014-04-01 11:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:26:39 --> Language Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Loader Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Controller Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:39 --> Session Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:26:39 --> A session cookie was not found.
DEBUG - 2014-04-01 11:26:39 --> Session routines successfully run
DEBUG - 2014-04-01 11:26:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:26:39 --> Model Class Initialized
DEBUG - 2014-04-01 11:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:26:39 --> Final output sent to browser
DEBUG - 2014-04-01 11:26:39 --> Total execution time: 0.0130
DEBUG - 2014-04-01 11:27:10 --> Config Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:27:10 --> URI Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Router Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Output Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Security Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Input Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:27:10 --> Language Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Loader Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Controller Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Config Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:27:10 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:27:10 --> URI Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Router Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Output Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:27:10 --> Security Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Input Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:27:10 --> Session Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Language Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:27:10 --> A session cookie was not found.
DEBUG - 2014-04-01 11:27:10 --> Loader Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Session routines successfully run
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:27:10 --> Controller Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Final output sent to browser
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Total execution time: 0.0130
DEBUG - 2014-04-01 11:27:10 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Config Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:27:10 --> URI Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Router Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Session Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:27:10 --> A session cookie was not found.
DEBUG - 2014-04-01 11:27:10 --> Output Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Session routines successfully run
DEBUG - 2014-04-01 11:27:10 --> Security Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:27:10 --> Input Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:27:10 --> Language Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Loader Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Controller Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Final output sent to browser
DEBUG - 2014-04-01 11:27:10 --> Total execution time: 0.0140
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:27:10 --> Session Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:27:10 --> A session cookie was not found.
DEBUG - 2014-04-01 11:27:10 --> Session routines successfully run
DEBUG - 2014-04-01 11:27:10 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:27:10 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:27:10 --> Final output sent to browser
DEBUG - 2014-04-01 11:27:10 --> Total execution time: 0.0110
DEBUG - 2014-04-01 11:27:59 --> Config Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:27:59 --> URI Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Router Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Output Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Security Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Input Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:27:59 --> Language Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Loader Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Controller Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:27:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:27:59 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Helper loaded: email_helper
DEBUG - 2014-04-01 11:27:59 --> Model Class Initialized
DEBUG - 2014-04-01 11:27:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:01 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:01 --> Total execution time: 1.8931
DEBUG - 2014-04-01 11:28:19 --> Config Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:28:19 --> URI Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Router Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Output Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Security Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Input Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:28:19 --> Language Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Loader Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Controller Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:28:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:28:19 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:28:19 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:19 --> Total execution time: 0.1680
DEBUG - 2014-04-01 11:28:26 --> Config Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:28:26 --> URI Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Router Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Output Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Security Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Input Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:28:26 --> Language Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Loader Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Controller Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:28:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:28:26 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:26 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:27 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:27 --> Total execution time: 0.9771
DEBUG - 2014-04-01 11:28:27 --> Config Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:28:27 --> URI Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Router Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Output Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Security Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Input Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:28:27 --> Language Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Loader Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Controller Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:28:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:28:27 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:27 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:27 --> Total execution time: 0.9291
DEBUG - 2014-04-01 11:28:54 --> Config Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Config Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:28:54 --> URI Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Router Class Initialized
DEBUG - 2014-04-01 11:28:54 --> URI Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Router Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Output Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Output Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Security Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Security Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Input Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:28:54 --> Input Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:28:54 --> Language Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Language Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Loader Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Loader Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Controller Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Controller Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:54 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Session Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:28:54 --> A session cookie was not found.
DEBUG - 2014-04-01 11:28:54 --> Session routines successfully run
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:54 --> Session Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:28:54 --> A session cookie was not found.
DEBUG - 2014-04-01 11:28:54 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:54 --> Total execution time: 0.0140
DEBUG - 2014-04-01 11:28:54 --> Session routines successfully run
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:54 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:54 --> Total execution time: 0.0160
DEBUG - 2014-04-01 11:28:54 --> Config Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:28:54 --> URI Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Router Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Output Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Security Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Input Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:28:54 --> Language Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Loader Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Controller Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:54 --> Session Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: string_helper
DEBUG - 2014-04-01 11:28:54 --> A session cookie was not found.
DEBUG - 2014-04-01 11:28:54 --> Session routines successfully run
DEBUG - 2014-04-01 11:28:54 --> Helper loaded: url_helper
DEBUG - 2014-04-01 11:28:54 --> Model Class Initialized
DEBUG - 2014-04-01 11:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:28:54 --> Final output sent to browser
DEBUG - 2014-04-01 11:28:54 --> Total execution time: 0.0100
DEBUG - 2014-04-01 11:29:09 --> Config Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:29:09 --> URI Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Router Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Output Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Security Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Input Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:29:09 --> Language Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Loader Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Controller Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:29:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:29:09 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Helper loaded: email_helper
DEBUG - 2014-04-01 11:29:09 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:29:10 --> Final output sent to browser
DEBUG - 2014-04-01 11:29:10 --> Total execution time: 1.8571
DEBUG - 2014-04-01 11:29:17 --> Config Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:29:17 --> URI Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Router Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Output Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Security Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Input Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:29:17 --> Language Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Loader Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Controller Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:29:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:29:17 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:29:17 --> Final output sent to browser
DEBUG - 2014-04-01 11:29:17 --> Total execution time: 0.1420
DEBUG - 2014-04-01 11:29:23 --> Config Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:29:23 --> URI Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Router Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Output Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Security Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Input Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:29:23 --> Language Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Loader Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Controller Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:29:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:29:23 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:29:23 --> Image Lib Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:29:24 --> Final output sent to browser
DEBUG - 2014-04-01 11:29:24 --> Total execution time: 0.9831
DEBUG - 2014-04-01 11:29:24 --> Config Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Hooks Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Utf8 Class Initialized
DEBUG - 2014-04-01 11:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 11:29:24 --> URI Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Router Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Output Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Security Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Input Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 11:29:24 --> Language Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Loader Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Controller Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 11:29:24 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 11:29:24 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Database Driver Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Model Class Initialized
DEBUG - 2014-04-01 11:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 11:29:25 --> Final output sent to browser
DEBUG - 2014-04-01 11:29:25 --> Total execution time: 0.9581
DEBUG - 2014-04-01 12:12:42 --> Config Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 12:12:42 --> URI Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Router Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Output Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Security Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Input Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 12:12:42 --> Language Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Loader Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Controller Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:12:42 --> Session Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 12:12:42 --> A session cookie was not found.
DEBUG - 2014-04-01 12:12:42 --> Session routines successfully run
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:12:42 --> Final output sent to browser
DEBUG - 2014-04-01 12:12:42 --> Total execution time: 0.0120
DEBUG - 2014-04-01 12:12:42 --> Config Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 12:12:42 --> URI Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Router Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Output Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Security Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Input Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 12:12:42 --> Language Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Loader Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Controller Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:12:42 --> Session Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 12:12:42 --> A session cookie was not found.
DEBUG - 2014-04-01 12:12:42 --> Session routines successfully run
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:12:42 --> Final output sent to browser
DEBUG - 2014-04-01 12:12:42 --> Total execution time: 0.0130
DEBUG - 2014-04-01 12:12:42 --> Config Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 12:12:42 --> URI Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Router Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Output Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Security Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Input Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 12:12:42 --> Language Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Loader Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Controller Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:12:42 --> Session Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 12:12:42 --> A session cookie was not found.
DEBUG - 2014-04-01 12:12:42 --> Session routines successfully run
DEBUG - 2014-04-01 12:12:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 12:12:42 --> Model Class Initialized
DEBUG - 2014-04-01 12:12:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:12:42 --> Final output sent to browser
DEBUG - 2014-04-01 12:12:42 --> Total execution time: 0.0230
DEBUG - 2014-04-01 12:16:44 --> Config Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 12:16:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 12:16:44 --> URI Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Router Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Output Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Security Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Input Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 12:16:44 --> Language Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Loader Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Controller Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 12:16:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 12:16:44 --> Model Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Model Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Model Class Initialized
DEBUG - 2014-04-01 12:16:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 12:16:47 --> Final output sent to browser
DEBUG - 2014-04-01 12:16:47 --> Total execution time: 2.9292
DEBUG - 2014-04-01 15:50:29 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:29 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:29 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:29 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:29 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:29 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:29 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:29 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:29 --> Session Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:50:29 --> A session cookie was not found.
DEBUG - 2014-04-01 15:50:29 --> Session routines successfully run
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:29 --> Total execution time: 0.0290
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:29 --> Session Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:50:29 --> A session cookie was not found.
DEBUG - 2014-04-01 15:50:29 --> Session routines successfully run
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:29 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:29 --> Total execution time: 0.0290
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:29 --> Session Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:50:29 --> A session cookie was not found.
DEBUG - 2014-04-01 15:50:29 --> Session routines successfully run
DEBUG - 2014-04-01 15:50:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:50:29 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:29 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:29 --> Total execution time: 0.0460
DEBUG - 2014-04-01 15:50:31 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:31 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:31 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:31 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:31 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:31 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:31 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:31 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:31 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Session Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:50:31 --> A session cookie was not found.
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Session routines successfully run
DEBUG - 2014-04-01 15:50:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:31 --> Session Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Session Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:50:31 --> A session cookie was not found.
DEBUG - 2014-04-01 15:50:31 --> A session cookie was not found.
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:50:31 --> Session routines successfully run
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Session routines successfully run
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:50:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:31 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:31 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:31 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:31 --> Total execution time: 0.0140
DEBUG - 2014-04-01 15:50:31 --> Total execution time: 0.0150
DEBUG - 2014-04-01 15:50:31 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:31 --> Total execution time: 0.0150
DEBUG - 2014-04-01 15:50:39 --> Config Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:50:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:50:39 --> URI Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Router Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Output Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Security Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Input Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:50:39 --> Language Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Loader Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Controller Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:50:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:50:39 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Model Class Initialized
DEBUG - 2014-04-01 15:50:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:50:40 --> Final output sent to browser
DEBUG - 2014-04-01 15:50:40 --> Total execution time: 1.2181
DEBUG - 2014-04-01 15:52:41 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:41 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:41 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:41 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:41 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:41 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:41 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:41 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:41 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Session Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:52:41 --> A session cookie was not found.
DEBUG - 2014-04-01 15:52:41 --> Session routines successfully run
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Session Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Total execution time: 0.0140
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:52:41 --> A session cookie was not found.
DEBUG - 2014-04-01 15:52:41 --> Session routines successfully run
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:41 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:41 --> Session Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Total execution time: 0.0180
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:52:41 --> A session cookie was not found.
DEBUG - 2014-04-01 15:52:41 --> Session routines successfully run
DEBUG - 2014-04-01 15:52:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:52:41 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:41 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:41 --> Total execution time: 0.0180
DEBUG - 2014-04-01 15:52:43 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:43 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:43 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:43 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:43 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:43 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:43 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:43 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:43 --> Session Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Session Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:43 --> Session Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:52:43 --> A session cookie was not found.
DEBUG - 2014-04-01 15:52:43 --> Session routines successfully run
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:52:43 --> A session cookie was not found.
DEBUG - 2014-04-01 15:52:43 --> Session routines successfully run
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:43 --> A session cookie was not found.
DEBUG - 2014-04-01 15:52:43 --> Session routines successfully run
DEBUG - 2014-04-01 15:52:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:52:43 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:43 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:43 --> Total execution time: 0.0150
DEBUG - 2014-04-01 15:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:43 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:43 --> Total execution time: 0.0170
DEBUG - 2014-04-01 15:52:43 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:43 --> Total execution time: 0.0180
DEBUG - 2014-04-01 15:52:49 --> Config Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:52:49 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:52:49 --> URI Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Router Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Output Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Security Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Input Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:52:49 --> Language Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Loader Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Controller Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:52:49 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:52:49 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Model Class Initialized
DEBUG - 2014-04-01 15:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:52:50 --> Final output sent to browser
DEBUG - 2014-04-01 15:52:50 --> Total execution time: 0.9771
DEBUG - 2014-04-01 15:53:33 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:33 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:33 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:33 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:33 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:34 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:34 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:34 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:34 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:34 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:34 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:34 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:34 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:34 --> Total execution time: 0.0190
DEBUG - 2014-04-01 15:53:34 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:34 --> Total execution time: 0.0200
DEBUG - 2014-04-01 15:53:34 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:34 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:34 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:34 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:34 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:34 --> Total execution time: 0.0220
DEBUG - 2014-04-01 15:53:35 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:35 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:35 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:35 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:35 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:35 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:35 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:35 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:35 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:35 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:35 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:35 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:35 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:35 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:35 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:35 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:35 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:35 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:35 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:35 --> Total execution time: 0.0160
DEBUG - 2014-04-01 15:53:35 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:35 --> Total execution time: 0.0130
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:35 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:35 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:35 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:35 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:35 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:35 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:35 --> Total execution time: 0.0180
DEBUG - 2014-04-01 15:53:47 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:47 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:47 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:47 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:47 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:47 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Config Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> URI Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Router Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Output Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Security Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Input Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:47 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:47 --> Language Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:47 --> Loader Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:47 --> Controller Class Initialized
DEBUG - 2014-04-01 15:53:47 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:47 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:47 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:47 --> Total execution time: 0.0160
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:47 --> Total execution time: 0.0190
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:47 --> Session Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:53:47 --> A session cookie was not found.
DEBUG - 2014-04-01 15:53:47 --> Session routines successfully run
DEBUG - 2014-04-01 15:53:47 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:53:47 --> Model Class Initialized
DEBUG - 2014-04-01 15:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:53:47 --> Final output sent to browser
DEBUG - 2014-04-01 15:53:47 --> Total execution time: 0.0200
DEBUG - 2014-04-01 15:56:05 --> Config Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Config Class Initialized
DEBUG - 2014-04-01 15:56:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:56:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:56:05 --> URI Class Initialized
DEBUG - 2014-04-01 15:56:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:56:05 --> Router Class Initialized
DEBUG - 2014-04-01 15:56:05 --> URI Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Router Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Output Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Output Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Security Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Security Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Config Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:56:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:56:05 --> URI Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Input Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:56:05 --> Input Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Router Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Language Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Output Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Loader Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:56:05 --> Controller Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Security Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Input Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:56:05 --> Language Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Loader Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Controller Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:56:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:05 --> Language Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Session Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Loader Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:56:05 --> Controller Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:56:05 --> A session cookie was not found.
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Session routines successfully run
DEBUG - 2014-04-01 15:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:56:05 --> Session Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:05 --> Session Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:56:05 --> A session cookie was not found.
DEBUG - 2014-04-01 15:56:05 --> Session routines successfully run
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:56:05 --> A session cookie was not found.
DEBUG - 2014-04-01 15:56:05 --> Session routines successfully run
DEBUG - 2014-04-01 15:56:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:56:05 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:05 --> Final output sent to browser
DEBUG - 2014-04-01 15:56:05 --> Total execution time: 0.0210
DEBUG - 2014-04-01 15:56:05 --> Final output sent to browser
DEBUG - 2014-04-01 15:56:05 --> Final output sent to browser
DEBUG - 2014-04-01 15:56:05 --> Total execution time: 0.0230
DEBUG - 2014-04-01 15:56:05 --> Total execution time: 0.0190
DEBUG - 2014-04-01 15:56:06 --> Config Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Config Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Config Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:56:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:56:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:56:07 --> URI Class Initialized
DEBUG - 2014-04-01 15:56:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:56:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:56:07 --> Router Class Initialized
DEBUG - 2014-04-01 15:56:07 --> URI Class Initialized
DEBUG - 2014-04-01 15:56:07 --> URI Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Router Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Router Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Output Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Output Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Security Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Output Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Security Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Input Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Security Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:56:07 --> Input Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Input Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:56:07 --> Language Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:56:07 --> Language Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Language Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Loader Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Controller Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Loader Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Loader Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Controller Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Controller Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:07 --> Session Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Session Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:56:07 --> A session cookie was not found.
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:56:07 --> Session routines successfully run
DEBUG - 2014-04-01 15:56:07 --> A session cookie was not found.
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:56:07 --> Session routines successfully run
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:07 --> Session Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:56:07 --> A session cookie was not found.
DEBUG - 2014-04-01 15:56:07 --> Session routines successfully run
DEBUG - 2014-04-01 15:56:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:07 --> Model Class Initialized
DEBUG - 2014-04-01 15:56:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:56:07 --> Final output sent to browser
DEBUG - 2014-04-01 15:56:07 --> Total execution time: 0.0170
DEBUG - 2014-04-01 15:56:07 --> Final output sent to browser
DEBUG - 2014-04-01 15:56:07 --> Total execution time: 0.0170
DEBUG - 2014-04-01 15:56:07 --> Final output sent to browser
DEBUG - 2014-04-01 15:56:07 --> Total execution time: 0.0170
DEBUG - 2014-04-01 15:58:42 --> Config Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Config Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:58:42 --> URI Class Initialized
DEBUG - 2014-04-01 15:58:42 --> URI Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Router Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Router Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Output Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Security Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Input Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Config Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:58:42 --> Output Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Language Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:58:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:58:42 --> Security Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Loader Class Initialized
DEBUG - 2014-04-01 15:58:42 --> URI Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Controller Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Input Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Router Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:58:42 --> Language Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:58:42 --> Output Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Loader Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Controller Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Security Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:58:42 --> Input Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:58:42 --> Language Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:42 --> Session Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:58:42 --> A session cookie was not found.
DEBUG - 2014-04-01 15:58:42 --> Session routines successfully run
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:42 --> Final output sent to browser
DEBUG - 2014-04-01 15:58:42 --> Total execution time: 0.0150
DEBUG - 2014-04-01 15:58:42 --> Loader Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Controller Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Session Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:58:42 --> A session cookie was not found.
DEBUG - 2014-04-01 15:58:42 --> Session routines successfully run
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:58:42 --> Session Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:58:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:42 --> A session cookie was not found.
DEBUG - 2014-04-01 15:58:42 --> Session routines successfully run
DEBUG - 2014-04-01 15:58:42 --> Final output sent to browser
DEBUG - 2014-04-01 15:58:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:58:42 --> Total execution time: 0.0210
DEBUG - 2014-04-01 15:58:42 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:42 --> Final output sent to browser
DEBUG - 2014-04-01 15:58:42 --> Total execution time: 0.0190
DEBUG - 2014-04-01 15:58:44 --> Config Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:58:44 --> URI Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Router Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Output Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Security Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Input Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Config Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:58:44 --> URI Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Router Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:58:44 --> Language Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Output Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Loader Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Config Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Controller Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Security Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Input Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:58:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Language Class Initialized
DEBUG - 2014-04-01 15:58:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:58:44 --> URI Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Loader Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:58:44 --> Router Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Controller Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:58:44 --> Output Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Security Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Input Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:58:44 --> Language Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Session Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Loader Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:58:44 --> A session cookie was not found.
DEBUG - 2014-04-01 15:58:44 --> Session routines successfully run
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Controller Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:58:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Session Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:44 --> Session Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:58:44 --> A session cookie was not found.
DEBUG - 2014-04-01 15:58:44 --> Session routines successfully run
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: string_helper
DEBUG - 2014-04-01 15:58:44 --> A session cookie was not found.
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Session routines successfully run
DEBUG - 2014-04-01 15:58:44 --> Final output sent to browser
DEBUG - 2014-04-01 15:58:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:44 --> Helper loaded: url_helper
DEBUG - 2014-04-01 15:58:44 --> Total execution time: 0.0180
DEBUG - 2014-04-01 15:58:44 --> Model Class Initialized
DEBUG - 2014-04-01 15:58:44 --> Final output sent to browser
DEBUG - 2014-04-01 15:58:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 15:58:44 --> Total execution time: 0.0140
DEBUG - 2014-04-01 15:58:44 --> Final output sent to browser
DEBUG - 2014-04-01 15:58:44 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:00:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:00:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:00:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:00:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:00:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:00:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:00:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:00:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:00:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:00:40 --> Session routines successfully run
DEBUG - 2014-04-01 16:00:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:00:40 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:40 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:40 --> Session Class Initialized
DEBUG - 2014-04-01 16:00:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:00:40 --> A session cookie was not found.
DEBUG - 2014-04-01 16:00:40 --> Final output sent to browser
DEBUG - 2014-04-01 16:00:40 --> Session routines successfully run
DEBUG - 2014-04-01 16:00:40 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:00:40 --> Session routines successfully run
DEBUG - 2014-04-01 16:00:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:00:40 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:00:40 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:40 --> Final output sent to browser
DEBUG - 2014-04-01 16:00:40 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:00:40 --> Final output sent to browser
DEBUG - 2014-04-01 16:00:40 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:00:41 --> Config Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Config Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Config Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:00:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:00:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:00:41 --> URI Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:00:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:00:41 --> Router Class Initialized
DEBUG - 2014-04-01 16:00:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:00:41 --> URI Class Initialized
DEBUG - 2014-04-01 16:00:41 --> URI Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Router Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Output Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Router Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Security Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Output Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Output Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Input Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Security Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:00:41 --> Security Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Input Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Language Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Input Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:00:41 --> Loader Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Language Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Language Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Loader Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Controller Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Controller Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:00:41 --> Loader Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Controller Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:00:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:41 --> Session Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Session Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:00:41 --> A session cookie was not found.
DEBUG - 2014-04-01 16:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:41 --> A session cookie was not found.
DEBUG - 2014-04-01 16:00:41 --> Session routines successfully run
DEBUG - 2014-04-01 16:00:41 --> Session routines successfully run
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:00:41 --> Session Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> A session cookie was not found.
DEBUG - 2014-04-01 16:00:41 --> Session routines successfully run
DEBUG - 2014-04-01 16:00:41 --> Final output sent to browser
DEBUG - 2014-04-01 16:00:41 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:00:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:41 --> Model Class Initialized
DEBUG - 2014-04-01 16:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:00:41 --> Final output sent to browser
DEBUG - 2014-04-01 16:00:41 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:00:41 --> Final output sent to browser
DEBUG - 2014-04-01 16:00:41 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:01:28 --> Config Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Config Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Config Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:01:28 --> URI Class Initialized
DEBUG - 2014-04-01 16:01:28 --> URI Class Initialized
DEBUG - 2014-04-01 16:01:28 --> URI Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Router Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Router Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Router Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Output Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Output Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Output Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Security Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Security Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Input Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Input Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:01:28 --> Security Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Language Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Language Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Input Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Loader Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:01:28 --> Loader Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Controller Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Controller Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Language Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Loader Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Controller Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:01:28 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:28 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Session Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:01:28 --> A session cookie was not found.
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Session routines successfully run
DEBUG - 2014-04-01 16:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:01:28 --> Session Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:01:28 --> A session cookie was not found.
DEBUG - 2014-04-01 16:01:28 --> Session routines successfully run
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:28 --> Session Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:01:28 --> A session cookie was not found.
DEBUG - 2014-04-01 16:01:28 --> Session routines successfully run
DEBUG - 2014-04-01 16:01:28 --> Final output sent to browser
DEBUG - 2014-04-01 16:01:28 --> Final output sent to browser
DEBUG - 2014-04-01 16:01:28 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:01:28 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:01:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:28 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:28 --> Final output sent to browser
DEBUG - 2014-04-01 16:01:28 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:01:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:01:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:01:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:01:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:01:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:01:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:01:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:01:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:01:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:01:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:01:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:01:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:01:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:01:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:01:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:01:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:01:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:01:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:01:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:01:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:01:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:01:29 --> Total execution time: 0.0260
DEBUG - 2014-04-01 16:01:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:01:29 --> Total execution time: 0.0230
DEBUG - 2014-04-01 16:02:01 --> Config Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Config Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:02:01 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:02:01 --> URI Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Config Class Initialized
DEBUG - 2014-04-01 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:02:01 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Router Class Initialized
DEBUG - 2014-04-01 16:02:01 --> URI Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Router Class Initialized
DEBUG - 2014-04-01 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:02:01 --> URI Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Output Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Output Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Router Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Security Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Security Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Input Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Output Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Input Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:02:01 --> Security Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Language Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Language Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Input Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:02:01 --> Loader Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Language Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Controller Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Loader Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:02:01 --> Loader Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Controller Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Controller Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:01 --> Session Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:02:01 --> A session cookie was not found.
DEBUG - 2014-04-01 16:02:01 --> Session routines successfully run
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:02:01 --> Session Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:02:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:01 --> Session Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Final output sent to browser
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:02:01 --> A session cookie was not found.
DEBUG - 2014-04-01 16:02:01 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:02:01 --> A session cookie was not found.
DEBUG - 2014-04-01 16:02:01 --> Session routines successfully run
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:02:01 --> Session routines successfully run
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:02:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:01 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:01 --> Final output sent to browser
DEBUG - 2014-04-01 16:02:01 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:02:01 --> Final output sent to browser
DEBUG - 2014-04-01 16:02:01 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:02:02 --> Config Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Config Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:02:02 --> URI Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Config Class Initialized
DEBUG - 2014-04-01 16:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:02:02 --> Router Class Initialized
DEBUG - 2014-04-01 16:02:02 --> URI Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Router Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Output Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Security Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Output Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Input Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Security Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:02:02 --> Input Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Language Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:02:02 --> Loader Class Initialized
DEBUG - 2014-04-01 16:02:02 --> URI Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:02:02 --> Controller Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Language Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:02:02 --> Loader Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:02:02 --> Router Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Controller Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:02:02 --> Output Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Security Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Input Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:02:02 --> Language Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Loader Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:02 --> Session Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Session Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:02:02 --> Controller Class Initialized
DEBUG - 2014-04-01 16:02:02 --> A session cookie was not found.
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:02:02 --> Session routines successfully run
DEBUG - 2014-04-01 16:02:02 --> A session cookie was not found.
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:02:02 --> Session routines successfully run
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Final output sent to browser
DEBUG - 2014-04-01 16:02:02 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:02:02 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Final output sent to browser
DEBUG - 2014-04-01 16:02:02 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:02 --> Session Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:02:02 --> A session cookie was not found.
DEBUG - 2014-04-01 16:02:02 --> Session routines successfully run
DEBUG - 2014-04-01 16:02:02 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:02:02 --> Model Class Initialized
DEBUG - 2014-04-01 16:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:02:02 --> Final output sent to browser
DEBUG - 2014-04-01 16:02:02 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:03:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:03:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:03:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:03:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:03:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:03:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:03:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:03:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:03:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:03:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Total execution time: 0.0120
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:03:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:03:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:03:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:03:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:03:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:03:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:03:37 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:03:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:03:37 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:03:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:03:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:03:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:03:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:03:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:03:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:03:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:03:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:03:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:03:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:03:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:03:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:03:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:03:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:03:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:03:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:03:39 --> Session routines successfully run
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Final output sent to browser
DEBUG - 2014-04-01 16:03:39 --> Total execution time: 0.0120
DEBUG - 2014-04-01 16:03:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:03:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:03:39 --> Session routines successfully run
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:39 --> Final output sent to browser
DEBUG - 2014-04-01 16:03:39 --> Total execution time: 0.0140
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:03:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:03:39 --> Session routines successfully run
DEBUG - 2014-04-01 16:03:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:03:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:03:39 --> Final output sent to browser
DEBUG - 2014-04-01 16:03:39 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:04:19 --> Config Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Config Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:04:19 --> URI Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Router Class Initialized
DEBUG - 2014-04-01 16:04:19 --> URI Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Config Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Router Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Output Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Output Class Initialized
DEBUG - 2014-04-01 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:04:19 --> Security Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Security Class Initialized
DEBUG - 2014-04-01 16:04:19 --> URI Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Input Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Router Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Input Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:04:19 --> Language Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Output Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Loader Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:04:19 --> Security Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Language Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Loader Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Controller Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:04:19 --> Controller Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:04:19 --> Input Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Language Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Loader Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Controller Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Session Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:04:19 --> A session cookie was not found.
DEBUG - 2014-04-01 16:04:19 --> Session routines successfully run
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Session Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:04:19 --> A session cookie was not found.
DEBUG - 2014-04-01 16:04:19 --> Session routines successfully run
DEBUG - 2014-04-01 16:04:19 --> Final output sent to browser
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:04:19 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:19 --> Final output sent to browser
DEBUG - 2014-04-01 16:04:19 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:19 --> Session Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:04:19 --> A session cookie was not found.
DEBUG - 2014-04-01 16:04:19 --> Session routines successfully run
DEBUG - 2014-04-01 16:04:19 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:04:19 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:19 --> Final output sent to browser
DEBUG - 2014-04-01 16:04:19 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:04:21 --> Config Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Config Class Initialized
DEBUG - 2014-04-01 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:04:21 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Config Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:04:21 --> URI Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Router Class Initialized
DEBUG - 2014-04-01 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:04:21 --> URI Class Initialized
DEBUG - 2014-04-01 16:04:21 --> URI Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Output Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Router Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Router Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Security Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Input Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Output Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Output Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:04:21 --> Security Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Language Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Security Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Input Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:04:21 --> Language Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Loader Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Controller Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Loader Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Controller Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:04:21 --> Input Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Language Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Loader Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Controller Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:04:21 --> Session Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> A session cookie was not found.
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:21 --> Session routines successfully run
DEBUG - 2014-04-01 16:04:21 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:21 --> Session Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:21 --> Session Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:04:21 --> A session cookie was not found.
DEBUG - 2014-04-01 16:04:21 --> Session routines successfully run
DEBUG - 2014-04-01 16:04:21 --> Final output sent to browser
DEBUG - 2014-04-01 16:04:21 --> Total execution time: 0.0140
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:04:21 --> A session cookie was not found.
DEBUG - 2014-04-01 16:04:21 --> Session routines successfully run
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:04:21 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Model Class Initialized
DEBUG - 2014-04-01 16:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:04:21 --> Final output sent to browser
DEBUG - 2014-04-01 16:04:21 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:04:21 --> Final output sent to browser
DEBUG - 2014-04-01 16:04:21 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:05:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:05:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:05:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:05:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:05:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:05:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:05:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:05:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:05:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:05:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:05:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:05:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:05:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:05:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:05:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:37 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:05:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:05:37 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:05:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:05:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:05:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:05:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:05:37 --> Total execution time: 0.0240
DEBUG - 2014-04-01 16:05:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:05:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:05:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:05:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Config Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:05:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:05:39 --> Session routines successfully run
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:05:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:39 --> URI Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Final output sent to browser
DEBUG - 2014-04-01 16:05:39 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:05:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:05:39 --> Router Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Output Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Security Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Input Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:05:39 --> Language Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Loader Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Controller Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:05:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:05:39 --> Session routines successfully run
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:39 --> Final output sent to browser
DEBUG - 2014-04-01 16:05:39 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:39 --> Session Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:05:39 --> A session cookie was not found.
DEBUG - 2014-04-01 16:05:39 --> Session routines successfully run
DEBUG - 2014-04-01 16:05:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:05:39 --> Model Class Initialized
DEBUG - 2014-04-01 16:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:05:39 --> Final output sent to browser
DEBUG - 2014-04-01 16:05:39 --> Total execution time: 0.0280
DEBUG - 2014-04-01 16:06:42 --> Config Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Config Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:06:42 --> URI Class Initialized
DEBUG - 2014-04-01 16:06:42 --> URI Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Router Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Router Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Output Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Output Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Security Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Security Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Input Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Config Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Input Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:06:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:06:42 --> Language Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Language Class Initialized
DEBUG - 2014-04-01 16:06:42 --> URI Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Loader Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Router Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Loader Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Controller Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Controller Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:06:42 --> Output Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:06:42 --> Security Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Input Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Language Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:42 --> Session Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:06:42 --> A session cookie was not found.
DEBUG - 2014-04-01 16:06:42 --> Session routines successfully run
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:42 --> Final output sent to browser
DEBUG - 2014-04-01 16:06:42 --> Total execution time: 0.0140
DEBUG - 2014-04-01 16:06:42 --> Loader Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Controller Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Session Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:06:42 --> A session cookie was not found.
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Session routines successfully run
DEBUG - 2014-04-01 16:06:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:06:42 --> Session Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:06:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:42 --> A session cookie was not found.
DEBUG - 2014-04-01 16:06:42 --> Session routines successfully run
DEBUG - 2014-04-01 16:06:42 --> Final output sent to browser
DEBUG - 2014-04-01 16:06:42 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:06:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:06:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:42 --> Final output sent to browser
DEBUG - 2014-04-01 16:06:42 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:06:44 --> Config Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Config Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Config Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:06:44 --> URI Class Initialized
DEBUG - 2014-04-01 16:06:44 --> URI Class Initialized
DEBUG - 2014-04-01 16:06:44 --> URI Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Router Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Router Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Output Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Router Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Output Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Security Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Security Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Output Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Input Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Input Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:06:44 --> Security Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:06:44 --> Language Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Input Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:06:44 --> Language Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Loader Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Loader Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Language Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Controller Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Controller Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Loader Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:06:44 --> Controller Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:44 --> Session Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Session Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:06:44 --> A session cookie was not found.
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:06:44 --> A session cookie was not found.
DEBUG - 2014-04-01 16:06:44 --> Session routines successfully run
DEBUG - 2014-04-01 16:06:44 --> Session routines successfully run
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:44 --> Final output sent to browser
DEBUG - 2014-04-01 16:06:44 --> Total execution time: 0.0140
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:44 --> Final output sent to browser
DEBUG - 2014-04-01 16:06:44 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:06:44 --> Session Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:06:44 --> A session cookie was not found.
DEBUG - 2014-04-01 16:06:44 --> Session routines successfully run
DEBUG - 2014-04-01 16:06:44 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:06:44 --> Model Class Initialized
DEBUG - 2014-04-01 16:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:06:44 --> Final output sent to browser
DEBUG - 2014-04-01 16:06:44 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:08:26 --> Config Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Config Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:08:26 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Config Class Initialized
DEBUG - 2014-04-01 16:08:26 --> URI Class Initialized
DEBUG - 2014-04-01 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:08:26 --> Router Class Initialized
DEBUG - 2014-04-01 16:08:26 --> URI Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Router Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:08:26 --> Output Class Initialized
DEBUG - 2014-04-01 16:08:26 --> URI Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Output Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Security Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Router Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Security Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Input Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:08:26 --> Input Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Output Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:08:26 --> Language Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Security Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Language Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Input Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Loader Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:08:26 --> Loader Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Controller Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Language Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Controller Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:26 --> Session Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:08:26 --> A session cookie was not found.
DEBUG - 2014-04-01 16:08:26 --> Session routines successfully run
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:26 --> Final output sent to browser
DEBUG - 2014-04-01 16:08:26 --> Total execution time: 0.0140
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:26 --> Session Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:08:26 --> A session cookie was not found.
DEBUG - 2014-04-01 16:08:26 --> Session routines successfully run
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:26 --> Loader Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Final output sent to browser
DEBUG - 2014-04-01 16:08:26 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:08:26 --> Controller Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:26 --> Session Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:08:26 --> A session cookie was not found.
DEBUG - 2014-04-01 16:08:26 --> Session routines successfully run
DEBUG - 2014-04-01 16:08:26 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:08:26 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:26 --> Final output sent to browser
DEBUG - 2014-04-01 16:08:26 --> Total execution time: 0.0270
DEBUG - 2014-04-01 16:08:27 --> Config Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Config Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:08:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:08:27 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Config Class Initialized
DEBUG - 2014-04-01 16:08:27 --> URI Class Initialized
DEBUG - 2014-04-01 16:08:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:08:27 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Router Class Initialized
DEBUG - 2014-04-01 16:08:27 --> URI Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:08:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:08:27 --> Router Class Initialized
DEBUG - 2014-04-01 16:08:27 --> URI Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Output Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Router Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Output Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Security Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Security Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Input Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Input Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:08:27 --> Output Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Language Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Security Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Loader Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Input Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Language Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Controller Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:08:27 --> Loader Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:08:27 --> Controller Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Language Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:08:27 --> Loader Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:08:27 --> Controller Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:08:27 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:27 --> Session Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:08:27 --> A session cookie was not found.
DEBUG - 2014-04-01 16:08:27 --> Session routines successfully run
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:27 --> Session Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> A session cookie was not found.
DEBUG - 2014-04-01 16:08:27 --> Session routines successfully run
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:27 --> Final output sent to browser
DEBUG - 2014-04-01 16:08:27 --> Final output sent to browser
DEBUG - 2014-04-01 16:08:27 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:08:27 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:27 --> Session Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:08:27 --> A session cookie was not found.
DEBUG - 2014-04-01 16:08:27 --> Session routines successfully run
DEBUG - 2014-04-01 16:08:27 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:08:27 --> Model Class Initialized
DEBUG - 2014-04-01 16:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:08:27 --> Final output sent to browser
DEBUG - 2014-04-01 16:08:27 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:09:18 --> Config Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Config Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Config Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:09:18 --> URI Class Initialized
DEBUG - 2014-04-01 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:09:18 --> URI Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Router Class Initialized
DEBUG - 2014-04-01 16:09:18 --> URI Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Router Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Router Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Output Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Output Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Security Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Input Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Security Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:09:18 --> Language Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Loader Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Controller Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Input Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:09:18 --> Language Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Loader Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Controller Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Output Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Security Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:09:18 --> Session Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:09:18 --> A session cookie was not found.
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Input Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:09:18 --> Session routines successfully run
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Session Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:09:18 --> A session cookie was not found.
DEBUG - 2014-04-01 16:09:18 --> Session routines successfully run
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:09:18 --> Final output sent to browser
DEBUG - 2014-04-01 16:09:18 --> Final output sent to browser
DEBUG - 2014-04-01 16:09:18 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:09:18 --> Language Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Total execution time: 0.0310
DEBUG - 2014-04-01 16:09:18 --> Loader Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Controller Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:09:18 --> Session Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:09:18 --> A session cookie was not found.
DEBUG - 2014-04-01 16:09:18 --> Session routines successfully run
DEBUG - 2014-04-01 16:09:18 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:09:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:09:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:09:18 --> Final output sent to browser
DEBUG - 2014-04-01 16:09:18 --> Total execution time: 0.0380
DEBUG - 2014-04-01 16:14:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:14:37 --> Config Class Initialized
DEBUG - 2014-04-01 16:14:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:14:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:14:37 --> URI Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Router Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Output Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:14:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Security Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:14:37 --> Input Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:14:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Language Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Loader Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Controller Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:14:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:14:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:14:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:14:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:14:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:14:37 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:37 --> Session Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:14:37 --> A session cookie was not found.
DEBUG - 2014-04-01 16:14:37 --> Session routines successfully run
DEBUG - 2014-04-01 16:14:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:14:37 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:37 --> Final output sent to browser
DEBUG - 2014-04-01 16:14:37 --> Total execution time: 0.0230
DEBUG - 2014-04-01 16:14:38 --> Config Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Config Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Config Class Initialized
DEBUG - 2014-04-01 16:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:14:38 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:14:38 --> URI Class Initialized
DEBUG - 2014-04-01 16:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:14:38 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:14:38 --> Router Class Initialized
DEBUG - 2014-04-01 16:14:38 --> URI Class Initialized
DEBUG - 2014-04-01 16:14:38 --> URI Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Router Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Output Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Output Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Security Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Security Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Input Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Router Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Input Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:14:38 --> Language Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Output Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:14:38 --> Security Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Loader Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Language Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Input Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Controller Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:14:38 --> Loader Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:14:38 --> Language Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Controller Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:14:38 --> Loader Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Controller Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:38 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Session Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Session Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:14:38 --> A session cookie was not found.
DEBUG - 2014-04-01 16:14:38 --> Session Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Session routines successfully run
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:14:38 --> A session cookie was not found.
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:14:38 --> A session cookie was not found.
DEBUG - 2014-04-01 16:14:38 --> Session routines successfully run
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:14:38 --> Session routines successfully run
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Model Class Initialized
DEBUG - 2014-04-01 16:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:14:38 --> Final output sent to browser
DEBUG - 2014-04-01 16:14:38 --> Final output sent to browser
DEBUG - 2014-04-01 16:14:38 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:14:38 --> Final output sent to browser
DEBUG - 2014-04-01 16:14:38 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:14:38 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:18:28 --> Config Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Config Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Config Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:18:28 --> URI Class Initialized
DEBUG - 2014-04-01 16:18:28 --> URI Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Router Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Router Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Output Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Output Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Security Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Input Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Security Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:18:28 --> Input Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Language Class Initialized
DEBUG - 2014-04-01 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:18:28 --> Language Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Loader Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Loader Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Controller Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:18:28 --> Controller Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> URI Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Router Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Output Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Security Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:28 --> Input Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Session Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:28 --> Session Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:18:28 --> Language Class Initialized
DEBUG - 2014-04-01 16:18:28 --> A session cookie was not found.
DEBUG - 2014-04-01 16:18:28 --> A session cookie was not found.
DEBUG - 2014-04-01 16:18:28 --> Session routines successfully run
DEBUG - 2014-04-01 16:18:28 --> Loader Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:18:28 --> Session routines successfully run
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:28 --> Controller Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:18:28 --> Final output sent to browser
DEBUG - 2014-04-01 16:18:28 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:18:28 --> Final output sent to browser
DEBUG - 2014-04-01 16:18:28 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:28 --> Session Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:18:28 --> A session cookie was not found.
DEBUG - 2014-04-01 16:18:28 --> Session routines successfully run
DEBUG - 2014-04-01 16:18:28 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:18:28 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:28 --> Final output sent to browser
DEBUG - 2014-04-01 16:18:28 --> Total execution time: 0.0240
DEBUG - 2014-04-01 16:18:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:18:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:18:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:18:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:18:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:18:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:18:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:18:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:18:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:18:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:18:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:18:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:18:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:18:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:18:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:18:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:18:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:18:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:18:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:18:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:18:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:18:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:18:29 --> Total execution time: 0.0120
DEBUG - 2014-04-01 16:18:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:18:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:18:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:18:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:18:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:18:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:18:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:18:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:18:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:18:29 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:18:29 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:19:20 --> Config Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Config Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:19:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:19:20 --> URI Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Config Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Router Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:19:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:19:20 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:19:20 --> URI Class Initialized
DEBUG - 2014-04-01 16:19:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:19:20 --> URI Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Router Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Output Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Security Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Output Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Input Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:19:20 --> Router Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Security Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Input Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:19:20 --> Output Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Language Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Language Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Security Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Loader Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Loader Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Controller Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Input Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:19:20 --> Language Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:19:20 --> Loader Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Controller Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Controller Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:19:20 --> Session Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:19:20 --> Session Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> A session cookie was not found.
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:19:20 --> Session routines successfully run
DEBUG - 2014-04-01 16:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:19:20 --> A session cookie was not found.
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Session Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:19:20 --> Session routines successfully run
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Final output sent to browser
DEBUG - 2014-04-01 16:19:20 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:19:20 --> A session cookie was not found.
DEBUG - 2014-04-01 16:19:20 --> Session routines successfully run
DEBUG - 2014-04-01 16:19:20 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:19:20 --> Model Class Initialized
DEBUG - 2014-04-01 16:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:19:20 --> Final output sent to browser
DEBUG - 2014-04-01 16:19:20 --> Final output sent to browser
DEBUG - 2014-04-01 16:19:20 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:19:20 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:22:42 --> Config Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Config Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Config Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:22:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:22:42 --> URI Class Initialized
DEBUG - 2014-04-01 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:22:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:22:42 --> Router Class Initialized
DEBUG - 2014-04-01 16:22:42 --> URI Class Initialized
DEBUG - 2014-04-01 16:22:42 --> URI Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Router Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Output Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Output Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Security Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Security Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Router Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Input Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Input Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:22:42 --> Language Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Output Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Language Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Security Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Loader Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Loader Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Input Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Controller Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Controller Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Language Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Loader Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Controller Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Session Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:22:42 --> A session cookie was not found.
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Session routines successfully run
DEBUG - 2014-04-01 16:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:22:42 --> Session Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:22:42 --> A session cookie was not found.
DEBUG - 2014-04-01 16:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:42 --> Session routines successfully run
DEBUG - 2014-04-01 16:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:42 --> Final output sent to browser
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Session Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:42 --> Final output sent to browser
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:22:42 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:22:42 --> A session cookie was not found.
DEBUG - 2014-04-01 16:22:42 --> Session routines successfully run
DEBUG - 2014-04-01 16:22:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:22:42 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:42 --> Final output sent to browser
DEBUG - 2014-04-01 16:22:42 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:22:43 --> Config Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Config Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Config Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:22:43 --> URI Class Initialized
DEBUG - 2014-04-01 16:22:43 --> URI Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Router Class Initialized
DEBUG - 2014-04-01 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:22:43 --> Router Class Initialized
DEBUG - 2014-04-01 16:22:43 --> URI Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Output Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Output Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Security Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Router Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Input Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:22:43 --> Security Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Output Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Language Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Security Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Loader Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Input Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Input Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Controller Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:22:43 --> Language Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Loader Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Controller Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:22:43 --> Language Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Loader Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Controller Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Session Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:22:43 --> A session cookie was not found.
DEBUG - 2014-04-01 16:22:43 --> Session routines successfully run
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Session Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> A session cookie was not found.
DEBUG - 2014-04-01 16:22:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Session routines successfully run
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:22:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:43 --> Session Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:22:43 --> A session cookie was not found.
DEBUG - 2014-04-01 16:22:43 --> Session routines successfully run
DEBUG - 2014-04-01 16:22:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:22:43 --> Model Class Initialized
DEBUG - 2014-04-01 16:22:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:22:43 --> Final output sent to browser
DEBUG - 2014-04-01 16:22:43 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:22:43 --> Final output sent to browser
DEBUG - 2014-04-01 16:22:43 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:22:43 --> Final output sent to browser
DEBUG - 2014-04-01 16:22:43 --> Total execution time: 0.0230
DEBUG - 2014-04-01 16:27:15 --> Config Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Config Class Initialized
DEBUG - 2014-04-01 16:27:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:27:15 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:27:15 --> URI Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Config Class Initialized
DEBUG - 2014-04-01 16:27:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:27:15 --> Router Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:27:15 --> URI Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Router Class Initialized
DEBUG - 2014-04-01 16:27:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:27:15 --> Output Class Initialized
DEBUG - 2014-04-01 16:27:15 --> URI Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Security Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Router Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Output Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Input Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Security Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:27:15 --> Output Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Input Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Language Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Security Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:27:15 --> Input Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Language Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:27:15 --> Loader Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Language Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Controller Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Loader Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Controller Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:27:15 --> Loader Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:27:15 --> Controller Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:15 --> Session Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:27:15 --> A session cookie was not found.
DEBUG - 2014-04-01 16:27:15 --> Session routines successfully run
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:15 --> Final output sent to browser
DEBUG - 2014-04-01 16:27:15 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:15 --> Session Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:27:15 --> A session cookie was not found.
DEBUG - 2014-04-01 16:27:15 --> Session Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Session routines successfully run
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:27:15 --> A session cookie was not found.
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Session routines successfully run
DEBUG - 2014-04-01 16:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:15 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:27:15 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:15 --> Final output sent to browser
DEBUG - 2014-04-01 16:27:15 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:27:15 --> Final output sent to browser
DEBUG - 2014-04-01 16:27:15 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:27:16 --> Config Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:27:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:27:16 --> Config Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:27:16 --> URI Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Router Class Initialized
DEBUG - 2014-04-01 16:27:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:27:16 --> URI Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Output Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Router Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Config Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Security Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Output Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:27:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:27:16 --> URI Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Input Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Router Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Security Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Input Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:27:16 --> Output Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:27:16 --> Language Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Language Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Security Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Loader Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Input Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Loader Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Controller Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:27:16 --> Controller Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:27:16 --> Language Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:27:16 --> Loader Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:27:16 --> Controller Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:27:16 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Session Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:27:16 --> Session Class Initialized
DEBUG - 2014-04-01 16:27:16 --> A session cookie was not found.
DEBUG - 2014-04-01 16:27:16 --> Session Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:27:16 --> A session cookie was not found.
DEBUG - 2014-04-01 16:27:16 --> Session routines successfully run
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Session routines successfully run
DEBUG - 2014-04-01 16:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:27:16 --> Final output sent to browser
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:27:16 --> A session cookie was not found.
DEBUG - 2014-04-01 16:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:16 --> Session routines successfully run
DEBUG - 2014-04-01 16:27:16 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:27:16 --> Model Class Initialized
DEBUG - 2014-04-01 16:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:27:16 --> Final output sent to browser
DEBUG - 2014-04-01 16:27:16 --> Final output sent to browser
DEBUG - 2014-04-01 16:27:16 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:27:16 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:28:48 --> Config Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Config Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:28:48 --> URI Class Initialized
DEBUG - 2014-04-01 16:28:48 --> URI Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Router Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Router Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Output Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Output Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Config Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Security Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Security Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Input Class Initialized
DEBUG - 2014-04-01 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:28:48 --> Input Class Initialized
DEBUG - 2014-04-01 16:28:48 --> URI Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:28:48 --> Router Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:28:48 --> Language Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Output Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Language Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Loader Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Security Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Loader Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Controller Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Input Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:28:48 --> Language Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:28:48 --> Controller Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Loader Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Controller Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:48 --> Session Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:28:48 --> A session cookie was not found.
DEBUG - 2014-04-01 16:28:48 --> Session routines successfully run
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:48 --> Session Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:28:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:48 --> Session Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Final output sent to browser
DEBUG - 2014-04-01 16:28:48 --> A session cookie was not found.
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:28:48 --> Session routines successfully run
DEBUG - 2014-04-01 16:28:48 --> A session cookie was not found.
DEBUG - 2014-04-01 16:28:48 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:28:48 --> Session routines successfully run
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:28:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:48 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:48 --> Final output sent to browser
DEBUG - 2014-04-01 16:28:48 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:28:48 --> Final output sent to browser
DEBUG - 2014-04-01 16:28:48 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:28:49 --> Config Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Config Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:28:49 --> URI Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Config Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Router Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:28:49 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:28:49 --> URI Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Router Class Initialized
DEBUG - 2014-04-01 16:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:28:49 --> Output Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Output Class Initialized
DEBUG - 2014-04-01 16:28:49 --> URI Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Router Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Security Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Input Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Security Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:28:49 --> Input Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Output Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Language Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:28:49 --> Security Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Language Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Loader Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Input Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Loader Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Controller Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:28:49 --> Controller Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Language Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:28:49 --> Loader Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:28:49 --> Controller Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:28:49 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:49 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Session Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> A session cookie was not found.
DEBUG - 2014-04-01 16:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:49 --> Session routines successfully run
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:28:49 --> Session Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> A session cookie was not found.
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:49 --> Session Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Final output sent to browser
DEBUG - 2014-04-01 16:28:49 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:28:49 --> A session cookie was not found.
DEBUG - 2014-04-01 16:28:49 --> Session routines successfully run
DEBUG - 2014-04-01 16:28:49 --> Session routines successfully run
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:28:49 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:49 --> Model Class Initialized
DEBUG - 2014-04-01 16:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:28:49 --> Final output sent to browser
DEBUG - 2014-04-01 16:28:49 --> Final output sent to browser
DEBUG - 2014-04-01 16:28:49 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:28:49 --> Total execution time: 0.0180
DEBUG - 2014-04-01 16:30:09 --> Config Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Config Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:30:09 --> URI Class Initialized
DEBUG - 2014-04-01 16:30:09 --> URI Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Router Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Router Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Output Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Output Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Security Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Security Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Config Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Input Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:30:09 --> Input Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:30:09 --> Language Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Loader Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Controller Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:30:09 --> URI Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Router Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Output Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Language Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Security Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Input Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:30:09 --> Language Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Loader Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Loader Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Controller Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:30:09 --> Controller Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:30:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:09 --> Session Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:09 --> Session Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:30:09 --> A session cookie was not found.
DEBUG - 2014-04-01 16:30:09 --> Session routines successfully run
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:09 --> Final output sent to browser
DEBUG - 2014-04-01 16:30:09 --> A session cookie was not found.
DEBUG - 2014-04-01 16:30:09 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:30:09 --> Session routines successfully run
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:09 --> Final output sent to browser
DEBUG - 2014-04-01 16:30:09 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:30:09 --> Session Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:30:09 --> A session cookie was not found.
DEBUG - 2014-04-01 16:30:09 --> Session routines successfully run
DEBUG - 2014-04-01 16:30:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:30:09 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:09 --> Final output sent to browser
DEBUG - 2014-04-01 16:30:09 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:30:11 --> Config Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Config Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Config Class Initialized
DEBUG - 2014-04-01 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:30:11 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:30:11 --> URI Class Initialized
DEBUG - 2014-04-01 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:30:11 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Router Class Initialized
DEBUG - 2014-04-01 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:30:11 --> URI Class Initialized
DEBUG - 2014-04-01 16:30:11 --> URI Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Router Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Output Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Router Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Security Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Output Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Input Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Output Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:30:11 --> Security Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Security Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Language Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Input Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:30:11 --> Loader Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Language Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Controller Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Input Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:30:11 --> Loader Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Controller Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Language Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:30:11 --> Loader Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Controller Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:30:11 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Session Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:11 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:30:11 --> Session Class Initialized
DEBUG - 2014-04-01 16:30:11 --> A session cookie was not found.
DEBUG - 2014-04-01 16:30:11 --> Session routines successfully run
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:30:11 --> A session cookie was not found.
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Session routines successfully run
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:30:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:11 --> Final output sent to browser
DEBUG - 2014-04-01 16:30:11 --> Total execution time: 0.0120
DEBUG - 2014-04-01 16:30:11 --> Session Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:30:11 --> A session cookie was not found.
DEBUG - 2014-04-01 16:30:11 --> Session routines successfully run
DEBUG - 2014-04-01 16:30:11 --> Final output sent to browser
DEBUG - 2014-04-01 16:30:11 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:30:11 --> Model Class Initialized
DEBUG - 2014-04-01 16:30:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:30:11 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:30:11 --> Final output sent to browser
DEBUG - 2014-04-01 16:30:11 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:31:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Config Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:31:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:31:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:31:29 --> URI Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Router Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Output Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:31:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:31:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Security Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Input Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:31:29 --> Language Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:31:29 --> Loader Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Controller Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:31:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:31:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:31:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:31:29 --> Session Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:31:29 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:31:29 --> A session cookie was not found.
DEBUG - 2014-04-01 16:31:29 --> Session routines successfully run
DEBUG - 2014-04-01 16:31:29 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:31:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:31:29 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:29 --> Final output sent to browser
DEBUG - 2014-04-01 16:31:29 --> Total execution time: 0.0230
DEBUG - 2014-04-01 16:31:30 --> Config Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Config Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:31:30 --> Config Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:31:30 --> URI Class Initialized
DEBUG - 2014-04-01 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:31:30 --> URI Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Router Class Initialized
DEBUG - 2014-04-01 16:31:30 --> URI Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Output Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Router Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Router Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Security Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Output Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Output Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Input Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Security Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:31:30 --> Input Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Language Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:31:30 --> Security Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Language Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Loader Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Input Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Controller Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Loader Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:31:30 --> Controller Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:31:30 --> Language Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:31:30 --> Loader Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Controller Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Session Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Session Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:31:30 --> A session cookie was not found.
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:31:30 --> A session cookie was not found.
DEBUG - 2014-04-01 16:31:30 --> Session routines successfully run
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:31:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Session Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:30 --> Session routines successfully run
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:31:30 --> Final output sent to browser
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:31:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:30 --> Final output sent to browser
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:31:30 --> A session cookie was not found.
DEBUG - 2014-04-01 16:31:30 --> Total execution time: 0.0140
DEBUG - 2014-04-01 16:31:30 --> Session routines successfully run
DEBUG - 2014-04-01 16:31:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:31:30 --> Model Class Initialized
DEBUG - 2014-04-01 16:31:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:31:30 --> Final output sent to browser
DEBUG - 2014-04-01 16:31:30 --> Total execution time: 0.0170
DEBUG - 2014-04-01 16:32:03 --> Config Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Config Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:32:03 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:32:03 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:32:03 --> URI Class Initialized
DEBUG - 2014-04-01 16:32:03 --> URI Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Router Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Output Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Router Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Security Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Output Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Security Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Input Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Input Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:32:03 --> Config Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:32:03 --> Language Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Language Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Loader Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Controller Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:32:03 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:32:03 --> Loader Class Initialized
DEBUG - 2014-04-01 16:32:03 --> URI Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:32:03 --> Controller Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:03 --> Router Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Session Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:32:03 --> Output Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> A session cookie was not found.
DEBUG - 2014-04-01 16:32:03 --> Security Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Session routines successfully run
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:32:03 --> Input Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Language Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:03 --> Loader Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Controller Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:32:03 --> Final output sent to browser
DEBUG - 2014-04-01 16:32:03 --> Total execution time: 0.0150
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:03 --> Session Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:32:03 --> A session cookie was not found.
DEBUG - 2014-04-01 16:32:03 --> Session Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Session routines successfully run
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:32:03 --> A session cookie was not found.
DEBUG - 2014-04-01 16:32:03 --> Session routines successfully run
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:32:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:03 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:03 --> Final output sent to browser
DEBUG - 2014-04-01 16:32:03 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:32:03 --> Final output sent to browser
DEBUG - 2014-04-01 16:32:03 --> Total execution time: 0.0210
DEBUG - 2014-04-01 16:32:05 --> Config Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Config Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Config Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:32:05 --> URI Class Initialized
DEBUG - 2014-04-01 16:32:05 --> URI Class Initialized
DEBUG - 2014-04-01 16:32:05 --> URI Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Router Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Router Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Router Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Output Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Output Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Output Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Security Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Security Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Security Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Input Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Input Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Input Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:32:05 --> Language Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Language Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Language Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Loader Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Loader Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Controller Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Loader Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Controller Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Controller Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Session Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:32:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:05 --> Session Class Initialized
DEBUG - 2014-04-01 16:32:05 --> A session cookie was not found.
DEBUG - 2014-04-01 16:32:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Session routines successfully run
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:32:05 --> A session cookie was not found.
DEBUG - 2014-04-01 16:32:05 --> Session routines successfully run
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:05 --> Final output sent to browser
DEBUG - 2014-04-01 16:32:05 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:32:05 --> Final output sent to browser
DEBUG - 2014-04-01 16:32:05 --> Session Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:32:05 --> A session cookie was not found.
DEBUG - 2014-04-01 16:32:05 --> Session routines successfully run
DEBUG - 2014-04-01 16:32:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:32:05 --> Model Class Initialized
DEBUG - 2014-04-01 16:32:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:32:05 --> Final output sent to browser
DEBUG - 2014-04-01 16:32:05 --> Total execution time: 0.0190
DEBUG - 2014-04-01 16:34:17 --> Config Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Config Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:34:17 --> URI Class Initialized
DEBUG - 2014-04-01 16:34:17 --> URI Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Router Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Router Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Config Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Output Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Output Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Security Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Security Class Initialized
DEBUG - 2014-04-01 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:34:17 --> Input Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Input Class Initialized
DEBUG - 2014-04-01 16:34:17 --> URI Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:34:17 --> Router Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Language Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Language Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Output Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Loader Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Loader Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Controller Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Security Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Controller Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Input Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:34:17 --> Language Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Loader Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Controller Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:17 --> Session Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:34:17 --> A session cookie was not found.
DEBUG - 2014-04-01 16:34:17 --> Session routines successfully run
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:17 --> Session Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:34:17 --> A session cookie was not found.
DEBUG - 2014-04-01 16:34:17 --> Final output sent to browser
DEBUG - 2014-04-01 16:34:17 --> Total execution time: 0.0160
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:17 --> Session routines successfully run
DEBUG - 2014-04-01 16:34:17 --> Session Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:34:17 --> A session cookie was not found.
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Session routines successfully run
DEBUG - 2014-04-01 16:34:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:17 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:34:17 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:17 --> Final output sent to browser
DEBUG - 2014-04-01 16:34:17 --> Total execution time: 0.0220
DEBUG - 2014-04-01 16:34:17 --> Final output sent to browser
DEBUG - 2014-04-01 16:34:17 --> Total execution time: 0.0200
DEBUG - 2014-04-01 16:34:18 --> Config Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Config Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Config Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:34:18 --> Hooks Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:34:18 --> Utf8 Class Initialized
DEBUG - 2014-04-01 16:34:18 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 16:34:18 --> URI Class Initialized
DEBUG - 2014-04-01 16:34:18 --> URI Class Initialized
DEBUG - 2014-04-01 16:34:18 --> URI Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Router Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Router Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Router Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Output Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Output Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Output Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Security Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Security Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Security Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Input Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Input Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Input Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 16:34:18 --> Language Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Language Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Language Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Loader Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Loader Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Loader Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Controller Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Controller Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:34:18 --> Controller Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Database Driver Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:18 --> Session Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:18 --> Session Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:34:18 --> Session Class Initialized
DEBUG - 2014-04-01 16:34:18 --> A session cookie was not found.
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: string_helper
DEBUG - 2014-04-01 16:34:18 --> A session cookie was not found.
DEBUG - 2014-04-01 16:34:18 --> Session routines successfully run
DEBUG - 2014-04-01 16:34:18 --> A session cookie was not found.
DEBUG - 2014-04-01 16:34:18 --> Session routines successfully run
DEBUG - 2014-04-01 16:34:18 --> Session routines successfully run
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:34:18 --> Helper loaded: url_helper
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Model Class Initialized
DEBUG - 2014-04-01 16:34:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 16:34:18 --> Final output sent to browser
DEBUG - 2014-04-01 16:34:18 --> Final output sent to browser
DEBUG - 2014-04-01 16:34:18 --> Final output sent to browser
DEBUG - 2014-04-01 16:34:18 --> Total execution time: 0.0120
DEBUG - 2014-04-01 16:34:18 --> Total execution time: 0.0130
DEBUG - 2014-04-01 16:34:18 --> Total execution time: 0.0140
DEBUG - 2014-04-01 22:53:14 --> Config Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Config Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Config Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:53:14 --> URI Class Initialized
DEBUG - 2014-04-01 22:53:14 --> URI Class Initialized
DEBUG - 2014-04-01 22:53:14 --> URI Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Router Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Router Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Router Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Output Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Output Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Output Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Security Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Security Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Security Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Input Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Input Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:53:14 --> Input Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:53:14 --> Language Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Loader Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Controller Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:53:14 --> Language Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Loader Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Controller Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:53:14 --> Language Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Loader Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Controller Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Session Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:53:14 --> A session cookie was not found.
DEBUG - 2014-04-01 22:53:14 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Session routines successfully run
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:53:14 --> Session Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:53:14 --> A session cookie was not found.
DEBUG - 2014-04-01 22:53:14 --> Session routines successfully run
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:53:14 --> Final output sent to browser
DEBUG - 2014-04-01 22:53:14 --> Total execution time: 0.0210
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Final output sent to browser
DEBUG - 2014-04-01 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:53:14 --> Total execution time: 0.0230
DEBUG - 2014-04-01 22:53:14 --> Session Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:53:14 --> A session cookie was not found.
DEBUG - 2014-04-01 22:53:14 --> Session routines successfully run
DEBUG - 2014-04-01 22:53:14 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:53:14 --> Model Class Initialized
DEBUG - 2014-04-01 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:53:14 --> Final output sent to browser
DEBUG - 2014-04-01 22:53:14 --> Total execution time: 0.0260
DEBUG - 2014-04-01 22:59:07 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:07 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:07 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:07 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:07 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:07 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:07 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:07 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:07 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:07 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:07 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:07 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:07 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:07 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:07 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:07 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:07 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:07 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:07 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:07 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:07 --> Total execution time: 0.0520
DEBUG - 2014-04-01 22:59:07 --> Total execution time: 0.0490
DEBUG - 2014-04-01 22:59:07 --> Total execution time: 0.0510
DEBUG - 2014-04-01 22:59:09 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:09 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:09 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:09 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:09 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:09 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:09 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:09 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:09 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:09 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:09 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:09 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:09 --> Total execution time: 0.0130
DEBUG - 2014-04-01 22:59:09 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:09 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:09 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:09 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:09 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:09 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:09 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:09 --> Total execution time: 0.0200
DEBUG - 2014-04-01 22:59:09 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:09 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:09 --> Total execution time: 0.0210
DEBUG - 2014-04-01 22:59:29 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:29 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:29 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:29 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:29 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:29 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:29 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:29 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:29 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:29 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:29 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:29 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:29 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:29 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:29 --> Total execution time: 0.0190
DEBUG - 2014-04-01 22:59:29 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:29 --> Total execution time: 0.0210
DEBUG - 2014-04-01 22:59:29 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:29 --> Total execution time: 0.0230
DEBUG - 2014-04-01 22:59:30 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:30 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:30 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:30 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:30 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:30 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:30 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:30 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:30 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:30 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:30 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:30 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:30 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:30 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:30 --> Total execution time: 0.0130
DEBUG - 2014-04-01 22:59:30 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:30 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:30 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:30 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:30 --> Total execution time: 0.0160
DEBUG - 2014-04-01 22:59:30 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:30 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:30 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:30 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:30 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:30 --> Total execution time: 0.0200
DEBUG - 2014-04-01 22:59:58 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:58 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:58 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:58 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:58 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:58 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:58 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:58 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:58 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:58 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:58 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:58 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:58 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:58 --> Total execution time: 0.0140
DEBUG - 2014-04-01 22:59:58 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:58 --> Total execution time: 0.0150
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:58 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:58 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:58 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:58 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:58 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:58 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:58 --> Total execution time: 0.0210
DEBUG - 2014-04-01 22:59:59 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:59 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Config Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Hooks Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Utf8 Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:59 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 22:59:59 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:59 --> URI Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Router Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:59 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Output Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Security Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Input Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:59 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Language Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Loader Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Controller Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 22:59:59 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Database Driver Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:59 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:59 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:59 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:59 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:59 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:59 --> Session Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:59 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Total execution time: 0.0130
DEBUG - 2014-04-01 22:59:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: string_helper
DEBUG - 2014-04-01 22:59:59 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:59 --> A session cookie was not found.
DEBUG - 2014-04-01 22:59:59 --> Session routines successfully run
DEBUG - 2014-04-01 22:59:59 --> Helper loaded: url_helper
DEBUG - 2014-04-01 22:59:59 --> Model Class Initialized
DEBUG - 2014-04-01 22:59:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 22:59:59 --> Total execution time: 0.0160
DEBUG - 2014-04-01 22:59:59 --> Final output sent to browser
DEBUG - 2014-04-01 22:59:59 --> Total execution time: 0.0180
DEBUG - 2014-04-01 23:06:07 --> Config Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Config Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:06:07 --> URI Class Initialized
DEBUG - 2014-04-01 23:06:07 --> URI Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Router Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Router Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Config Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Output Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Output Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Security Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Security Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Input Class Initialized
DEBUG - 2014-04-01 23:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:06:07 --> Input Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:06:07 --> URI Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:06:07 --> Language Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Router Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Language Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Loader Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Loader Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Output Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Controller Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Controller Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Security Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:06:07 --> Input Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Language Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Loader Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Controller Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Session Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:06:07 --> A session cookie was not found.
DEBUG - 2014-04-01 23:06:07 --> Session Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Session routines successfully run
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:06:07 --> A session cookie was not found.
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:07 --> Final output sent to browser
DEBUG - 2014-04-01 23:06:07 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:06:07 --> Session routines successfully run
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:07 --> Final output sent to browser
DEBUG - 2014-04-01 23:06:07 --> Session Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:06:07 --> A session cookie was not found.
DEBUG - 2014-04-01 23:06:07 --> Session routines successfully run
DEBUG - 2014-04-01 23:06:07 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:06:07 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:07 --> Final output sent to browser
DEBUG - 2014-04-01 23:06:07 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:06:09 --> Config Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:06:09 --> URI Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Router Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Output Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Security Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Config Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:06:09 --> Input Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:06:09 --> Config Class Initialized
DEBUG - 2014-04-01 23:06:09 --> URI Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Language Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Router Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:06:09 --> Loader Class Initialized
DEBUG - 2014-04-01 23:06:09 --> URI Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Output Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Controller Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Router Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Security Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Input Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:06:09 --> Output Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:06:09 --> Language Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Security Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Loader Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Input Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Controller Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:06:09 --> Language Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:06:09 --> Loader Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Controller Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:06:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Session Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:06:09 --> A session cookie was not found.
DEBUG - 2014-04-01 23:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:09 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Session Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:06:09 --> A session cookie was not found.
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Session routines successfully run
DEBUG - 2014-04-01 23:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:06:09 --> Session Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:06:09 --> A session cookie was not found.
DEBUG - 2014-04-01 23:06:09 --> Session routines successfully run
DEBUG - 2014-04-01 23:06:09 --> Session routines successfully run
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:06:09 --> Final output sent to browser
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:09 --> Model Class Initialized
DEBUG - 2014-04-01 23:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:06:09 --> Final output sent to browser
DEBUG - 2014-04-01 23:06:09 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:06:09 --> Final output sent to browser
DEBUG - 2014-04-01 23:06:09 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:06:09 --> Total execution time: 0.0140
DEBUG - 2014-04-01 23:07:31 --> Config Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Config Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:07:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:07:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:07:31 --> Config Class Initialized
DEBUG - 2014-04-01 23:07:31 --> URI Class Initialized
DEBUG - 2014-04-01 23:07:31 --> URI Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Router Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Router Class Initialized
DEBUG - 2014-04-01 23:07:31 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:07:31 --> URI Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Output Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Router Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Output Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Security Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Security Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Output Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Input Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Input Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Security Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:07:31 --> Input Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Language Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Language Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:07:31 --> Language Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Loader Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Loader Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Controller Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Loader Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Controller Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Controller Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:07:31 --> Session Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Session Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:07:31 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:07:31 --> A session cookie was not found.
DEBUG - 2014-04-01 23:07:31 --> A session cookie was not found.
DEBUG - 2014-04-01 23:07:31 --> Session routines successfully run
DEBUG - 2014-04-01 23:07:31 --> Session routines successfully run
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:07:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:07:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:07:31 --> Session Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:07:31 --> Final output sent to browser
DEBUG - 2014-04-01 23:07:31 --> Final output sent to browser
DEBUG - 2014-04-01 23:07:31 --> A session cookie was not found.
DEBUG - 2014-04-01 23:07:31 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:07:31 --> Total execution time: 0.0140
DEBUG - 2014-04-01 23:07:31 --> Session routines successfully run
DEBUG - 2014-04-01 23:07:31 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:07:31 --> Model Class Initialized
DEBUG - 2014-04-01 23:07:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:07:31 --> Final output sent to browser
DEBUG - 2014-04-01 23:07:31 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:11:37 --> Config Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Config Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:11:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:11:37 --> URI Class Initialized
DEBUG - 2014-04-01 23:11:37 --> URI Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Router Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Output Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Router Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Security Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Output Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Input Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:11:37 --> Security Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Config Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Language Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Input Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:11:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Loader Class Initialized
DEBUG - 2014-04-01 23:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:11:37 --> Language Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Controller Class Initialized
DEBUG - 2014-04-01 23:11:37 --> URI Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:11:37 --> Loader Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Router Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Controller Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Output Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Security Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Input Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Language Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Loader Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Controller Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:11:37 --> Session Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Session Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> A session cookie was not found.
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:11:37 --> A session cookie was not found.
DEBUG - 2014-04-01 23:11:37 --> Session routines successfully run
DEBUG - 2014-04-01 23:11:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Session routines successfully run
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:37 --> Final output sent to browser
DEBUG - 2014-04-01 23:11:37 --> Session Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Final output sent to browser
DEBUG - 2014-04-01 23:11:37 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:11:37 --> Total execution time: 0.0140
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:11:37 --> A session cookie was not found.
DEBUG - 2014-04-01 23:11:37 --> Session routines successfully run
DEBUG - 2014-04-01 23:11:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:11:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:37 --> Final output sent to browser
DEBUG - 2014-04-01 23:11:37 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:11:39 --> Config Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Config Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Config Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:11:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:11:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:11:39 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:11:39 --> URI Class Initialized
DEBUG - 2014-04-01 23:11:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:11:39 --> URI Class Initialized
DEBUG - 2014-04-01 23:11:39 --> URI Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Router Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Router Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Output Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Output Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Security Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Security Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Input Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Input Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Router Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:11:39 --> Language Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Language Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Output Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Loader Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Loader Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Security Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Controller Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Controller Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Input Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:11:39 --> Language Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Loader Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Controller Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:11:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:39 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Session Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:11:39 --> Session Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:11:39 --> A session cookie was not found.
DEBUG - 2014-04-01 23:11:39 --> Session routines successfully run
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:11:39 --> A session cookie was not found.
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Session routines successfully run
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:11:39 --> Session Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:11:39 --> A session cookie was not found.
DEBUG - 2014-04-01 23:11:39 --> Session routines successfully run
DEBUG - 2014-04-01 23:11:39 --> Final output sent to browser
DEBUG - 2014-04-01 23:11:39 --> Total execution time: 0.0120
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:39 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:11:39 --> Model Class Initialized
DEBUG - 2014-04-01 23:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:11:39 --> Final output sent to browser
DEBUG - 2014-04-01 23:11:39 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:11:39 --> Final output sent to browser
DEBUG - 2014-04-01 23:11:39 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:13:05 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:05 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:05 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:05 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:05 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:05 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:05 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:05 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:05 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:05 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:05 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:05 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:05 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:05 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:05 --> Total execution time: 0.0170
DEBUG - 2014-04-01 23:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:05 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:05 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:05 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:05 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:05 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:05 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:05 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:05 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:05 --> Total execution time: 0.0220
DEBUG - 2014-04-01 23:13:08 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:08 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:08 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:08 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:08 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:08 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:08 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:08 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:08 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:08 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:08 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:08 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:08 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:13:08 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:08 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:08 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:08 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:13:08 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:08 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:08 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:08 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:08 --> Total execution time: 0.0230
DEBUG - 2014-04-01 23:13:29 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:29 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Config Class Initialized
DEBUG - 2014-04-01 23:13:29 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:13:29 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:29 --> URI Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Router Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:29 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Output Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:29 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Security Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Input Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:29 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:29 --> Language Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Loader Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Controller Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:29 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:13:29 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:29 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:29 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:29 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:29 --> Session Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:29 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:13:29 --> A session cookie was not found.
DEBUG - 2014-04-01 23:13:29 --> Session routines successfully run
DEBUG - 2014-04-01 23:13:29 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:13:29 --> Model Class Initialized
DEBUG - 2014-04-01 23:13:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:13:29 --> Final output sent to browser
DEBUG - 2014-04-01 23:13:29 --> Total execution time: 0.0180
DEBUG - 2014-04-01 23:14:41 --> Config Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Config Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:14:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:14:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:14:41 --> URI Class Initialized
DEBUG - 2014-04-01 23:14:41 --> URI Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Router Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Router Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Output Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Output Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Security Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Security Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Input Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Input Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:14:41 --> Language Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Language Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Loader Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Loader Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Controller Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Controller Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:41 --> Session Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Session Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:14:41 --> A session cookie was not found.
DEBUG - 2014-04-01 23:14:41 --> A session cookie was not found.
DEBUG - 2014-04-01 23:14:41 --> Session routines successfully run
DEBUG - 2014-04-01 23:14:41 --> Session routines successfully run
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:41 --> Final output sent to browser
DEBUG - 2014-04-01 23:14:41 --> Final output sent to browser
DEBUG - 2014-04-01 23:14:41 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:14:41 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:14:41 --> Config Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:14:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:14:41 --> URI Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Router Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Output Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Security Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Input Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:14:41 --> Language Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Loader Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Controller Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:41 --> Session Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:14:41 --> A session cookie was not found.
DEBUG - 2014-04-01 23:14:41 --> Session routines successfully run
DEBUG - 2014-04-01 23:14:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:14:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:41 --> Final output sent to browser
DEBUG - 2014-04-01 23:14:41 --> Total execution time: 0.0110
DEBUG - 2014-04-01 23:14:43 --> Config Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Config Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Config Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:14:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:14:43 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:14:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:14:43 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:14:43 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:14:43 --> URI Class Initialized
DEBUG - 2014-04-01 23:14:43 --> URI Class Initialized
DEBUG - 2014-04-01 23:14:43 --> URI Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Router Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Router Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Router Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Output Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Output Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Output Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Security Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Security Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Security Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Input Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Input Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Input Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:14:43 --> Language Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Language Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Language Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Loader Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Controller Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Loader Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Loader Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Controller Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:14:43 --> Controller Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:43 --> Session Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:14:43 --> Session Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Session Class Initialized
DEBUG - 2014-04-01 23:14:43 --> A session cookie was not found.
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:14:43 --> Session routines successfully run
DEBUG - 2014-04-01 23:14:43 --> A session cookie was not found.
DEBUG - 2014-04-01 23:14:43 --> A session cookie was not found.
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:14:43 --> Session routines successfully run
DEBUG - 2014-04-01 23:14:43 --> Session routines successfully run
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:14:43 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:14:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Model Class Initialized
DEBUG - 2014-04-01 23:14:43 --> Final output sent to browser
DEBUG - 2014-04-01 23:14:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:43 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:14:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:14:43 --> Final output sent to browser
DEBUG - 2014-04-01 23:14:43 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:14:43 --> Final output sent to browser
DEBUG - 2014-04-01 23:14:43 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:21:40 --> Config Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Config Class Initialized
DEBUG - 2014-04-01 23:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:21:40 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:21:40 --> URI Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Router Class Initialized
DEBUG - 2014-04-01 23:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:21:40 --> Config Class Initialized
DEBUG - 2014-04-01 23:21:40 --> URI Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Output Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Router Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Security Class Initialized
DEBUG - 2014-04-01 23:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:21:40 --> Output Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Input Class Initialized
DEBUG - 2014-04-01 23:21:40 --> URI Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:21:40 --> Security Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Router Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Input Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Language Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:21:40 --> Language Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Output Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Loader Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Controller Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Security Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Loader Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Controller Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Input Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:21:40 --> Language Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Loader Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Controller Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:40 --> Session Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Session Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:21:40 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:21:40 --> A session cookie was not found.
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:21:40 --> Session routines successfully run
DEBUG - 2014-04-01 23:21:40 --> A session cookie was not found.
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:21:40 --> Session routines successfully run
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:40 --> Final output sent to browser
DEBUG - 2014-04-01 23:21:40 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:40 --> Session Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:21:40 --> A session cookie was not found.
DEBUG - 2014-04-01 23:21:40 --> Session routines successfully run
DEBUG - 2014-04-01 23:21:40 --> Final output sent to browser
DEBUG - 2014-04-01 23:21:40 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:21:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:21:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:40 --> Final output sent to browser
DEBUG - 2014-04-01 23:21:40 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:21:41 --> Config Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:21:41 --> URI Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Router Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Output Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Security Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Input Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:21:41 --> Language Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Loader Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Controller Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Config Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Config Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:21:41 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:21:41 --> Session Class Initialized
DEBUG - 2014-04-01 23:21:41 --> URI Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Router Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Output Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:21:41 --> URI Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Security Class Initialized
DEBUG - 2014-04-01 23:21:41 --> A session cookie was not found.
DEBUG - 2014-04-01 23:21:41 --> Router Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Session routines successfully run
DEBUG - 2014-04-01 23:21:41 --> Input Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Output Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:21:41 --> Security Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Language Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:41 --> Loader Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Controller Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Final output sent to browser
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:21:41 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:21:41 --> Input Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:21:41 --> Language Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Loader Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Controller Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:41 --> Session Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:21:41 --> A session cookie was not found.
DEBUG - 2014-04-01 23:21:41 --> Session routines successfully run
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:41 --> Final output sent to browser
DEBUG - 2014-04-01 23:21:41 --> Total execution time: 0.0180
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:41 --> Session Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:21:41 --> A session cookie was not found.
DEBUG - 2014-04-01 23:21:41 --> Session routines successfully run
DEBUG - 2014-04-01 23:21:41 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:21:41 --> Model Class Initialized
DEBUG - 2014-04-01 23:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:21:41 --> Final output sent to browser
DEBUG - 2014-04-01 23:21:41 --> Total execution time: 0.0290
DEBUG - 2014-04-01 23:23:40 --> Config Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Config Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:23:40 --> URI Class Initialized
DEBUG - 2014-04-01 23:23:40 --> URI Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Router Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Router Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Config Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Output Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Output Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Security Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Security Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Input Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Input Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:23:40 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:23:40 --> Language Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Language Class Initialized
DEBUG - 2014-04-01 23:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:23:40 --> Loader Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Loader Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Controller Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Controller Class Initialized
DEBUG - 2014-04-01 23:23:40 --> URI Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:23:40 --> Router Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Output Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Security Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Input Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:23:40 --> Language Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Loader Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:40 --> Controller Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Session Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:23:40 --> Session Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:23:40 --> A session cookie was not found.
DEBUG - 2014-04-01 23:23:40 --> A session cookie was not found.
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Session routines successfully run
DEBUG - 2014-04-01 23:23:40 --> Session routines successfully run
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:40 --> Final output sent to browser
DEBUG - 2014-04-01 23:23:40 --> Final output sent to browser
DEBUG - 2014-04-01 23:23:40 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:40 --> Session Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:23:40 --> A session cookie was not found.
DEBUG - 2014-04-01 23:23:40 --> Session routines successfully run
DEBUG - 2014-04-01 23:23:40 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:23:40 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:40 --> Final output sent to browser
DEBUG - 2014-04-01 23:23:40 --> Total execution time: 0.0200
DEBUG - 2014-04-01 23:23:42 --> Config Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Config Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:23:42 --> URI Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Config Class Initialized
DEBUG - 2014-04-01 23:23:42 --> URI Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Router Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Router Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:23:42 --> URI Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Output Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Output Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Router Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Security Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Security Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Input Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Output Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Input Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:23:42 --> Security Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Language Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Language Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Input Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:23:42 --> Loader Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Loader Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Controller Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Language Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Controller Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:23:42 --> Loader Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Controller Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:23:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:42 --> Session Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> A session cookie was not found.
DEBUG - 2014-04-01 23:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:42 --> Session routines successfully run
DEBUG - 2014-04-01 23:23:42 --> Session Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Session Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:23:42 --> A session cookie was not found.
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> A session cookie was not found.
DEBUG - 2014-04-01 23:23:42 --> Session routines successfully run
DEBUG - 2014-04-01 23:23:42 --> Session routines successfully run
DEBUG - 2014-04-01 23:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:23:42 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:42 --> Final output sent to browser
DEBUG - 2014-04-01 23:23:42 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:23:42 --> Final output sent to browser
DEBUG - 2014-04-01 23:23:42 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:23:42 --> Model Class Initialized
DEBUG - 2014-04-01 23:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:23:42 --> Final output sent to browser
DEBUG - 2014-04-01 23:23:42 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:24:35 --> Config Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Config Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Config Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:24:35 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:24:35 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:24:35 --> URI Class Initialized
DEBUG - 2014-04-01 23:24:35 --> URI Class Initialized
DEBUG - 2014-04-01 23:24:35 --> URI Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Router Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Router Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Router Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Output Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Output Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Security Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Security Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Output Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Input Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Input Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Security Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:24:35 --> Input Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Language Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Language Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:24:35 --> Language Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Loader Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Loader Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Controller Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Controller Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Loader Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:24:35 --> Controller Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:35 --> Session Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:24:35 --> A session cookie was not found.
DEBUG - 2014-04-01 23:24:35 --> Session routines successfully run
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:35 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Final output sent to browser
DEBUG - 2014-04-01 23:24:35 --> Total execution time: 0.0140
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:35 --> Session Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:24:35 --> A session cookie was not found.
DEBUG - 2014-04-01 23:24:35 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Session routines successfully run
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:35 --> Final output sent to browser
DEBUG - 2014-04-01 23:24:35 --> Session Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:24:35 --> A session cookie was not found.
DEBUG - 2014-04-01 23:24:35 --> Session routines successfully run
DEBUG - 2014-04-01 23:24:35 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:24:35 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:35 --> Final output sent to browser
DEBUG - 2014-04-01 23:24:35 --> Total execution time: 0.0220
DEBUG - 2014-04-01 23:24:37 --> Config Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Config Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Config Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:24:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:24:37 --> URI Class Initialized
DEBUG - 2014-04-01 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:24:37 --> URI Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Router Class Initialized
DEBUG - 2014-04-01 23:24:37 --> URI Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Router Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Router Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Output Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Output Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Security Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Output Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Security Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Input Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Security Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:24:37 --> Input Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Input Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:24:37 --> Language Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Language Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:24:37 --> Language Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Loader Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Controller Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Loader Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Loader Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:24:37 --> Controller Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Controller Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:37 --> Session Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> A session cookie was not found.
DEBUG - 2014-04-01 23:24:37 --> Session Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:37 --> Session routines successfully run
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:24:37 --> A session cookie was not found.
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:24:37 --> Session Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Session routines successfully run
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> A session cookie was not found.
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:37 --> Session routines successfully run
DEBUG - 2014-04-01 23:24:37 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:24:37 --> Final output sent to browser
DEBUG - 2014-04-01 23:24:37 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:24:37 --> Final output sent to browser
DEBUG - 2014-04-01 23:24:37 --> Model Class Initialized
DEBUG - 2014-04-01 23:24:37 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:24:37 --> Final output sent to browser
DEBUG - 2014-04-01 23:24:37 --> Total execution time: 0.0160
DEBUG - 2014-04-01 23:30:23 --> Config Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Config Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Config Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:30:23 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:30:23 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:30:23 --> URI Class Initialized
DEBUG - 2014-04-01 23:30:23 --> URI Class Initialized
DEBUG - 2014-04-01 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:30:23 --> Router Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Router Class Initialized
DEBUG - 2014-04-01 23:30:23 --> URI Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Router Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Output Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Output Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Output Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Security Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Security Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Security Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Input Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Input Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:30:23 --> Input Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Language Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Language Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Loader Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Loader Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Controller Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Controller Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:30:23 --> Language Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:30:23 --> Loader Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Controller Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:23 --> Session Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> A session cookie was not found.
DEBUG - 2014-04-01 23:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:23 --> Session Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Session Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:30:23 --> A session cookie was not found.
DEBUG - 2014-04-01 23:30:23 --> A session cookie was not found.
DEBUG - 2014-04-01 23:30:23 --> Session routines successfully run
DEBUG - 2014-04-01 23:30:23 --> Session routines successfully run
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:30:23 --> Session routines successfully run
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:30:23 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:23 --> Final output sent to browser
DEBUG - 2014-04-01 23:30:23 --> Final output sent to browser
DEBUG - 2014-04-01 23:30:23 --> Final output sent to browser
DEBUG - 2014-04-01 23:30:23 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:30:23 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:30:23 --> Total execution time: 0.0180
DEBUG - 2014-04-01 23:30:25 --> Config Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:30:25 --> URI Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Router Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Config Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Config Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Output Class Initialized
DEBUG - 2014-04-01 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:30:25 --> Security Class Initialized
DEBUG - 2014-04-01 23:30:25 --> URI Class Initialized
DEBUG - 2014-04-01 23:30:25 --> URI Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Input Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:30:25 --> Router Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Language Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Output Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Router Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Security Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Loader Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Input Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Output Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:30:25 --> Controller Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Language Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Security Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:30:25 --> Input Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Loader Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:30:25 --> Controller Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Language Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:30:25 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Loader Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:30:25 --> Controller Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:30:25 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:25 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Session Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Session Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:30:25 --> A session cookie was not found.
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Session routines successfully run
DEBUG - 2014-04-01 23:30:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:30:25 --> Session Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:30:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:30:25 --> A session cookie was not found.
DEBUG - 2014-04-01 23:30:25 --> Session routines successfully run
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:30:25 --> A session cookie was not found.
DEBUG - 2014-04-01 23:30:25 --> Final output sent to browser
DEBUG - 2014-04-01 23:30:25 --> Total execution time: 0.0130
DEBUG - 2014-04-01 23:30:25 --> Session routines successfully run
DEBUG - 2014-04-01 23:30:25 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Model Class Initialized
DEBUG - 2014-04-01 23:30:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:25 --> Final output sent to browser
DEBUG - 2014-04-01 23:30:25 --> Total execution time: 0.0190
DEBUG - 2014-04-01 23:30:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:30:25 --> Final output sent to browser
DEBUG - 2014-04-01 23:30:25 --> Total execution time: 0.0210
DEBUG - 2014-04-01 23:57:33 --> Config Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Config Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Config Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:57:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:57:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:57:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:57:33 --> URI Class Initialized
DEBUG - 2014-04-01 23:57:33 --> URI Class Initialized
DEBUG - 2014-04-01 23:57:33 --> URI Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Router Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Router Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Router Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Output Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Output Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Output Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Security Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Security Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Security Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Input Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Input Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Input Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:57:33 --> Language Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Language Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Language Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Loader Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Loader Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Loader Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Controller Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Controller Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Controller Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:33 --> Session Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:57:33 --> A session cookie was not found.
DEBUG - 2014-04-01 23:57:33 --> Session routines successfully run
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:33 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Final output sent to browser
DEBUG - 2014-04-01 23:57:33 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:57:33 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:33 --> Session Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Session Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:57:33 --> A session cookie was not found.
DEBUG - 2014-04-01 23:57:33 --> Session routines successfully run
DEBUG - 2014-04-01 23:57:33 --> A session cookie was not found.
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:57:33 --> Session routines successfully run
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:33 --> Final output sent to browser
DEBUG - 2014-04-01 23:57:33 --> Total execution time: 0.0200
DEBUG - 2014-04-01 23:57:33 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:57:33 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:33 --> Final output sent to browser
DEBUG - 2014-04-01 23:57:33 --> Total execution time: 0.0220
DEBUG - 2014-04-01 23:57:36 --> Config Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Config Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:57:36 --> Config Class Initialized
DEBUG - 2014-04-01 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:57:36 --> Hooks Class Initialized
DEBUG - 2014-04-01 23:57:36 --> URI Class Initialized
DEBUG - 2014-04-01 23:57:36 --> URI Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Utf8 Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Router Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Router Class Initialized
DEBUG - 2014-04-01 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-01 23:57:36 --> URI Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Router Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Output Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Output Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Output Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Security Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Security Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Input Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Input Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Security Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:57:36 --> Input Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-01 23:57:36 --> Language Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Language Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Language Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Loader Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Loader Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Loader Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Controller Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Controller Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Controller Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Database Driver Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:36 --> Session Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Session Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:57:36 --> A session cookie was not found.
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:36 --> Session routines successfully run
DEBUG - 2014-04-01 23:57:36 --> A session cookie was not found.
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:57:36 --> Session routines successfully run
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:57:36 --> Session Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: string_helper
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:36 --> A session cookie was not found.
DEBUG - 2014-04-01 23:57:36 --> Session routines successfully run
DEBUG - 2014-04-01 23:57:36 --> Helper loaded: url_helper
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:36 --> Model Class Initialized
DEBUG - 2014-04-01 23:57:36 --> Final output sent to browser
DEBUG - 2014-04-01 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-01 23:57:36 --> Total execution time: 0.0140
DEBUG - 2014-04-01 23:57:36 --> Final output sent to browser
DEBUG - 2014-04-01 23:57:36 --> Total execution time: 0.0150
DEBUG - 2014-04-01 23:57:36 --> Final output sent to browser
DEBUG - 2014-04-01 23:57:36 --> Total execution time: 0.0170
