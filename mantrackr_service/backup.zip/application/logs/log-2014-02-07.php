<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-07 03:07:52 --> Config Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:07:52 --> URI Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Router Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Output Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Security Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Input Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:07:52 --> Language Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Loader Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Controller Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:07:52 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Database Driver Class Initialized
ERROR - 2014-02-07 03:07:52 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 03:07:52 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:07:52 --> Session Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:07:52 --> A session cookie was not found.
DEBUG - 2014-02-07 03:07:52 --> Session routines successfully run
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:07:52 --> Config Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:07:52 --> URI Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Router Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Output Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Security Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Input Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:07:52 --> Language Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Loader Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Controller Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:07:52 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Database Driver Class Initialized
ERROR - 2014-02-07 03:07:52 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 03:07:52 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:07:52 --> Session Class Initialized
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:07:52 --> Session routines successfully run
DEBUG - 2014-02-07 03:07:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:07:52 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 03:07:52 --> Final output sent to browser
DEBUG - 2014-02-07 03:07:52 --> Total execution time: 0.0150
DEBUG - 2014-02-07 03:07:59 --> Config Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:07:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:07:59 --> URI Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Router Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Output Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Security Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Input Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:07:59 --> Language Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Loader Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Controller Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:07:59 --> Session Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:07:59 --> Session routines successfully run
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:07:59 --> Config Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:07:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:07:59 --> URI Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Router Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Output Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Security Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Input Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:07:59 --> Language Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Loader Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Controller Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:07:59 --> Session Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:07:59 --> Session routines successfully run
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:07:59 --> Config Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:07:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:07:59 --> URI Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Router Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Output Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Security Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Input Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:07:59 --> Language Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Loader Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Controller Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Database Driver Class Initialized
ERROR - 2014-02-07 03:07:59 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 03:07:59 --> Model Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:07:59 --> Session Class Initialized
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:07:59 --> Session routines successfully run
DEBUG - 2014-02-07 03:07:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:07:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 03:07:59 --> Final output sent to browser
DEBUG - 2014-02-07 03:07:59 --> Total execution time: 0.0160
DEBUG - 2014-02-07 03:08:00 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:00 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:00 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:00 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:00 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:00 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:00 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:00 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:00 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:00 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:00 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:00 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:00 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: utilities_helper
ERROR - 2014-02-07 03:08:00 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:00 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:00 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:00 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:00 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:00 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:00 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:00 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:00 --> Total execution time: 0.0200
DEBUG - 2014-02-07 03:08:00 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:00 --> Total execution time: 0.0180
DEBUG - 2014-02-07 03:08:00 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:00 --> Total execution time: 0.0280
DEBUG - 2014-02-07 03:08:02 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:02 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:02 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:02 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:02 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:02 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:02 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 03:08:02 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:02 --> Total execution time: 0.0190
DEBUG - 2014-02-07 03:08:02 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:02 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:02 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:02 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:02 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:02 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:02 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:02 --> Total execution time: 0.0110
DEBUG - 2014-02-07 03:08:03 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:03 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:03 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:03 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:03 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:03 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:03 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:03 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:03 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 03:08:03 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:03 --> Total execution time: 0.0220
DEBUG - 2014-02-07 03:08:05 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Config Class Initialized
DEBUG - 2014-02-07 03:08:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:05 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:08:05 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:08:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:08:05 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:05 --> URI Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Router Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Output Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Security Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:05 --> Input Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:08:05 --> Language Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Loader Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:05 --> Controller Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:05 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Session Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:08:05 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:05 --> Session routines successfully run
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:05 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:08:05 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:05 --> Total execution time: 0.0140
DEBUG - 2014-02-07 03:08:05 --> Final output sent to browser
DEBUG - 2014-02-07 03:08:05 --> Total execution time: 0.0170
DEBUG - 2014-02-07 03:43:05 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:05 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:05 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:05 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:05 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:05 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:05 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:15 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:15 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:15 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:15 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:15 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:15 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:15 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:15 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 03:43:15 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:15 --> Total execution time: 0.0210
DEBUG - 2014-02-07 03:43:16 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:16 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:16 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:16 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:16 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:16 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:16 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:16 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:16 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:16 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:16 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:16 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:16 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:16 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:16 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:16 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:16 --> Total execution time: 0.0160
DEBUG - 2014-02-07 03:43:16 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:16 --> Total execution time: 0.0200
DEBUG - 2014-02-07 03:43:16 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:16 --> Total execution time: 0.0280
DEBUG - 2014-02-07 03:43:17 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:17 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:17 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:17 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:17 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:17 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:17 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:17 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 03:43:17 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:17 --> Total execution time: 0.0190
DEBUG - 2014-02-07 03:43:18 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:18 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:18 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:18 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:18 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:18 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:18 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:18 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:18 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:18 --> Total execution time: 0.0100
DEBUG - 2014-02-07 03:43:19 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:19 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:19 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:19 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:19 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:19 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:19 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:19 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:19 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 03:43:19 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:19 --> Total execution time: 0.0200
DEBUG - 2014-02-07 03:43:21 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:21 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:21 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:21 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:21 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:21 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:21 --> Total execution time: 0.0140
DEBUG - 2014-02-07 03:43:21 --> Config Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Hooks Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Utf8 Class Initialized
DEBUG - 2014-02-07 03:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 03:43:21 --> URI Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Router Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Output Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Security Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Input Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 03:43:21 --> Language Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Loader Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Controller Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Database Driver Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:21 --> Session Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: string_helper
DEBUG - 2014-02-07 03:43:21 --> Session routines successfully run
DEBUG - 2014-02-07 03:43:21 --> Helper loaded: url_helper
DEBUG - 2014-02-07 03:43:21 --> Model Class Initialized
DEBUG - 2014-02-07 03:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 03:43:21 --> Final output sent to browser
DEBUG - 2014-02-07 03:43:21 --> Total execution time: 0.0210
DEBUG - 2014-02-07 18:53:26 --> Config Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:53:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:53:26 --> URI Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Router Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Output Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Security Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Input Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:53:26 --> Language Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Loader Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Controller Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:53:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:53:26 --> Model Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Model Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Database Driver Class Initialized
ERROR - 2014-02-07 18:53:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 18:53:26 --> Model Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:53:26 --> Session Class Initialized
DEBUG - 2014-02-07 18:53:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:53:26 --> A session cookie was not found.
DEBUG - 2014-02-07 18:53:26 --> Session routines successfully run
DEBUG - 2014-02-07 18:53:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:53:36 --> Config Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:53:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:53:36 --> URI Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Router Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Output Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Security Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Input Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:53:36 --> Language Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Loader Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Controller Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:53:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:53:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Database Driver Class Initialized
ERROR - 2014-02-07 18:53:36 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 18:53:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:53:36 --> Session Class Initialized
DEBUG - 2014-02-07 18:53:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:53:36 --> Session routines successfully run
DEBUG - 2014-02-07 18:53:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:53:36 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 18:53:36 --> Final output sent to browser
DEBUG - 2014-02-07 18:53:36 --> Total execution time: 0.0230
DEBUG - 2014-02-07 18:55:38 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:38 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:38 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Database Driver Class Initialized
ERROR - 2014-02-07 18:55:38 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:38 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:38 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:38 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:38 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:38 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Database Driver Class Initialized
ERROR - 2014-02-07 18:55:38 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:38 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:38 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:38 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:38 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:38 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:38 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:38 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:38 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 18:55:38 --> Final output sent to browser
DEBUG - 2014-02-07 18:55:38 --> Total execution time: 0.0200
DEBUG - 2014-02-07 18:55:39 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:39 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:39 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:39 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:39 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:39 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:39 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:39 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:39 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:39 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:39 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:39 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:39 --> Final output sent to browser
DEBUG - 2014-02-07 18:55:39 --> Total execution time: 0.0160
DEBUG - 2014-02-07 18:55:39 --> Final output sent to browser
DEBUG - 2014-02-07 18:55:39 --> Total execution time: 0.0250
DEBUG - 2014-02-07 18:55:39 --> Final output sent to browser
DEBUG - 2014-02-07 18:55:39 --> Total execution time: 0.0220
DEBUG - 2014-02-07 18:55:44 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:44 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Config Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:44 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:55:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:55:44 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:44 --> URI Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Router Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:44 --> Output Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Security Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Input Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:55:44 --> Language Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Loader Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Controller Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:55:44 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:44 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:44 --> Session Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:55:44 --> Session routines successfully run
DEBUG - 2014-02-07 18:55:44 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:55:44 --> Model Class Initialized
DEBUG - 2014-02-07 18:55:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:55:44 --> Final output sent to browser
DEBUG - 2014-02-07 18:55:44 --> Total execution time: 0.0200
DEBUG - 2014-02-07 18:55:44 --> Final output sent to browser
DEBUG - 2014-02-07 18:55:44 --> Total execution time: 0.0340
DEBUG - 2014-02-07 18:59:20 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:20 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:20 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:20 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:20 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:20 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:20 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:20 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:30 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:30 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:30 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:30 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:30 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 18:59:30 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:30 --> Total execution time: 0.0210
DEBUG - 2014-02-07 18:59:30 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:30 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:30 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:30 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:30 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:30 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:30 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:30 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:30 --> Total execution time: 0.0110
DEBUG - 2014-02-07 18:59:31 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:31 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:31 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:31 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:31 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:31 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:31 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:31 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:31 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:31 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:31 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:31 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:31 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:31 --> Total execution time: 0.0250
DEBUG - 2014-02-07 18:59:31 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:31 --> Total execution time: 0.0320
DEBUG - 2014-02-07 18:59:35 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:35 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:35 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:35 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:35 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:35 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:35 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:35 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:35 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:35 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:35 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 18:59:35 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:35 --> Total execution time: 0.0090
DEBUG - 2014-02-07 18:59:35 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:35 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:35 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:36 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:36 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:36 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:36 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:36 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:36 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:36 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:36 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:36 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:36 --> Total execution time: 0.0420
DEBUG - 2014-02-07 18:59:36 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:36 --> Total execution time: 0.0270
DEBUG - 2014-02-07 18:59:38 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:38 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:38 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:38 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:38 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:38 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:38 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:38 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:38 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:38 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:38 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 18:59:38 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:38 --> Total execution time: 0.0090
DEBUG - 2014-02-07 18:59:52 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:52 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:52 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:52 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:52 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:52 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:52 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 18:59:52 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:52 --> Total execution time: 0.0200
DEBUG - 2014-02-07 18:59:52 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:52 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:52 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:52 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:53 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:53 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:53 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:53 --> Total execution time: 0.0110
DEBUG - 2014-02-07 18:59:53 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:53 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:53 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:53 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:53 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:53 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:53 --> Total execution time: 0.0230
DEBUG - 2014-02-07 18:59:53 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:53 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:53 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:53 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:53 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:53 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:53 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:53 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:53 --> Total execution time: 0.0160
DEBUG - 2014-02-07 18:59:55 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:55 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:55 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:55 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:55 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:55 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:55 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:55 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:55 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:55 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:55 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:55 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:55 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:55 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 18:59:55 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:55 --> Total execution time: 0.0110
DEBUG - 2014-02-07 18:59:58 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:58 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:58 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:58 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:58 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:58 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:58 --> Total execution time: 0.0240
DEBUG - 2014-02-07 18:59:58 --> Config Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Hooks Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Utf8 Class Initialized
DEBUG - 2014-02-07 18:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 18:59:58 --> URI Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Router Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Output Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Security Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Input Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 18:59:58 --> Language Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Loader Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Controller Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Database Driver Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:58 --> Session Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: string_helper
DEBUG - 2014-02-07 18:59:58 --> Session routines successfully run
DEBUG - 2014-02-07 18:59:58 --> Helper loaded: url_helper
DEBUG - 2014-02-07 18:59:58 --> Model Class Initialized
DEBUG - 2014-02-07 18:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 18:59:58 --> Final output sent to browser
DEBUG - 2014-02-07 18:59:58 --> Total execution time: 0.0290
DEBUG - 2014-02-07 19:00:20 --> Config Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:00:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:00:20 --> URI Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Router Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Output Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Security Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Input Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:00:20 --> Language Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Loader Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Controller Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:00:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:00:20 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:00:20 --> Session Class Initialized
DEBUG - 2014-02-07 19:00:20 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:00:20 --> Session routines successfully run
DEBUG - 2014-02-07 19:00:20 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:00:25 --> Config Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:00:25 --> URI Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Router Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Output Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Security Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Input Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:00:25 --> Language Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Loader Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Controller Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:00:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:00:25 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:00:25 --> Session Class Initialized
DEBUG - 2014-02-07 19:00:25 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:00:25 --> Session routines successfully run
DEBUG - 2014-02-07 19:00:25 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:00:25 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 19:00:25 --> Final output sent to browser
DEBUG - 2014-02-07 19:00:25 --> Total execution time: 0.0180
DEBUG - 2014-02-07 19:00:29 --> Config Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:00:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:00:29 --> URI Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Router Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Output Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Security Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Input Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:00:29 --> Language Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Loader Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Controller Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:00:29 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:00:29 --> Session Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:00:29 --> Session routines successfully run
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:00:29 --> Config Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:00:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:00:29 --> URI Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Router Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Output Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Security Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Input Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:00:29 --> Language Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Loader Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Controller Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:00:29 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:00:29 --> Session Class Initialized
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:00:29 --> Session routines successfully run
DEBUG - 2014-02-07 19:00:29 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:00:29 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 19:00:29 --> Final output sent to browser
DEBUG - 2014-02-07 19:00:29 --> Total execution time: 0.0090
DEBUG - 2014-02-07 19:00:39 --> Config Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:00:39 --> URI Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Router Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Output Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Security Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Input Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:00:39 --> Language Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Loader Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Controller Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:00:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:00:39 --> Session Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:00:39 --> Session routines successfully run
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:00:39 --> Config Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:00:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:00:39 --> URI Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Router Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Output Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Security Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Input Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:00:39 --> Language Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Loader Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Controller Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:00:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:00:39 --> Session Class Initialized
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:00:39 --> Session routines successfully run
DEBUG - 2014-02-07 19:00:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:00:39 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 19:00:39 --> Final output sent to browser
DEBUG - 2014-02-07 19:00:39 --> Total execution time: 0.0170
DEBUG - 2014-02-07 19:02:49 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:49 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:49 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:49 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:49 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:49 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:49 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:49 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:49 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:49 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:49 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:49 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:49 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:49 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:49 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:49 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:02:49 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:49 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:02:49 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:49 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:49 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:49 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:49 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:49 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:49 --> Total execution time: 0.0240
DEBUG - 2014-02-07 19:02:50 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:50 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:50 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:50 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:50 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:50 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:50 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:50 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:50 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:50 --> Total execution time: 0.0250
DEBUG - 2014-02-07 19:02:50 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:50 --> Total execution time: 0.0310
DEBUG - 2014-02-07 19:02:54 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:54 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:54 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:54 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:54 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:54 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:54 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:02:54 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:54 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:54 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:54 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:54 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:54 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:54 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:54 --> Total execution time: 0.0300
DEBUG - 2014-02-07 19:02:59 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:59 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:59 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:59 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:02:59 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:59 --> Total execution time: 0.0130
DEBUG - 2014-02-07 19:02:59 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:59 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:59 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:59 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:59 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:59 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:59 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:59 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:59 --> Total execution time: 0.0120
DEBUG - 2014-02-07 19:02:59 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:59 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:02:59 --> Config Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:02:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:02:59 --> URI Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Router Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Output Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Security Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Input Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:02:59 --> Language Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Loader Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Controller Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Session Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:02:59 --> Session routines successfully run
DEBUG - 2014-02-07 19:02:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:02:59 --> Model Class Initialized
DEBUG - 2014-02-07 19:02:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:02:59 --> Final output sent to browser
DEBUG - 2014-02-07 19:02:59 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:03:04 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:04 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:04 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:04 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:04 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:04 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:04 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:04 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:04 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:04 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:04 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:04 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:04 --> Total execution time: 0.0420
DEBUG - 2014-02-07 19:03:04 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:04 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:03:33 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:33 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:33 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:33 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:33 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:33 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:33 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:33 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:03:33 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:33 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:03:34 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:34 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:34 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:34 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:34 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:34 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:34 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:34 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:34 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:34 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:34 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:34 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:34 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:34 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:34 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:34 --> Total execution time: 0.0140
DEBUG - 2014-02-07 19:03:34 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:34 --> Total execution time: 0.0180
DEBUG - 2014-02-07 19:03:34 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:34 --> Total execution time: 0.0260
DEBUG - 2014-02-07 19:03:39 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:39 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Config Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:39 --> URI Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Router Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Output Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Security Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:39 --> Input Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Language Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Loader Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Controller Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:39 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Session Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:03:39 --> Session routines successfully run
DEBUG - 2014-02-07 19:03:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:03:39 --> Model Class Initialized
DEBUG - 2014-02-07 19:03:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:03:39 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:39 --> Total execution time: 0.0240
DEBUG - 2014-02-07 19:03:39 --> Final output sent to browser
DEBUG - 2014-02-07 19:03:39 --> Total execution time: 0.0240
DEBUG - 2014-02-07 19:25:34 --> Config Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:25:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:25:34 --> URI Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Router Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Output Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Security Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Input Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:25:34 --> Language Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Loader Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Controller Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:25:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:25:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:25:34 --> Session Class Initialized
DEBUG - 2014-02-07 19:25:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:25:34 --> Session routines successfully run
DEBUG - 2014-02-07 19:25:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:25:34 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 19:25:34 --> Final output sent to browser
DEBUG - 2014-02-07 19:25:34 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:25:35 --> Config Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:25:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:25:35 --> URI Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Router Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Output Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Security Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Input Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:25:35 --> Language Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Loader Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Controller Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:25:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:25:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:25:35 --> Session Class Initialized
DEBUG - 2014-02-07 19:25:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:25:35 --> Session routines successfully run
DEBUG - 2014-02-07 19:25:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:25:35 --> Final output sent to browser
DEBUG - 2014-02-07 19:25:35 --> Total execution time: 0.0110
DEBUG - 2014-02-07 19:25:37 --> Config Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:25:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:25:37 --> URI Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Router Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Output Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Security Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Input Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:25:37 --> Language Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Loader Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Controller Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:25:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:25:37 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Model Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:25:37 --> Session Class Initialized
DEBUG - 2014-02-07 19:25:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:25:37 --> Session routines successfully run
DEBUG - 2014-02-07 19:25:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:25:37 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 19:25:37 --> Final output sent to browser
DEBUG - 2014-02-07 19:25:37 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:36:51 --> Config Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:36:51 --> URI Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Router Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Output Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Security Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Input Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:36:51 --> Language Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Loader Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Controller Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:36:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:51 --> Session Class Initialized
DEBUG - 2014-02-07 19:36:51 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:36:51 --> Session routines successfully run
DEBUG - 2014-02-07 19:36:51 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:36:56 --> Config Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:36:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:36:56 --> URI Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Router Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Output Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Security Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Input Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:36:56 --> Language Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Loader Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Controller Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:36:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:36:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:56 --> Session Class Initialized
DEBUG - 2014-02-07 19:36:56 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:36:56 --> Session routines successfully run
DEBUG - 2014-02-07 19:36:56 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:36:56 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:36:56 --> Final output sent to browser
DEBUG - 2014-02-07 19:36:56 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:36:57 --> Config Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Config Class Initialized
DEBUG - 2014-02-07 19:36:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:36:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:36:57 --> URI Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Router Class Initialized
DEBUG - 2014-02-07 19:36:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:36:57 --> URI Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Router Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Output Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Security Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Output Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Input Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Security Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:36:57 --> Input Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Language Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Config Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:36:57 --> Loader Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Controller Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Language Class Initialized
DEBUG - 2014-02-07 19:36:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:36:57 --> URI Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Loader Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Router Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:36:57 --> Controller Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:36:57 --> Output Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:36:57 --> Security Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Input Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:36:57 --> Language Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Loader Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Controller Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Session Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Session routines successfully run
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Session Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:36:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Session routines successfully run
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Session Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:36:57 --> Final output sent to browser
DEBUG - 2014-02-07 19:36:57 --> Session routines successfully run
DEBUG - 2014-02-07 19:36:57 --> Total execution time: 0.0150
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Final output sent to browser
DEBUG - 2014-02-07 19:36:57 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:36:57 --> Config Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:36:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:36:57 --> URI Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Router Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Final output sent to browser
DEBUG - 2014-02-07 19:36:57 --> Total execution time: 0.0300
DEBUG - 2014-02-07 19:36:57 --> Output Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Security Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Input Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:36:57 --> Language Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Loader Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Controller Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Session Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:36:57 --> Session routines successfully run
DEBUG - 2014-02-07 19:36:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:36:57 --> Model Class Initialized
DEBUG - 2014-02-07 19:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:36:57 --> Final output sent to browser
DEBUG - 2014-02-07 19:36:57 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:37:02 --> Config Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:37:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:37:02 --> URI Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Router Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Output Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Security Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Input Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:37:02 --> Language Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Loader Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Controller Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:37:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:37:02 --> Model Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Model Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Model Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:37:02 --> Session Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:37:02 --> Session routines successfully run
DEBUG - 2014-02-07 19:37:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:37:02 --> Model Class Initialized
DEBUG - 2014-02-07 19:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:37:02 --> Final output sent to browser
DEBUG - 2014-02-07 19:37:02 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:38:03 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:03 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:03 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:03 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:03 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:03 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:03 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:03 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:38:03 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:03 --> Total execution time: 0.0130
DEBUG - 2014-02-07 19:38:04 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:04 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:04 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:04 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:04 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:04 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:04 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:04 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:04 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:04 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:04 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:04 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:04 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:04 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:04 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:04 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:04 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:04 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:04 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:04 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:04 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:04 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:38:04 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:04 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:38:04 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:04 --> Total execution time: 0.0260
DEBUG - 2014-02-07 19:38:09 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:09 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:09 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:09 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:09 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:09 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:09 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:09 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:09 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:38:09 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:09 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:38:11 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:11 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:11 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:11 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:38:11 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:11 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:38:11 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:11 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:11 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:11 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:11 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:11 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:11 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:11 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:11 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:11 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:11 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:11 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:11 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:11 --> Total execution time: 0.0160
DEBUG - 2014-02-07 19:38:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:11 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:11 --> Total execution time: 0.0180
DEBUG - 2014-02-07 19:38:11 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:11 --> Total execution time: 0.0250
DEBUG - 2014-02-07 19:38:16 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:16 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:16 --> Config Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:38:16 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:16 --> URI Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:16 --> Router Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:16 --> Output Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Security Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Input Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:38:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Language Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Loader Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Controller Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:38:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:38:16 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:16 --> Session Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:38:16 --> Session routines successfully run
DEBUG - 2014-02-07 19:38:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:38:16 --> Model Class Initialized
DEBUG - 2014-02-07 19:38:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:38:16 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:16 --> Total execution time: 0.0260
DEBUG - 2014-02-07 19:38:16 --> Final output sent to browser
DEBUG - 2014-02-07 19:38:16 --> Total execution time: 0.0360
DEBUG - 2014-02-07 19:41:35 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:35 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:35 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:35 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:35 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:35 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:41:35 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:35 --> Total execution time: 0.0130
DEBUG - 2014-02-07 19:41:36 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:36 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:36 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:36 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:36 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:36 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:36 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:36 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:36 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:36 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:36 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:36 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:36 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:36 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:36 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:41:36 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:36 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:36 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:41:36 --> Total execution time: 0.0250
DEBUG - 2014-02-07 19:41:41 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:41 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:41 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:41 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:41 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:41 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:41 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:41 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:41 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:41 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:41 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:41 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:41 --> Total execution time: 0.0360
DEBUG - 2014-02-07 19:41:42 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:42 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:42 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:42 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:42 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:42 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:42 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:41:42 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:42 --> Total execution time: 0.0160
DEBUG - 2014-02-07 19:41:43 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:43 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:43 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:43 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:43 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:43 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:43 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:43 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:43 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:43 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:43 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:43 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:43 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:43 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:43 --> Total execution time: 0.0150
DEBUG - 2014-02-07 19:41:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:43 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:43 --> Total execution time: 0.0170
DEBUG - 2014-02-07 19:41:43 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:43 --> Total execution time: 0.0250
DEBUG - 2014-02-07 19:41:45 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:45 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:45 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:45 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:41:45 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:45 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:41:45 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:45 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:45 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:45 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:45 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:45 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:45 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:45 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:45 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:45 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:45 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:45 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:45 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:45 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:45 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:45 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:45 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:45 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:45 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:45 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:45 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:45 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:45 --> Total execution time: 0.0215
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:45 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:46 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:46 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:46 --> Total execution time: 0.0255
DEBUG - 2014-02-07 19:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:46 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:46 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:46 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:46 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:46 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:46 --> Total execution time: 0.0370
DEBUG - 2014-02-07 19:41:46 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:46 --> Total execution time: 0.0365
DEBUG - 2014-02-07 19:41:46 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:46 --> Total execution time: 0.0140
DEBUG - 2014-02-07 19:41:48 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:48 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Config Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:41:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:41:48 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:48 --> URI Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Router Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:48 --> Output Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:48 --> Security Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Input Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:41:48 --> Language Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Loader Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Controller Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:41:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:48 --> Session Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:41:48 --> Session routines successfully run
DEBUG - 2014-02-07 19:41:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:41:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:41:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:41:48 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:48 --> Total execution time: 0.0330
DEBUG - 2014-02-07 19:41:48 --> Final output sent to browser
DEBUG - 2014-02-07 19:41:48 --> Total execution time: 0.0410
DEBUG - 2014-02-07 19:43:46 --> Config Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:43:46 --> URI Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Router Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Output Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Security Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Input Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:43:46 --> Language Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Loader Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Controller Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:43:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:43:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:46 --> Session Class Initialized
DEBUG - 2014-02-07 19:43:46 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:43:46 --> Session routines successfully run
DEBUG - 2014-02-07 19:43:46 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:43:46 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:43:46 --> Final output sent to browser
DEBUG - 2014-02-07 19:43:46 --> Total execution time: 0.0120
DEBUG - 2014-02-07 19:43:47 --> Config Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:43:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:43:47 --> URI Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Router Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Config Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Config Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Output Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Security Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:43:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:43:47 --> Input Class Initialized
DEBUG - 2014-02-07 19:43:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:43:47 --> URI Class Initialized
DEBUG - 2014-02-07 19:43:47 --> URI Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Router Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Router Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:43:47 --> Language Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Output Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Output Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Security Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Loader Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Security Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Input Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Controller Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:43:47 --> Input Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Language Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Loader Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Controller Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:43:47 --> Language Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Loader Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Controller Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:47 --> Session Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:43:47 --> Session Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Session routines successfully run
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:43:47 --> Session routines successfully run
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:47 --> Session Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:43:47 --> Session routines successfully run
DEBUG - 2014-02-07 19:43:47 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:43:47 --> Final output sent to browser
DEBUG - 2014-02-07 19:43:47 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:43:47 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:47 --> Final output sent to browser
DEBUG - 2014-02-07 19:43:47 --> Total execution time: 0.0365
DEBUG - 2014-02-07 19:43:47 --> Final output sent to browser
DEBUG - 2014-02-07 19:43:47 --> Total execution time: 0.0380
DEBUG - 2014-02-07 19:43:52 --> Config Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Config Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:43:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:43:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:43:52 --> URI Class Initialized
DEBUG - 2014-02-07 19:43:52 --> URI Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Router Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Router Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Output Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Output Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Security Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Security Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Input Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Input Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:43:52 --> Language Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Language Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Loader Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Loader Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Controller Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Controller Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:52 --> Session Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Session Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:43:52 --> Session routines successfully run
DEBUG - 2014-02-07 19:43:52 --> Session routines successfully run
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:43:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Model Class Initialized
DEBUG - 2014-02-07 19:43:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:43:52 --> Final output sent to browser
DEBUG - 2014-02-07 19:43:52 --> Total execution time: 0.0280
DEBUG - 2014-02-07 19:43:52 --> Final output sent to browser
DEBUG - 2014-02-07 19:43:52 --> Total execution time: 0.0350
DEBUG - 2014-02-07 19:44:22 --> Config Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:44:22 --> URI Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Router Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Output Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Security Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Input Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:44:22 --> Language Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Loader Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Controller Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Session Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:44:22 --> Session routines successfully run
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:44:22 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:44:22 --> Final output sent to browser
DEBUG - 2014-02-07 19:44:22 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:44:22 --> Config Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:44:22 --> URI Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Router Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Output Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Security Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Config Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Input Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Config Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:44:22 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Language Class Initialized
DEBUG - 2014-02-07 19:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:44:22 --> URI Class Initialized
DEBUG - 2014-02-07 19:44:22 --> URI Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Router Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Loader Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Router Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Controller Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Output Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:44:22 --> Output Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Security Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:44:22 --> Input Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Security Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Input Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Language Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:44:22 --> Language Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Loader Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Controller Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Loader Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Controller Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Session Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:44:22 --> Session routines successfully run
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Session Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Session Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:44:22 --> Session routines successfully run
DEBUG - 2014-02-07 19:44:22 --> Session routines successfully run
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:44:22 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:22 --> Final output sent to browser
DEBUG - 2014-02-07 19:44:22 --> Total execution time: 0.0150
DEBUG - 2014-02-07 19:44:22 --> Final output sent to browser
DEBUG - 2014-02-07 19:44:22 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:44:22 --> Final output sent to browser
DEBUG - 2014-02-07 19:44:22 --> Total execution time: 0.0550
DEBUG - 2014-02-07 19:44:27 --> Config Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:44:27 --> URI Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Router Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Output Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Security Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Input Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Config Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:44:27 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Language Class Initialized
DEBUG - 2014-02-07 19:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:44:27 --> URI Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Loader Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Router Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Controller Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:44:27 --> Output Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:44:27 --> Security Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Input Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:44:27 --> Language Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Loader Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Controller Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Session Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:44:27 --> Session routines successfully run
DEBUG - 2014-02-07 19:44:27 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:27 --> Session Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:44:27 --> Session routines successfully run
DEBUG - 2014-02-07 19:44:27 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:44:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:44:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:44:27 --> Final output sent to browser
DEBUG - 2014-02-07 19:44:27 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:44:27 --> Final output sent to browser
DEBUG - 2014-02-07 19:44:27 --> Total execution time: 0.0440
DEBUG - 2014-02-07 19:46:07 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:07 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:07 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:07 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:07 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:07 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:07 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:07 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:07 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:46:07 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:07 --> Total execution time: 0.0160
DEBUG - 2014-02-07 19:46:08 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:08 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:08 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:08 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:08 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:08 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:08 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:08 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:08 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:08 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:08 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:08 --> Total execution time: 0.0140
DEBUG - 2014-02-07 19:46:08 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:08 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:08 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:08 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:08 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:08 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:08 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:08 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:46:08 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:08 --> Total execution time: 0.0280
DEBUG - 2014-02-07 19:46:09 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:09 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:09 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:09 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:09 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:09 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:46:09 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:09 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:46:10 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:10 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:10 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:10 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:10 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:10 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:10 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:10 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:10 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:10 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:10 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:10 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:10 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:10 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:10 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:10 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:10 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:10 --> Total execution time: 0.0275
DEBUG - 2014-02-07 19:46:10 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:10 --> Total execution time: 0.0275
DEBUG - 2014-02-07 19:46:10 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:10 --> Total execution time: 0.0295
DEBUG - 2014-02-07 19:46:10 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:10 --> Total execution time: 0.0435
DEBUG - 2014-02-07 19:46:13 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:13 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Config Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:13 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:46:13 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:13 --> URI Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Router Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:13 --> Output Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Security Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Input Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:46:13 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Language Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Loader Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Controller Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:13 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:13 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:13 --> Session Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:46:13 --> Session routines successfully run
DEBUG - 2014-02-07 19:46:13 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:46:13 --> Model Class Initialized
DEBUG - 2014-02-07 19:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:46:13 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:13 --> Total execution time: 0.0340
DEBUG - 2014-02-07 19:46:13 --> Final output sent to browser
DEBUG - 2014-02-07 19:46:13 --> Total execution time: 0.0400
DEBUG - 2014-02-07 19:47:26 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:26 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:26 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:26 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:47:26 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:26 --> Total execution time: 0.0120
DEBUG - 2014-02-07 19:47:26 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:26 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:26 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:26 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:26 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:26 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:26 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:26 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:26 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:26 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:26 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:26 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:26 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:26 --> Total execution time: 0.0140
DEBUG - 2014-02-07 19:47:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:26 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:26 --> Total execution time: 0.0160
DEBUG - 2014-02-07 19:47:26 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:26 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:47:27 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:27 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:27 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:27 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:27 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:27 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:27 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:27 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:47:27 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:27 --> Total execution time: 0.0110
DEBUG - 2014-02-07 19:47:28 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:28 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:28 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:28 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:28 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:28 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:28 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:28 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:28 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:28 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:28 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:28 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:28 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:28 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:28 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:28 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:28 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:28 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Total execution time: 0.0240
DEBUG - 2014-02-07 19:47:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:28 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:28 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:28 --> Total execution time: 0.0260
DEBUG - 2014-02-07 19:47:28 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:28 --> Total execution time: 0.0330
DEBUG - 2014-02-07 19:47:28 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:28 --> Total execution time: 0.0330
DEBUG - 2014-02-07 19:47:28 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:28 --> Total execution time: 0.0400
DEBUG - 2014-02-07 19:47:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:47:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:47:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:47:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:47:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:47:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:47:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:31 --> Total execution time: 0.0320
DEBUG - 2014-02-07 19:47:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:47:31 --> Total execution time: 0.0420
DEBUG - 2014-02-07 19:49:30 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:30 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:30 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:30 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:30 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:30 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:30 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:30 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:49:30 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:30 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:49:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:31 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:49:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:31 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:49:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:31 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:31 --> Total execution time: 0.0250
DEBUG - 2014-02-07 19:49:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:31 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:49:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:31 --> Total execution time: 0.0350
DEBUG - 2014-02-07 19:49:41 --> Config Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:49:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:49:41 --> URI Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Router Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Output Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Security Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Input Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:49:41 --> Language Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Loader Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Controller Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:49:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:49:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:41 --> Session Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:49:41 --> Session routines successfully run
DEBUG - 2014-02-07 19:49:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:49:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:49:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:49:41 --> Final output sent to browser
DEBUG - 2014-02-07 19:49:41 --> Total execution time: 0.0270
DEBUG - 2014-02-07 19:52:43 --> Config Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:52:43 --> URI Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Router Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Output Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Security Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Input Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:52:43 --> Language Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Loader Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Controller Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:52:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Model Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:52:43 --> Session Class Initialized
DEBUG - 2014-02-07 19:52:43 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:52:43 --> Session routines successfully run
DEBUG - 2014-02-07 19:52:43 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:52:43 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 19:52:43 --> Final output sent to browser
DEBUG - 2014-02-07 19:52:43 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:52:49 --> Config Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:52:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:52:49 --> URI Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Router Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Output Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Security Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Input Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:52:49 --> Language Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Loader Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Controller Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:52:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:52:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Model Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:52:49 --> Session Class Initialized
DEBUG - 2014-02-07 19:52:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:52:49 --> Session routines successfully run
DEBUG - 2014-02-07 19:52:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:52:49 --> Final output sent to browser
DEBUG - 2014-02-07 19:52:49 --> Total execution time: 0.0190
DEBUG - 2014-02-07 19:54:35 --> Config Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:54:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:54:35 --> URI Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Router Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Output Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Security Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Input Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:54:35 --> Language Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Loader Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Controller Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:54:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:54:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:54:35 --> Session Class Initialized
DEBUG - 2014-02-07 19:54:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:54:35 --> Session routines successfully run
DEBUG - 2014-02-07 19:54:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:54:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 19:54:35 --> Final output sent to browser
DEBUG - 2014-02-07 19:54:35 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:54:36 --> Config Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:54:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:54:36 --> URI Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Router Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Output Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Security Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Input Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:54:36 --> Language Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Loader Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Controller Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:54:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:54:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:54:36 --> Session Class Initialized
DEBUG - 2014-02-07 19:54:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:54:36 --> Session routines successfully run
DEBUG - 2014-02-07 19:54:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:54:36 --> Final output sent to browser
DEBUG - 2014-02-07 19:54:36 --> Total execution time: 0.0110
DEBUG - 2014-02-07 19:54:48 --> Config Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:54:48 --> URI Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Router Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Output Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Security Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Input Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:54:48 --> Language Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Loader Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Controller Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:54:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:54:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:54:48 --> Session Class Initialized
DEBUG - 2014-02-07 19:54:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:54:48 --> Session routines successfully run
DEBUG - 2014-02-07 19:54:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:54:48 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-07 19:54:48 --> Final output sent to browser
DEBUG - 2014-02-07 19:54:48 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:54:54 --> Config Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:54:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:54:54 --> URI Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Router Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Output Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Security Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Input Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:54:54 --> Language Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Loader Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Controller Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:54:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:54:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Model Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:54:54 --> Session Class Initialized
DEBUG - 2014-02-07 19:54:54 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:54:54 --> Session routines successfully run
DEBUG - 2014-02-07 19:54:54 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:54:54 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 19:54:54 --> Final output sent to browser
DEBUG - 2014-02-07 19:54:54 --> Total execution time: 0.0170
DEBUG - 2014-02-07 19:55:08 --> Config Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:55:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:55:08 --> URI Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Router Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Output Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Security Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Input Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:55:08 --> Language Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Loader Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Controller Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:55:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:55:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:55:08 --> Session Class Initialized
DEBUG - 2014-02-07 19:55:08 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:55:08 --> Session routines successfully run
DEBUG - 2014-02-07 19:55:08 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:55:08 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 19:55:08 --> Final output sent to browser
DEBUG - 2014-02-07 19:55:08 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:55:15 --> Config Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:55:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:55:15 --> URI Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Router Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Output Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Security Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Input Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:55:15 --> Language Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Loader Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Controller Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:55:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:55:15 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:55:15 --> Session Class Initialized
DEBUG - 2014-02-07 19:55:15 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:55:15 --> Session routines successfully run
DEBUG - 2014-02-07 19:55:15 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:55:15 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 19:55:15 --> Final output sent to browser
DEBUG - 2014-02-07 19:55:15 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:55:31 --> Config Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:55:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:55:31 --> URI Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Router Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Output Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Security Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Input Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:55:31 --> Language Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Loader Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Controller Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:55:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:55:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Model Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:55:31 --> Session Class Initialized
DEBUG - 2014-02-07 19:55:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:55:31 --> Session routines successfully run
DEBUG - 2014-02-07 19:55:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:55:31 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 19:55:31 --> Final output sent to browser
DEBUG - 2014-02-07 19:55:31 --> Total execution time: 0.0230
DEBUG - 2014-02-07 19:57:23 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:23 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:23 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:23 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:23 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:23 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:23 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:23 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:23 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 19:57:23 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:23 --> Total execution time: 0.0150
DEBUG - 2014-02-07 19:57:27 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:27 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:27 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:27 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:27 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:27 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:27 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:27 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-07 19:57:27 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:27 --> Total execution time: 0.0160
DEBUG - 2014-02-07 19:57:41 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:41 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:41 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:41 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:41 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:41 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-07 19:57:41 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:41 --> Total execution time: 0.0210
DEBUG - 2014-02-07 19:57:50 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:50 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:50 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:50 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:50 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:50 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:50 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:50 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 19:57:50 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:50 --> Total execution time: 0.0160
DEBUG - 2014-02-07 19:57:51 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:51 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:51 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:51 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:51 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:51 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:51 --> Total execution time: 0.0120
DEBUG - 2014-02-07 19:57:51 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:51 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:51 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:51 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:51 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:51 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:51 --> Total execution time: 0.0290
DEBUG - 2014-02-07 19:57:51 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:51 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:51 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:51 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:51 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:51 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:51 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:51 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:51 --> Total execution time: 0.0180
DEBUG - 2014-02-07 19:57:56 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:56 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:56 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:56 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:56 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:56 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:56 --> Total execution time: 0.0380
DEBUG - 2014-02-07 19:57:56 --> Config Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:57:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:57:56 --> URI Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Router Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Output Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Security Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Input Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:57:56 --> Language Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Loader Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Controller Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:56 --> Session Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:57:56 --> Session routines successfully run
DEBUG - 2014-02-07 19:57:56 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:57:56 --> Model Class Initialized
DEBUG - 2014-02-07 19:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:57:56 --> Final output sent to browser
DEBUG - 2014-02-07 19:57:56 --> Total execution time: 0.0200
DEBUG - 2014-02-07 19:58:11 --> Config Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:58:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:58:11 --> URI Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Router Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Output Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Security Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Input Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:58:11 --> Language Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Loader Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Controller Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:58:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:58:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Model Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:58:11 --> Session Class Initialized
DEBUG - 2014-02-07 19:58:11 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:58:11 --> Session routines successfully run
DEBUG - 2014-02-07 19:58:11 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:58:11 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 19:58:11 --> Final output sent to browser
DEBUG - 2014-02-07 19:58:11 --> Total execution time: 0.0220
DEBUG - 2014-02-07 19:58:18 --> Config Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Hooks Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Utf8 Class Initialized
DEBUG - 2014-02-07 19:58:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 19:58:18 --> URI Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Router Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Output Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Security Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Input Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 19:58:18 --> Language Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Loader Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Controller Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 19:58:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 19:58:18 --> Model Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Model Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Database Driver Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Model Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 19:58:18 --> Session Class Initialized
DEBUG - 2014-02-07 19:58:18 --> Helper loaded: string_helper
DEBUG - 2014-02-07 19:58:18 --> Session routines successfully run
DEBUG - 2014-02-07 19:58:18 --> Helper loaded: url_helper
DEBUG - 2014-02-07 19:58:18 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 19:58:18 --> Final output sent to browser
DEBUG - 2014-02-07 19:58:18 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:00:19 --> Config Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:00:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:00:19 --> URI Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Router Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Output Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Security Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Input Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:00:19 --> Language Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Loader Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Controller Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:00:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:00:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:00:19 --> Session Class Initialized
DEBUG - 2014-02-07 20:00:19 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:00:19 --> Session routines successfully run
DEBUG - 2014-02-07 20:00:19 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:00:19 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:00:19 --> Final output sent to browser
DEBUG - 2014-02-07 20:00:19 --> Total execution time: 0.0250
DEBUG - 2014-02-07 20:00:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:00:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:00:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:00:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:00:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:00:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:00:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:00:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:00:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:00:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:00:28 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:00:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:00:28 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:00:31 --> Config Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:00:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:00:31 --> URI Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Router Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Output Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Security Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Input Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:00:31 --> Language Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Loader Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Controller Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:00:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:00:31 --> Session Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:00:31 --> Session routines successfully run
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:00:31 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:00:31 --> Final output sent to browser
DEBUG - 2014-02-07 20:00:31 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:00:31 --> Config Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:00:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:00:31 --> URI Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Router Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Output Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Security Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Input Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:00:31 --> Language Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Loader Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Controller Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:00:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:00:31 --> Session Class Initialized
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:00:31 --> Session routines successfully run
DEBUG - 2014-02-07 20:00:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:00:31 --> Final output sent to browser
DEBUG - 2014-02-07 20:00:31 --> Total execution time: 0.0100
DEBUG - 2014-02-07 20:00:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:00:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:00:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:00:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:00:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:00:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:00:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:00:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:00:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:00:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:00:32 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-07 20:00:32 --> Final output sent to browser
DEBUG - 2014-02-07 20:00:32 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:01:00 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:00 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:00 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:00 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:00 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:00 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:00 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:00 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:01:00 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:00 --> Total execution time: 0.0120
DEBUG - 2014-02-07 20:01:01 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:01 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:01 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:01 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:01 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:01 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:01 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:01 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:01 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:01 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:01 --> Total execution time: 0.0130
DEBUG - 2014-02-07 20:01:01 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:01 --> Total execution time: 0.0260
DEBUG - 2014-02-07 20:01:01 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:01 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:01 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:01 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:01 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:01 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:01 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:01 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:01 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:01:02 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:02 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:02 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:02 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:02 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:02 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:01:02 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:02 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:01:06 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:06 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:06 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:06 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:06 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:06 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:06 --> Total execution time: 0.0320
DEBUG - 2014-02-07 20:01:06 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:06 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:06 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:06 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:06 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:06 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:06 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:06 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:01:08 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:08 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:08 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:08 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:08 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:08 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:08 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:08 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:08 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:01:08 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:08 --> Total execution time: 0.0230
DEBUG - 2014-02-07 20:01:20 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:20 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:20 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:20 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:20 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:20 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:20 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:20 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:01:20 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:20 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:01:23 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:23 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:23 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:23 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:23 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:23 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:23 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:23 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:23 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:01:23 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:23 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:01:24 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:24 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:24 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:24 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:24 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:24 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:24 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:24 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:24 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-07 20:01:24 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:24 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:01:29 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:29 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:29 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:29 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:29 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:29 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:29 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:29 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:29 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-07 20:01:29 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:29 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:01:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:32 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:01:32 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:32 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:01:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:33 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:33 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:01:33 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:33 --> Total execution time: 0.0320
DEBUG - 2014-02-07 20:01:33 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:33 --> Total execution time: 0.0340
DEBUG - 2014-02-07 20:01:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:01:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:01:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:01:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:01:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:01:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:01:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:01:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:01:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:38 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:01:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:01:38 --> Total execution time: 0.0340
DEBUG - 2014-02-07 20:02:02 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:02 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:02 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:02 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:02 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:02:02 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:02 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:02:03 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:03 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:03 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:03 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:03 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:03 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:03 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:03 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:03 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:03 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:03 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:03 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:03 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:03 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:03 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:03 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:02:03 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:03 --> Total execution time: 0.0240
DEBUG - 2014-02-07 20:02:03 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:03 --> Total execution time: 0.0240
DEBUG - 2014-02-07 20:02:07 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:07 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:07 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:07 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:07 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:07 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:07 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:07 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:07 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:07 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:07 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:07 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:07 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:07 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:02:07 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:07 --> Total execution time: 0.0380
DEBUG - 2014-02-07 20:02:14 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:14 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:14 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:14 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:14 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:02:14 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:14 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:02:14 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:14 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:14 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:14 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:14 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:14 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:14 --> Total execution time: 0.0130
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:14 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:14 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:14 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:14 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:14 --> Total execution time: 0.0300
DEBUG - 2014-02-07 20:02:15 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:15 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:15 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:15 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:15 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:15 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:15 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:15 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:15 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:15 --> Total execution time: 0.1190
DEBUG - 2014-02-07 20:02:19 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:19 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:19 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:19 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:19 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:19 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:19 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:02:19 --> Config Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:02:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:02:19 --> URI Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Router Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Output Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Security Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Input Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:02:19 --> Language Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Loader Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Controller Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:19 --> Session Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:02:19 --> Session routines successfully run
DEBUG - 2014-02-07 20:02:19 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:02:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:02:19 --> Final output sent to browser
DEBUG - 2014-02-07 20:02:19 --> Total execution time: 0.0140
DEBUG - 2014-02-07 20:18:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:34 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:18:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:34 --> Total execution time: 0.0280
DEBUG - 2014-02-07 20:18:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:34 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:18:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:34 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:18:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:34 --> Total execution time: 0.0270
DEBUG - 2014-02-07 20:18:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:34 --> Total execution time: 0.0370
DEBUG - 2014-02-07 20:18:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:39 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:18:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:42 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:18:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:42 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:18:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Total execution time: 0.0160
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:42 --> Total execution time: 0.0250
DEBUG - 2014-02-07 20:18:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:42 --> Total execution time: 0.0310
DEBUG - 2014-02-07 20:18:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:42 --> Total execution time: 0.0340
DEBUG - 2014-02-07 20:18:47 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:47 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:47 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:47 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:47 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:47 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:47 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:47 --> Total execution time: 0.0250
DEBUG - 2014-02-07 20:18:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:48 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:18:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:48 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:18:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:48 --> Total execution time: 0.0305
DEBUG - 2014-02-07 20:18:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:48 --> Total execution time: 0.0300
DEBUG - 2014-02-07 20:18:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:48 --> Total execution time: 0.0545
DEBUG - 2014-02-07 20:18:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:48 --> Total execution time: 0.0185
DEBUG - 2014-02-07 20:18:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:49 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:18:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:49 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:18:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:49 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:49 --> Total execution time: 0.0310
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:49 --> Total execution time: 0.0390
DEBUG - 2014-02-07 20:18:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:49 --> Total execution time: 0.0475
DEBUG - 2014-02-07 20:18:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:49 --> Total execution time: 0.0185
DEBUG - 2014-02-07 20:18:53 --> Config Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:18:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:18:53 --> URI Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Router Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Output Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Security Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Input Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:18:53 --> Language Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Loader Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Controller Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:18:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:18:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:53 --> Session Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:18:53 --> Session routines successfully run
DEBUG - 2014-02-07 20:18:53 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:18:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:18:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:18:53 --> Final output sent to browser
DEBUG - 2014-02-07 20:18:53 --> Total execution time: 0.0250
DEBUG - 2014-02-07 20:19:11 --> Config Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:19:11 --> URI Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Router Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Output Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Security Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Input Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:19:11 --> Language Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Loader Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Controller Class Initialized
DEBUG - 2014-02-07 20:19:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:19:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:19:12 --> Session Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:19:12 --> Session routines successfully run
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:19:12 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:19:12 --> Final output sent to browser
DEBUG - 2014-02-07 20:19:12 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:19:12 --> Config Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:19:12 --> URI Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Router Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Output Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Security Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Input Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:19:12 --> Language Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Loader Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Controller Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:19:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:19:12 --> Session Class Initialized
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:19:12 --> Session routines successfully run
DEBUG - 2014-02-07 20:19:12 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:19:12 --> Final output sent to browser
DEBUG - 2014-02-07 20:19:12 --> Total execution time: 0.0110
DEBUG - 2014-02-07 20:19:14 --> Config Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:19:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:19:14 --> URI Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Router Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Output Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Security Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Input Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:19:14 --> Language Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Loader Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Controller Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:19:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:19:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:19:14 --> Session Class Initialized
DEBUG - 2014-02-07 20:19:14 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:19:14 --> Session routines successfully run
DEBUG - 2014-02-07 20:19:14 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:19:14 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:19:14 --> Final output sent to browser
DEBUG - 2014-02-07 20:19:14 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:19:16 --> Config Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:19:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:19:16 --> URI Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Router Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Output Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Security Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Input Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:19:16 --> Language Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Loader Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Controller Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:19:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:19:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:19:16 --> Session Class Initialized
DEBUG - 2014-02-07 20:19:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:19:16 --> Session routines successfully run
DEBUG - 2014-02-07 20:19:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:19:16 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:19:16 --> Final output sent to browser
DEBUG - 2014-02-07 20:19:16 --> Total execution time: 0.0120
DEBUG - 2014-02-07 20:19:18 --> Config Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:19:18 --> URI Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Router Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Output Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Security Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Input Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:19:18 --> Language Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Loader Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Controller Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:19:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:19:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:19:18 --> Session Class Initialized
DEBUG - 2014-02-07 20:19:18 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:19:18 --> Session routines successfully run
DEBUG - 2014-02-07 20:19:18 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:19:18 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:19:18 --> Final output sent to browser
DEBUG - 2014-02-07 20:19:18 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:19:21 --> Config Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:19:21 --> URI Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Router Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Output Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Security Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Input Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:19:21 --> Language Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Loader Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Controller Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:19:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:19:21 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Model Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:19:21 --> Session Class Initialized
DEBUG - 2014-02-07 20:19:21 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:19:21 --> Session routines successfully run
DEBUG - 2014-02-07 20:19:21 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:19:21 --> Final output sent to browser
DEBUG - 2014-02-07 20:19:21 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:22:09 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:09 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:09 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:09 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:09 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:22:09 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:09 --> Total execution time: 0.0270
DEBUG - 2014-02-07 20:22:09 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:09 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:09 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:09 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:09 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:09 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:09 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:09 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:09 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:22:09 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:09 --> Total execution time: 0.0260
DEBUG - 2014-02-07 20:22:09 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:09 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:09 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:09 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:09 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:22:09 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:09 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:09 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:09 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:09 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:09 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:22:14 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:14 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:14 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:14 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:14 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:14 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:14 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:14 --> Total execution time: 0.0280
DEBUG - 2014-02-07 20:22:16 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:16 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:16 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:16 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:16 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:16 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:22:16 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:16 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:22:16 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:16 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:16 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:16 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:16 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:16 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:16 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:16 --> Total execution time: 0.0100
DEBUG - 2014-02-07 20:22:19 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:19 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:19 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:19 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:19 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:19 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:19 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:19 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:22:19 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:19 --> Total execution time: 0.0160
DEBUG - 2014-02-07 20:22:21 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:21 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:21 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:21 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:21 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:21 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:21 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:21 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:21 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:22:21 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:21 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:22:25 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:25 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:25 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:25 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:25 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:25 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:25 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:25 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:25 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:22:25 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:25 --> Total execution time: 0.0160
DEBUG - 2014-02-07 20:22:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:28 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:22:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:28 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:22:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:28 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:22:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:28 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:22:31 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:31 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:31 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:31 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:31 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:31 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-07 20:22:31 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:31 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:22:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:32 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:22:32 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:32 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:22:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:34 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:22:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:34 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:22:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:34 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:22:34 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:34 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:34 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Total execution time: 0.0385
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:34 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:34 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:34 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:34 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:34 --> Total execution time: 0.0145
DEBUG - 2014-02-07 20:22:35 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:35 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:35 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:35 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:35 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:35 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:39 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:22:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:22:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:22:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:22:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:22:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:22:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:22:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:22:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:22:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:22:39 --> Total execution time: 0.0300
DEBUG - 2014-02-07 20:23:36 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:36 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:36 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:36 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:36 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:36 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:36 --> File loaded: application/views/admin/visitorStats.php
DEBUG - 2014-02-07 20:23:36 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:36 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:23:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:38 --> Total execution time: 0.0285
DEBUG - 2014-02-07 20:23:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:38 --> Total execution time: 0.0260
DEBUG - 2014-02-07 20:23:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:38 --> Total execution time: 0.0320
DEBUG - 2014-02-07 20:23:38 --> Total execution time: 0.0380
DEBUG - 2014-02-07 20:23:40 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:40 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:40 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:40 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:40 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:40 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:40 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:40 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:40 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:23:40 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:40 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:23:41 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:41 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:41 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:41 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:41 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:41 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:41 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:41 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:41 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:41 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:41 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:41 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:41 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:41 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:41 --> Total execution time: 0.0320
DEBUG - 2014-02-07 20:23:41 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:41 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:41 --> Total execution time: 0.0350
DEBUG - 2014-02-07 20:23:41 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:41 --> Total execution time: 0.0290
DEBUG - 2014-02-07 20:23:41 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:41 --> Total execution time: 0.0430
DEBUG - 2014-02-07 20:23:41 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:41 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:41 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:41 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:41 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:41 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:41 --> File loaded: application/views/admin/visitorStats.php
DEBUG - 2014-02-07 20:23:41 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:41 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:23:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:42 --> Total execution time: 0.0295
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:42 --> Total execution time: 0.0300
DEBUG - 2014-02-07 20:23:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:42 --> Total execution time: 0.0315
DEBUG - 2014-02-07 20:23:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Total execution time: 0.0450
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:42 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:23:43 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:43 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:43 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:43 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:43 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:43 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-07 20:23:43 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:43 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:23:43 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:43 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:43 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:43 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:43 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:43 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:43 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:43 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:43 --> Total execution time: 0.0130
DEBUG - 2014-02-07 20:23:45 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:45 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:45 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:45 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:45 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:45 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:45 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:45 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:45 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:23:45 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:45 --> Total execution time: 0.0140
DEBUG - 2014-02-07 20:23:46 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:46 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:46 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:46 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:46 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:46 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:46 --> Total execution time: 0.0230
DEBUG - 2014-02-07 20:23:46 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:46 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:46 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:46 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:46 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:46 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:46 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:23:46 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:46 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:23:47 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:47 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:47 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:47 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:47 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:47 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:47 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:47 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:23:47 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:47 --> Total execution time: 0.0120
DEBUG - 2014-02-07 20:23:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:48 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:23:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:48 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:23:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Total execution time: 0.0120
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:49 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:23:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:49 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:49 --> Total execution time: 0.0230
DEBUG - 2014-02-07 20:23:51 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:51 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:51 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:51 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:51 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:51 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:51 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:23:51 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:51 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:23:51 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:51 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:51 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:51 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:51 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:51 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:51 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:51 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:51 --> Total execution time: 0.0110
DEBUG - 2014-02-07 20:23:52 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:52 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:52 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:52 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:52 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:52 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:52 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:23:52 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:52 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:23:52 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:52 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:52 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:52 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:52 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:52 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:52 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:52 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:52 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:23:53 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:53 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:53 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:53 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:53 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:53 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:53 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:53 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:23:53 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:53 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:23:54 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:54 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:54 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:54 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:54 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:54 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:54 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:54 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:54 --> Total execution time: 0.0310
DEBUG - 2014-02-07 20:23:56 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:56 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:56 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:56 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:56 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:56 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:56 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-07 20:23:56 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:56 --> Total execution time: 0.0160
DEBUG - 2014-02-07 20:23:56 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:56 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:56 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:56 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:56 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:56 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:56 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:56 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:23:56 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:56 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0305
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0345
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0350
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> File loaded: application/views/admin/visitorStats.php
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0320
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0375
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0460
DEBUG - 2014-02-07 20:23:57 --> Config Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> URI Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Router Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Output Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Security Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Input Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:23:57 --> Language Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Loader Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Controller Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Session Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:23:57 --> Session routines successfully run
DEBUG - 2014-02-07 20:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:23:57 --> Model Class Initialized
DEBUG - 2014-02-07 20:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:23:57 --> Final output sent to browser
DEBUG - 2014-02-07 20:23:57 --> Total execution time: 0.0185
DEBUG - 2014-02-07 20:24:00 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:00 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:00 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:00 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:00 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:00 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:00 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:00 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:00 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:00 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:00 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:00 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 20:24:00 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:00 --> Total execution time: 0.0090
DEBUG - 2014-02-07 20:24:02 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:02 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:02 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:02 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:02 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:02 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:02 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:02 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:02 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:02 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:02 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:02 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:02 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:24:02 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:02 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:24:06 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:06 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:06 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:06 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:06 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:06 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:06 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:06 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:06 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:06 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:06 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:06 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 20:24:06 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:06 --> Total execution time: 0.0090
DEBUG - 2014-02-07 20:24:12 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:12 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:12 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:12 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:12 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:12 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:12 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:12 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:12 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:12 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:12 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:12 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:12 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:12 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:12 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:12 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:12 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:24:12 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:12 --> Total execution time: 0.0120
DEBUG - 2014-02-07 20:24:13 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:13 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:13 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:13 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:13 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:13 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:13 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:13 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:13 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:13 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:13 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:13 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:13 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:13 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:13 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:13 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:13 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:13 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:13 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:13 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:13 --> Total execution time: 0.0130
DEBUG - 2014-02-07 20:24:13 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:13 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:24:13 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:13 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:24:17 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:17 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:17 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:17 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:17 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:17 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:17 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:17 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:17 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:17 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:17 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:17 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-07 20:24:17 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:17 --> Total execution time: 0.0110
DEBUG - 2014-02-07 20:24:18 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:18 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:18 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:18 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:18 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:18 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:18 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:18 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:18 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:18 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:18 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:18 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:18 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:18 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:18 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:18 --> Total execution time: 0.0240
DEBUG - 2014-02-07 20:24:18 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:18 --> Total execution time: 0.0420
DEBUG - 2014-02-07 20:24:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:28 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-07 20:24:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:28 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:24:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:28 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:28 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:28 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:28 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:24:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:28 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:24:28 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:28 --> Total execution time: 0.0260
DEBUG - 2014-02-07 20:24:31 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:31 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:31 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:31 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:31 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:31 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-07 20:24:31 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:31 --> Total execution time: 0.0130
DEBUG - 2014-02-07 20:24:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:32 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:32 --> Total execution time: 0.0100
DEBUG - 2014-02-07 20:24:32 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:32 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:32 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:32 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:32 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:32 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:32 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-07 20:24:32 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:32 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:24:33 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:33 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:33 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:33 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:33 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:33 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:33 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:33 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:33 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:33 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:33 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:33 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:24:33 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:33 --> Total execution time: 0.0280
DEBUG - 2014-02-07 20:24:33 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:33 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:33 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:33 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:33 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:33 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:33 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-07 20:24:33 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:33 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:24:36 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:36 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:36 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:36 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:36 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:36 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:36 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-07 20:24:36 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:36 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:24:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:24:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:37 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:24:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:37 --> Total execution time: 0.0195
DEBUG - 2014-02-07 20:24:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:37 --> Total execution time: 0.0135
DEBUG - 2014-02-07 20:24:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:37 --> Total execution time: 0.0170
DEBUG - 2014-02-07 20:24:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:38 --> File loaded: application/views/admin/visitorStats.php
DEBUG - 2014-02-07 20:24:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:38 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:24:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:38 --> Total execution time: 0.0285
DEBUG - 2014-02-07 20:24:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:38 --> Total execution time: 0.0315
DEBUG - 2014-02-07 20:24:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:38 --> Total execution time: 0.0425
DEBUG - 2014-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:38 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:38 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:38 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:38 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:38 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:38 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:38 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:24:38 --> Total execution time: 0.0225
DEBUG - 2014-02-07 20:24:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:39 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:24:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:39 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:24:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:39 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:39 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:39 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:39 --> Total execution time: 0.0330
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:39 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:39 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:39 --> Total execution time: 0.0385
DEBUG - 2014-02-07 20:24:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:39 --> Total execution time: 0.0355
DEBUG - 2014-02-07 20:24:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:39 --> Total execution time: 0.0455
DEBUG - 2014-02-07 20:24:39 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:39 --> Total execution time: 0.0490
DEBUG - 2014-02-07 20:24:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:24:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:24:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:24:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:24:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:24:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:24:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:24:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:42 --> Total execution time: 0.0160
DEBUG - 2014-02-07 20:24:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:24:42 --> Total execution time: 0.0330
DEBUG - 2014-02-07 20:31:35 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:35 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:35 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:35 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:35 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:35 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:35 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:35 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:35 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-07 20:31:35 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:35 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:31:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:31:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:37 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:31:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:37 --> Total execution time: 0.0150
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:37 --> Total execution time: 0.0310
DEBUG - 2014-02-07 20:31:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:37 --> Total execution time: 0.0330
DEBUG - 2014-02-07 20:31:37 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:37 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:37 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:37 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:37 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:37 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:37 --> Total execution time: 0.0185
DEBUG - 2014-02-07 20:31:42 --> Config Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:31:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:31:42 --> URI Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Router Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Output Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Security Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Input Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:31:42 --> Language Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Loader Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Controller Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:31:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:31:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:42 --> Session Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:31:42 --> Session routines successfully run
DEBUG - 2014-02-07 20:31:42 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:31:42 --> Model Class Initialized
DEBUG - 2014-02-07 20:31:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:31:42 --> Final output sent to browser
DEBUG - 2014-02-07 20:31:42 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:32:48 --> Config Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:32:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:32:48 --> URI Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Router Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Output Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Security Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Input Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:32:48 --> Language Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Loader Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Controller Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:32:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:32:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:48 --> Session Class Initialized
DEBUG - 2014-02-07 20:32:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:32:48 --> Session routines successfully run
DEBUG - 2014-02-07 20:32:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:32:48 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:32:48 --> Final output sent to browser
DEBUG - 2014-02-07 20:32:48 --> Total execution time: 0.0240
DEBUG - 2014-02-07 20:32:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:32:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:32:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:32:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:32:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:32:49 --> Config Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:32:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:32:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:32:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:32:49 --> URI Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Router Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Output Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Security Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:32:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:32:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Input Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Language Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Loader Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:32:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Controller Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:32:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:32:49 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Session Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:32:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:32:49 --> Session routines successfully run
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:32:49 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:32:49 --> Total execution time: 0.0260
DEBUG - 2014-02-07 20:32:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:32:49 --> Total execution time: 0.0250
DEBUG - 2014-02-07 20:32:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:32:49 --> Total execution time: 0.0210
DEBUG - 2014-02-07 20:32:49 --> Final output sent to browser
DEBUG - 2014-02-07 20:32:49 --> Total execution time: 0.0410
DEBUG - 2014-02-07 20:32:59 --> Config Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:32:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:32:59 --> URI Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Router Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Output Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Security Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Input Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:32:59 --> Language Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Loader Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Controller Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:32:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:32:59 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:59 --> Session Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:32:59 --> Session routines successfully run
DEBUG - 2014-02-07 20:32:59 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:32:59 --> Model Class Initialized
DEBUG - 2014-02-07 20:32:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:32:59 --> Final output sent to browser
DEBUG - 2014-02-07 20:32:59 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:37:25 --> Config Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:37:25 --> URI Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Router Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Output Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Security Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Input Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:37:25 --> Language Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Loader Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Controller Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:37:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:37:25 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:25 --> Session Class Initialized
DEBUG - 2014-02-07 20:37:25 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:37:25 --> Session routines successfully run
DEBUG - 2014-02-07 20:37:25 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:37:25 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:37:25 --> Final output sent to browser
DEBUG - 2014-02-07 20:37:25 --> Total execution time: 0.0190
DEBUG - 2014-02-07 20:37:26 --> Config Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Config Class Initialized
DEBUG - 2014-02-07 20:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:37:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:37:26 --> URI Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Config Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Router Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:37:26 --> URI Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Router Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Output Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Security Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Output Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Input Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Security Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:37:26 --> Input Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Language Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:37:26 --> Language Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Loader Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Loader Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Controller Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Controller Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:37:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:37:26 --> URI Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Router Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Config Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Output Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Security Class Initialized
DEBUG - 2014-02-07 20:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> URI Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Input Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Session Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:37:26 --> Router Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:37:26 --> Session Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Language Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:37:26 --> Session routines successfully run
DEBUG - 2014-02-07 20:37:26 --> Loader Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:37:26 --> Session routines successfully run
DEBUG - 2014-02-07 20:37:26 --> Output Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Controller Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Security Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Input Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:37:26 --> Language Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Loader Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Controller Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:37:26 --> Session Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Final output sent to browser
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:37:26 --> Session routines successfully run
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:37:26 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Final output sent to browser
DEBUG - 2014-02-07 20:37:26 --> Total execution time: 0.0220
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Session Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:37:26 --> Session routines successfully run
DEBUG - 2014-02-07 20:37:26 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:37:26 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:26 --> Final output sent to browser
DEBUG - 2014-02-07 20:37:26 --> Total execution time: 0.0320
DEBUG - 2014-02-07 20:37:26 --> Final output sent to browser
DEBUG - 2014-02-07 20:37:26 --> Total execution time: 0.0260
DEBUG - 2014-02-07 20:37:31 --> Config Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:37:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:37:31 --> URI Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Router Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Output Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Security Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Input Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:37:31 --> Language Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Loader Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Controller Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:37:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:37:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:31 --> Session Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:37:31 --> Session routines successfully run
DEBUG - 2014-02-07 20:37:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:37:31 --> Model Class Initialized
DEBUG - 2014-02-07 20:37:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:37:31 --> Final output sent to browser
DEBUG - 2014-02-07 20:37:31 --> Total execution time: 0.0340
DEBUG - 2014-02-07 20:40:09 --> Config Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:40:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:40:09 --> URI Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Router Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Output Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Security Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Input Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:40:09 --> Language Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Loader Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Controller Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:40:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:40:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:09 --> Session Class Initialized
DEBUG - 2014-02-07 20:40:09 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:40:09 --> Session routines successfully run
DEBUG - 2014-02-07 20:40:09 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:40:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 20:40:09 --> Final output sent to browser
DEBUG - 2014-02-07 20:40:09 --> Total execution time: 0.0230
DEBUG - 2014-02-07 20:40:10 --> Config Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Config Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:40:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Config Class Initialized
DEBUG - 2014-02-07 20:40:10 --> URI Class Initialized
DEBUG - 2014-02-07 20:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:40:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Router Class Initialized
DEBUG - 2014-02-07 20:40:10 --> URI Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:40:10 --> Router Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Output Class Initialized
DEBUG - 2014-02-07 20:40:10 --> URI Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Config Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Router Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Security Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Output Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Output Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Security Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Input Class Initialized
DEBUG - 2014-02-07 20:40:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:40:10 --> URI Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Input Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:40:10 --> Security Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Router Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Language Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:40:10 --> Input Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Language Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Loader Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:40:10 --> Controller Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Loader Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Language Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:40:10 --> Controller Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:40:10 --> Loader Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:40:10 --> Controller Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Output Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:40:10 --> Security Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Input Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:40:10 --> Session Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Language Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Loader Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Session Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Controller Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:40:10 --> Session Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:40:10 --> Session routines successfully run
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:40:10 --> Session routines successfully run
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:40:10 --> Session routines successfully run
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Final output sent to browser
DEBUG - 2014-02-07 20:40:10 --> Total execution time: 0.0180
DEBUG - 2014-02-07 20:40:10 --> Final output sent to browser
DEBUG - 2014-02-07 20:40:10 --> Total execution time: 0.0200
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Session Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:40:10 --> Session routines successfully run
DEBUG - 2014-02-07 20:40:10 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:40:10 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:10 --> Final output sent to browser
DEBUG - 2014-02-07 20:40:10 --> Total execution time: 0.0240
DEBUG - 2014-02-07 20:40:10 --> Final output sent to browser
DEBUG - 2014-02-07 20:40:10 --> Total execution time: 0.0310
DEBUG - 2014-02-07 20:40:20 --> Config Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Hooks Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Utf8 Class Initialized
DEBUG - 2014-02-07 20:40:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 20:40:20 --> URI Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Router Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Output Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Security Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Input Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 20:40:20 --> Language Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Loader Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Controller Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 20:40:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 20:40:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Database Driver Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:20 --> Session Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Helper loaded: string_helper
DEBUG - 2014-02-07 20:40:20 --> Session routines successfully run
DEBUG - 2014-02-07 20:40:20 --> Helper loaded: url_helper
DEBUG - 2014-02-07 20:40:20 --> Model Class Initialized
DEBUG - 2014-02-07 20:40:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 20:40:20 --> Final output sent to browser
DEBUG - 2014-02-07 20:40:20 --> Total execution time: 0.0410
DEBUG - 2014-02-07 21:09:24 --> Config Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:09:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:09:24 --> URI Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Router Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Output Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Security Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Input Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:09:24 --> Language Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Loader Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Controller Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:09:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:09:24 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:24 --> Session Class Initialized
DEBUG - 2014-02-07 21:09:24 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:09:24 --> Session routines successfully run
DEBUG - 2014-02-07 21:09:24 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:09:24 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 21:09:24 --> Final output sent to browser
DEBUG - 2014-02-07 21:09:24 --> Total execution time: 0.0220
DEBUG - 2014-02-07 21:09:25 --> Config Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Config Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:09:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:09:25 --> URI Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Router Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Output Class Initialized
DEBUG - 2014-02-07 21:09:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:09:25 --> URI Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Config Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Security Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Input Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Router Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:09:25 --> Language Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Output Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Security Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Loader Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Input Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:09:25 --> Controller Class Initialized
DEBUG - 2014-02-07 21:09:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:09:25 --> Language Class Initialized
DEBUG - 2014-02-07 21:09:25 --> URI Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Loader Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Router Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Controller Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:09:25 --> Output Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:09:25 --> Security Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Input Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:09:25 --> Language Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Loader Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:09:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Session Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Controller Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:09:25 --> Session routines successfully run
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:09:25 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:25 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Final output sent to browser
DEBUG - 2014-02-07 21:09:25 --> Total execution time: 0.0190
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:25 --> Session Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Session Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:09:25 --> Session routines successfully run
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:09:25 --> Session routines successfully run
DEBUG - 2014-02-07 21:09:25 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:25 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:25 --> Final output sent to browser
DEBUG - 2014-02-07 21:09:25 --> Total execution time: 0.0220
DEBUG - 2014-02-07 21:09:25 --> Final output sent to browser
DEBUG - 2014-02-07 21:09:25 --> Total execution time: 0.0395
DEBUG - 2014-02-07 21:09:30 --> Config Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Config Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:09:30 --> URI Class Initialized
DEBUG - 2014-02-07 21:09:30 --> URI Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Router Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Router Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Output Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Output Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Security Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Security Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Input Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Input Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:09:30 --> Language Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Language Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Loader Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Loader Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Controller Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Controller Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:30 --> Session Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Session Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:09:30 --> Session routines successfully run
DEBUG - 2014-02-07 21:09:30 --> Session routines successfully run
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Model Class Initialized
DEBUG - 2014-02-07 21:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:09:30 --> Final output sent to browser
DEBUG - 2014-02-07 21:09:30 --> Total execution time: 0.0180
DEBUG - 2014-02-07 21:09:30 --> Final output sent to browser
DEBUG - 2014-02-07 21:09:30 --> Total execution time: 0.0190
DEBUG - 2014-02-07 21:13:37 --> Config Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:13:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:13:37 --> URI Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Router Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Output Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Security Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Input Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:13:37 --> Language Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Loader Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Controller Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:13:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:13:37 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:37 --> Session Class Initialized
DEBUG - 2014-02-07 21:13:37 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:13:37 --> Session routines successfully run
DEBUG - 2014-02-07 21:13:37 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:13:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 21:13:37 --> Final output sent to browser
DEBUG - 2014-02-07 21:13:37 --> Total execution time: 0.0240
DEBUG - 2014-02-07 21:13:39 --> Config Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:13:39 --> URI Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Router Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Output Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Security Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Input Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:13:39 --> Language Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Loader Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Controller Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Config Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Config Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Config Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:13:39 --> Session Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:13:39 --> URI Class Initialized
DEBUG - 2014-02-07 21:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:13:39 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Session routines successfully run
DEBUG - 2014-02-07 21:13:39 --> Router Class Initialized
DEBUG - 2014-02-07 21:13:39 --> URI Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Router Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Output Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Security Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Input Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:13:39 --> Language Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Loader Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Output Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Security Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Input Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:13:39 --> Final output sent to browser
DEBUG - 2014-02-07 21:13:39 --> Total execution time: 0.0140
DEBUG - 2014-02-07 21:13:39 --> Language Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Controller Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Loader Class Initialized
DEBUG - 2014-02-07 21:13:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:13:39 --> Controller Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:13:39 --> URI Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Router Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Session Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Output Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Security Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Session routines successfully run
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Input Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Session Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:13:39 --> Language Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:13:39 --> Session routines successfully run
DEBUG - 2014-02-07 21:13:39 --> Loader Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:13:39 --> Controller Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Session Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:13:39 --> Session routines successfully run
DEBUG - 2014-02-07 21:13:39 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:13:39 --> Final output sent to browser
DEBUG - 2014-02-07 21:13:39 --> Total execution time: 0.0240
DEBUG - 2014-02-07 21:13:39 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:39 --> Final output sent to browser
DEBUG - 2014-02-07 21:13:39 --> Total execution time: 0.0285
DEBUG - 2014-02-07 21:13:39 --> Final output sent to browser
DEBUG - 2014-02-07 21:13:39 --> Total execution time: 0.0390
DEBUG - 2014-02-07 21:13:44 --> Config Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:13:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:13:44 --> URI Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Router Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Output Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Security Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Input Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:13:44 --> Language Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Loader Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Controller Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:13:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:13:44 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:44 --> Session Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:13:44 --> Session routines successfully run
DEBUG - 2014-02-07 21:13:44 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:13:44 --> Model Class Initialized
DEBUG - 2014-02-07 21:13:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:13:44 --> Final output sent to browser
DEBUG - 2014-02-07 21:13:44 --> Total execution time: 0.0320
DEBUG - 2014-02-07 21:14:31 --> Config Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:14:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:14:31 --> URI Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Router Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Output Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Security Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Input Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:14:31 --> Language Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Loader Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Controller Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:14:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:14:31 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:14:31 --> Session Class Initialized
DEBUG - 2014-02-07 21:14:31 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:14:31 --> Session routines successfully run
DEBUG - 2014-02-07 21:14:31 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:14:31 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 21:14:31 --> Final output sent to browser
DEBUG - 2014-02-07 21:14:31 --> Total execution time: 0.0210
DEBUG - 2014-02-07 21:14:38 --> Config Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:14:38 --> URI Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Router Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Output Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Security Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Input Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:14:38 --> Language Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Loader Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Controller Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:14:38 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:14:38 --> Session Class Initialized
DEBUG - 2014-02-07 21:14:38 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:14:38 --> Session routines successfully run
DEBUG - 2014-02-07 21:14:38 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:14:38 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 21:14:38 --> Final output sent to browser
DEBUG - 2014-02-07 21:14:38 --> Total execution time: 0.0120
DEBUG - 2014-02-07 21:14:48 --> Config Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Hooks Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Utf8 Class Initialized
DEBUG - 2014-02-07 21:14:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-07 21:14:48 --> URI Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Router Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Output Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Security Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Input Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-07 21:14:48 --> Language Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Loader Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Controller Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-07 21:14:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-07 21:14:48 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Database Driver Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Model Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-07 21:14:48 --> Session Class Initialized
DEBUG - 2014-02-07 21:14:48 --> Helper loaded: string_helper
DEBUG - 2014-02-07 21:14:48 --> Session routines successfully run
DEBUG - 2014-02-07 21:14:48 --> Helper loaded: url_helper
DEBUG - 2014-02-07 21:14:48 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-07 21:14:48 --> Final output sent to browser
DEBUG - 2014-02-07 21:14:48 --> Total execution time: 0.0200
