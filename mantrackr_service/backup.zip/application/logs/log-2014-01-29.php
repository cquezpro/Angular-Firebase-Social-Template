<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-29 00:03:31 --> Config Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:03:31 --> URI Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Router Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Output Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Security Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Input Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:03:31 --> Language Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Loader Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Controller Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:03:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:03:31 --> Model Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Model Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Model Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:03:31 --> Session Class Initialized
DEBUG - 2014-01-29 00:03:31 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:03:31 --> Session routines successfully run
DEBUG - 2014-01-29 00:03:31 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:03:31 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:03:31 --> Final output sent to browser
DEBUG - 2014-01-29 00:03:31 --> Total execution time: 0.0170
DEBUG - 2014-01-29 00:03:46 --> Config Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:03:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:03:46 --> URI Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Router Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Output Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Security Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Input Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:03:46 --> Language Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Loader Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Controller Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:03:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:03:46 --> Model Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Model Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Model Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:03:46 --> Session Class Initialized
DEBUG - 2014-01-29 00:03:46 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:03:46 --> Session routines successfully run
DEBUG - 2014-01-29 00:03:46 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:03:46 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:03:46 --> Final output sent to browser
DEBUG - 2014-01-29 00:03:46 --> Total execution time: 0.0150
DEBUG - 2014-01-29 00:05:57 --> Config Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:05:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:05:57 --> URI Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Router Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Output Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Security Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Input Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:05:57 --> Language Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Loader Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Controller Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:05:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:05:57 --> Model Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Model Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Model Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:05:57 --> Session Class Initialized
DEBUG - 2014-01-29 00:05:57 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:05:57 --> Session routines successfully run
DEBUG - 2014-01-29 00:05:57 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:05:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:05:57 --> Final output sent to browser
DEBUG - 2014-01-29 00:05:57 --> Total execution time: 0.0130
DEBUG - 2014-01-29 00:06:33 --> Config Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:06:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:06:33 --> URI Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Router Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Output Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Security Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Input Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:06:33 --> Language Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Loader Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Controller Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:06:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:06:33 --> Model Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Model Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Model Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:06:33 --> Session Class Initialized
DEBUG - 2014-01-29 00:06:33 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:06:33 --> Session routines successfully run
DEBUG - 2014-01-29 00:06:33 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:06:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:06:33 --> Final output sent to browser
DEBUG - 2014-01-29 00:06:33 --> Total execution time: 0.0130
DEBUG - 2014-01-29 00:08:58 --> Config Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:08:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:08:58 --> URI Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Router Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Output Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Security Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Input Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:08:58 --> Language Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Loader Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Controller Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:08:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:08:58 --> Model Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Model Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Model Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:08:58 --> Session Class Initialized
DEBUG - 2014-01-29 00:08:58 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:08:58 --> Session routines successfully run
DEBUG - 2014-01-29 00:08:58 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:08:58 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:08:58 --> Final output sent to browser
DEBUG - 2014-01-29 00:08:58 --> Total execution time: 0.0120
DEBUG - 2014-01-29 00:10:51 --> Config Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:10:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:10:51 --> URI Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Router Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Output Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Security Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Input Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:10:51 --> Language Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Loader Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Controller Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:10:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:10:51 --> Model Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Model Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Model Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:10:51 --> Session Class Initialized
DEBUG - 2014-01-29 00:10:51 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:10:51 --> Session routines successfully run
DEBUG - 2014-01-29 00:10:51 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:10:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:10:51 --> Final output sent to browser
DEBUG - 2014-01-29 00:10:51 --> Total execution time: 0.0120
DEBUG - 2014-01-29 00:11:10 --> Config Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:11:10 --> URI Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Router Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Output Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Security Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Input Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:11:10 --> Language Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Loader Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Controller Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:11:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Model Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:11:10 --> Session Class Initialized
DEBUG - 2014-01-29 00:11:10 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:11:10 --> Session routines successfully run
DEBUG - 2014-01-29 00:11:10 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:11:10 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:11:10 --> Final output sent to browser
DEBUG - 2014-01-29 00:11:10 --> Total execution time: 0.0180
DEBUG - 2014-01-29 00:14:09 --> Config Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Hooks Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Utf8 Class Initialized
DEBUG - 2014-01-29 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 00:14:09 --> URI Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Router Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Output Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Security Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Input Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 00:14:09 --> Language Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Loader Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Controller Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 00:14:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Database Driver Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 00:14:09 --> Session Class Initialized
DEBUG - 2014-01-29 00:14:09 --> Helper loaded: string_helper
DEBUG - 2014-01-29 00:14:09 --> Session routines successfully run
DEBUG - 2014-01-29 00:14:09 --> Helper loaded: url_helper
DEBUG - 2014-01-29 00:14:09 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 00:14:09 --> Final output sent to browser
DEBUG - 2014-01-29 00:14:09 --> Total execution time: 0.0120
DEBUG - 2014-01-29 05:30:22 --> Config Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:30:22 --> URI Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Router Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Output Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Security Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Input Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:30:22 --> Language Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Loader Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Controller Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:30:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:30:22 --> Model Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Model Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Model Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:30:22 --> Session Class Initialized
DEBUG - 2014-01-29 05:30:22 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:30:22 --> A session cookie was not found.
DEBUG - 2014-01-29 05:30:22 --> Session routines successfully run
DEBUG - 2014-01-29 05:30:22 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:30:22 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:30:22 --> Final output sent to browser
DEBUG - 2014-01-29 05:30:22 --> Total execution time: 0.0170
DEBUG - 2014-01-29 05:41:21 --> Config Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:41:21 --> URI Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Router Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Output Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Security Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Input Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:41:21 --> Language Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Loader Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Controller Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:41:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:41:21 --> Model Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Model Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Model Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:41:21 --> Session Class Initialized
DEBUG - 2014-01-29 05:41:21 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:41:21 --> Session routines successfully run
DEBUG - 2014-01-29 05:41:21 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:41:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:41:21 --> Final output sent to browser
DEBUG - 2014-01-29 05:41:21 --> Total execution time: 0.0180
DEBUG - 2014-01-29 05:41:50 --> Config Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:41:50 --> URI Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Router Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Output Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Security Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Input Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:41:50 --> Language Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Loader Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Controller Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:41:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:41:50 --> Model Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Model Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Model Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:41:50 --> Session Class Initialized
DEBUG - 2014-01-29 05:41:50 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:41:50 --> Session routines successfully run
DEBUG - 2014-01-29 05:41:50 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:41:50 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:41:50 --> Final output sent to browser
DEBUG - 2014-01-29 05:41:50 --> Total execution time: 0.0140
DEBUG - 2014-01-29 05:52:26 --> Config Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:52:26 --> URI Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Router Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Output Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Security Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Input Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:52:26 --> Language Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Loader Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Controller Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:52:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:52:26 --> Model Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Model Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Model Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:52:26 --> Session Class Initialized
DEBUG - 2014-01-29 05:52:26 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:52:26 --> Session routines successfully run
DEBUG - 2014-01-29 05:52:26 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:52:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:52:26 --> Final output sent to browser
DEBUG - 2014-01-29 05:52:26 --> Total execution time: 0.0220
DEBUG - 2014-01-29 05:54:02 --> Config Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:54:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:54:02 --> URI Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Router Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Output Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Security Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Input Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:54:02 --> Language Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Loader Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Controller Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:54:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:54:02 --> Model Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Model Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Model Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:54:02 --> Session Class Initialized
DEBUG - 2014-01-29 05:54:02 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:54:02 --> Session routines successfully run
DEBUG - 2014-01-29 05:54:02 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:54:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:54:02 --> Final output sent to browser
DEBUG - 2014-01-29 05:54:02 --> Total execution time: 0.0120
DEBUG - 2014-01-29 05:54:19 --> Config Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:54:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:54:19 --> URI Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Router Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Output Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Security Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Input Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:54:19 --> Language Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Loader Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Controller Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:54:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:54:19 --> Model Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Model Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Model Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:54:19 --> Session Class Initialized
DEBUG - 2014-01-29 05:54:19 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:54:19 --> Session routines successfully run
DEBUG - 2014-01-29 05:54:19 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:54:19 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:54:19 --> Final output sent to browser
DEBUG - 2014-01-29 05:54:19 --> Total execution time: 0.0170
DEBUG - 2014-01-29 05:55:20 --> Config Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:55:20 --> URI Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Router Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Output Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Security Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Input Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:55:20 --> Language Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Loader Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Controller Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:55:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:55:20 --> Model Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Model Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Model Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:55:20 --> Session Class Initialized
DEBUG - 2014-01-29 05:55:20 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:55:20 --> Session routines successfully run
DEBUG - 2014-01-29 05:55:20 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:55:20 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:55:20 --> Final output sent to browser
DEBUG - 2014-01-29 05:55:20 --> Total execution time: 0.0120
DEBUG - 2014-01-29 05:57:46 --> Config Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:57:46 --> URI Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Router Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Output Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Security Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Input Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:57:46 --> Language Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Loader Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Controller Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:57:46 --> Model Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Model Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Model Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:57:46 --> Session Class Initialized
DEBUG - 2014-01-29 05:57:46 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:57:46 --> Session routines successfully run
DEBUG - 2014-01-29 05:57:46 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:57:46 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:57:46 --> Final output sent to browser
DEBUG - 2014-01-29 05:57:46 --> Total execution time: 0.0120
DEBUG - 2014-01-29 05:58:29 --> Config Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:58:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:58:29 --> URI Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Router Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Output Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Security Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Input Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:58:29 --> Language Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Loader Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Controller Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:58:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:58:29 --> Model Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Model Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Model Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:58:29 --> Session Class Initialized
DEBUG - 2014-01-29 05:58:29 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:58:29 --> Session routines successfully run
DEBUG - 2014-01-29 05:58:29 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:58:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:58:29 --> Final output sent to browser
DEBUG - 2014-01-29 05:58:29 --> Total execution time: 0.0140
DEBUG - 2014-01-29 05:58:58 --> Config Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:58:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:58:58 --> URI Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Router Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Output Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Security Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Input Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:58:58 --> Language Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Loader Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Controller Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:58:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:58:58 --> Model Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Model Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Model Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:58:58 --> Session Class Initialized
DEBUG - 2014-01-29 05:58:58 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:58:58 --> Session routines successfully run
DEBUG - 2014-01-29 05:58:58 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:58:58 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:58:58 --> Final output sent to browser
DEBUG - 2014-01-29 05:58:58 --> Total execution time: 0.0120
DEBUG - 2014-01-29 05:59:49 --> Config Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Hooks Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Utf8 Class Initialized
DEBUG - 2014-01-29 05:59:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 05:59:49 --> URI Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Router Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Output Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Security Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Input Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 05:59:49 --> Language Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Loader Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Controller Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 05:59:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 05:59:49 --> Model Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Model Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Database Driver Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Model Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 05:59:49 --> Session Class Initialized
DEBUG - 2014-01-29 05:59:49 --> Helper loaded: string_helper
DEBUG - 2014-01-29 05:59:49 --> Session routines successfully run
DEBUG - 2014-01-29 05:59:49 --> Helper loaded: url_helper
DEBUG - 2014-01-29 05:59:49 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 05:59:49 --> Final output sent to browser
DEBUG - 2014-01-29 05:59:49 --> Total execution time: 0.0160
DEBUG - 2014-01-29 06:48:41 --> Config Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Hooks Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Utf8 Class Initialized
DEBUG - 2014-01-29 06:48:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 06:48:41 --> URI Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Router Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Output Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Security Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Input Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 06:48:41 --> Language Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Loader Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Controller Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 06:48:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 06:48:41 --> Model Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Model Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Database Driver Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Model Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 06:48:41 --> Session Class Initialized
DEBUG - 2014-01-29 06:48:41 --> Helper loaded: string_helper
DEBUG - 2014-01-29 06:48:41 --> Session routines successfully run
DEBUG - 2014-01-29 06:48:41 --> Helper loaded: url_helper
DEBUG - 2014-01-29 06:48:41 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 06:48:41 --> Final output sent to browser
DEBUG - 2014-01-29 06:48:41 --> Total execution time: 0.0130
DEBUG - 2014-01-29 06:49:35 --> Config Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Hooks Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Utf8 Class Initialized
DEBUG - 2014-01-29 06:49:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 06:49:35 --> URI Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Router Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Output Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Security Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Input Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 06:49:35 --> Language Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Loader Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Controller Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 06:49:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 06:49:35 --> Model Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Model Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Database Driver Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Model Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 06:49:35 --> Session Class Initialized
DEBUG - 2014-01-29 06:49:35 --> Helper loaded: string_helper
DEBUG - 2014-01-29 06:49:35 --> Session routines successfully run
DEBUG - 2014-01-29 06:49:35 --> Helper loaded: url_helper
DEBUG - 2014-01-29 06:49:35 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 06:49:35 --> Final output sent to browser
DEBUG - 2014-01-29 06:49:35 --> Total execution time: 0.0170
DEBUG - 2014-01-29 06:50:25 --> Config Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Hooks Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Utf8 Class Initialized
DEBUG - 2014-01-29 06:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 06:50:25 --> URI Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Router Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Output Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Security Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Input Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 06:50:25 --> Language Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Loader Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Controller Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 06:50:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 06:50:25 --> Model Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Model Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Database Driver Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Model Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 06:50:25 --> Session Class Initialized
DEBUG - 2014-01-29 06:50:25 --> Helper loaded: string_helper
DEBUG - 2014-01-29 06:50:25 --> Session routines successfully run
DEBUG - 2014-01-29 06:50:25 --> Helper loaded: url_helper
DEBUG - 2014-01-29 06:50:25 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 06:50:25 --> Final output sent to browser
DEBUG - 2014-01-29 06:50:25 --> Total execution time: 0.0200
DEBUG - 2014-01-29 07:19:26 --> Config Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:19:26 --> URI Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Router Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Output Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Security Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Input Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:19:26 --> Language Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Loader Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Controller Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:19:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:19:26 --> Model Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Model Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Model Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:19:26 --> Session Class Initialized
DEBUG - 2014-01-29 07:19:26 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:19:26 --> Session routines successfully run
DEBUG - 2014-01-29 07:19:26 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:19:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:19:26 --> Final output sent to browser
DEBUG - 2014-01-29 07:19:26 --> Total execution time: 0.0210
DEBUG - 2014-01-29 07:20:21 --> Config Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:20:21 --> URI Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Router Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Output Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Security Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Input Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:20:21 --> Language Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Loader Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Controller Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:20:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:20:21 --> Model Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Model Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Model Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:20:21 --> Session Class Initialized
DEBUG - 2014-01-29 07:20:21 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:20:21 --> Session routines successfully run
DEBUG - 2014-01-29 07:20:21 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:20:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:20:21 --> Final output sent to browser
DEBUG - 2014-01-29 07:20:21 --> Total execution time: 0.0120
DEBUG - 2014-01-29 07:21:45 --> Config Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:21:45 --> URI Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Router Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Output Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Security Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Input Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:21:45 --> Language Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Loader Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Controller Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:21:45 --> Model Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Model Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Model Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:21:45 --> Session Class Initialized
DEBUG - 2014-01-29 07:21:45 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:21:45 --> Session routines successfully run
DEBUG - 2014-01-29 07:21:45 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:21:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:21:45 --> Final output sent to browser
DEBUG - 2014-01-29 07:21:45 --> Total execution time: 0.0110
DEBUG - 2014-01-29 07:21:57 --> Config Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:21:57 --> URI Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Router Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Output Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Security Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Input Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:21:57 --> Language Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Loader Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Controller Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:21:57 --> Model Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Model Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Model Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:21:57 --> Session Class Initialized
DEBUG - 2014-01-29 07:21:57 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:21:57 --> Session routines successfully run
DEBUG - 2014-01-29 07:21:57 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:21:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:21:57 --> Final output sent to browser
DEBUG - 2014-01-29 07:21:57 --> Total execution time: 0.0110
DEBUG - 2014-01-29 07:22:30 --> Config Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:22:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:22:30 --> URI Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Router Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Output Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Security Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Input Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:22:30 --> Language Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Loader Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Controller Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:22:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:22:30 --> Model Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Model Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Model Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:22:30 --> Session Class Initialized
DEBUG - 2014-01-29 07:22:30 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:22:30 --> Session routines successfully run
DEBUG - 2014-01-29 07:22:30 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:22:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:22:30 --> Final output sent to browser
DEBUG - 2014-01-29 07:22:30 --> Total execution time: 0.0110
DEBUG - 2014-01-29 07:23:39 --> Config Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:23:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:23:39 --> URI Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Router Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Output Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Security Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Input Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:23:39 --> Language Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Loader Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Controller Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:23:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:23:39 --> Model Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Model Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Model Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:23:39 --> Session Class Initialized
DEBUG - 2014-01-29 07:23:39 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:23:39 --> Session routines successfully run
DEBUG - 2014-01-29 07:23:39 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:23:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:23:39 --> Final output sent to browser
DEBUG - 2014-01-29 07:23:39 --> Total execution time: 0.0110
DEBUG - 2014-01-29 07:23:56 --> Config Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:23:56 --> URI Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Router Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Output Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Security Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Input Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:23:56 --> Language Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Loader Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Controller Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:23:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:23:56 --> Model Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Model Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Model Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:23:56 --> Session Class Initialized
DEBUG - 2014-01-29 07:23:56 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:23:56 --> Session routines successfully run
DEBUG - 2014-01-29 07:23:56 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:23:56 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:23:56 --> Final output sent to browser
DEBUG - 2014-01-29 07:23:56 --> Total execution time: 0.0120
DEBUG - 2014-01-29 07:24:28 --> Config Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:24:28 --> URI Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Router Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Output Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Security Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Input Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:24:28 --> Language Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Loader Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Controller Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:24:28 --> Model Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Model Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Model Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:24:28 --> Session Class Initialized
DEBUG - 2014-01-29 07:24:28 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:24:28 --> Session routines successfully run
DEBUG - 2014-01-29 07:24:28 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:24:28 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:24:28 --> Final output sent to browser
DEBUG - 2014-01-29 07:24:28 --> Total execution time: 0.0170
DEBUG - 2014-01-29 07:28:14 --> Config Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:28:14 --> URI Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Router Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Output Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Security Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Input Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:28:14 --> Language Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Loader Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Controller Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:28:14 --> Model Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Model Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Model Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:28:14 --> Session Class Initialized
DEBUG - 2014-01-29 07:28:14 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:28:14 --> Session routines successfully run
DEBUG - 2014-01-29 07:28:14 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:28:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:28:14 --> Final output sent to browser
DEBUG - 2014-01-29 07:28:14 --> Total execution time: 0.0190
DEBUG - 2014-01-29 07:30:48 --> Config Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:30:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:30:48 --> URI Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Router Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Output Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Security Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Input Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:30:48 --> Language Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Loader Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Controller Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:30:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:30:48 --> Model Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Model Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Model Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:30:48 --> Session Class Initialized
DEBUG - 2014-01-29 07:30:48 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:30:48 --> Session routines successfully run
DEBUG - 2014-01-29 07:30:48 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:30:48 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:30:48 --> Final output sent to browser
DEBUG - 2014-01-29 07:30:48 --> Total execution time: 0.0180
DEBUG - 2014-01-29 07:31:25 --> Config Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:31:25 --> URI Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Router Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Output Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Security Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Input Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:31:25 --> Language Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Loader Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Controller Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:31:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:31:25 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:31:25 --> Session Class Initialized
DEBUG - 2014-01-29 07:31:25 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:31:25 --> Session routines successfully run
DEBUG - 2014-01-29 07:31:25 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:31:25 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:31:25 --> Final output sent to browser
DEBUG - 2014-01-29 07:31:25 --> Total execution time: 0.0120
DEBUG - 2014-01-29 07:31:31 --> Config Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:31:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:31:31 --> URI Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Router Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Output Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Security Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Input Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:31:31 --> Language Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Loader Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Controller Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:31:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:31:31 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:31:31 --> Session Class Initialized
DEBUG - 2014-01-29 07:31:31 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:31:31 --> Session routines successfully run
DEBUG - 2014-01-29 07:31:31 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:31:31 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:31:31 --> Final output sent to browser
DEBUG - 2014-01-29 07:31:31 --> Total execution time: 0.0190
DEBUG - 2014-01-29 07:31:45 --> Config Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:31:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:31:45 --> URI Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Router Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Output Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Security Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Input Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:31:45 --> Language Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Loader Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Controller Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:31:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:31:45 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:31:45 --> Session Class Initialized
DEBUG - 2014-01-29 07:31:45 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:31:45 --> Session routines successfully run
DEBUG - 2014-01-29 07:31:45 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:31:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:31:45 --> Final output sent to browser
DEBUG - 2014-01-29 07:31:45 --> Total execution time: 0.0160
DEBUG - 2014-01-29 07:31:50 --> Config Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Hooks Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Utf8 Class Initialized
DEBUG - 2014-01-29 07:31:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 07:31:50 --> URI Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Router Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Output Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Security Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Input Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 07:31:50 --> Language Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Loader Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Controller Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 07:31:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 07:31:50 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Database Driver Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Model Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 07:31:50 --> Session Class Initialized
DEBUG - 2014-01-29 07:31:50 --> Helper loaded: string_helper
DEBUG - 2014-01-29 07:31:50 --> Session routines successfully run
DEBUG - 2014-01-29 07:31:50 --> Helper loaded: url_helper
DEBUG - 2014-01-29 07:31:50 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 07:31:50 --> Final output sent to browser
DEBUG - 2014-01-29 07:31:50 --> Total execution time: 0.0200
DEBUG - 2014-01-29 14:18:21 --> Config Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:18:21 --> URI Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Router Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Output Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Security Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Input Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:18:21 --> Language Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Loader Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Controller Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:18:21 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:18:21 --> Session Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:18:21 --> A session cookie was not found.
DEBUG - 2014-01-29 14:18:21 --> Session routines successfully run
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:18:21 --> Config Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:18:21 --> URI Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Router Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Output Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Security Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Input Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:18:21 --> Language Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Loader Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Controller Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:18:21 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:18:21 --> Session Class Initialized
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:18:21 --> Session routines successfully run
DEBUG - 2014-01-29 14:18:21 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:18:21 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-29 14:18:21 --> Final output sent to browser
DEBUG - 2014-01-29 14:18:21 --> Total execution time: 0.0100
DEBUG - 2014-01-29 14:18:27 --> Config Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:18:27 --> URI Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Router Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Output Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Security Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Input Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:18:27 --> Language Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Loader Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Controller Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:18:27 --> Session Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:18:27 --> Session routines successfully run
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:18:27 --> Config Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:18:27 --> URI Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Router Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Output Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Security Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Input Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:18:27 --> Language Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Loader Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Controller Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:18:27 --> Session Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:18:27 --> Session routines successfully run
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:18:27 --> Config Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:18:27 --> URI Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Router Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Output Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Security Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Input Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:18:27 --> Language Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Loader Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Controller Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Model Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:18:27 --> Session Class Initialized
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:18:27 --> Session routines successfully run
DEBUG - 2014-01-29 14:18:27 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:18:27 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 14:18:27 --> Final output sent to browser
DEBUG - 2014-01-29 14:18:27 --> Total execution time: 0.0100
DEBUG - 2014-01-29 14:26:47 --> Config Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:26:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:26:47 --> URI Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Router Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Output Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Security Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Input Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:26:47 --> Language Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Loader Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Controller Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:26:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:26:47 --> Model Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Model Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Model Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:26:47 --> Session Class Initialized
DEBUG - 2014-01-29 14:26:47 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:26:47 --> Session routines successfully run
DEBUG - 2014-01-29 14:26:47 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:26:47 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 14:26:47 --> Final output sent to browser
DEBUG - 2014-01-29 14:26:47 --> Total execution time: 0.0230
DEBUG - 2014-01-29 14:29:37 --> Config Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:29:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:29:37 --> URI Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Router Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Output Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Security Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Input Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:29:37 --> Language Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Loader Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Controller Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:29:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:29:37 --> Model Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Model Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Model Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:29:37 --> Session Class Initialized
DEBUG - 2014-01-29 14:29:37 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:29:37 --> Session routines successfully run
DEBUG - 2014-01-29 14:29:37 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:29:37 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 14:29:37 --> Final output sent to browser
DEBUG - 2014-01-29 14:29:37 --> Total execution time: 0.0220
DEBUG - 2014-01-29 14:29:39 --> Config Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Hooks Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Utf8 Class Initialized
DEBUG - 2014-01-29 14:29:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 14:29:39 --> URI Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Router Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Output Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Security Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Input Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 14:29:39 --> Language Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Loader Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Controller Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 14:29:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 14:29:39 --> Model Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Model Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Database Driver Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Model Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 14:29:39 --> Session Class Initialized
DEBUG - 2014-01-29 14:29:39 --> Helper loaded: string_helper
DEBUG - 2014-01-29 14:29:39 --> Session routines successfully run
DEBUG - 2014-01-29 14:29:39 --> Helper loaded: url_helper
DEBUG - 2014-01-29 14:29:39 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 14:29:39 --> Final output sent to browser
DEBUG - 2014-01-29 14:29:39 --> Total execution time: 0.0190
DEBUG - 2014-01-29 16:18:13 --> Config Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:18:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:18:13 --> URI Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Router Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Output Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Security Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Input Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:18:13 --> Language Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Loader Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Controller Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:18:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:18:13 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:18:13 --> Session Class Initialized
DEBUG - 2014-01-29 16:18:13 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:18:13 --> Session routines successfully run
DEBUG - 2014-01-29 16:18:13 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:18:13 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:18:13 --> Final output sent to browser
DEBUG - 2014-01-29 16:18:13 --> Total execution time: 0.0190
DEBUG - 2014-01-29 16:18:17 --> Config Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:18:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:18:17 --> URI Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Router Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Output Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Security Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Input Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:18:17 --> Language Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Loader Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Controller Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:18:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:18:17 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:18:17 --> Session Class Initialized
DEBUG - 2014-01-29 16:18:17 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:18:17 --> Session routines successfully run
DEBUG - 2014-01-29 16:18:17 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:18:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:18:17 --> Final output sent to browser
DEBUG - 2014-01-29 16:18:17 --> Total execution time: 0.0200
DEBUG - 2014-01-29 16:18:19 --> Config Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:18:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:18:19 --> URI Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Router Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Output Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Security Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Input Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:18:19 --> Language Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Loader Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Controller Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:18:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:18:19 --> Session Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:18:19 --> Session routines successfully run
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:18:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:18:19 --> Final output sent to browser
DEBUG - 2014-01-29 16:18:19 --> Total execution time: 0.0150
DEBUG - 2014-01-29 16:18:19 --> Config Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:18:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:18:19 --> URI Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Router Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Output Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Security Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Input Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:18:19 --> Language Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Loader Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Controller Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:18:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:18:19 --> Session Class Initialized
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:18:19 --> Session routines successfully run
DEBUG - 2014-01-29 16:18:19 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:18:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:18:19 --> Final output sent to browser
DEBUG - 2014-01-29 16:18:19 --> Total execution time: 0.0190
DEBUG - 2014-01-29 16:19:56 --> Config Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:19:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:19:56 --> URI Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Router Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Output Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Security Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Input Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:19:56 --> Language Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Loader Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Controller Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:19:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:19:56 --> Model Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Model Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Model Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:19:56 --> Session Class Initialized
DEBUG - 2014-01-29 16:19:56 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:19:56 --> Session routines successfully run
DEBUG - 2014-01-29 16:19:56 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:19:56 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:19:56 --> Final output sent to browser
DEBUG - 2014-01-29 16:19:56 --> Total execution time: 0.0220
DEBUG - 2014-01-29 16:22:35 --> Config Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:22:35 --> URI Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Router Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Output Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Security Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Input Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:22:35 --> Language Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Loader Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Controller Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:22:35 --> Model Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Model Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Model Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:22:35 --> Session Class Initialized
DEBUG - 2014-01-29 16:22:35 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:22:35 --> Session routines successfully run
DEBUG - 2014-01-29 16:22:35 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:22:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:22:35 --> Final output sent to browser
DEBUG - 2014-01-29 16:22:35 --> Total execution time: 0.0190
DEBUG - 2014-01-29 16:33:32 --> Config Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:33:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:33:32 --> URI Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Router Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Output Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Security Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Input Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:33:32 --> Language Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Loader Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Controller Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:33:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:33:32 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:33:32 --> Session Class Initialized
DEBUG - 2014-01-29 16:33:32 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:33:32 --> Session routines successfully run
DEBUG - 2014-01-29 16:33:32 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:33:32 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:33:32 --> Final output sent to browser
DEBUG - 2014-01-29 16:33:32 --> Total execution time: 0.0130
DEBUG - 2014-01-29 16:33:38 --> Config Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:33:38 --> URI Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Router Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Output Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Security Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Input Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:33:38 --> Language Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Loader Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Controller Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:33:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:33:38 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:33:38 --> Session Class Initialized
DEBUG - 2014-01-29 16:33:38 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:33:38 --> Session routines successfully run
DEBUG - 2014-01-29 16:33:38 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:33:38 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:33:38 --> Final output sent to browser
DEBUG - 2014-01-29 16:33:38 --> Total execution time: 0.0130
DEBUG - 2014-01-29 16:33:50 --> Config Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:33:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:33:50 --> URI Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Router Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Output Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Security Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Input Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:33:50 --> Language Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Loader Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Controller Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:33:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:33:50 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Model Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:33:50 --> Session Class Initialized
DEBUG - 2014-01-29 16:33:50 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:33:50 --> Session routines successfully run
DEBUG - 2014-01-29 16:33:50 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:33:50 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:33:50 --> Final output sent to browser
DEBUG - 2014-01-29 16:33:50 --> Total execution time: 0.0130
DEBUG - 2014-01-29 16:35:14 --> Config Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:35:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:35:14 --> URI Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Router Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Output Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Security Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Input Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:35:14 --> Language Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Loader Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Controller Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:35:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:35:14 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:35:14 --> Session Class Initialized
DEBUG - 2014-01-29 16:35:14 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:35:14 --> Session routines successfully run
DEBUG - 2014-01-29 16:35:14 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:35:14 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:35:14 --> Final output sent to browser
DEBUG - 2014-01-29 16:35:14 --> Total execution time: 0.0150
DEBUG - 2014-01-29 16:35:18 --> Config Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:35:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:35:18 --> URI Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Router Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Output Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Security Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Input Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:35:18 --> Language Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Loader Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Controller Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:35:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:35:18 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:35:18 --> Session Class Initialized
DEBUG - 2014-01-29 16:35:18 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:35:18 --> Session routines successfully run
DEBUG - 2014-01-29 16:35:18 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:35:18 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:35:18 --> Final output sent to browser
DEBUG - 2014-01-29 16:35:18 --> Total execution time: 0.0210
DEBUG - 2014-01-29 16:35:19 --> Config Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:35:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:35:19 --> URI Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Router Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Output Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Security Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Input Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:35:19 --> Language Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Loader Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Controller Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:35:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:35:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:35:19 --> Session Class Initialized
DEBUG - 2014-01-29 16:35:19 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:35:19 --> Session routines successfully run
DEBUG - 2014-01-29 16:35:19 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:35:19 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:35:19 --> Final output sent to browser
DEBUG - 2014-01-29 16:35:19 --> Total execution time: 0.0160
DEBUG - 2014-01-29 16:38:10 --> Config Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:38:10 --> URI Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Router Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Output Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Security Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Input Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:38:10 --> Language Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Loader Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Controller Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:38:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:38:10 --> Model Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Model Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Model Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:38:10 --> Session Class Initialized
DEBUG - 2014-01-29 16:38:10 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:38:10 --> Session routines successfully run
DEBUG - 2014-01-29 16:38:10 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:38:10 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:38:10 --> Final output sent to browser
DEBUG - 2014-01-29 16:38:10 --> Total execution time: 0.0200
DEBUG - 2014-01-29 16:38:56 --> Config Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:38:56 --> URI Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Router Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Output Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Security Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Input Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:38:56 --> Language Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Loader Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Controller Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:38:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:38:56 --> Model Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Model Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Model Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:38:56 --> Session Class Initialized
DEBUG - 2014-01-29 16:38:56 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:38:56 --> Session routines successfully run
DEBUG - 2014-01-29 16:38:56 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:38:56 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:38:56 --> Final output sent to browser
DEBUG - 2014-01-29 16:38:56 --> Total execution time: 0.0210
DEBUG - 2014-01-29 16:39:08 --> Config Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:39:08 --> URI Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Router Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Output Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Security Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Input Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:39:08 --> Language Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Loader Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Controller Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:39:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:39:08 --> Model Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Model Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Model Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:39:08 --> Session Class Initialized
DEBUG - 2014-01-29 16:39:08 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:39:08 --> Session routines successfully run
DEBUG - 2014-01-29 16:39:08 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:39:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:39:08 --> Final output sent to browser
DEBUG - 2014-01-29 16:39:08 --> Total execution time: 0.0120
DEBUG - 2014-01-29 16:39:38 --> Config Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:39:38 --> URI Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Router Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Output Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Security Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Input Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:39:38 --> Language Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Loader Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Controller Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:39:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:39:38 --> Model Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Model Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Model Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:39:38 --> Session Class Initialized
DEBUG - 2014-01-29 16:39:38 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:39:38 --> Session routines successfully run
DEBUG - 2014-01-29 16:39:38 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:39:38 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:39:38 --> Final output sent to browser
DEBUG - 2014-01-29 16:39:38 --> Total execution time: 0.0180
DEBUG - 2014-01-29 16:40:13 --> Config Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:40:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:40:13 --> URI Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Router Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Output Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Security Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Input Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:40:13 --> Language Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Loader Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Controller Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:40:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:40:13 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:40:13 --> Session Class Initialized
DEBUG - 2014-01-29 16:40:13 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:40:13 --> Session routines successfully run
DEBUG - 2014-01-29 16:40:13 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:40:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:40:13 --> Final output sent to browser
DEBUG - 2014-01-29 16:40:13 --> Total execution time: 0.0120
DEBUG - 2014-01-29 16:40:18 --> Config Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:40:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:40:18 --> URI Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Router Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Output Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Security Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Input Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:40:18 --> Language Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Loader Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Controller Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:40:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:40:18 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:40:18 --> Session Class Initialized
DEBUG - 2014-01-29 16:40:18 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:40:18 --> Session routines successfully run
DEBUG - 2014-01-29 16:40:18 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:40:18 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:40:18 --> Final output sent to browser
DEBUG - 2014-01-29 16:40:18 --> Total execution time: 0.0130
DEBUG - 2014-01-29 16:40:39 --> Config Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:40:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:40:39 --> URI Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Router Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Output Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Security Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Input Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:40:39 --> Language Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Loader Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Controller Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:40:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:40:39 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:40:39 --> Session Class Initialized
DEBUG - 2014-01-29 16:40:39 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:40:39 --> Session routines successfully run
DEBUG - 2014-01-29 16:40:39 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:40:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:40:39 --> Final output sent to browser
DEBUG - 2014-01-29 16:40:39 --> Total execution time: 0.0120
DEBUG - 2014-01-29 16:40:57 --> Config Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:40:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:40:57 --> URI Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Router Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Output Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Security Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Input Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:40:57 --> Language Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Loader Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Controller Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:40:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:40:57 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Model Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:40:57 --> Session Class Initialized
DEBUG - 2014-01-29 16:40:57 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:40:57 --> Session routines successfully run
DEBUG - 2014-01-29 16:40:57 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:40:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:40:57 --> Final output sent to browser
DEBUG - 2014-01-29 16:40:57 --> Total execution time: 0.0120
DEBUG - 2014-01-29 16:41:03 --> Config Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:41:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:41:03 --> URI Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Router Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Output Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Security Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Input Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:41:03 --> Language Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Loader Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Controller Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:41:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:41:03 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:41:03 --> Session Class Initialized
DEBUG - 2014-01-29 16:41:03 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:41:03 --> Session routines successfully run
DEBUG - 2014-01-29 16:41:03 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:41:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:41:03 --> Final output sent to browser
DEBUG - 2014-01-29 16:41:03 --> Total execution time: 0.0210
DEBUG - 2014-01-29 16:41:11 --> Config Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:41:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:41:11 --> URI Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Router Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Output Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Security Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Input Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:41:11 --> Language Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Loader Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Controller Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:41:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:41:11 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:41:11 --> Session Class Initialized
DEBUG - 2014-01-29 16:41:11 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:41:11 --> Session routines successfully run
DEBUG - 2014-01-29 16:41:11 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:41:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:41:11 --> Final output sent to browser
DEBUG - 2014-01-29 16:41:11 --> Total execution time: 0.0160
DEBUG - 2014-01-29 16:41:17 --> Config Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:41:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:41:17 --> URI Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Router Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Output Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Security Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Input Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:41:17 --> Language Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Loader Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Controller Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:41:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:41:17 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:41:17 --> Session Class Initialized
DEBUG - 2014-01-29 16:41:17 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:41:17 --> Session routines successfully run
DEBUG - 2014-01-29 16:41:17 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:41:17 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:41:17 --> Final output sent to browser
DEBUG - 2014-01-29 16:41:17 --> Total execution time: 0.0170
DEBUG - 2014-01-29 16:41:19 --> Config Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:41:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:41:19 --> URI Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Router Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Output Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Security Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Input Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:41:19 --> Language Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Loader Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Controller Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:41:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:41:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Model Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:41:19 --> Session Class Initialized
DEBUG - 2014-01-29 16:41:19 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:41:19 --> Session routines successfully run
DEBUG - 2014-01-29 16:41:19 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:41:19 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:41:19 --> Final output sent to browser
DEBUG - 2014-01-29 16:41:19 --> Total execution time: 0.0140
DEBUG - 2014-01-29 16:43:32 --> Config Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:43:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:43:32 --> URI Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Router Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Output Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Security Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Input Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:43:32 --> Language Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Loader Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Controller Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:43:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:43:32 --> Model Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Model Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Model Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:43:32 --> Session Class Initialized
DEBUG - 2014-01-29 16:43:32 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:43:32 --> Session routines successfully run
DEBUG - 2014-01-29 16:43:32 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:43:32 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:43:32 --> Final output sent to browser
DEBUG - 2014-01-29 16:43:32 --> Total execution time: 0.0150
DEBUG - 2014-01-29 16:43:46 --> Config Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:43:46 --> URI Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Router Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Output Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Security Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Input Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:43:46 --> Language Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Loader Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Controller Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:43:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:43:46 --> Model Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Model Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Model Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:43:46 --> Session Class Initialized
DEBUG - 2014-01-29 16:43:46 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:43:46 --> Session routines successfully run
DEBUG - 2014-01-29 16:43:46 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:43:46 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:43:46 --> Final output sent to browser
DEBUG - 2014-01-29 16:43:46 --> Total execution time: 0.0200
DEBUG - 2014-01-29 16:44:02 --> Config Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:44:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:44:02 --> URI Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Router Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Output Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Security Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Input Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:44:02 --> Language Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Loader Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Controller Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:44:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:44:02 --> Model Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Model Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Model Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:44:02 --> Session Class Initialized
DEBUG - 2014-01-29 16:44:02 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:44:02 --> Session routines successfully run
DEBUG - 2014-01-29 16:44:02 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:44:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 16:44:02 --> Final output sent to browser
DEBUG - 2014-01-29 16:44:02 --> Total execution time: 0.0200
DEBUG - 2014-01-29 16:47:26 --> Config Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Hooks Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Utf8 Class Initialized
DEBUG - 2014-01-29 16:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 16:47:26 --> URI Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Router Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Output Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Security Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Input Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 16:47:26 --> Language Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Loader Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Controller Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 16:47:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 16:47:26 --> Model Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Model Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Database Driver Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Model Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 16:47:26 --> Session Class Initialized
DEBUG - 2014-01-29 16:47:26 --> Helper loaded: string_helper
DEBUG - 2014-01-29 16:47:26 --> Session routines successfully run
DEBUG - 2014-01-29 16:47:26 --> Helper loaded: url_helper
DEBUG - 2014-01-29 16:47:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 16:47:26 --> Final output sent to browser
DEBUG - 2014-01-29 16:47:26 --> Total execution time: 0.0210
DEBUG - 2014-01-29 17:12:51 --> Config Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:12:51 --> URI Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Router Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Output Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Security Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Input Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:12:51 --> Language Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Loader Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Controller Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:12:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:12:51 --> Model Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Model Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Model Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:12:51 --> Session Class Initialized
DEBUG - 2014-01-29 17:12:51 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:12:51 --> Session routines successfully run
DEBUG - 2014-01-29 17:12:51 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:12:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:12:51 --> Final output sent to browser
DEBUG - 2014-01-29 17:12:51 --> Total execution time: 0.0190
DEBUG - 2014-01-29 17:13:46 --> Config Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:13:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:13:46 --> URI Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Router Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Output Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Security Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Input Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:13:46 --> Language Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Loader Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Controller Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:13:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:13:46 --> Model Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Model Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Model Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:13:46 --> Session Class Initialized
DEBUG - 2014-01-29 17:13:46 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:13:46 --> Session routines successfully run
DEBUG - 2014-01-29 17:13:46 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:13:46 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:13:46 --> Final output sent to browser
DEBUG - 2014-01-29 17:13:46 --> Total execution time: 0.0160
DEBUG - 2014-01-29 17:13:47 --> Config Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:13:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:13:47 --> URI Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Router Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Output Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Security Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Input Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:13:47 --> Language Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Loader Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Controller Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:13:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:13:47 --> Model Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Model Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Model Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:13:47 --> Session Class Initialized
DEBUG - 2014-01-29 17:13:47 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:13:47 --> Session routines successfully run
DEBUG - 2014-01-29 17:13:47 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:13:47 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:13:47 --> Final output sent to browser
DEBUG - 2014-01-29 17:13:47 --> Total execution time: 0.0190
DEBUG - 2014-01-29 17:18:17 --> Config Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:18:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:18:17 --> URI Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Router Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Output Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Security Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Input Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:18:17 --> Language Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Loader Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Controller Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:18:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:18:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:18:17 --> Session Class Initialized
DEBUG - 2014-01-29 17:18:17 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:18:17 --> Session routines successfully run
DEBUG - 2014-01-29 17:18:17 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:18:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:18:17 --> Final output sent to browser
DEBUG - 2014-01-29 17:18:17 --> Total execution time: 0.0220
DEBUG - 2014-01-29 17:18:47 --> Config Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:18:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:18:47 --> URI Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Router Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Output Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Security Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Input Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:18:47 --> Language Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Loader Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Controller Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:18:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:18:47 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:18:47 --> Session Class Initialized
DEBUG - 2014-01-29 17:18:47 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:18:47 --> Session routines successfully run
DEBUG - 2014-01-29 17:18:47 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:18:47 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:18:47 --> Final output sent to browser
DEBUG - 2014-01-29 17:18:47 --> Total execution time: 0.0130
DEBUG - 2014-01-29 17:18:51 --> Config Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:18:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:18:51 --> URI Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Router Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Output Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Security Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Input Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:18:51 --> Language Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Loader Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Controller Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:18:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:18:51 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:18:51 --> Session Class Initialized
DEBUG - 2014-01-29 17:18:51 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:18:51 --> Session routines successfully run
DEBUG - 2014-01-29 17:18:51 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:18:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:18:51 --> Final output sent to browser
DEBUG - 2014-01-29 17:18:51 --> Total execution time: 0.0130
DEBUG - 2014-01-29 17:18:52 --> Config Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:18:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:18:52 --> URI Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Router Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Output Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Security Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Input Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:18:52 --> Language Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Loader Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Controller Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:18:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:18:52 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Model Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:18:52 --> Session Class Initialized
DEBUG - 2014-01-29 17:18:52 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:18:52 --> Session routines successfully run
DEBUG - 2014-01-29 17:18:52 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:18:52 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:18:52 --> Final output sent to browser
DEBUG - 2014-01-29 17:18:52 --> Total execution time: 0.0180
DEBUG - 2014-01-29 17:20:14 --> Config Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:20:14 --> URI Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Router Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Output Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Security Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Input Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:20:14 --> Language Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Loader Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Controller Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:20:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:20:14 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:20:14 --> Session Class Initialized
DEBUG - 2014-01-29 17:20:14 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:20:14 --> Session routines successfully run
DEBUG - 2014-01-29 17:20:14 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:20:14 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:20:14 --> Final output sent to browser
DEBUG - 2014-01-29 17:20:14 --> Total execution time: 0.0120
DEBUG - 2014-01-29 17:20:29 --> Config Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:20:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:20:29 --> URI Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Router Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Output Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Security Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Input Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:20:29 --> Language Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Loader Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Controller Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:20:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:20:29 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:20:29 --> Session Class Initialized
DEBUG - 2014-01-29 17:20:29 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:20:29 --> Session routines successfully run
DEBUG - 2014-01-29 17:20:29 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:20:29 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:20:29 --> Final output sent to browser
DEBUG - 2014-01-29 17:20:29 --> Total execution time: 0.0120
DEBUG - 2014-01-29 17:20:32 --> Config Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:20:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:20:32 --> URI Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Router Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Output Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Security Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Input Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:20:32 --> Language Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Loader Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Controller Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:20:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:20:32 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:20:32 --> Session Class Initialized
DEBUG - 2014-01-29 17:20:32 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:20:32 --> Session routines successfully run
DEBUG - 2014-01-29 17:20:32 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:20:32 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:20:32 --> Final output sent to browser
DEBUG - 2014-01-29 17:20:32 --> Total execution time: 0.0180
DEBUG - 2014-01-29 17:20:33 --> Config Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:20:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:20:33 --> URI Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Router Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Output Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Security Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Input Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:20:33 --> Language Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Loader Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Controller Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:20:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:20:33 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:20:33 --> Session Class Initialized
DEBUG - 2014-01-29 17:20:33 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:20:33 --> Session routines successfully run
DEBUG - 2014-01-29 17:20:33 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:20:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:20:33 --> Final output sent to browser
DEBUG - 2014-01-29 17:20:33 --> Total execution time: 0.0190
DEBUG - 2014-01-29 17:20:58 --> Config Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:20:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:20:58 --> URI Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Router Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Output Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Security Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Input Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:20:58 --> Language Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Loader Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Controller Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:20:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:20:58 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Model Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:20:58 --> Session Class Initialized
DEBUG - 2014-01-29 17:20:58 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:20:58 --> Session routines successfully run
DEBUG - 2014-01-29 17:20:58 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:20:58 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:20:58 --> Final output sent to browser
DEBUG - 2014-01-29 17:20:58 --> Total execution time: 0.0210
DEBUG - 2014-01-29 17:21:00 --> Config Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:21:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:21:00 --> URI Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Router Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Output Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Security Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Input Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:21:00 --> Language Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Loader Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Controller Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:21:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:21:00 --> Model Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Model Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Model Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:21:00 --> Session Class Initialized
DEBUG - 2014-01-29 17:21:00 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:21:00 --> Session routines successfully run
DEBUG - 2014-01-29 17:21:00 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:21:00 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:21:00 --> Final output sent to browser
DEBUG - 2014-01-29 17:21:00 --> Total execution time: 0.0110
DEBUG - 2014-01-29 17:21:12 --> Config Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:21:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:21:12 --> URI Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Router Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Output Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Security Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Input Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:21:12 --> Language Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Loader Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Controller Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:21:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:21:12 --> Model Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Model Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Model Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:21:12 --> Session Class Initialized
DEBUG - 2014-01-29 17:21:12 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:21:12 --> Session routines successfully run
DEBUG - 2014-01-29 17:21:12 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:21:12 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:21:12 --> Final output sent to browser
DEBUG - 2014-01-29 17:21:12 --> Total execution time: 0.0180
DEBUG - 2014-01-29 17:23:26 --> Config Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:23:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:23:26 --> URI Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Router Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Output Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Security Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Input Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:23:26 --> Language Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Loader Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Controller Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:23:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:23:26 --> Model Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Model Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Model Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:23:26 --> Session Class Initialized
DEBUG - 2014-01-29 17:23:26 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:23:26 --> Session routines successfully run
DEBUG - 2014-01-29 17:23:26 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:23:40 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:23:40 --> Final output sent to browser
DEBUG - 2014-01-29 17:23:40 --> Total execution time: 13.9708
DEBUG - 2014-01-29 17:24:32 --> Config Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:24:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:24:32 --> URI Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Router Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Output Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Security Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Input Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:24:32 --> Language Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Loader Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Controller Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:24:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:24:32 --> Model Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Model Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Model Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:24:32 --> Session Class Initialized
DEBUG - 2014-01-29 17:24:32 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:24:32 --> Session routines successfully run
DEBUG - 2014-01-29 17:24:32 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:24:32 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:24:32 --> Final output sent to browser
DEBUG - 2014-01-29 17:24:32 --> Total execution time: 0.0130
DEBUG - 2014-01-29 17:24:58 --> Config Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:24:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:24:58 --> URI Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Router Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Output Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Security Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Input Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:24:58 --> Language Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Loader Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Controller Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:24:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:24:58 --> Model Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Model Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Model Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:24:58 --> Session Class Initialized
DEBUG - 2014-01-29 17:24:58 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:24:58 --> Session routines successfully run
DEBUG - 2014-01-29 17:24:58 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:24:58 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:24:58 --> Final output sent to browser
DEBUG - 2014-01-29 17:24:58 --> Total execution time: 0.0200
DEBUG - 2014-01-29 17:27:00 --> Config Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:27:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:27:00 --> URI Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Router Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Output Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Security Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Input Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:27:00 --> Language Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Loader Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Controller Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:27:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:27:00 --> Model Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Model Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Model Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:27:00 --> Session Class Initialized
DEBUG - 2014-01-29 17:27:00 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:27:00 --> Session routines successfully run
DEBUG - 2014-01-29 17:27:00 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:27:00 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:27:00 --> Final output sent to browser
DEBUG - 2014-01-29 17:27:00 --> Total execution time: 0.0120
DEBUG - 2014-01-29 17:35:14 --> Config Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:35:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:35:14 --> URI Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Router Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Output Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Security Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Input Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:35:14 --> Language Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Loader Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Controller Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:35:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:35:14 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:35:14 --> Session Class Initialized
DEBUG - 2014-01-29 17:35:14 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:35:14 --> Session routines successfully run
DEBUG - 2014-01-29 17:35:14 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:35:14 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:35:14 --> Final output sent to browser
DEBUG - 2014-01-29 17:35:14 --> Total execution time: 0.0200
DEBUG - 2014-01-29 17:35:17 --> Config Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:35:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:35:17 --> URI Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Router Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Output Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Security Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Input Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:35:17 --> Language Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Loader Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Controller Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:35:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:35:17 --> Session Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:35:17 --> Session routines successfully run
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:35:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:35:17 --> Final output sent to browser
DEBUG - 2014-01-29 17:35:17 --> Total execution time: 0.0200
DEBUG - 2014-01-29 17:35:17 --> Config Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:35:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:35:17 --> URI Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Router Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Output Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Security Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Input Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:35:17 --> Language Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Loader Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Controller Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:35:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:35:17 --> Session Class Initialized
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:35:17 --> Session routines successfully run
DEBUG - 2014-01-29 17:35:17 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:35:17 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 17:35:17 --> Final output sent to browser
DEBUG - 2014-01-29 17:35:17 --> Total execution time: 0.0120
DEBUG - 2014-01-29 17:35:18 --> Config Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:35:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:35:18 --> URI Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Router Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Output Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Security Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Input Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:35:18 --> Language Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Loader Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Controller Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:35:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:35:18 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Model Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:35:18 --> Session Class Initialized
DEBUG - 2014-01-29 17:35:18 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:35:18 --> Session routines successfully run
DEBUG - 2014-01-29 17:35:18 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:35:18 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:35:18 --> Final output sent to browser
DEBUG - 2014-01-29 17:35:18 --> Total execution time: 0.0200
DEBUG - 2014-01-29 17:55:22 --> Config Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Hooks Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Utf8 Class Initialized
DEBUG - 2014-01-29 17:55:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 17:55:22 --> URI Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Router Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Output Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Security Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Input Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 17:55:22 --> Language Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Loader Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Controller Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 17:55:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 17:55:22 --> Model Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Model Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Database Driver Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Model Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 17:55:22 --> Session Class Initialized
DEBUG - 2014-01-29 17:55:22 --> Helper loaded: string_helper
DEBUG - 2014-01-29 17:55:22 --> Session routines successfully run
DEBUG - 2014-01-29 17:55:22 --> Helper loaded: url_helper
DEBUG - 2014-01-29 17:55:22 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 17:55:22 --> Final output sent to browser
DEBUG - 2014-01-29 17:55:22 --> Total execution time: 0.0210
DEBUG - 2014-01-29 18:11:46 --> Config Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Hooks Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Utf8 Class Initialized
DEBUG - 2014-01-29 18:11:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 18:11:46 --> URI Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Router Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Output Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Security Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Input Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 18:11:46 --> Language Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Loader Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Controller Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 18:11:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 18:11:46 --> Model Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Model Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Database Driver Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Model Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 18:11:46 --> Session Class Initialized
DEBUG - 2014-01-29 18:11:46 --> Helper loaded: string_helper
DEBUG - 2014-01-29 18:11:46 --> Session routines successfully run
DEBUG - 2014-01-29 18:11:46 --> Helper loaded: url_helper
DEBUG - 2014-01-29 18:11:46 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 18:11:46 --> Final output sent to browser
DEBUG - 2014-01-29 18:11:46 --> Total execution time: 0.0200
DEBUG - 2014-01-29 18:12:34 --> Config Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Hooks Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Utf8 Class Initialized
DEBUG - 2014-01-29 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 18:12:34 --> URI Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Router Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Output Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Security Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Input Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 18:12:34 --> Language Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Loader Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Controller Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 18:12:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 18:12:34 --> Model Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Model Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Database Driver Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Model Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 18:12:34 --> Session Class Initialized
DEBUG - 2014-01-29 18:12:34 --> Helper loaded: string_helper
DEBUG - 2014-01-29 18:12:34 --> Session routines successfully run
DEBUG - 2014-01-29 18:12:34 --> Helper loaded: url_helper
DEBUG - 2014-01-29 18:12:34 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 18:12:34 --> Final output sent to browser
DEBUG - 2014-01-29 18:12:34 --> Total execution time: 0.0210
DEBUG - 2014-01-29 19:14:52 --> Config Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:14:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:14:52 --> URI Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Router Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Output Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Security Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Input Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:14:52 --> Language Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Loader Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Controller Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:14:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:14:52 --> Model Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Model Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Model Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:14:52 --> Session Class Initialized
DEBUG - 2014-01-29 19:14:52 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:14:52 --> Session routines successfully run
DEBUG - 2014-01-29 19:14:52 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:14:52 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:14:52 --> Final output sent to browser
DEBUG - 2014-01-29 19:14:52 --> Total execution time: 0.0220
DEBUG - 2014-01-29 19:15:37 --> Config Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:15:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:15:37 --> URI Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Router Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Output Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Security Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Input Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:15:37 --> Language Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Loader Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Controller Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:15:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:15:37 --> Model Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Model Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Model Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:15:37 --> Session Class Initialized
DEBUG - 2014-01-29 19:15:37 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:15:37 --> Session routines successfully run
DEBUG - 2014-01-29 19:15:37 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:15:37 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:15:37 --> Final output sent to browser
DEBUG - 2014-01-29 19:15:37 --> Total execution time: 0.0140
DEBUG - 2014-01-29 19:25:38 --> Config Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:25:38 --> URI Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Router Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Output Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Security Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Input Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:25:38 --> Language Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Loader Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Controller Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:25:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:25:38 --> Model Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Model Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Model Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:25:38 --> Session Class Initialized
DEBUG - 2014-01-29 19:25:38 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:25:38 --> Session routines successfully run
DEBUG - 2014-01-29 19:25:38 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:25:38 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:25:38 --> Final output sent to browser
DEBUG - 2014-01-29 19:25:38 --> Total execution time: 0.0220
DEBUG - 2014-01-29 19:26:20 --> Config Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:26:20 --> URI Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Router Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Output Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Security Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Input Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:26:20 --> Language Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Loader Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Controller Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:26:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:26:20 --> Model Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Model Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Model Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:26:20 --> Session Class Initialized
DEBUG - 2014-01-29 19:26:20 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:26:20 --> Session routines successfully run
DEBUG - 2014-01-29 19:26:20 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:26:20 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:26:20 --> Final output sent to browser
DEBUG - 2014-01-29 19:26:20 --> Total execution time: 0.0110
DEBUG - 2014-01-29 19:26:37 --> Config Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:26:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:26:37 --> URI Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Router Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Output Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Security Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Input Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:26:37 --> Language Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Loader Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Controller Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:26:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:26:37 --> Model Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Model Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Model Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:26:37 --> Session Class Initialized
DEBUG - 2014-01-29 19:26:37 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:26:37 --> Session routines successfully run
DEBUG - 2014-01-29 19:26:37 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:26:37 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:26:37 --> Final output sent to browser
DEBUG - 2014-01-29 19:26:37 --> Total execution time: 0.0200
DEBUG - 2014-01-29 19:27:53 --> Config Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:27:53 --> URI Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Router Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Output Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Security Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Input Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:27:53 --> Language Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Loader Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Controller Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:27:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:27:53 --> Model Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Model Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Model Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:27:53 --> Session Class Initialized
DEBUG - 2014-01-29 19:27:53 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:27:53 --> Session routines successfully run
DEBUG - 2014-01-29 19:27:53 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:27:53 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:27:53 --> Final output sent to browser
DEBUG - 2014-01-29 19:27:53 --> Total execution time: 0.0130
DEBUG - 2014-01-29 19:28:14 --> Config Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:28:14 --> URI Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Router Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Output Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Security Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Input Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:28:14 --> Language Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Loader Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Controller Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:28:14 --> Model Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Model Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Model Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:28:14 --> Session Class Initialized
DEBUG - 2014-01-29 19:28:14 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:28:14 --> Session routines successfully run
DEBUG - 2014-01-29 19:28:14 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:28:14 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:28:14 --> Final output sent to browser
DEBUG - 2014-01-29 19:28:14 --> Total execution time: 0.0130
DEBUG - 2014-01-29 19:28:34 --> Config Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Hooks Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Utf8 Class Initialized
DEBUG - 2014-01-29 19:28:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 19:28:34 --> URI Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Router Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Output Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Security Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Input Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 19:28:34 --> Language Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Loader Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Controller Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 19:28:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 19:28:34 --> Model Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Model Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Database Driver Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Model Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 19:28:34 --> Session Class Initialized
DEBUG - 2014-01-29 19:28:34 --> Helper loaded: string_helper
DEBUG - 2014-01-29 19:28:34 --> Session routines successfully run
DEBUG - 2014-01-29 19:28:34 --> Helper loaded: url_helper
DEBUG - 2014-01-29 19:28:34 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 19:28:34 --> Final output sent to browser
DEBUG - 2014-01-29 19:28:34 --> Total execution time: 0.0190
DEBUG - 2014-01-29 23:16:27 --> Config Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:16:27 --> URI Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Router Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Output Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Security Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Input Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:16:27 --> Language Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Loader Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Controller Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:16:27 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:16:27 --> Session Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:16:27 --> A session cookie was not found.
DEBUG - 2014-01-29 23:16:27 --> Session routines successfully run
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:16:27 --> Config Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:16:27 --> URI Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Router Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Output Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Security Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Input Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:16:27 --> Language Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Loader Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Controller Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:16:27 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:16:27 --> Session Class Initialized
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:16:27 --> Session routines successfully run
DEBUG - 2014-01-29 23:16:27 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:16:27 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-29 23:16:27 --> Final output sent to browser
DEBUG - 2014-01-29 23:16:27 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:16:30 --> Config Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:16:30 --> URI Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Router Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Output Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Security Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Input Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:16:30 --> Language Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Loader Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Controller Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:16:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:16:30 --> Session Class Initialized
DEBUG - 2014-01-29 23:16:30 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:16:30 --> Session routines successfully run
DEBUG - 2014-01-29 23:16:30 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:16:30 --> Final output sent to browser
DEBUG - 2014-01-29 23:16:30 --> Total execution time: 0.0110
DEBUG - 2014-01-29 23:16:35 --> Config Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:16:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:16:35 --> URI Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Router Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Output Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Security Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Input Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:16:35 --> Language Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Loader Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Controller Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:16:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:16:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:16:35 --> Session Class Initialized
DEBUG - 2014-01-29 23:16:35 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:16:35 --> Session routines successfully run
DEBUG - 2014-01-29 23:16:35 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:16:35 --> Final output sent to browser
DEBUG - 2014-01-29 23:16:35 --> Total execution time: 0.0170
DEBUG - 2014-01-29 23:17:35 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:35 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:35 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:35 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:35 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:35 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:35 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:35 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:35 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:35 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:35 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:35 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-29 23:17:35 --> Final output sent to browser
DEBUG - 2014-01-29 23:17:35 --> Total execution time: 0.0090
DEBUG - 2014-01-29 23:17:38 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:38 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:38 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:38 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:38 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:38 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:38 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:38 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:38 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:38 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:38 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:38 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:38 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:38 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:38 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:38 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:38 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 23:17:38 --> Final output sent to browser
DEBUG - 2014-01-29 23:17:38 --> Total execution time: 0.0110
DEBUG - 2014-01-29 23:17:39 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:39 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:39 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:39 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:39 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:39 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:39 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:39 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:39 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:17:39 --> Final output sent to browser
DEBUG - 2014-01-29 23:17:39 --> Total execution time: 0.0190
DEBUG - 2014-01-29 23:17:40 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:40 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:40 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:40 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:40 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:40 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:40 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:40 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:40 --> Final output sent to browser
DEBUG - 2014-01-29 23:17:40 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:17:53 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:53 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:53 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:53 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:53 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:53 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:53 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:53 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:53 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:17:53 --> Final output sent to browser
DEBUG - 2014-01-29 23:17:53 --> Total execution time: 0.0200
DEBUG - 2014-01-29 23:17:54 --> Config Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:17:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:17:54 --> URI Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Router Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Output Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Security Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Input Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:17:54 --> Language Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Loader Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Controller Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:17:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:17:54 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Model Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:17:54 --> Session Class Initialized
DEBUG - 2014-01-29 23:17:54 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:17:54 --> Session routines successfully run
DEBUG - 2014-01-29 23:17:54 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:17:54 --> Final output sent to browser
DEBUG - 2014-01-29 23:17:54 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:19:46 --> Config Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:19:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:19:46 --> URI Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Router Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Output Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Security Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Input Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:19:46 --> Language Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Loader Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Controller Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:19:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:19:46 --> Model Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Model Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Model Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:19:46 --> Session Class Initialized
DEBUG - 2014-01-29 23:19:46 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:19:46 --> Session routines successfully run
DEBUG - 2014-01-29 23:19:46 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:19:46 --> Final output sent to browser
DEBUG - 2014-01-29 23:19:46 --> Total execution time: 0.0200
DEBUG - 2014-01-29 23:20:03 --> Config Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:20:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:20:03 --> URI Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Router Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Output Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Security Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Input Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:20:03 --> Language Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Loader Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Controller Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:20:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:20:03 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:20:03 --> Session Class Initialized
DEBUG - 2014-01-29 23:20:03 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:20:03 --> Session routines successfully run
DEBUG - 2014-01-29 23:20:03 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:20:03 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:20:03 --> Final output sent to browser
DEBUG - 2014-01-29 23:20:03 --> Total execution time: 0.0180
DEBUG - 2014-01-29 23:20:04 --> Config Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:20:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:20:04 --> URI Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Router Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Output Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Security Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Input Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:20:04 --> Language Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Loader Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Controller Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:20:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:20:04 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:20:04 --> Session Class Initialized
DEBUG - 2014-01-29 23:20:04 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:20:04 --> Session routines successfully run
DEBUG - 2014-01-29 23:20:04 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:20:04 --> Final output sent to browser
DEBUG - 2014-01-29 23:20:04 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:20:05 --> Config Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:20:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:20:05 --> URI Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Router Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Output Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Security Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Input Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:20:05 --> Language Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Loader Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Controller Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:20:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:20:05 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:20:05 --> Session Class Initialized
DEBUG - 2014-01-29 23:20:05 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:20:05 --> Session routines successfully run
DEBUG - 2014-01-29 23:20:05 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:20:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-29 23:20:05 --> Final output sent to browser
DEBUG - 2014-01-29 23:20:05 --> Total execution time: 0.0160
DEBUG - 2014-01-29 23:20:06 --> Config Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:20:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:20:06 --> URI Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Router Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Output Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Security Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Input Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:20:06 --> Language Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Loader Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Controller Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:20:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:20:06 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:20:06 --> Session Class Initialized
DEBUG - 2014-01-29 23:20:06 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:20:06 --> Session routines successfully run
DEBUG - 2014-01-29 23:20:06 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:20:06 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:20:06 --> Final output sent to browser
DEBUG - 2014-01-29 23:20:06 --> Total execution time: 0.0200
DEBUG - 2014-01-29 23:20:07 --> Config Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:20:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:20:07 --> URI Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Router Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Output Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Security Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Input Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:20:07 --> Language Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Loader Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Controller Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:20:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:20:07 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Model Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:20:07 --> Session Class Initialized
DEBUG - 2014-01-29 23:20:07 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:20:07 --> Session routines successfully run
DEBUG - 2014-01-29 23:20:07 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:20:07 --> Final output sent to browser
DEBUG - 2014-01-29 23:20:07 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:49:55 --> Config Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:49:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:49:55 --> URI Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Router Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Output Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Security Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Input Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:49:55 --> Language Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Loader Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Controller Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:49:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:49:55 --> Model Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Model Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Model Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:49:55 --> Session Class Initialized
DEBUG - 2014-01-29 23:49:55 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:49:55 --> Session routines successfully run
DEBUG - 2014-01-29 23:49:55 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:49:55 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:49:55 --> Final output sent to browser
DEBUG - 2014-01-29 23:49:55 --> Total execution time: 0.0220
DEBUG - 2014-01-29 23:49:57 --> Config Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:49:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:49:57 --> URI Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Router Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Output Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Security Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Input Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:49:57 --> Language Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Loader Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Controller Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:49:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:49:57 --> Model Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Model Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Model Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:49:57 --> Session Class Initialized
DEBUG - 2014-01-29 23:49:57 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:49:57 --> Session routines successfully run
DEBUG - 2014-01-29 23:49:57 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:49:57 --> Final output sent to browser
DEBUG - 2014-01-29 23:49:57 --> Total execution time: 0.0110
DEBUG - 2014-01-29 23:50:14 --> Config Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:50:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:50:14 --> URI Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Router Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Output Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Security Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Input Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:50:14 --> Language Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Loader Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Controller Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:50:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:50:14 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:14 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:50:15 --> Session Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:50:15 --> Session routines successfully run
DEBUG - 2014-01-29 23:50:15 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:50:15 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:50:15 --> Final output sent to browser
DEBUG - 2014-01-29 23:50:15 --> Total execution time: 0.0240
DEBUG - 2014-01-29 23:50:15 --> Config Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:50:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:50:15 --> URI Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Router Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Output Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Security Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Input Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:50:15 --> Language Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Loader Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Controller Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:50:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:50:15 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:50:15 --> Session Class Initialized
DEBUG - 2014-01-29 23:50:15 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:50:15 --> Session routines successfully run
DEBUG - 2014-01-29 23:50:15 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:50:15 --> Final output sent to browser
DEBUG - 2014-01-29 23:50:15 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:50:33 --> Config Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:50:33 --> URI Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Router Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Output Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Security Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Input Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:50:33 --> Language Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Loader Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Controller Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:50:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:50:33 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:50:33 --> Session Class Initialized
DEBUG - 2014-01-29 23:50:33 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:50:33 --> Session routines successfully run
DEBUG - 2014-01-29 23:50:33 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:50:33 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:50:33 --> Final output sent to browser
DEBUG - 2014-01-29 23:50:33 --> Total execution time: 0.0220
DEBUG - 2014-01-29 23:50:34 --> Config Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:50:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:50:34 --> URI Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Router Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Output Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Security Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Input Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:50:34 --> Language Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Loader Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Controller Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:50:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:50:34 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:50:34 --> Session Class Initialized
DEBUG - 2014-01-29 23:50:34 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:50:34 --> Session routines successfully run
DEBUG - 2014-01-29 23:50:34 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:50:34 --> Final output sent to browser
DEBUG - 2014-01-29 23:50:34 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:50:36 --> Config Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:50:36 --> URI Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Router Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Output Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Security Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Input Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:50:36 --> Language Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Loader Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Controller Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:50:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:50:36 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:50:36 --> Session Class Initialized
DEBUG - 2014-01-29 23:50:36 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:50:36 --> Session routines successfully run
DEBUG - 2014-01-29 23:50:36 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:50:36 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:50:36 --> Final output sent to browser
DEBUG - 2014-01-29 23:50:36 --> Total execution time: 0.0200
DEBUG - 2014-01-29 23:50:37 --> Config Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:50:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:50:37 --> URI Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Router Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Output Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Security Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Input Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:50:37 --> Language Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Loader Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Controller Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:50:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:50:37 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Model Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:50:37 --> Session Class Initialized
DEBUG - 2014-01-29 23:50:37 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:50:37 --> Session routines successfully run
DEBUG - 2014-01-29 23:50:37 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:50:37 --> Final output sent to browser
DEBUG - 2014-01-29 23:50:37 --> Total execution time: 0.0100
DEBUG - 2014-01-29 23:52:06 --> Config Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:52:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:52:06 --> URI Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Router Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Output Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Security Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Input Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:52:06 --> Language Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Loader Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Controller Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:52:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:52:06 --> Model Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Model Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Model Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:52:06 --> Session Class Initialized
DEBUG - 2014-01-29 23:52:06 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:52:06 --> Session routines successfully run
DEBUG - 2014-01-29 23:52:06 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:52:06 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-29 23:52:06 --> Final output sent to browser
DEBUG - 2014-01-29 23:52:06 --> Total execution time: 0.0390
DEBUG - 2014-01-29 23:52:07 --> Config Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Hooks Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Utf8 Class Initialized
DEBUG - 2014-01-29 23:52:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-29 23:52:07 --> URI Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Router Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Output Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Security Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Input Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-29 23:52:07 --> Language Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Loader Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Controller Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-29 23:52:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-29 23:52:07 --> Model Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Model Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Database Driver Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Model Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-29 23:52:07 --> Session Class Initialized
DEBUG - 2014-01-29 23:52:07 --> Helper loaded: string_helper
DEBUG - 2014-01-29 23:52:07 --> Session routines successfully run
DEBUG - 2014-01-29 23:52:07 --> Helper loaded: url_helper
DEBUG - 2014-01-29 23:52:07 --> Final output sent to browser
DEBUG - 2014-01-29 23:52:07 --> Total execution time: 0.0110
