<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-12 00:14:50 --> Config Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:14:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:14:50 --> URI Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Router Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Output Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Security Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Input Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:14:50 --> Language Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Loader Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Controller Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:14:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:14:50 --> Model Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Model Class Initialized
DEBUG - 2014-02-12 00:14:50 --> Database Driver Class Initialized
ERROR - 2014-02-12 00:14:51 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 00:14:52 --> Model Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:14:52 --> Session Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:14:52 --> A session cookie was not found.
DEBUG - 2014-02-12 00:14:52 --> Session routines successfully run
DEBUG - 2014-02-12 00:14:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:14:52 --> Config Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:14:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:14:52 --> URI Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Router Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Output Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Security Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Input Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:14:52 --> Language Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Loader Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Controller Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:14:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:14:52 --> Model Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Model Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Database Driver Class Initialized
ERROR - 2014-02-12 00:14:52 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 00:14:52 --> Model Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:14:52 --> Session Class Initialized
DEBUG - 2014-02-12 00:14:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:14:52 --> Session routines successfully run
DEBUG - 2014-02-12 00:14:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:14:52 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-12 00:14:52 --> Final output sent to browser
DEBUG - 2014-02-12 00:14:52 --> Total execution time: 0.3250
DEBUG - 2014-02-12 00:15:03 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:03 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:03 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:03 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Database Driver Class Initialized
ERROR - 2014-02-12 00:15:03 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 00:15:03 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:03 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:03 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:09 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:09 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:09 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:09 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Database Driver Class Initialized
ERROR - 2014-02-12 00:15:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 00:15:09 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:09 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:09 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:10 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:10 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:10 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:10 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Database Driver Class Initialized
ERROR - 2014-02-12 00:15:10 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 00:15:10 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:10 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:10 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:10 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:10 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:10 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 00:15:10 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:10 --> Total execution time: 0.8360
DEBUG - 2014-02-12 00:15:13 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:13 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:13 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:13 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:13 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:13 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:13 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:13 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:13 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:13 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:13 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:13 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:13 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:13 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:13 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:13 --> Total execution time: 0.1830
DEBUG - 2014-02-12 00:15:13 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:13 --> Total execution time: 0.1810
DEBUG - 2014-02-12 00:15:14 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:14 --> Total execution time: 0.3750
DEBUG - 2014-02-12 00:15:16 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:16 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:16 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:16 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:16 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:16 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:16 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:16 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:17 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 00:15:17 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:17 --> Total execution time: 0.2620
DEBUG - 2014-02-12 00:15:18 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:18 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Config Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:15:18 --> URI Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Router Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:18 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:18 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:18 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:18 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:18 --> Total execution time: 0.0160
DEBUG - 2014-02-12 00:15:18 --> Output Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Security Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Input Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:15:18 --> Language Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Loader Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Controller Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:18 --> Session Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:15:18 --> Session routines successfully run
DEBUG - 2014-02-12 00:15:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:15:18 --> Model Class Initialized
DEBUG - 2014-02-12 00:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:15:18 --> Final output sent to browser
DEBUG - 2014-02-12 00:15:18 --> Total execution time: 0.0870
DEBUG - 2014-02-12 00:55:43 --> Config Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:55:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:55:43 --> URI Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Router Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Output Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Security Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Input Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:55:43 --> Language Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Loader Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Controller Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:55:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:55:43 --> Model Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Model Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Model Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:55:43 --> Session Class Initialized
DEBUG - 2014-02-12 00:55:43 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:55:43 --> Session routines successfully run
DEBUG - 2014-02-12 00:55:43 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:55:43 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 00:55:43 --> Final output sent to browser
DEBUG - 2014-02-12 00:55:43 --> Total execution time: 0.1380
DEBUG - 2014-02-12 00:56:30 --> Config Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 00:56:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 00:56:30 --> URI Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Router Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Output Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Security Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Input Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 00:56:30 --> Language Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Loader Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Controller Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 00:56:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 00:56:30 --> Model Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Model Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Model Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 00:56:30 --> Session Class Initialized
DEBUG - 2014-02-12 00:56:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 00:56:30 --> Session routines successfully run
DEBUG - 2014-02-12 00:56:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 00:56:30 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 00:56:30 --> Final output sent to browser
DEBUG - 2014-02-12 00:56:30 --> Total execution time: 0.0220
DEBUG - 2014-02-12 01:03:36 --> Config Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:03:36 --> URI Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Router Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Output Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Security Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Input Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:03:36 --> Language Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Loader Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Controller Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:03:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:03:36 --> Model Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Model Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Model Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:03:36 --> Session Class Initialized
DEBUG - 2014-02-12 01:03:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:03:36 --> Session routines successfully run
DEBUG - 2014-02-12 01:03:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:03:36 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:03:36 --> Final output sent to browser
DEBUG - 2014-02-12 01:03:36 --> Total execution time: 0.1170
DEBUG - 2014-02-12 01:05:27 --> Config Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:05:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:05:27 --> URI Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Router Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Output Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Security Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Input Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:05:27 --> Language Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Loader Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Controller Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:05:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:05:27 --> Model Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Model Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Model Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:05:27 --> Session Class Initialized
DEBUG - 2014-02-12 01:05:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:05:27 --> Session routines successfully run
DEBUG - 2014-02-12 01:05:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:05:27 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:05:27 --> Final output sent to browser
DEBUG - 2014-02-12 01:05:27 --> Total execution time: 0.0910
DEBUG - 2014-02-12 01:06:59 --> Config Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:06:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:06:59 --> URI Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Router Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Output Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Security Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Input Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:06:59 --> Language Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Loader Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Controller Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:06:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:06:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:06:59 --> Session Class Initialized
DEBUG - 2014-02-12 01:06:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:06:59 --> Session routines successfully run
DEBUG - 2014-02-12 01:06:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:06:59 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:06:59 --> Final output sent to browser
DEBUG - 2014-02-12 01:06:59 --> Total execution time: 0.0320
DEBUG - 2014-02-12 01:08:12 --> Config Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:08:12 --> URI Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Router Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Output Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Security Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Input Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:08:12 --> Language Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Loader Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Controller Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:08:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:08:12 --> Model Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Model Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Model Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:08:12 --> Session Class Initialized
DEBUG - 2014-02-12 01:08:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:08:12 --> Session routines successfully run
DEBUG - 2014-02-12 01:08:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:08:12 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:08:12 --> Final output sent to browser
DEBUG - 2014-02-12 01:08:12 --> Total execution time: 0.0220
DEBUG - 2014-02-12 01:09:28 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:28 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:28 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:28 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:28 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:28 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:28 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:28 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:28 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:28 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:28 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:28 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:28 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:28 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 01:09:28 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:28 --> Total execution time: 0.0100
DEBUG - 2014-02-12 01:09:29 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:29 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:29 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:29 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:29 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:29 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:29 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:29 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:29 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:29 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:29 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:29 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:29 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:29 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:29 --> Total execution time: 0.0440
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:29 --> Total execution time: 0.0880
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:29 --> Total execution time: 0.1020
DEBUG - 2014-02-12 01:09:29 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:29 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:29 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:29 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:29 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 01:09:29 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:29 --> Total execution time: 0.0120
DEBUG - 2014-02-12 01:09:30 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:30 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:30 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:30 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:30 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:30 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:30 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:30 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:30 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:30 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:30 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:30 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:30 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:30 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:30 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:30 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:30 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:30 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Total execution time: 0.0180
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:30 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:30 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:30 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:30 --> Total execution time: 0.0260
DEBUG - 2014-02-12 01:09:30 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:30 --> Total execution time: 0.0310
DEBUG - 2014-02-12 01:09:30 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:30 --> Total execution time: 0.0370
DEBUG - 2014-02-12 01:09:30 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:30 --> Total execution time: 0.0500
DEBUG - 2014-02-12 01:09:32 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:32 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:32 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:32 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:32 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:32 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:32 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:09:32 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:32 --> Total execution time: 0.0220
DEBUG - 2014-02-12 01:09:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Total execution time: 0.0210
DEBUG - 2014-02-12 01:09:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:34 --> Total execution time: 0.0240
DEBUG - 2014-02-12 01:09:55 --> Config Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:09:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:09:55 --> URI Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Router Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Output Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Security Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Input Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:09:55 --> Language Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Loader Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Controller Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:09:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:09:55 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Model Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:09:55 --> Session Class Initialized
DEBUG - 2014-02-12 01:09:55 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:09:55 --> Session routines successfully run
DEBUG - 2014-02-12 01:09:55 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:09:55 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:09:55 --> Final output sent to browser
DEBUG - 2014-02-12 01:09:55 --> Total execution time: 0.0120
DEBUG - 2014-02-12 01:10:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:10:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:10:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:10:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:10:34 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 01:10:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:10:34 --> Total execution time: 0.0220
DEBUG - 2014-02-12 01:10:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:10:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:10:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:10:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:10:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:10:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:10:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:10:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:10:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:10:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:10:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:10:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:10:34 --> Total execution time: 0.0140
DEBUG - 2014-02-12 01:10:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:10:34 --> Total execution time: 0.0160
DEBUG - 2014-02-12 01:10:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:10:34 --> Total execution time: 0.0300
DEBUG - 2014-02-12 01:10:39 --> Config Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:10:39 --> URI Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Router Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Output Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Config Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Security Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Input Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:10:39 --> URI Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Language Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Router Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Loader Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Controller Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Output Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Security Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:10:39 --> Input Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Language Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Loader Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Controller Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Session Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:10:39 --> Session routines successfully run
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Session Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:10:39 --> Session routines successfully run
DEBUG - 2014-02-12 01:10:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:10:39 --> Model Class Initialized
DEBUG - 2014-02-12 01:10:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:10:39 --> Final output sent to browser
DEBUG - 2014-02-12 01:10:39 --> Total execution time: 0.0260
DEBUG - 2014-02-12 01:10:39 --> Final output sent to browser
DEBUG - 2014-02-12 01:10:39 --> Total execution time: 0.0420
DEBUG - 2014-02-12 01:12:44 --> Config Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:12:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:12:44 --> URI Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Router Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Output Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Security Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Input Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:12:44 --> Language Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Loader Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Controller Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:12:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:12:44 --> Model Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Model Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Model Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:12:44 --> Session Class Initialized
DEBUG - 2014-02-12 01:12:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:12:44 --> Session routines successfully run
DEBUG - 2014-02-12 01:12:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:12:44 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:12:44 --> Final output sent to browser
DEBUG - 2014-02-12 01:12:44 --> Total execution time: 0.0240
DEBUG - 2014-02-12 01:12:54 --> Config Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:12:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:12:54 --> URI Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Router Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Output Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Security Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Input Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:12:54 --> Language Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Loader Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Controller Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:12:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:12:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:12:54 --> Session Class Initialized
DEBUG - 2014-02-12 01:12:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:12:54 --> Session routines successfully run
DEBUG - 2014-02-12 01:12:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:12:54 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:12:54 --> Final output sent to browser
DEBUG - 2014-02-12 01:12:54 --> Total execution time: 0.1080
DEBUG - 2014-02-12 01:15:14 --> Config Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:15:14 --> URI Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Router Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Output Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Security Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Input Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:15:14 --> Language Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Loader Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Controller Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:15:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:15:14 --> Model Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Model Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Model Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:15:14 --> Session Class Initialized
DEBUG - 2014-02-12 01:15:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:15:14 --> Session routines successfully run
DEBUG - 2014-02-12 01:15:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:15:14 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:15:14 --> Final output sent to browser
DEBUG - 2014-02-12 01:15:14 --> Total execution time: 0.0510
DEBUG - 2014-02-12 01:19:30 --> Config Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:19:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:19:30 --> URI Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Router Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Output Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Security Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Input Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:19:30 --> Language Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Loader Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Controller Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:19:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:19:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Model Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:19:30 --> Session Class Initialized
DEBUG - 2014-02-12 01:19:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:19:30 --> Session routines successfully run
DEBUG - 2014-02-12 01:19:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:19:30 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:19:30 --> Final output sent to browser
DEBUG - 2014-02-12 01:19:30 --> Total execution time: 0.0140
DEBUG - 2014-02-12 01:20:37 --> Config Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:20:37 --> URI Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Router Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Output Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Security Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Input Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:20:37 --> Language Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Loader Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Controller Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:20:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:20:37 --> Model Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Model Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Model Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:20:37 --> Session Class Initialized
DEBUG - 2014-02-12 01:20:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:20:37 --> Session routines successfully run
DEBUG - 2014-02-12 01:20:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:20:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:20:37 --> Final output sent to browser
DEBUG - 2014-02-12 01:20:37 --> Total execution time: 0.0130
DEBUG - 2014-02-12 01:23:40 --> Config Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:23:40 --> URI Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Router Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Output Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Security Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Input Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:23:40 --> Language Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Loader Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Controller Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:23:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:23:40 --> Model Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Model Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Model Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:23:40 --> Session Class Initialized
DEBUG - 2014-02-12 01:23:40 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:23:40 --> Session routines successfully run
DEBUG - 2014-02-12 01:23:40 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:23:40 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:23:40 --> Final output sent to browser
DEBUG - 2014-02-12 01:23:40 --> Total execution time: 0.0180
DEBUG - 2014-02-12 01:23:53 --> Config Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:23:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:23:53 --> URI Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Router Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Output Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Security Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Input Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:23:53 --> Language Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Loader Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Controller Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:23:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:23:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:23:53 --> Session Class Initialized
DEBUG - 2014-02-12 01:23:53 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:23:53 --> Session routines successfully run
DEBUG - 2014-02-12 01:23:53 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:23:53 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:23:53 --> Final output sent to browser
DEBUG - 2014-02-12 01:23:53 --> Total execution time: 0.0130
DEBUG - 2014-02-12 01:30:53 --> Config Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:30:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:30:53 --> URI Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Router Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Output Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Security Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Input Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:30:53 --> Language Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Loader Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Controller Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:30:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:30:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:30:53 --> Session Class Initialized
DEBUG - 2014-02-12 01:30:53 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:30:53 --> Session routines successfully run
DEBUG - 2014-02-12 01:30:53 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:30:53 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:30:53 --> Final output sent to browser
DEBUG - 2014-02-12 01:30:53 --> Total execution time: 0.0240
DEBUG - 2014-02-12 01:32:19 --> Config Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:32:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:32:19 --> URI Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Router Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Output Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Security Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Input Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:32:19 --> Language Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Loader Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Controller Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:32:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:32:19 --> Model Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Model Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Model Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:32:19 --> Session Class Initialized
DEBUG - 2014-02-12 01:32:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:32:19 --> Session routines successfully run
DEBUG - 2014-02-12 01:32:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:32:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:32:19 --> Final output sent to browser
DEBUG - 2014-02-12 01:32:19 --> Total execution time: 0.0130
DEBUG - 2014-02-12 01:36:47 --> Config Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:36:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:36:47 --> URI Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Router Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Output Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Security Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Input Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:36:47 --> Language Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Loader Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Controller Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:36:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:36:47 --> Model Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Model Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Model Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:36:47 --> Session Class Initialized
DEBUG - 2014-02-12 01:36:47 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:36:47 --> Session routines successfully run
DEBUG - 2014-02-12 01:36:47 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:36:47 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:36:47 --> Final output sent to browser
DEBUG - 2014-02-12 01:36:47 --> Total execution time: 0.0170
DEBUG - 2014-02-12 01:38:13 --> Config Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:38:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:38:13 --> URI Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Router Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Output Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Security Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Input Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:38:13 --> Language Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Loader Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Controller Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:38:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:38:13 --> Model Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Model Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Model Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:38:13 --> Session Class Initialized
DEBUG - 2014-02-12 01:38:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:38:13 --> Session routines successfully run
DEBUG - 2014-02-12 01:38:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:38:13 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:38:13 --> Final output sent to browser
DEBUG - 2014-02-12 01:38:13 --> Total execution time: 0.0220
DEBUG - 2014-02-12 01:38:34 --> Config Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:38:34 --> URI Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Router Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Output Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Security Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Input Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:38:34 --> Language Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Loader Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Controller Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:38:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:38:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Model Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:38:34 --> Session Class Initialized
DEBUG - 2014-02-12 01:38:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:38:34 --> Session routines successfully run
DEBUG - 2014-02-12 01:38:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:38:34 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:38:34 --> Final output sent to browser
DEBUG - 2014-02-12 01:38:34 --> Total execution time: 0.0370
DEBUG - 2014-02-12 01:40:52 --> Config Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:40:52 --> URI Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Router Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Output Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Security Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Input Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:40:52 --> Language Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Loader Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Controller Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:40:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:40:52 --> Model Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Model Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Model Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:40:52 --> Session Class Initialized
DEBUG - 2014-02-12 01:40:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:40:52 --> Session routines successfully run
DEBUG - 2014-02-12 01:40:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:40:52 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:40:52 --> Final output sent to browser
DEBUG - 2014-02-12 01:40:52 --> Total execution time: 0.0230
DEBUG - 2014-02-12 01:41:08 --> Config Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:41:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:41:08 --> URI Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Router Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Output Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Security Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Input Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:41:08 --> Language Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Loader Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Controller Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:41:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:41:08 --> Model Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Model Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Model Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:41:08 --> Session Class Initialized
DEBUG - 2014-02-12 01:41:08 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:41:08 --> Session routines successfully run
DEBUG - 2014-02-12 01:41:08 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:41:08 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:41:08 --> Final output sent to browser
DEBUG - 2014-02-12 01:41:08 --> Total execution time: 0.0130
DEBUG - 2014-02-12 01:42:53 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:53 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:53 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:53 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:53 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:53 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-12 01:42:53 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:53 --> Total execution time: 0.0200
DEBUG - 2014-02-12 01:42:53 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:53 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:53 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:53 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:53 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:53 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:53 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 01:42:53 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:53 --> Total execution time: 0.0120
DEBUG - 2014-02-12 01:42:54 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:54 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:54 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:54 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:54 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:54 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:54 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:54 --> Total execution time: 0.0130
DEBUG - 2014-02-12 01:42:54 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:54 --> Total execution time: 0.0290
DEBUG - 2014-02-12 01:42:54 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:54 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:54 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:54 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:54 --> Total execution time: 0.0160
DEBUG - 2014-02-12 01:42:54 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:54 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:54 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:54 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:54 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:55 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 01:42:55 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:55 --> Total execution time: 0.1140
DEBUG - 2014-02-12 01:42:57 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:57 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:57 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:57 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:57 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:57 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:57 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 01:42:57 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:57 --> Total execution time: 0.0430
DEBUG - 2014-02-12 01:42:59 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:59 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:59 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:59 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:59 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:59 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:59 --> Total execution time: 0.0280
DEBUG - 2014-02-12 01:42:59 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:59 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:59 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:59 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:59 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:59 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:59 --> Total execution time: 0.0280
DEBUG - 2014-02-12 01:42:59 --> Config Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:42:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:42:59 --> URI Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Router Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Output Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Security Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Input Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:42:59 --> Language Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Loader Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Controller Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Model Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:42:59 --> Session Class Initialized
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:42:59 --> Session routines successfully run
DEBUG - 2014-02-12 01:42:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:42:59 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 01:42:59 --> Final output sent to browser
DEBUG - 2014-02-12 01:42:59 --> Total execution time: 0.0160
DEBUG - 2014-02-12 01:43:01 --> Config Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:43:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:43:01 --> URI Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Router Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Output Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Security Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Input Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:43:01 --> Language Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Loader Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Controller Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:43:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:43:01 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:43:01 --> Session Class Initialized
DEBUG - 2014-02-12 01:43:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:43:01 --> Session routines successfully run
DEBUG - 2014-02-12 01:43:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:43:01 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 01:43:01 --> Final output sent to browser
DEBUG - 2014-02-12 01:43:01 --> Total execution time: 0.0220
DEBUG - 2014-02-12 01:43:02 --> Config Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:43:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:43:02 --> URI Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Router Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Output Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Security Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Input Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:43:02 --> Language Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Loader Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Controller Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:43:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:43:02 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:43:02 --> Session Class Initialized
DEBUG - 2014-02-12 01:43:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:43:02 --> Session routines successfully run
DEBUG - 2014-02-12 01:43:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:43:02 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 01:43:02 --> Final output sent to browser
DEBUG - 2014-02-12 01:43:02 --> Total execution time: 0.0580
DEBUG - 2014-02-12 01:43:09 --> Config Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:43:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:43:09 --> URI Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Router Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Output Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Security Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Input Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:43:09 --> Language Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Loader Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Controller Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:43:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:43:09 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:43:09 --> Session Class Initialized
DEBUG - 2014-02-12 01:43:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:43:09 --> Session routines successfully run
DEBUG - 2014-02-12 01:43:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:43:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:43:09 --> Final output sent to browser
DEBUG - 2014-02-12 01:43:09 --> Total execution time: 0.0160
DEBUG - 2014-02-12 01:43:13 --> Config Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:43:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:43:13 --> URI Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Router Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Output Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Security Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Input Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:43:13 --> Language Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Loader Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Controller Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:43:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:43:13 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Model Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:43:13 --> Session Class Initialized
DEBUG - 2014-02-12 01:43:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:43:13 --> Session routines successfully run
DEBUG - 2014-02-12 01:43:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:43:13 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-12 01:43:13 --> Final output sent to browser
DEBUG - 2014-02-12 01:43:13 --> Total execution time: 0.0190
DEBUG - 2014-02-12 01:45:27 --> Config Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:45:27 --> URI Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Router Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Output Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Security Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Input Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:45:27 --> Language Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Loader Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Controller Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:45:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:45:27 --> Model Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Model Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Model Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:45:27 --> Session Class Initialized
DEBUG - 2014-02-12 01:45:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:45:27 --> Session routines successfully run
DEBUG - 2014-02-12 01:45:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:45:27 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:45:27 --> Final output sent to browser
DEBUG - 2014-02-12 01:45:27 --> Total execution time: 0.0240
DEBUG - 2014-02-12 01:45:58 --> Config Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:45:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:45:58 --> URI Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Router Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Output Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Security Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Input Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:45:58 --> Language Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Loader Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Controller Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:45:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:45:58 --> Model Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Model Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Model Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:45:58 --> Session Class Initialized
DEBUG - 2014-02-12 01:45:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:45:58 --> Session routines successfully run
DEBUG - 2014-02-12 01:45:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:45:58 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:45:58 --> Final output sent to browser
DEBUG - 2014-02-12 01:45:58 --> Total execution time: 0.0210
DEBUG - 2014-02-12 01:51:14 --> Config Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 01:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 01:51:14 --> URI Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Router Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Output Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Security Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Input Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 01:51:14 --> Language Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Loader Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Controller Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 01:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 01:51:14 --> Model Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Model Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Model Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 01:51:14 --> Session Class Initialized
DEBUG - 2014-02-12 01:51:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 01:51:14 --> Session routines successfully run
DEBUG - 2014-02-12 01:51:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 01:51:14 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 01:51:14 --> Final output sent to browser
DEBUG - 2014-02-12 01:51:14 --> Total execution time: 0.0160
DEBUG - 2014-02-12 02:09:22 --> Config Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:09:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:09:22 --> URI Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Router Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Output Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Security Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Input Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:09:22 --> Language Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Loader Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Controller Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:09:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:09:22 --> Model Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Model Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Model Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:09:22 --> Session Class Initialized
DEBUG - 2014-02-12 02:09:22 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:09:22 --> Session routines successfully run
DEBUG - 2014-02-12 02:09:22 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:09:22 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 02:09:22 --> Final output sent to browser
DEBUG - 2014-02-12 02:09:22 --> Total execution time: 0.0270
DEBUG - 2014-02-12 02:09:58 --> Config Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:09:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:09:58 --> URI Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Router Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Output Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Security Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Input Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:09:58 --> Language Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Loader Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Controller Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:09:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:09:58 --> Model Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Model Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Model Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:09:58 --> Session Class Initialized
DEBUG - 2014-02-12 02:09:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:09:58 --> Session routines successfully run
DEBUG - 2014-02-12 02:09:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:09:58 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 02:09:58 --> Final output sent to browser
DEBUG - 2014-02-12 02:09:58 --> Total execution time: 0.0150
DEBUG - 2014-02-12 02:10:00 --> Config Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:10:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:10:00 --> URI Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Router Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Output Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Security Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Input Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:10:00 --> Language Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Loader Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Controller Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:10:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:10:00 --> Model Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Model Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Model Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:10:00 --> Session Class Initialized
DEBUG - 2014-02-12 02:10:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:10:00 --> Session routines successfully run
DEBUG - 2014-02-12 02:10:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:10:00 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 02:10:00 --> Final output sent to browser
DEBUG - 2014-02-12 02:10:00 --> Total execution time: 0.0100
DEBUG - 2014-02-12 02:14:17 --> Config Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:14:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:14:17 --> URI Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Router Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Output Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Security Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Input Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:14:17 --> Language Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Loader Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Controller Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:14:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:14:17 --> Model Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Model Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Model Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:14:17 --> Session Class Initialized
DEBUG - 2014-02-12 02:14:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:14:17 --> Session routines successfully run
DEBUG - 2014-02-12 02:14:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:14:17 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-12 02:14:17 --> Final output sent to browser
DEBUG - 2014-02-12 02:14:17 --> Total execution time: 0.0230
DEBUG - 2014-02-12 02:28:50 --> Config Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:28:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:28:50 --> URI Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Router Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Output Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Security Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Input Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:28:50 --> Language Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Loader Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Controller Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:28:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:28:50 --> Model Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Model Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Model Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:28:50 --> Session Class Initialized
DEBUG - 2014-02-12 02:28:50 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:28:50 --> Session routines successfully run
DEBUG - 2014-02-12 02:28:50 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:28:50 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 02:28:50 --> Final output sent to browser
DEBUG - 2014-02-12 02:28:50 --> Total execution time: 0.0240
DEBUG - 2014-02-12 02:39:47 --> Config Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:39:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:39:47 --> URI Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Router Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Output Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Security Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Input Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:39:47 --> Language Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Loader Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Controller Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:39:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:39:47 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:39:47 --> Session Class Initialized
DEBUG - 2014-02-12 02:39:47 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:39:47 --> Session routines successfully run
DEBUG - 2014-02-12 02:39:47 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:39:47 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 02:39:47 --> Final output sent to browser
DEBUG - 2014-02-12 02:39:47 --> Total execution time: 0.0560
DEBUG - 2014-02-12 02:39:52 --> Config Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:39:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:39:52 --> URI Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Router Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Output Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Security Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Input Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:39:52 --> Language Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Loader Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Controller Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:39:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:39:52 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:39:52 --> Session Class Initialized
DEBUG - 2014-02-12 02:39:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:39:52 --> Session routines successfully run
DEBUG - 2014-02-12 02:39:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:39:52 --> Final output sent to browser
DEBUG - 2014-02-12 02:39:52 --> Total execution time: 0.0490
DEBUG - 2014-02-12 02:39:54 --> Config Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:39:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:39:54 --> URI Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Router Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Output Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Security Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Input Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:39:54 --> Language Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Loader Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Controller Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:39:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:39:54 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:39:54 --> Session Class Initialized
DEBUG - 2014-02-12 02:39:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:39:54 --> Session routines successfully run
DEBUG - 2014-02-12 02:39:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:39:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 02:39:54 --> Final output sent to browser
DEBUG - 2014-02-12 02:39:54 --> Total execution time: 0.0120
DEBUG - 2014-02-12 02:39:59 --> Config Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:39:59 --> URI Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Router Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Output Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Security Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Input Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:39:59 --> Language Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Loader Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Controller Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:39:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:39:59 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Model Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:39:59 --> Session Class Initialized
DEBUG - 2014-02-12 02:39:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:39:59 --> Session routines successfully run
DEBUG - 2014-02-12 02:39:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:39:59 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 02:39:59 --> Final output sent to browser
DEBUG - 2014-02-12 02:39:59 --> Total execution time: 0.0370
DEBUG - 2014-02-12 02:40:01 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:01 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:01 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:01 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:01 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:01 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:01 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 02:40:01 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:01 --> Total execution time: 0.0480
DEBUG - 2014-02-12 02:40:03 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:03 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:03 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:03 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:03 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:03 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:03 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 02:40:03 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:03 --> Total execution time: 0.2890
DEBUG - 2014-02-12 02:40:05 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:05 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:05 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:05 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:05 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:05 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 02:40:05 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:05 --> Total execution time: 0.0190
DEBUG - 2014-02-12 02:40:05 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:05 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:05 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:05 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:05 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:05 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:05 --> Total execution time: 0.0100
DEBUG - 2014-02-12 02:40:07 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:07 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:07 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:07 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:07 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:07 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:07 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:07 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:07 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 02:40:07 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:07 --> Total execution time: 0.0230
DEBUG - 2014-02-12 02:40:08 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:08 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:08 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:08 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:08 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:08 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:08 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:08 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:08 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 02:40:08 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:08 --> Total execution time: 0.0180
DEBUG - 2014-02-12 02:40:18 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:18 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:18 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:18 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:18 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:18 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:18 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:18 --> Total execution time: 0.0190
DEBUG - 2014-02-12 02:40:19 --> Config Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:40:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:40:19 --> URI Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Router Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Output Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Security Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Input Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:40:19 --> Language Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Loader Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Controller Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:40:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:40:19 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Model Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:40:19 --> Session Class Initialized
DEBUG - 2014-02-12 02:40:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:40:19 --> Session routines successfully run
DEBUG - 2014-02-12 02:40:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:40:19 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 02:40:19 --> Final output sent to browser
DEBUG - 2014-02-12 02:40:19 --> Total execution time: 0.0110
DEBUG - 2014-02-12 02:52:05 --> Config Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 02:52:05 --> URI Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Router Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Output Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Security Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Input Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 02:52:05 --> Language Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Loader Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Controller Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 02:52:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 02:52:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Model Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 02:52:05 --> Session Class Initialized
DEBUG - 2014-02-12 02:52:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 02:52:05 --> Session routines successfully run
DEBUG - 2014-02-12 02:52:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 02:52:05 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 02:52:05 --> Final output sent to browser
DEBUG - 2014-02-12 02:52:05 --> Total execution time: 0.0260
DEBUG - 2014-02-12 03:03:17 --> Config Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:03:17 --> URI Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Router Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Output Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Security Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Input Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:03:17 --> Language Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Loader Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Controller Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:03:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:03:17 --> Model Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Model Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Model Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:03:17 --> Session Class Initialized
DEBUG - 2014-02-12 03:03:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:03:17 --> Session routines successfully run
DEBUG - 2014-02-12 03:03:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:03:17 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:03:17 --> Final output sent to browser
DEBUG - 2014-02-12 03:03:17 --> Total execution time: 0.0270
DEBUG - 2014-02-12 03:05:14 --> Config Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:05:14 --> URI Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Router Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Output Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Security Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Input Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:05:14 --> Language Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Loader Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Controller Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:05:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:05:14 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:14 --> Session Class Initialized
DEBUG - 2014-02-12 03:05:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:05:14 --> Session routines successfully run
DEBUG - 2014-02-12 03:05:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:05:14 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:05:14 --> Final output sent to browser
DEBUG - 2014-02-12 03:05:14 --> Total execution time: 0.0170
DEBUG - 2014-02-12 03:05:19 --> Config Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:05:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:05:19 --> URI Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Router Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Output Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Security Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Input Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:05:19 --> Language Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Loader Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Controller Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:19 --> Session Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:05:19 --> Session routines successfully run
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:19 --> Config Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:05:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:05:19 --> URI Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Router Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Output Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Security Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Input Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:05:19 --> Language Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Loader Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Controller Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:19 --> Session Class Initialized
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:05:19 --> Session routines successfully run
DEBUG - 2014-02-12 03:05:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:05:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:05:19 --> Final output sent to browser
DEBUG - 2014-02-12 03:05:19 --> Total execution time: 0.0110
DEBUG - 2014-02-12 03:05:26 --> Config Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:05:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:05:26 --> URI Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Router Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Output Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Security Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Input Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:05:26 --> Language Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Loader Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Controller Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:26 --> Session Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:05:26 --> Session routines successfully run
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:26 --> Config Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:05:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:05:26 --> URI Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Router Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Output Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Security Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Input Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:05:26 --> Language Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Loader Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Controller Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:05:26 --> Session Class Initialized
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:05:26 --> Session routines successfully run
DEBUG - 2014-02-12 03:05:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:05:26 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:05:26 --> Final output sent to browser
DEBUG - 2014-02-12 03:05:26 --> Total execution time: 0.0190
DEBUG - 2014-02-12 03:06:37 --> Config Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:06:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:06:37 --> URI Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Router Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Output Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Security Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Input Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:06:37 --> Language Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Loader Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Controller Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:06:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:06:37 --> Session Class Initialized
DEBUG - 2014-02-12 03:06:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:06:37 --> Session routines successfully run
DEBUG - 2014-02-12 03:06:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:06:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:06:37 --> Final output sent to browser
DEBUG - 2014-02-12 03:06:37 --> Total execution time: 0.0120
DEBUG - 2014-02-12 03:07:02 --> Config Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:07:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:07:02 --> URI Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Router Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Output Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Security Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Input Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:07:02 --> Language Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Loader Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Controller Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:07:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:07:02 --> Model Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Model Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Model Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:07:02 --> Session Class Initialized
DEBUG - 2014-02-12 03:07:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:07:02 --> Session routines successfully run
DEBUG - 2014-02-12 03:07:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:07:02 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:07:02 --> Final output sent to browser
DEBUG - 2014-02-12 03:07:02 --> Total execution time: 0.0210
DEBUG - 2014-02-12 03:07:18 --> Config Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:07:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:07:18 --> URI Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Router Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Output Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Security Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Input Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:07:18 --> Language Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Loader Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Controller Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:07:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:07:18 --> Model Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Model Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Model Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:07:18 --> Session Class Initialized
DEBUG - 2014-02-12 03:07:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:07:18 --> Session routines successfully run
DEBUG - 2014-02-12 03:07:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:07:18 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:07:18 --> Final output sent to browser
DEBUG - 2014-02-12 03:07:18 --> Total execution time: 0.0190
DEBUG - 2014-02-12 03:09:01 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:01 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:01 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:01 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:01 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:01 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:01 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:09:01 --> Final output sent to browser
DEBUG - 2014-02-12 03:09:01 --> Total execution time: 0.0240
DEBUG - 2014-02-12 03:09:02 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:02 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:02 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:02 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:02 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:02 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:02 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:09:02 --> Final output sent to browser
DEBUG - 2014-02-12 03:09:02 --> Total execution time: 0.0150
DEBUG - 2014-02-12 03:09:12 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:12 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:12 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:12 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:12 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:17 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:17 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:17 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:17 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:17 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:17 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:17 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:09:17 --> Final output sent to browser
DEBUG - 2014-02-12 03:09:17 --> Total execution time: 0.0160
DEBUG - 2014-02-12 03:09:26 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:26 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:26 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:26 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:26 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:26 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:09:26 --> Final output sent to browser
DEBUG - 2014-02-12 03:09:26 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:09:29 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:29 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:29 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:29 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:29 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:29 --> Config Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:09:29 --> URI Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Router Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Output Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Security Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Input Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:09:29 --> Language Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Loader Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Controller Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Model Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:09:29 --> Session Class Initialized
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:09:29 --> Session routines successfully run
DEBUG - 2014-02-12 03:09:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:09:29 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:09:29 --> Final output sent to browser
DEBUG - 2014-02-12 03:09:29 --> Total execution time: 0.0110
DEBUG - 2014-02-12 03:12:38 --> Config Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:12:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:12:38 --> URI Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Router Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Output Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Security Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Input Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:12:38 --> Language Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Loader Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Controller Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:12:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:12:38 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:38 --> Session Class Initialized
DEBUG - 2014-02-12 03:12:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:12:38 --> Session routines successfully run
DEBUG - 2014-02-12 03:12:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:12:38 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:12:38 --> Final output sent to browser
DEBUG - 2014-02-12 03:12:38 --> Total execution time: 0.0390
DEBUG - 2014-02-12 03:12:41 --> Config Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:12:41 --> URI Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Router Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Output Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Security Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Input Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:12:41 --> Language Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Loader Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Controller Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:41 --> Session Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:12:41 --> Session routines successfully run
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:41 --> Config Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:12:41 --> URI Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Router Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Output Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Security Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Input Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:12:41 --> Language Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Loader Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Controller Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:41 --> Session Class Initialized
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:12:41 --> Session routines successfully run
DEBUG - 2014-02-12 03:12:41 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:12:41 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:12:41 --> Final output sent to browser
DEBUG - 2014-02-12 03:12:41 --> Total execution time: 0.0160
DEBUG - 2014-02-12 03:12:46 --> Config Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:12:46 --> URI Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Router Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Output Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Security Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Input Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:12:46 --> Language Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Loader Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Controller Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:12:46 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:46 --> Session Class Initialized
DEBUG - 2014-02-12 03:12:46 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:12:46 --> Session routines successfully run
DEBUG - 2014-02-12 03:12:46 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:12:46 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:12:46 --> Final output sent to browser
DEBUG - 2014-02-12 03:12:46 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:12:49 --> Config Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:12:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:12:49 --> URI Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Router Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Output Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Security Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Input Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:12:49 --> Language Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Loader Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Controller Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:12:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:12:49 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:49 --> Session Class Initialized
DEBUG - 2014-02-12 03:12:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:12:49 --> Session routines successfully run
DEBUG - 2014-02-12 03:12:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:12:49 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:12:49 --> Final output sent to browser
DEBUG - 2014-02-12 03:12:49 --> Total execution time: 0.0170
DEBUG - 2014-02-12 03:12:51 --> Config Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:12:51 --> URI Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Router Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Output Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Security Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Input Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:12:51 --> Language Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Loader Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Controller Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:12:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:12:51 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Model Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:12:51 --> Session Class Initialized
DEBUG - 2014-02-12 03:12:51 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:12:51 --> Session routines successfully run
DEBUG - 2014-02-12 03:12:51 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:12:51 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:12:51 --> Final output sent to browser
DEBUG - 2014-02-12 03:12:51 --> Total execution time: 0.0160
DEBUG - 2014-02-12 03:18:57 --> Config Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:18:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:18:57 --> URI Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Router Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Output Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Security Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Input Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:18:57 --> Language Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Loader Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Controller Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:18:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:18:57 --> Model Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Model Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Model Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:18:57 --> Session Class Initialized
DEBUG - 2014-02-12 03:18:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:18:57 --> Session routines successfully run
DEBUG - 2014-02-12 03:18:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:18:57 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:18:57 --> Final output sent to browser
DEBUG - 2014-02-12 03:18:57 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:19:04 --> Config Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:19:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:19:04 --> URI Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Router Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Output Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Security Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Input Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:19:04 --> Language Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Loader Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Controller Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:19:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:19:04 --> Model Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Model Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Model Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:19:04 --> Session Class Initialized
DEBUG - 2014-02-12 03:19:04 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:19:04 --> Session routines successfully run
DEBUG - 2014-02-12 03:19:04 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:19:04 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:19:04 --> Final output sent to browser
DEBUG - 2014-02-12 03:19:04 --> Total execution time: 0.0230
DEBUG - 2014-02-12 03:19:44 --> Config Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:19:44 --> URI Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Router Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Output Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Security Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Input Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:19:44 --> Language Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Loader Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Controller Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:19:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:19:44 --> Model Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Model Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Model Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:19:44 --> Session Class Initialized
DEBUG - 2014-02-12 03:19:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:19:44 --> Session routines successfully run
DEBUG - 2014-02-12 03:19:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:19:44 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:19:44 --> Final output sent to browser
DEBUG - 2014-02-12 03:19:44 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:27:07 --> Config Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:27:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:27:07 --> URI Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Router Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Output Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Security Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Input Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:27:07 --> Language Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Loader Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Controller Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:27:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:27:07 --> Model Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Model Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Model Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:27:07 --> Session Class Initialized
DEBUG - 2014-02-12 03:27:07 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:27:07 --> Session routines successfully run
DEBUG - 2014-02-12 03:27:07 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:27:07 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:27:07 --> Final output sent to browser
DEBUG - 2014-02-12 03:27:07 --> Total execution time: 0.0180
DEBUG - 2014-02-12 03:29:06 --> Config Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:29:06 --> URI Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Router Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Output Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Security Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Input Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:29:06 --> Language Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Loader Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Controller Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:29:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:29:06 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:29:06 --> Session Class Initialized
DEBUG - 2014-02-12 03:29:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:29:06 --> Session routines successfully run
DEBUG - 2014-02-12 03:29:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:29:06 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:29:06 --> Final output sent to browser
DEBUG - 2014-02-12 03:29:06 --> Total execution time: 0.0140
DEBUG - 2014-02-12 03:29:09 --> Config Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:29:09 --> URI Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Router Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Output Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Security Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Input Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:29:09 --> Language Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Loader Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Controller Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:29:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:29:09 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:29:09 --> Session Class Initialized
DEBUG - 2014-02-12 03:29:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:29:09 --> Session routines successfully run
DEBUG - 2014-02-12 03:29:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:29:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:29:09 --> Final output sent to browser
DEBUG - 2014-02-12 03:29:09 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:29:36 --> Config Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:29:36 --> URI Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Router Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Output Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Security Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Input Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:29:36 --> Language Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Loader Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Controller Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:29:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:29:36 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:29:36 --> Session Class Initialized
DEBUG - 2014-02-12 03:29:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:29:36 --> Session routines successfully run
DEBUG - 2014-02-12 03:29:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:29:36 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:29:36 --> Final output sent to browser
DEBUG - 2014-02-12 03:29:36 --> Total execution time: 0.0230
DEBUG - 2014-02-12 03:29:52 --> Config Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:29:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:29:52 --> URI Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Router Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Output Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Security Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Input Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:29:52 --> Language Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Loader Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Controller Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:29:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:29:52 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Model Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:29:52 --> Session Class Initialized
DEBUG - 2014-02-12 03:29:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:29:52 --> Session routines successfully run
DEBUG - 2014-02-12 03:29:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:29:52 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:29:52 --> Final output sent to browser
DEBUG - 2014-02-12 03:29:52 --> Total execution time: 0.0200
DEBUG - 2014-02-12 03:30:00 --> Config Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:30:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:30:00 --> URI Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Router Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Output Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Security Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Input Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:30:00 --> Language Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Loader Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Controller Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:30:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:30:00 --> Model Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Model Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Model Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:30:00 --> Session Class Initialized
DEBUG - 2014-02-12 03:30:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:30:00 --> Session routines successfully run
DEBUG - 2014-02-12 03:30:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:30:00 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:30:00 --> Final output sent to browser
DEBUG - 2014-02-12 03:30:00 --> Total execution time: 0.0130
DEBUG - 2014-02-12 03:30:23 --> Config Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:30:23 --> URI Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Router Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Output Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Security Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Input Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:30:23 --> Language Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Loader Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Controller Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:30:23 --> Model Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Model Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Model Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:30:23 --> Session Class Initialized
DEBUG - 2014-02-12 03:30:23 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:30:23 --> Session routines successfully run
DEBUG - 2014-02-12 03:30:23 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:30:23 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:30:23 --> Final output sent to browser
DEBUG - 2014-02-12 03:30:23 --> Total execution time: 0.0230
DEBUG - 2014-02-12 03:31:03 --> Config Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:31:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:31:03 --> URI Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Router Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Output Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Security Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Input Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:31:03 --> Language Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Loader Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Controller Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:31:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:31:03 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:31:03 --> Session Class Initialized
DEBUG - 2014-02-12 03:31:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:31:03 --> Session routines successfully run
DEBUG - 2014-02-12 03:31:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:31:03 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:31:03 --> Final output sent to browser
DEBUG - 2014-02-12 03:31:03 --> Total execution time: 0.0130
DEBUG - 2014-02-12 03:31:10 --> Config Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:31:10 --> URI Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Router Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Output Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Security Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Input Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:31:10 --> Language Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Loader Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Controller Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:31:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:31:10 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:31:10 --> Session Class Initialized
DEBUG - 2014-02-12 03:31:10 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:31:10 --> Session routines successfully run
DEBUG - 2014-02-12 03:31:10 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:31:10 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:31:10 --> Final output sent to browser
DEBUG - 2014-02-12 03:31:10 --> Total execution time: 0.0200
DEBUG - 2014-02-12 03:31:12 --> Config Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:31:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:31:12 --> URI Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Router Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Output Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Security Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Input Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:31:12 --> Language Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Loader Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Controller Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:31:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:31:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Model Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:31:12 --> Session Class Initialized
DEBUG - 2014-02-12 03:31:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:31:12 --> Session routines successfully run
DEBUG - 2014-02-12 03:31:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:31:12 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:31:12 --> Final output sent to browser
DEBUG - 2014-02-12 03:31:12 --> Total execution time: 0.0140
DEBUG - 2014-02-12 03:33:05 --> Config Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:33:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:33:05 --> URI Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Router Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Output Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Security Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Input Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:33:05 --> Language Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Loader Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Controller Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:33:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:33:05 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:33:05 --> Session Class Initialized
DEBUG - 2014-02-12 03:33:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:33:05 --> Session routines successfully run
DEBUG - 2014-02-12 03:33:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:33:05 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:33:05 --> Final output sent to browser
DEBUG - 2014-02-12 03:33:05 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:33:10 --> Config Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:33:10 --> URI Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Router Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Output Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Security Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Input Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:33:10 --> Language Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Loader Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Controller Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:33:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:33:10 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:33:10 --> Session Class Initialized
DEBUG - 2014-02-12 03:33:10 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:33:10 --> Session routines successfully run
DEBUG - 2014-02-12 03:33:10 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:33:10 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:33:10 --> Final output sent to browser
DEBUG - 2014-02-12 03:33:10 --> Total execution time: 0.0190
DEBUG - 2014-02-12 03:33:32 --> Config Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:33:32 --> URI Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Router Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Output Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Security Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Input Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:33:32 --> Language Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Loader Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Controller Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:33:32 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:33:32 --> Session Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:33:32 --> Session routines successfully run
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:33:32 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:33:32 --> Final output sent to browser
DEBUG - 2014-02-12 03:33:32 --> Total execution time: 0.0210
DEBUG - 2014-02-12 03:33:32 --> Config Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:33:32 --> URI Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Router Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Output Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Security Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Input Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:33:32 --> Language Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Loader Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Controller Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:33:32 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Model Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:33:32 --> Session Class Initialized
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:33:32 --> Session routines successfully run
DEBUG - 2014-02-12 03:33:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:33:32 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:33:32 --> Final output sent to browser
DEBUG - 2014-02-12 03:33:32 --> Total execution time: 0.0120
DEBUG - 2014-02-12 03:35:49 --> Config Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:35:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:35:49 --> URI Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Router Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Output Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Security Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Input Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:35:49 --> Language Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Loader Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Controller Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:35:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:35:49 --> Model Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Model Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Model Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:35:49 --> Session Class Initialized
DEBUG - 2014-02-12 03:35:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:35:49 --> Session routines successfully run
DEBUG - 2014-02-12 03:35:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:35:49 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:35:49 --> Final output sent to browser
DEBUG - 2014-02-12 03:35:49 --> Total execution time: 0.0150
DEBUG - 2014-02-12 03:36:18 --> Config Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:36:18 --> URI Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Router Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Output Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Security Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Input Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:36:18 --> Language Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Loader Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Controller Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:36:18 --> Model Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Model Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Model Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:36:18 --> Session Class Initialized
DEBUG - 2014-02-12 03:36:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:36:18 --> Session routines successfully run
DEBUG - 2014-02-12 03:36:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:36:18 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:36:18 --> Final output sent to browser
DEBUG - 2014-02-12 03:36:18 --> Total execution time: 0.0200
DEBUG - 2014-02-12 03:41:03 --> Config Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:41:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:41:03 --> URI Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Router Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Output Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Security Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Input Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:41:03 --> Language Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Loader Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Controller Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:41:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:41:03 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:41:03 --> Session Class Initialized
DEBUG - 2014-02-12 03:41:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:41:03 --> Session routines successfully run
DEBUG - 2014-02-12 03:41:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:41:03 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:41:03 --> Final output sent to browser
DEBUG - 2014-02-12 03:41:03 --> Total execution time: 0.0220
DEBUG - 2014-02-12 03:41:06 --> Config Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:41:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:41:06 --> URI Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Router Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Output Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Security Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Input Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:41:06 --> Language Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Loader Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Controller Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:41:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:41:06 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:41:06 --> Session Class Initialized
DEBUG - 2014-02-12 03:41:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:41:06 --> Session routines successfully run
DEBUG - 2014-02-12 03:41:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:41:06 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:41:06 --> Final output sent to browser
DEBUG - 2014-02-12 03:41:06 --> Total execution time: 0.0170
DEBUG - 2014-02-12 03:41:37 --> Config Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:41:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:41:37 --> URI Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Router Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Output Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Security Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Input Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:41:37 --> Language Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Loader Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Controller Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:41:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:41:37 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:41:37 --> Session Class Initialized
DEBUG - 2014-02-12 03:41:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:41:37 --> Session routines successfully run
DEBUG - 2014-02-12 03:41:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:41:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:41:37 --> Final output sent to browser
DEBUG - 2014-02-12 03:41:37 --> Total execution time: 0.0120
DEBUG - 2014-02-12 03:41:39 --> Config Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:41:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:41:39 --> URI Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Router Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Output Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Security Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Input Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:41:39 --> Language Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Loader Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Controller Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:41:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:41:39 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Model Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:41:39 --> Session Class Initialized
DEBUG - 2014-02-12 03:41:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:41:39 --> Session routines successfully run
DEBUG - 2014-02-12 03:41:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:41:39 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:41:39 --> Final output sent to browser
DEBUG - 2014-02-12 03:41:39 --> Total execution time: 0.0200
DEBUG - 2014-02-12 03:42:39 --> Config Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 03:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 03:42:39 --> URI Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Router Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Output Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Security Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Input Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 03:42:39 --> Language Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Loader Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Controller Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 03:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 03:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 03:42:39 --> Session Class Initialized
DEBUG - 2014-02-12 03:42:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 03:42:39 --> Session routines successfully run
DEBUG - 2014-02-12 03:42:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 03:42:39 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 03:42:39 --> Final output sent to browser
DEBUG - 2014-02-12 03:42:39 --> Total execution time: 0.0120
DEBUG - 2014-02-12 04:35:55 --> Config Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:35:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:35:55 --> URI Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Router Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Output Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Security Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Input Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:35:55 --> Language Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Loader Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Controller Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:35:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:35:55 --> Model Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Model Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Model Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:35:55 --> Session Class Initialized
DEBUG - 2014-02-12 04:35:55 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:35:55 --> Session routines successfully run
DEBUG - 2014-02-12 04:35:55 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:35:55 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:35:55 --> Final output sent to browser
DEBUG - 2014-02-12 04:35:55 --> Total execution time: 0.0260
DEBUG - 2014-02-12 04:37:26 --> Config Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:37:26 --> URI Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Router Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Output Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Security Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Input Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:37:26 --> Language Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Loader Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Controller Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:37:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:37:26 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:37:26 --> Session Class Initialized
DEBUG - 2014-02-12 04:37:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:37:26 --> Session routines successfully run
DEBUG - 2014-02-12 04:37:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:37:26 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:37:26 --> Final output sent to browser
DEBUG - 2014-02-12 04:37:26 --> Total execution time: 0.0230
DEBUG - 2014-02-12 04:37:27 --> Config Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:37:27 --> URI Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Router Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Output Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Security Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Input Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:37:27 --> Language Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Loader Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Controller Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:37:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:37:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:37:27 --> Session Class Initialized
DEBUG - 2014-02-12 04:37:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:37:27 --> Session routines successfully run
DEBUG - 2014-02-12 04:37:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:37:27 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:37:27 --> Final output sent to browser
DEBUG - 2014-02-12 04:37:27 --> Total execution time: 0.0200
DEBUG - 2014-02-12 04:37:29 --> Config Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:37:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:37:29 --> URI Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Router Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Output Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Security Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Input Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:37:29 --> Language Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Loader Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Controller Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:37:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:37:29 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:37:29 --> Session Class Initialized
DEBUG - 2014-02-12 04:37:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:37:29 --> Session routines successfully run
DEBUG - 2014-02-12 04:37:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:37:29 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:37:29 --> Final output sent to browser
DEBUG - 2014-02-12 04:37:29 --> Total execution time: 0.0170
DEBUG - 2014-02-12 04:37:31 --> Config Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:37:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:37:31 --> URI Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Router Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Output Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Security Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Input Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:37:31 --> Language Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Loader Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Controller Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:37:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:37:31 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:37:31 --> Session Class Initialized
DEBUG - 2014-02-12 04:37:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:37:31 --> Session routines successfully run
DEBUG - 2014-02-12 04:37:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:37:31 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:37:31 --> Final output sent to browser
DEBUG - 2014-02-12 04:37:31 --> Total execution time: 0.0190
DEBUG - 2014-02-12 04:37:33 --> Config Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:37:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:37:33 --> URI Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Router Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Output Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Security Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Input Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:37:33 --> Language Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Loader Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Controller Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:37:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:37:33 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Model Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:37:33 --> Session Class Initialized
DEBUG - 2014-02-12 04:37:33 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:37:33 --> Session routines successfully run
DEBUG - 2014-02-12 04:37:33 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:37:33 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:37:33 --> Final output sent to browser
DEBUG - 2014-02-12 04:37:33 --> Total execution time: 0.0190
DEBUG - 2014-02-12 04:46:31 --> Config Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:46:31 --> URI Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Router Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Output Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Security Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Input Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:46:31 --> Language Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Loader Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Controller Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:46:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:46:31 --> Model Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Model Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Model Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:46:31 --> Session Class Initialized
DEBUG - 2014-02-12 04:46:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:46:31 --> Session routines successfully run
DEBUG - 2014-02-12 04:46:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:46:31 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:46:31 --> Final output sent to browser
DEBUG - 2014-02-12 04:46:31 --> Total execution time: 0.0240
DEBUG - 2014-02-12 04:46:38 --> Config Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:46:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:46:38 --> URI Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Router Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Output Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Security Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Input Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:46:38 --> Language Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Loader Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Controller Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:46:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:46:38 --> Model Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Model Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Model Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:46:38 --> Session Class Initialized
DEBUG - 2014-02-12 04:46:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:46:38 --> Session routines successfully run
DEBUG - 2014-02-12 04:46:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:46:38 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:46:38 --> Final output sent to browser
DEBUG - 2014-02-12 04:46:38 --> Total execution time: 0.0210
DEBUG - 2014-02-12 04:54:08 --> Config Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:54:08 --> URI Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Router Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Output Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Security Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Input Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:54:08 --> Language Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Loader Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Controller Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:54:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:54:08 --> Model Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Model Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Model Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:54:08 --> Session Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:54:08 --> Session routines successfully run
DEBUG - 2014-02-12 04:54:08 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:54:08 --> Model Class Initialized
DEBUG - 2014-02-12 04:54:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:54:08 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:54:08 --> Final output sent to browser
DEBUG - 2014-02-12 04:54:08 --> Total execution time: 0.0280
DEBUG - 2014-02-12 04:55:30 --> Config Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:55:30 --> URI Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Router Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Output Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Security Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Input Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:55:30 --> Language Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Loader Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Controller Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:55:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:55:30 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:55:30 --> Session Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:55:30 --> Session routines successfully run
DEBUG - 2014-02-12 04:55:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:55:30 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:55:30 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:55:30 --> Final output sent to browser
DEBUG - 2014-02-12 04:55:30 --> Total execution time: 0.0350
DEBUG - 2014-02-12 04:55:52 --> Config Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:55:52 --> URI Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Router Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Output Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Security Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Input Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:55:52 --> Language Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Loader Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Controller Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:55:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:55:52 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:55:52 --> Session Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:55:52 --> Session routines successfully run
DEBUG - 2014-02-12 04:55:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:55:52 --> Model Class Initialized
DEBUG - 2014-02-12 04:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:55:52 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:55:52 --> Final output sent to browser
DEBUG - 2014-02-12 04:55:52 --> Total execution time: 0.0240
DEBUG - 2014-02-12 04:56:27 --> Config Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:56:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:56:27 --> URI Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Router Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Output Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Security Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Input Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:56:27 --> Language Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Loader Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Controller Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:56:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:56:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:56:27 --> Session Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:56:27 --> Session routines successfully run
DEBUG - 2014-02-12 04:56:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:56:27 --> Model Class Initialized
DEBUG - 2014-02-12 04:56:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:56:27 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:56:27 --> Final output sent to browser
DEBUG - 2014-02-12 04:56:27 --> Total execution time: 0.0230
DEBUG - 2014-02-12 04:57:11 --> Config Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:57:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:57:11 --> URI Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Router Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Output Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Security Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Input Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:57:11 --> Language Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Loader Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Controller Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:57:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:57:11 --> Model Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Model Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Model Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:57:11 --> Session Class Initialized
DEBUG - 2014-02-12 04:57:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:57:11 --> Session routines successfully run
DEBUG - 2014-02-12 04:57:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:57:53 --> Model Class Initialized
DEBUG - 2014-02-12 04:57:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:58:47 --> Config Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Hooks Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Utf8 Class Initialized
DEBUG - 2014-02-12 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 04:58:47 --> URI Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Router Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Output Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Security Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Input Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 04:58:47 --> Language Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Loader Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Controller Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 04:58:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 04:58:47 --> Model Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Model Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Database Driver Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Model Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:58:47 --> Session Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Helper loaded: string_helper
DEBUG - 2014-02-12 04:58:47 --> Session routines successfully run
DEBUG - 2014-02-12 04:58:47 --> Helper loaded: url_helper
DEBUG - 2014-02-12 04:58:47 --> Model Class Initialized
DEBUG - 2014-02-12 04:58:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 04:58:47 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 04:58:47 --> Final output sent to browser
DEBUG - 2014-02-12 04:58:47 --> Total execution time: 0.0140
DEBUG - 2014-02-12 05:19:38 --> Config Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:19:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:19:38 --> URI Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Router Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Output Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Security Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Input Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:19:38 --> Language Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Loader Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Controller Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:19:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:19:38 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:19:38 --> Session Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:19:38 --> Session routines successfully run
DEBUG - 2014-02-12 05:19:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:19:38 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:19:38 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:19:38 --> Final output sent to browser
DEBUG - 2014-02-12 05:19:38 --> Total execution time: 0.0310
DEBUG - 2014-02-12 05:19:46 --> Config Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:19:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:19:46 --> URI Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Router Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Output Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Security Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Input Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:19:46 --> Language Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Loader Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Controller Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:19:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:19:46 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:19:46 --> Session Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:19:46 --> Session routines successfully run
DEBUG - 2014-02-12 05:19:46 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:19:46 --> Model Class Initialized
DEBUG - 2014-02-12 05:19:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:19:46 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:19:46 --> Final output sent to browser
DEBUG - 2014-02-12 05:19:46 --> Total execution time: 0.0180
DEBUG - 2014-02-12 05:20:17 --> Config Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:20:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:20:17 --> URI Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Router Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Output Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Security Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Input Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:20:17 --> Language Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Loader Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Controller Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:20:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:20:17 --> Model Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Model Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Model Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:20:17 --> Session Class Initialized
DEBUG - 2014-02-12 05:20:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:20:17 --> Session routines successfully run
DEBUG - 2014-02-12 05:20:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:20:19 --> Model Class Initialized
DEBUG - 2014-02-12 05:20:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:20:46 --> Upload Class Initialized
DEBUG - 2014-02-12 05:21:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:21:45 --> Config Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:21:45 --> URI Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Router Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Output Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Security Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Input Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:21:45 --> Language Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Loader Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Controller Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:21:45 --> Session Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:21:45 --> Session routines successfully run
DEBUG - 2014-02-12 05:21:45 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 05:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:21:45 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:21:45 --> Final output sent to browser
DEBUG - 2014-02-12 05:21:45 --> Total execution time: 0.0140
DEBUG - 2014-02-12 05:23:05 --> Config Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:23:05 --> URI Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Router Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Output Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Security Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Input Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:23:05 --> Language Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Loader Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Controller Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:23:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:23:05 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:23:05 --> Session Class Initialized
DEBUG - 2014-02-12 05:23:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:23:05 --> Session routines successfully run
DEBUG - 2014-02-12 05:23:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:23:07 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:23:57 --> Upload Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 05:23:57 --> You did not select a file to upload.
ERROR - 2014-02-12 05:23:57 --> You did not select a file to upload.
DEBUG - 2014-02-12 05:23:57 --> Config Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:23:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:23:57 --> URI Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Router Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Output Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Security Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Input Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:23:57 --> Language Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Loader Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Controller Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:23:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:23:57 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:23:57 --> Session Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:23:57 --> Session routines successfully run
DEBUG - 2014-02-12 05:23:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:23:57 --> Model Class Initialized
DEBUG - 2014-02-12 05:23:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:23:57 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:23:57 --> Final output sent to browser
DEBUG - 2014-02-12 05:23:57 --> Total execution time: 0.0170
DEBUG - 2014-02-12 05:26:19 --> Config Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:26:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:26:19 --> URI Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Router Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Output Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Security Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Input Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:26:19 --> Language Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Loader Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Controller Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:26:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:26:19 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:26:19 --> Session Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:26:19 --> Session routines successfully run
DEBUG - 2014-02-12 05:26:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:26:19 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:26:19 --> Upload Class Initialized
DEBUG - 2014-02-12 05:26:19 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 05:26:19 --> You did not select a file to upload.
ERROR - 2014-02-12 05:26:19 --> You did not select a file to upload.
DEBUG - 2014-02-12 05:26:24 --> Config Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:26:24 --> URI Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Router Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Output Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Security Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Input Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:26:24 --> Language Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Loader Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Controller Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:26:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:26:24 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:26:24 --> Session Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:26:24 --> Session routines successfully run
DEBUG - 2014-02-12 05:26:24 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:26:24 --> Model Class Initialized
DEBUG - 2014-02-12 05:26:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:26:24 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:26:24 --> Final output sent to browser
DEBUG - 2014-02-12 05:26:24 --> Total execution time: 0.0140
DEBUG - 2014-02-12 05:47:44 --> Config Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:47:44 --> URI Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Router Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Output Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Security Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Input Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:47:44 --> Language Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Loader Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Controller Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Session Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:47:44 --> Session routines successfully run
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:47:44 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 05:47:44 --> Final output sent to browser
DEBUG - 2014-02-12 05:47:44 --> Total execution time: 0.0150
DEBUG - 2014-02-12 05:47:44 --> Config Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:47:44 --> URI Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Router Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Config Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Output Class Initialized
DEBUG - 2014-02-12 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:47:44 --> Config Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Security Class Initialized
DEBUG - 2014-02-12 05:47:44 --> URI Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Input Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Router Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:47:44 --> Output Class Initialized
DEBUG - 2014-02-12 05:47:44 --> URI Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Language Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Security Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Router Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Loader Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Input Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Output Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Controller Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:47:44 --> Security Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:47:44 --> Input Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Language Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Language Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Loader Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Controller Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Loader Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:47:44 --> Controller Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Session Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Session routines successfully run
DEBUG - 2014-02-12 05:47:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Session Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Session routines successfully run
DEBUG - 2014-02-12 05:47:44 --> Session Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:47:44 --> Final output sent to browser
DEBUG - 2014-02-12 05:47:44 --> Total execution time: 0.0140
DEBUG - 2014-02-12 05:47:44 --> Session routines successfully run
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:44 --> Final output sent to browser
DEBUG - 2014-02-12 05:47:44 --> Total execution time: 0.0210
DEBUG - 2014-02-12 05:47:44 --> Final output sent to browser
DEBUG - 2014-02-12 05:47:44 --> Total execution time: 0.0220
DEBUG - 2014-02-12 05:47:49 --> Config Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:47:49 --> URI Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Router Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Output Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Config Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Security Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Input Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:47:49 --> URI Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Language Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Router Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Loader Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Output Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Controller Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Security Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:47:49 --> Input Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Language Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Loader Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Controller Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Session Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:47:49 --> Session routines successfully run
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:49 --> Session Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:47:49 --> Session routines successfully run
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:49 --> Model Class Initialized
DEBUG - 2014-02-12 05:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:47:49 --> Final output sent to browser
DEBUG - 2014-02-12 05:47:49 --> Total execution time: 0.0180
DEBUG - 2014-02-12 05:47:49 --> Final output sent to browser
DEBUG - 2014-02-12 05:47:49 --> Total execution time: 0.0250
DEBUG - 2014-02-12 05:49:58 --> Config Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:49:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:49:58 --> URI Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Router Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Output Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Security Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Input Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:49:58 --> Language Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Loader Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Controller Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:49:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:49:58 --> Model Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Model Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Model Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:49:58 --> Session Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:49:58 --> Session routines successfully run
DEBUG - 2014-02-12 05:49:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:49:58 --> Model Class Initialized
DEBUG - 2014-02-12 05:49:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:49:58 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:49:58 --> Final output sent to browser
DEBUG - 2014-02-12 05:49:58 --> Total execution time: 0.0150
DEBUG - 2014-02-12 05:54:40 --> Config Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:54:40 --> URI Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Router Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Output Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Security Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Input Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:54:40 --> Language Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Loader Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Controller Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:54:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:54:40 --> Model Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Model Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Model Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:54:40 --> Session Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:54:40 --> Session routines successfully run
DEBUG - 2014-02-12 05:54:40 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:54:40 --> Model Class Initialized
DEBUG - 2014-02-12 05:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:54:40 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:54:40 --> Final output sent to browser
DEBUG - 2014-02-12 05:54:40 --> Total execution time: 0.0250
DEBUG - 2014-02-12 05:55:00 --> Config Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 05:55:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 05:55:00 --> URI Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Router Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Output Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Security Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Input Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 05:55:00 --> Language Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Loader Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Controller Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 05:55:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 05:55:00 --> Model Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Model Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Model Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:55:00 --> Session Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 05:55:00 --> Session routines successfully run
DEBUG - 2014-02-12 05:55:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 05:55:00 --> Model Class Initialized
DEBUG - 2014-02-12 05:55:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 05:55:00 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 05:55:00 --> Final output sent to browser
DEBUG - 2014-02-12 05:55:00 --> Total execution time: 0.0150
DEBUG - 2014-02-12 06:00:06 --> Config Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:00:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:00:06 --> URI Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Router Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Output Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Security Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Input Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:00:06 --> Language Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Loader Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Controller Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:00:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:00:06 --> Model Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Model Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Model Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:00:06 --> Session Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:00:06 --> Session routines successfully run
DEBUG - 2014-02-12 06:00:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:00:06 --> Model Class Initialized
DEBUG - 2014-02-12 06:00:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:00:06 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:00:06 --> Final output sent to browser
DEBUG - 2014-02-12 06:00:06 --> Total execution time: 0.0210
DEBUG - 2014-02-12 06:04:19 --> Config Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:04:19 --> URI Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Router Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Output Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Security Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Input Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:04:19 --> Language Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Loader Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Controller Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:04:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:04:19 --> Session Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:04:19 --> Session routines successfully run
DEBUG - 2014-02-12 06:04:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:04:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:04:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:04:19 --> Final output sent to browser
DEBUG - 2014-02-12 06:04:19 --> Total execution time: 0.0150
DEBUG - 2014-02-12 06:06:20 --> Config Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:06:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:06:20 --> URI Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Router Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Output Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Security Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Input Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:06:20 --> Language Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Loader Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Controller Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:06:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:06:20 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:06:20 --> Session Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:06:20 --> Session routines successfully run
DEBUG - 2014-02-12 06:06:20 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:06:20 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:06:20 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:06:20 --> Final output sent to browser
DEBUG - 2014-02-12 06:06:20 --> Total execution time: 0.0220
DEBUG - 2014-02-12 06:06:33 --> Config Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:06:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:06:33 --> URI Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Router Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Output Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Security Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Input Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:06:33 --> Language Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Loader Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Controller Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:06:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:06:33 --> Session Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:06:33 --> Session routines successfully run
DEBUG - 2014-02-12 06:06:33 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:06:33 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:06:33 --> Final output sent to browser
DEBUG - 2014-02-12 06:06:33 --> Total execution time: 0.0180
DEBUG - 2014-02-12 06:06:37 --> Config Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:06:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:06:37 --> URI Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Router Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Output Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Security Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Input Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:06:37 --> Language Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Loader Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Controller Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:06:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:06:37 --> Session Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:06:37 --> Session routines successfully run
DEBUG - 2014-02-12 06:06:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:06:37 --> Model Class Initialized
DEBUG - 2014-02-12 06:06:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:06:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:06:37 --> Final output sent to browser
DEBUG - 2014-02-12 06:06:37 --> Total execution time: 0.0240
DEBUG - 2014-02-12 06:07:58 --> Config Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:07:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:07:58 --> URI Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Router Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Output Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Security Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Input Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:07:58 --> Language Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Loader Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Controller Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:07:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:07:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:07:58 --> Session Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:07:58 --> Session routines successfully run
DEBUG - 2014-02-12 06:07:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:07:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:07:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:07:58 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:07:58 --> Final output sent to browser
DEBUG - 2014-02-12 06:07:58 --> Total execution time: 0.0260
DEBUG - 2014-02-12 06:08:22 --> Config Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:08:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:08:22 --> URI Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Router Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Output Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Security Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Input Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:08:22 --> Language Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Loader Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Controller Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:08:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:08:22 --> Model Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Model Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Model Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:08:22 --> Session Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:08:22 --> Session routines successfully run
DEBUG - 2014-02-12 06:08:22 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:08:22 --> Model Class Initialized
DEBUG - 2014-02-12 06:08:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:08:22 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:08:22 --> Final output sent to browser
DEBUG - 2014-02-12 06:08:22 --> Total execution time: 0.0430
DEBUG - 2014-02-12 06:10:47 --> Config Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:10:47 --> URI Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Router Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Output Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Security Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Input Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:10:47 --> Language Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Loader Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Controller Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:10:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:10:47 --> Model Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Model Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Model Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:10:47 --> Session Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:10:47 --> Session routines successfully run
DEBUG - 2014-02-12 06:10:47 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:10:47 --> Model Class Initialized
DEBUG - 2014-02-12 06:10:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:10:47 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:10:47 --> Final output sent to browser
DEBUG - 2014-02-12 06:10:47 --> Total execution time: 0.0250
DEBUG - 2014-02-12 06:11:16 --> Config Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:11:16 --> URI Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Router Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Output Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Security Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Input Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:11:16 --> Language Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Loader Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Controller Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:11:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:11:16 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:11:16 --> Session Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:11:16 --> Session routines successfully run
DEBUG - 2014-02-12 06:11:16 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:11:16 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:11:16 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:11:16 --> Final output sent to browser
DEBUG - 2014-02-12 06:11:16 --> Total execution time: 0.0200
DEBUG - 2014-02-12 06:11:53 --> Config Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:11:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:11:53 --> URI Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Router Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Output Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Security Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Input Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:11:53 --> Language Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Loader Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Controller Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:11:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:11:53 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:11:53 --> Session Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:11:53 --> Session routines successfully run
DEBUG - 2014-02-12 06:11:53 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:11:53 --> Model Class Initialized
DEBUG - 2014-02-12 06:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:11:53 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:11:53 --> Final output sent to browser
DEBUG - 2014-02-12 06:11:53 --> Total execution time: 0.0250
DEBUG - 2014-02-12 06:12:27 --> Config Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:12:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:12:27 --> URI Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Router Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Output Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Security Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Input Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:12:27 --> Language Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Loader Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Controller Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:12:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:12:27 --> Model Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Model Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Model Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:12:27 --> Session Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:12:27 --> Session routines successfully run
DEBUG - 2014-02-12 06:12:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:12:27 --> Model Class Initialized
DEBUG - 2014-02-12 06:12:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:12:27 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:12:27 --> Final output sent to browser
DEBUG - 2014-02-12 06:12:27 --> Total execution time: 0.0150
DEBUG - 2014-02-12 06:13:09 --> Config Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:13:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:13:09 --> URI Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Router Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Output Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Security Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Input Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:13:09 --> Language Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Loader Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Controller Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:13:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:13:09 --> Model Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Model Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Model Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:13:09 --> Session Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:13:09 --> Session routines successfully run
DEBUG - 2014-02-12 06:13:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:13:09 --> Model Class Initialized
DEBUG - 2014-02-12 06:13:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:13:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:13:09 --> Final output sent to browser
DEBUG - 2014-02-12 06:13:09 --> Total execution time: 0.0150
DEBUG - 2014-02-12 06:14:07 --> Config Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:14:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:14:07 --> URI Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Router Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Output Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Security Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Input Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:14:07 --> Language Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Loader Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Controller Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:14:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:14:07 --> Model Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Model Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Model Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:14:07 --> Session Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:14:07 --> Session routines successfully run
DEBUG - 2014-02-12 06:14:07 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:14:07 --> Model Class Initialized
DEBUG - 2014-02-12 06:14:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:14:07 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:14:07 --> Final output sent to browser
DEBUG - 2014-02-12 06:14:07 --> Total execution time: 0.0210
DEBUG - 2014-02-12 06:40:58 --> Config Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:40:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:40:58 --> URI Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Router Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Output Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Security Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Input Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:40:58 --> Language Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Loader Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Controller Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:40:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:40:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:40:58 --> Session Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:40:58 --> Session routines successfully run
DEBUG - 2014-02-12 06:40:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:40:58 --> Model Class Initialized
DEBUG - 2014-02-12 06:40:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:40:58 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:40:58 --> Final output sent to browser
DEBUG - 2014-02-12 06:40:58 --> Total execution time: 0.0150
DEBUG - 2014-02-12 06:42:39 --> Config Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:42:39 --> URI Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Router Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Output Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Security Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Input Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:42:39 --> Language Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Loader Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Controller Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:42:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:42:39 --> Session Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:42:39 --> Session routines successfully run
DEBUG - 2014-02-12 06:42:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:42:39 --> Model Class Initialized
DEBUG - 2014-02-12 06:42:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:42:39 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:42:39 --> Final output sent to browser
DEBUG - 2014-02-12 06:42:39 --> Total execution time: 0.0240
DEBUG - 2014-02-12 06:45:31 --> Config Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:45:31 --> URI Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Router Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Output Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Security Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Input Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:45:31 --> Language Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Loader Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Controller Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:45:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:45:31 --> Model Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Model Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Model Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:45:31 --> Session Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:45:31 --> Session routines successfully run
DEBUG - 2014-02-12 06:45:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:45:31 --> Model Class Initialized
DEBUG - 2014-02-12 06:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:45:31 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:45:31 --> Final output sent to browser
DEBUG - 2014-02-12 06:45:31 --> Total execution time: 0.0270
DEBUG - 2014-02-12 06:46:18 --> Config Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:46:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:46:18 --> URI Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Router Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Output Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Security Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Input Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:46:18 --> Language Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Loader Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Controller Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:46:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:46:18 --> Model Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Model Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Model Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:46:18 --> Session Class Initialized
DEBUG - 2014-02-12 06:46:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:46:18 --> Session routines successfully run
DEBUG - 2014-02-12 06:46:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:46:20 --> Model Class Initialized
DEBUG - 2014-02-12 06:46:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:47:12 --> Upload Class Initialized
DEBUG - 2014-02-12 06:47:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 06:47:13 --> You did not select a file to upload.
ERROR - 2014-02-12 06:47:15 --> You did not select a file to upload.
DEBUG - 2014-02-12 06:47:19 --> Config Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 06:47:19 --> URI Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Router Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Output Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Security Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Input Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 06:47:19 --> Language Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Loader Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Controller Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 06:47:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 06:47:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:47:19 --> Session Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 06:47:19 --> Session routines successfully run
DEBUG - 2014-02-12 06:47:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 06:47:19 --> Model Class Initialized
DEBUG - 2014-02-12 06:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 06:47:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 06:47:19 --> Final output sent to browser
DEBUG - 2014-02-12 06:47:19 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:02:19 --> Config Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:02:19 --> URI Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Router Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Output Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Security Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Input Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:02:19 --> Language Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Loader Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Controller Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:02:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:02:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:02:19 --> Session Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:02:19 --> Session routines successfully run
DEBUG - 2014-02-12 07:02:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:02:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:02:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:02:19 --> Final output sent to browser
DEBUG - 2014-02-12 07:02:19 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:03:19 --> Config Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:03:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:03:19 --> URI Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Router Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Output Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Security Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Input Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:03:19 --> Language Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Loader Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Controller Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:03:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:03:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:03:19 --> Session Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:03:19 --> Session routines successfully run
DEBUG - 2014-02-12 07:03:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:03:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:03:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:03:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:03:19 --> Final output sent to browser
DEBUG - 2014-02-12 07:03:19 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:04:26 --> Config Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:04:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:04:26 --> URI Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Router Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Output Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Security Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Input Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:04:26 --> Language Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Loader Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Controller Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:04:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:04:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:04:26 --> Session Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:04:26 --> Session routines successfully run
DEBUG - 2014-02-12 07:04:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:04:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:04:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:04:26 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:04:26 --> Final output sent to browser
DEBUG - 2014-02-12 07:04:26 --> Total execution time: 0.0260
DEBUG - 2014-02-12 07:05:33 --> Config Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:05:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:05:33 --> URI Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Router Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Output Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Security Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Input Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:05:33 --> Language Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Loader Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Controller Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:05:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:05:33 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:05:33 --> Session Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:05:33 --> Session routines successfully run
DEBUG - 2014-02-12 07:05:33 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:05:33 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:05:33 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:05:33 --> Final output sent to browser
DEBUG - 2014-02-12 07:05:33 --> Total execution time: 0.0140
DEBUG - 2014-02-12 07:05:43 --> Config Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:05:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:05:43 --> URI Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Router Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Output Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Security Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Input Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:05:43 --> Language Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Loader Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Controller Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:05:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:05:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:05:43 --> Session Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:05:43 --> Session routines successfully run
DEBUG - 2014-02-12 07:05:43 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:05:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:05:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:05:43 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:05:43 --> Final output sent to browser
DEBUG - 2014-02-12 07:05:43 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:07:37 --> Config Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:07:37 --> URI Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Router Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Output Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Security Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Input Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:07:37 --> Language Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Loader Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Controller Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:07:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:07:37 --> Session Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:07:37 --> Session routines successfully run
DEBUG - 2014-02-12 07:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:07:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:07:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:07:37 --> Final output sent to browser
DEBUG - 2014-02-12 07:07:37 --> Total execution time: 0.0240
DEBUG - 2014-02-12 07:10:13 --> Config Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:10:13 --> URI Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Router Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Output Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Security Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Input Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:10:13 --> Language Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Loader Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Controller Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:10:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:10:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:13 --> Session Class Initialized
DEBUG - 2014-02-12 07:10:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:10:13 --> Session routines successfully run
DEBUG - 2014-02-12 07:10:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:10:24 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:24 --> Upload Class Initialized
DEBUG - 2014-02-12 07:10:24 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:10:24 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:10:25 --> Config Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:10:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:10:25 --> URI Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Router Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Output Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Security Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Input Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:10:25 --> Language Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Loader Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Controller Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:10:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:10:25 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:25 --> Session Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:10:25 --> Session routines successfully run
DEBUG - 2014-02-12 07:10:25 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:10:25 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:25 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:10:25 --> Final output sent to browser
DEBUG - 2014-02-12 07:10:25 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:10:34 --> Config Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:10:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:10:34 --> URI Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Router Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Output Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Security Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Input Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:10:34 --> Language Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Loader Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Controller Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:10:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:34 --> Session Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:10:34 --> Session routines successfully run
DEBUG - 2014-02-12 07:10:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:10:34 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:34 --> Upload Class Initialized
DEBUG - 2014-02-12 07:10:34 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:10:34 --> You did not select a file to upload.
ERROR - 2014-02-12 07:10:34 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:10:40 --> Config Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:10:40 --> URI Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Router Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Output Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Security Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Input Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:10:40 --> Language Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Loader Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Controller Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:10:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:10:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:40 --> Session Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:10:40 --> Session routines successfully run
DEBUG - 2014-02-12 07:10:40 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:10:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:10:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:10:40 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:10:40 --> Final output sent to browser
DEBUG - 2014-02-12 07:10:40 --> Total execution time: 0.0200
DEBUG - 2014-02-12 07:11:38 --> Config Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:11:38 --> URI Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Router Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Output Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Security Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Input Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:11:38 --> Language Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Loader Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Controller Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:11:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:11:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:11:38 --> Session Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:11:38 --> Session routines successfully run
DEBUG - 2014-02-12 07:11:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:11:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:11:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:11:38 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:11:38 --> Final output sent to browser
DEBUG - 2014-02-12 07:11:38 --> Total execution time: 0.0220
DEBUG - 2014-02-12 07:15:40 --> Config Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:15:40 --> URI Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Router Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Output Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Security Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Input Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:15:40 --> Language Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Loader Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Controller Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:15:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:15:40 --> Session Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:15:40 --> Session routines successfully run
DEBUG - 2014-02-12 07:15:40 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:15:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:15:40 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:15:40 --> Final output sent to browser
DEBUG - 2014-02-12 07:15:40 --> Total execution time: 0.0160
DEBUG - 2014-02-12 07:15:57 --> Config Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:15:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:15:57 --> URI Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Router Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Output Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Security Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Input Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:15:57 --> Language Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Loader Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Controller Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:15:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:15:57 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:15:57 --> Session Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:15:57 --> Session routines successfully run
DEBUG - 2014-02-12 07:15:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:15:57 --> Model Class Initialized
DEBUG - 2014-02-12 07:15:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:15:57 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:15:57 --> Final output sent to browser
DEBUG - 2014-02-12 07:15:57 --> Total execution time: 0.0140
DEBUG - 2014-02-12 07:16:22 --> Config Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:16:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:16:22 --> URI Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Router Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Output Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Security Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Input Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:16:22 --> Language Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Loader Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Controller Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:16:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:16:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:16:22 --> Session Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:16:22 --> Session routines successfully run
DEBUG - 2014-02-12 07:16:22 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:16:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:16:22 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:16:22 --> Final output sent to browser
DEBUG - 2014-02-12 07:16:22 --> Total execution time: 0.0220
DEBUG - 2014-02-12 07:16:53 --> Config Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:16:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:16:53 --> URI Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Router Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Output Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Security Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Input Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:16:53 --> Language Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Loader Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Controller Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:16:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:16:53 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:16:53 --> Session Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:16:53 --> Session routines successfully run
DEBUG - 2014-02-12 07:16:53 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:16:53 --> Model Class Initialized
DEBUG - 2014-02-12 07:16:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:16:53 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:16:53 --> Final output sent to browser
DEBUG - 2014-02-12 07:16:53 --> Total execution time: 0.0250
DEBUG - 2014-02-12 07:17:22 --> Config Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:17:22 --> URI Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Router Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Output Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Security Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Input Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:17:22 --> Language Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Loader Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Controller Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:17:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:17:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:17:22 --> Session Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:17:22 --> Session routines successfully run
DEBUG - 2014-02-12 07:17:22 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:17:22 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:17:22 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:17:22 --> Final output sent to browser
DEBUG - 2014-02-12 07:17:22 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:17:52 --> Config Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:17:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:17:52 --> URI Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Router Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Output Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Security Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Input Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:17:52 --> Language Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Loader Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Controller Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:17:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:17:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:17:52 --> Session Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:17:52 --> Session routines successfully run
DEBUG - 2014-02-12 07:17:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:17:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:17:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:17:52 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:17:52 --> Final output sent to browser
DEBUG - 2014-02-12 07:17:52 --> Total execution time: 0.0280
DEBUG - 2014-02-12 07:19:26 --> Config Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:19:26 --> URI Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Router Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Output Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Security Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Input Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:19:26 --> Language Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Loader Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Controller Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:19:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:19:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:19:26 --> Session Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:19:26 --> Session routines successfully run
DEBUG - 2014-02-12 07:19:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:19:26 --> Model Class Initialized
DEBUG - 2014-02-12 07:19:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:19:26 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:19:26 --> Final output sent to browser
DEBUG - 2014-02-12 07:19:26 --> Total execution time: 0.0250
DEBUG - 2014-02-12 07:20:07 --> Config Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:20:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:20:07 --> URI Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Router Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Output Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Security Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Input Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:20:07 --> Language Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Loader Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Controller Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:20:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:20:07 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:20:07 --> Session Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:20:07 --> Session routines successfully run
DEBUG - 2014-02-12 07:20:07 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:20:07 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:20:07 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:20:07 --> Final output sent to browser
DEBUG - 2014-02-12 07:20:07 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:20:58 --> Config Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:20:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:20:58 --> URI Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Router Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Output Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Security Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Input Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:20:58 --> Language Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Loader Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Controller Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:20:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:20:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:20:58 --> Session Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:20:58 --> Session routines successfully run
DEBUG - 2014-02-12 07:20:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:20:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:20:58 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:20:58 --> Final output sent to browser
DEBUG - 2014-02-12 07:20:58 --> Total execution time: 0.0190
DEBUG - 2014-02-12 07:21:15 --> Config Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:21:15 --> URI Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Router Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Output Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Security Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Input Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:21:15 --> Language Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Loader Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Controller Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:21:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:21:15 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:21:15 --> Session Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:21:15 --> Session routines successfully run
DEBUG - 2014-02-12 07:21:15 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:21:15 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:21:15 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:21:15 --> Final output sent to browser
DEBUG - 2014-02-12 07:21:15 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:21:38 --> Config Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:21:38 --> URI Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Router Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Output Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Security Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Input Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:21:38 --> Language Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Loader Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Controller Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:21:38 --> Session Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:21:38 --> Session routines successfully run
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:21:38 --> Upload Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:21:38 --> You did not select a file to upload.
ERROR - 2014-02-12 07:21:38 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:21:38 --> Config Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:21:38 --> URI Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Router Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Output Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Security Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Input Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:21:38 --> Language Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Loader Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Controller Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:21:38 --> Session Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:21:38 --> Session routines successfully run
DEBUG - 2014-02-12 07:21:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:21:38 --> Model Class Initialized
DEBUG - 2014-02-12 07:21:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:21:38 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:21:38 --> Final output sent to browser
DEBUG - 2014-02-12 07:21:38 --> Total execution time: 0.0210
DEBUG - 2014-02-12 07:22:12 --> Config Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:22:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:22:12 --> URI Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Router Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Output Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Security Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Input Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:22:12 --> Language Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Loader Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Controller Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:22:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:22:12 --> Session Class Initialized
DEBUG - 2014-02-12 07:22:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:22:12 --> Session routines successfully run
DEBUG - 2014-02-12 07:22:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:22:14 --> Upload Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:22:14 --> You did not select a file to upload.
ERROR - 2014-02-12 07:22:14 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 07:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:22:14 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 07:22:14 --> Total execution time: 0.0140
DEBUG - 2014-02-12 07:25:28 --> Config Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:25:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:25:28 --> URI Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Router Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Output Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Security Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Input Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:25:28 --> Language Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Loader Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Controller Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:25:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:25:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:25:28 --> Session Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:25:28 --> Session routines successfully run
DEBUG - 2014-02-12 07:25:28 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:25:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:25:28 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:25:28 --> Final output sent to browser
DEBUG - 2014-02-12 07:25:28 --> Total execution time: 0.0190
DEBUG - 2014-02-12 07:31:05 --> Config Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:31:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:31:05 --> URI Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Router Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Output Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Security Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Input Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:31:05 --> Language Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Loader Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Controller Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:31:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:31:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:31:05 --> Session Class Initialized
DEBUG - 2014-02-12 07:31:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:31:05 --> Session routines successfully run
DEBUG - 2014-02-12 07:31:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:31:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:31:06 --> Upload Class Initialized
DEBUG - 2014-02-12 07:31:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:31:06 --> You did not select a file to upload.
ERROR - 2014-02-12 07:31:06 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:31:11 --> Config Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:31:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:31:11 --> URI Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Router Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Output Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Security Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Input Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:31:11 --> Language Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Loader Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Controller Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:31:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:31:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:31:11 --> Session Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:31:11 --> Session routines successfully run
DEBUG - 2014-02-12 07:31:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:31:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:31:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:31:11 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:31:11 --> Final output sent to browser
DEBUG - 2014-02-12 07:31:11 --> Total execution time: 0.0300
DEBUG - 2014-02-12 07:33:58 --> Config Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:33:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:33:58 --> URI Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Router Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Output Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Security Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Input Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:33:58 --> Language Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Loader Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Controller Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:33:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:33:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:33:58 --> Session Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:33:58 --> Session routines successfully run
DEBUG - 2014-02-12 07:33:58 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:33:58 --> Model Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:33:58 --> Upload Class Initialized
DEBUG - 2014-02-12 07:33:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:33:58 --> You did not select a file to upload.
ERROR - 2014-02-12 07:33:58 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:34:03 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:03 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:03 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:03 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:03 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:03 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:03 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:03 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:34:03 --> Final output sent to browser
DEBUG - 2014-02-12 07:34:03 --> Total execution time: 0.0250
DEBUG - 2014-02-12 07:34:13 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:13 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:13 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:13 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:13 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:13 --> Upload Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:34:13 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:34:13 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:13 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:13 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:13 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:13 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:13 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:34:13 --> Final output sent to browser
DEBUG - 2014-02-12 07:34:13 --> Total execution time: 0.0220
DEBUG - 2014-02-12 07:34:19 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:19 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:19 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:19 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:19 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:19 --> Upload Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:34:19 --> You did not select a file to upload.
ERROR - 2014-02-12 07:34:19 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:34:19 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:19 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:19 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:19 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:19 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:19 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:19 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:34:19 --> Final output sent to browser
DEBUG - 2014-02-12 07:34:19 --> Total execution time: 0.0220
DEBUG - 2014-02-12 07:34:31 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:31 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:31 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:31 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:31 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:31 --> Upload Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:34:31 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:34:31 --> Config Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:34:31 --> URI Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Router Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Output Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Security Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Input Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:34:31 --> Language Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Loader Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Controller Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:31 --> Session Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:34:31 --> Session routines successfully run
DEBUG - 2014-02-12 07:34:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:34:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:34:31 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:34:31 --> Final output sent to browser
DEBUG - 2014-02-12 07:34:31 --> Total execution time: 0.0220
DEBUG - 2014-02-12 07:35:13 --> Config Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:35:13 --> URI Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Router Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Output Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Security Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Input Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:35:13 --> Language Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Loader Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Controller Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:35:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:35:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:35:13 --> Session Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:35:13 --> Session routines successfully run
DEBUG - 2014-02-12 07:35:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:35:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:35:13 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:35:13 --> Final output sent to browser
DEBUG - 2014-02-12 07:35:13 --> Total execution time: 0.0190
DEBUG - 2014-02-12 07:35:35 --> Config Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:35:35 --> URI Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Router Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Output Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Security Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Input Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:35:35 --> Language Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Loader Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Controller Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:35:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:35:35 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:35:35 --> Session Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:35:35 --> Session routines successfully run
DEBUG - 2014-02-12 07:35:35 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:35:35 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:35:35 --> Upload Class Initialized
DEBUG - 2014-02-12 07:35:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:35:35 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:35:40 --> Config Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:35:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:35:40 --> URI Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Router Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Output Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Security Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Input Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:35:40 --> Language Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Loader Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Controller Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:35:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:35:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:35:40 --> Session Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:35:40 --> Session routines successfully run
DEBUG - 2014-02-12 07:35:40 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:35:40 --> Model Class Initialized
DEBUG - 2014-02-12 07:35:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:35:40 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:35:40 --> Final output sent to browser
DEBUG - 2014-02-12 07:35:40 --> Total execution time: 0.0240
DEBUG - 2014-02-12 07:40:05 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:05 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:05 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:05 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:05 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:05 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:05 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:05 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:05 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:05 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 07:40:05 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:05 --> Total execution time: 0.0120
DEBUG - 2014-02-12 07:40:06 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:06 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:06 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:06 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:06 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:06 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:06 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:06 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:06 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:06 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:06 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:06 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:06 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:06 --> Total execution time: 0.0160
DEBUG - 2014-02-12 07:40:06 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:06 --> Total execution time: 0.0280
DEBUG - 2014-02-12 07:40:06 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:06 --> Total execution time: 0.0340
DEBUG - 2014-02-12 07:40:09 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:09 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:09 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:09 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:09 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:09 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:09 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:40:09 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:09 --> Total execution time: 0.0300
DEBUG - 2014-02-12 07:40:11 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:11 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Config Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:40:11 --> URI Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Router Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:11 --> Output Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Security Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Input Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:40:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Language Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Loader Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Controller Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:40:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:40:11 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:11 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:11 --> Session Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:40:11 --> Session routines successfully run
DEBUG - 2014-02-12 07:40:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:40:11 --> Model Class Initialized
DEBUG - 2014-02-12 07:40:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:40:11 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:11 --> Total execution time: 0.0190
DEBUG - 2014-02-12 07:40:11 --> Final output sent to browser
DEBUG - 2014-02-12 07:40:11 --> Total execution time: 0.0180
DEBUG - 2014-02-12 07:41:00 --> Config Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:41:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:41:00 --> URI Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Router Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Output Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Security Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Input Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:41:00 --> Language Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Loader Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Controller Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:41:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:41:00 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:41:00 --> Session Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:41:00 --> Session routines successfully run
DEBUG - 2014-02-12 07:41:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:41:00 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:41:00 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:41:00 --> Final output sent to browser
DEBUG - 2014-02-12 07:41:00 --> Total execution time: 0.0140
DEBUG - 2014-02-12 07:41:31 --> Config Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:41:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:41:31 --> URI Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Router Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Output Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Security Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Input Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:41:31 --> Language Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Loader Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Controller Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:41:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:41:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:41:31 --> Session Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:41:31 --> Session routines successfully run
DEBUG - 2014-02-12 07:41:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:41:31 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:41:31 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:41:31 --> Final output sent to browser
DEBUG - 2014-02-12 07:41:31 --> Total execution time: 0.0140
DEBUG - 2014-02-12 07:41:47 --> Config Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:41:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:41:47 --> URI Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Router Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Output Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Security Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Input Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:41:47 --> Language Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Loader Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Controller Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:41:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:41:47 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:41:47 --> Session Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:41:47 --> Session routines successfully run
DEBUG - 2014-02-12 07:41:47 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:41:47 --> Model Class Initialized
DEBUG - 2014-02-12 07:41:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:41:47 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:41:47 --> Final output sent to browser
DEBUG - 2014-02-12 07:41:47 --> Total execution time: 0.0210
DEBUG - 2014-02-12 07:42:14 --> Config Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:42:14 --> URI Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Router Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Output Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Security Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Input Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:42:14 --> Language Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Loader Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Controller Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:42:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:42:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:42:14 --> Session Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:42:14 --> Session routines successfully run
DEBUG - 2014-02-12 07:42:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:42:14 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:42:14 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:42:14 --> Final output sent to browser
DEBUG - 2014-02-12 07:42:14 --> Total execution time: 0.0150
DEBUG - 2014-02-12 07:42:16 --> Config Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:42:16 --> URI Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Router Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Output Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Security Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Input Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:42:16 --> Language Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Loader Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Controller Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:42:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:42:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:42:16 --> Session Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:42:16 --> Session routines successfully run
DEBUG - 2014-02-12 07:42:16 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:42:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:42:16 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:42:16 --> Final output sent to browser
DEBUG - 2014-02-12 07:42:16 --> Total execution time: 0.0180
DEBUG - 2014-02-12 07:42:29 --> Config Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:42:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:42:29 --> URI Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Router Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Output Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Security Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Input Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:42:29 --> Language Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Loader Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Controller Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:42:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:42:29 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:42:29 --> Session Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:42:29 --> Session routines successfully run
DEBUG - 2014-02-12 07:42:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:42:29 --> Model Class Initialized
DEBUG - 2014-02-12 07:42:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:42:29 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:42:29 --> Final output sent to browser
DEBUG - 2014-02-12 07:42:29 --> Total execution time: 0.0260
DEBUG - 2014-02-12 07:44:50 --> Config Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:44:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:44:50 --> URI Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Router Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Output Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Security Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Input Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:44:50 --> Language Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Loader Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Controller Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:44:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:44:50 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:44:50 --> Session Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:44:50 --> Session routines successfully run
DEBUG - 2014-02-12 07:44:50 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:44:50 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:44:50 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:44:50 --> Final output sent to browser
DEBUG - 2014-02-12 07:44:50 --> Total execution time: 0.0250
DEBUG - 2014-02-12 07:44:52 --> Config Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:44:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:44:52 --> URI Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Router Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Output Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Security Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Input Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:44:52 --> Language Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Loader Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Controller Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:44:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:44:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:44:52 --> Session Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:44:52 --> Session routines successfully run
DEBUG - 2014-02-12 07:44:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:44:52 --> Model Class Initialized
DEBUG - 2014-02-12 07:44:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:44:52 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:44:52 --> Final output sent to browser
DEBUG - 2014-02-12 07:44:52 --> Total execution time: 0.0210
DEBUG - 2014-02-12 07:45:43 --> Config Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:45:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:45:43 --> URI Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Router Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Output Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Security Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Input Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:45:43 --> Language Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Loader Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Controller Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:45:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:45:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:45:43 --> Session Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:45:43 --> Session routines successfully run
DEBUG - 2014-02-12 07:45:43 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:45:43 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:45:43 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:45:43 --> Final output sent to browser
DEBUG - 2014-02-12 07:45:43 --> Total execution time: 0.0200
DEBUG - 2014-02-12 07:45:45 --> Config Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:45:45 --> URI Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Router Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Output Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Security Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Input Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:45:45 --> Language Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Loader Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Controller Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:45:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:45:45 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:45:45 --> Session Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:45:45 --> Session routines successfully run
DEBUG - 2014-02-12 07:45:45 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:45:45 --> Model Class Initialized
DEBUG - 2014-02-12 07:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:45:45 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:45:45 --> Final output sent to browser
DEBUG - 2014-02-12 07:45:45 --> Total execution time: 0.0190
DEBUG - 2014-02-12 07:46:13 --> Config Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:46:13 --> URI Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Router Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Output Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Security Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Input Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:46:13 --> Language Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Loader Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Controller Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:46:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:46:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:46:13 --> Session Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:46:13 --> Session routines successfully run
DEBUG - 2014-02-12 07:46:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:46:13 --> Model Class Initialized
DEBUG - 2014-02-12 07:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:46:13 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:46:13 --> Final output sent to browser
DEBUG - 2014-02-12 07:46:13 --> Total execution time: 0.0220
DEBUG - 2014-02-12 07:50:51 --> Config Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:50:51 --> URI Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Router Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Output Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Security Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Input Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:50:51 --> Language Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Loader Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Controller Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:50:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:50:51 --> Model Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Model Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Model Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:50:51 --> Session Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:50:51 --> Session routines successfully run
DEBUG - 2014-02-12 07:50:51 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:50:51 --> Model Class Initialized
DEBUG - 2014-02-12 07:50:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:50:51 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:50:51 --> Final output sent to browser
DEBUG - 2014-02-12 07:50:51 --> Total execution time: 0.0170
DEBUG - 2014-02-12 07:53:36 --> Config Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:53:36 --> URI Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Router Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Output Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Security Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Input Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:53:36 --> Language Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Loader Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Controller Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:53:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:53:36 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:53:36 --> Session Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:53:36 --> Session routines successfully run
DEBUG - 2014-02-12 07:53:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:53:36 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:53:36 --> Upload Class Initialized
DEBUG - 2014-02-12 07:53:36 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:53:36 --> You did not select a file to upload.
ERROR - 2014-02-12 07:53:36 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:53:41 --> Config Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:53:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:53:41 --> URI Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Router Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Output Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Security Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Input Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:53:41 --> Language Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Loader Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Controller Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:53:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:53:41 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:53:41 --> Session Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:53:41 --> Session routines successfully run
DEBUG - 2014-02-12 07:53:41 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:53:41 --> Model Class Initialized
DEBUG - 2014-02-12 07:53:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:53:41 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:53:41 --> Final output sent to browser
DEBUG - 2014-02-12 07:53:41 --> Total execution time: 0.0200
DEBUG - 2014-02-12 07:56:23 --> Config Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:56:23 --> URI Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Router Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Output Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Security Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Input Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:56:23 --> Language Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Loader Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Controller Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:56:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:56:23 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:56:23 --> Session Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:56:23 --> Session routines successfully run
DEBUG - 2014-02-12 07:56:23 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:56:23 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:56:23 --> Upload Class Initialized
DEBUG - 2014-02-12 07:56:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:56:23 --> You did not select a file to upload.
ERROR - 2014-02-12 07:56:23 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:56:28 --> Config Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:56:28 --> URI Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Router Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Output Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Security Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Input Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:56:28 --> Language Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Loader Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Controller Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:56:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:56:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:56:28 --> Session Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:56:28 --> Session routines successfully run
DEBUG - 2014-02-12 07:56:28 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:56:28 --> Model Class Initialized
DEBUG - 2014-02-12 07:56:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:56:28 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:56:28 --> Final output sent to browser
DEBUG - 2014-02-12 07:56:28 --> Total execution time: 0.0190
DEBUG - 2014-02-12 07:58:37 --> Config Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:58:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:58:37 --> URI Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Router Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Output Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Security Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Input Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:58:37 --> Language Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Loader Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Controller Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:58:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:58:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:58:37 --> Session Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:58:37 --> Session routines successfully run
DEBUG - 2014-02-12 07:58:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:58:37 --> Model Class Initialized
DEBUG - 2014-02-12 07:58:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:58:37 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:58:37 --> Final output sent to browser
DEBUG - 2014-02-12 07:58:37 --> Total execution time: 0.0250
DEBUG - 2014-02-12 07:59:16 --> Config Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:59:16 --> URI Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Router Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Output Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Security Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Input Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:59:16 --> Language Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Loader Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Controller Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:59:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:59:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:59:16 --> Session Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:59:16 --> Session routines successfully run
DEBUG - 2014-02-12 07:59:16 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:59:16 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:59:16 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:59:16 --> Final output sent to browser
DEBUG - 2014-02-12 07:59:16 --> Total execution time: 0.0210
DEBUG - 2014-02-12 07:59:27 --> Config Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:59:27 --> URI Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Router Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Output Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Security Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Input Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:59:27 --> Language Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Loader Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Controller Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:59:27 --> Session Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:59:27 --> Session routines successfully run
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:59:27 --> Upload Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 07:59:27 --> You did not select a file to upload.
ERROR - 2014-02-12 07:59:27 --> You did not select a file to upload.
DEBUG - 2014-02-12 07:59:27 --> Config Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Hooks Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Utf8 Class Initialized
DEBUG - 2014-02-12 07:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 07:59:27 --> URI Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Router Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Output Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Security Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Input Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 07:59:27 --> Language Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Loader Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Controller Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Database Driver Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:59:27 --> Session Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: string_helper
DEBUG - 2014-02-12 07:59:27 --> Session routines successfully run
DEBUG - 2014-02-12 07:59:27 --> Helper loaded: url_helper
DEBUG - 2014-02-12 07:59:27 --> Model Class Initialized
DEBUG - 2014-02-12 07:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 07:59:27 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 07:59:27 --> Final output sent to browser
DEBUG - 2014-02-12 07:59:27 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:00:09 --> Config Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:00:09 --> URI Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Router Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Output Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Security Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Input Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:00:09 --> Language Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Loader Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Controller Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:09 --> Session Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:00:09 --> Session routines successfully run
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:09 --> Upload Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 08:00:09 --> You did not select a file to upload.
ERROR - 2014-02-12 08:00:09 --> You did not select a file to upload.
DEBUG - 2014-02-12 08:00:09 --> Config Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:00:09 --> URI Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Router Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Output Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Security Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Input Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:00:09 --> Language Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Loader Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Controller Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:09 --> Session Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:00:09 --> Session routines successfully run
DEBUG - 2014-02-12 08:00:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:00:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:00:09 --> Final output sent to browser
DEBUG - 2014-02-12 08:00:09 --> Total execution time: 0.0160
DEBUG - 2014-02-12 08:00:18 --> Config Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:00:18 --> URI Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Router Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Output Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Security Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Input Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:00:18 --> Language Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Loader Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Controller Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:18 --> Session Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:00:18 --> Session routines successfully run
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:18 --> Upload Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 08:00:18 --> You did not select a file to upload.
ERROR - 2014-02-12 08:00:18 --> You did not select a file to upload.
DEBUG - 2014-02-12 08:00:18 --> Config Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:00:18 --> URI Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Router Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Output Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Security Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Input Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:00:18 --> Language Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Loader Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Controller Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:18 --> Session Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:00:18 --> Session routines successfully run
DEBUG - 2014-02-12 08:00:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:00:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:18 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:00:18 --> Final output sent to browser
DEBUG - 2014-02-12 08:00:18 --> Total execution time: 0.0140
DEBUG - 2014-02-12 08:00:50 --> Config Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:00:50 --> URI Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Router Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Output Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Security Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Input Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:00:50 --> Language Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Loader Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Controller Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:00:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:00:50 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:50 --> Session Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:00:50 --> Session routines successfully run
DEBUG - 2014-02-12 08:00:50 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:00:50 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:50 --> Upload Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Config Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:00:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:00:55 --> URI Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Router Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Output Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Security Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Input Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:00:55 --> Language Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Loader Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Controller Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:00:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:55 --> Session Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:00:55 --> Session routines successfully run
DEBUG - 2014-02-12 08:00:55 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:00:55 --> Model Class Initialized
DEBUG - 2014-02-12 08:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:00:55 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:00:55 --> Final output sent to browser
DEBUG - 2014-02-12 08:00:55 --> Total execution time: 0.0250
DEBUG - 2014-02-12 08:01:07 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:07 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:07 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:07 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:07 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:07 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:07 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:07 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:07 --> Upload Class Initialized
DEBUG - 2014-02-12 08:01:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 08:01:07 --> You did not select a file to upload.
DEBUG - 2014-02-12 08:01:17 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:17 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:17 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:17 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:17 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:17 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:01:17 --> Final output sent to browser
DEBUG - 2014-02-12 08:01:17 --> Total execution time: 0.0240
DEBUG - 2014-02-12 08:01:21 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:21 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:21 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:21 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:21 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:21 --> Upload Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 08:01:21 --> You did not select a file to upload.
ERROR - 2014-02-12 08:01:21 --> You did not select a file to upload.
DEBUG - 2014-02-12 08:01:21 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:21 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:21 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:21 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:21 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:21 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:21 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:01:21 --> Final output sent to browser
DEBUG - 2014-02-12 08:01:21 --> Total execution time: 0.0190
DEBUG - 2014-02-12 08:01:25 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:25 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:25 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:25 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:25 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:25 --> Upload Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 08:01:25 --> You did not select a file to upload.
ERROR - 2014-02-12 08:01:25 --> You did not select a file to upload.
DEBUG - 2014-02-12 08:01:25 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:25 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:25 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:25 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:25 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:25 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:25 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:25 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:01:25 --> Final output sent to browser
DEBUG - 2014-02-12 08:01:25 --> Total execution time: 0.0170
DEBUG - 2014-02-12 08:01:39 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:39 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:39 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:39 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:39 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:39 --> Upload Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-12 08:01:39 --> You did not select a file to upload.
DEBUG - 2014-02-12 08:01:39 --> Config Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:01:39 --> URI Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Router Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Output Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Security Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Input Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:01:39 --> Language Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Loader Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Controller Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:39 --> Session Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:01:39 --> Session routines successfully run
DEBUG - 2014-02-12 08:01:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:01:39 --> Model Class Initialized
DEBUG - 2014-02-12 08:01:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:01:39 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:01:39 --> Final output sent to browser
DEBUG - 2014-02-12 08:01:39 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:03:08 --> Config Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:03:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:03:08 --> URI Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Router Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Output Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Security Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Input Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:03:08 --> Language Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Loader Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Controller Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:03:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:03:08 --> Model Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Model Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Model Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:03:08 --> Session Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:03:08 --> Session routines successfully run
DEBUG - 2014-02-12 08:03:08 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:03:08 --> Model Class Initialized
DEBUG - 2014-02-12 08:03:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:03:08 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:03:08 --> Final output sent to browser
DEBUG - 2014-02-12 08:03:08 --> Total execution time: 0.0240
DEBUG - 2014-02-12 08:04:01 --> Config Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:04:01 --> URI Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Router Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Output Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Security Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Input Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:04:01 --> Language Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Loader Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Controller Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:04:01 --> Model Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Model Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Model Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:04:01 --> Session Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:04:01 --> Session routines successfully run
DEBUG - 2014-02-12 08:04:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:04:01 --> Model Class Initialized
DEBUG - 2014-02-12 08:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:04:01 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:04:01 --> Final output sent to browser
DEBUG - 2014-02-12 08:04:01 --> Total execution time: 0.0150
DEBUG - 2014-02-12 08:07:05 --> Config Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:07:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:07:05 --> URI Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Router Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Output Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Security Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Input Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:07:05 --> Language Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Loader Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Controller Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:07:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:07:05 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:07:05 --> Session Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:07:05 --> Session routines successfully run
DEBUG - 2014-02-12 08:07:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:07:05 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:07:05 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:07:05 --> Final output sent to browser
DEBUG - 2014-02-12 08:07:05 --> Total execution time: 0.0250
DEBUG - 2014-02-12 08:07:19 --> Config Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:07:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:07:19 --> URI Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Router Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Output Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Security Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Input Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:07:19 --> Language Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Loader Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Controller Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:07:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:07:19 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Model Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:07:19 --> Session Class Initialized
DEBUG - 2014-02-12 08:07:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:07:19 --> Session routines successfully run
DEBUG - 2014-02-12 08:07:19 --> Helper loaded: url_helper
ERROR - 2014-02-12 08:07:19 --> 404 Page Not Found --> admin/deactivateAd
DEBUG - 2014-02-12 08:10:17 --> Config Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:10:17 --> URI Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Router Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Output Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Security Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Input Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:10:17 --> Language Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Loader Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Controller Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:10:17 --> Session Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:10:17 --> Session routines successfully run
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:10:17 --> Config Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:10:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:10:17 --> URI Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Router Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Output Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Security Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Input Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:10:17 --> Language Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Loader Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Controller Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:10:17 --> Session Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:10:17 --> Session routines successfully run
DEBUG - 2014-02-12 08:10:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:10:17 --> Model Class Initialized
DEBUG - 2014-02-12 08:10:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:10:17 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:10:17 --> Final output sent to browser
DEBUG - 2014-02-12 08:10:17 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:15:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:15:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:15:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:15:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:15:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:15:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:15:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:15:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:15:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:36 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:15:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:15:36 --> Total execution time: 0.0230
DEBUG - 2014-02-12 08:15:49 --> Config Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:15:49 --> URI Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Router Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Output Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Security Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Input Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:15:49 --> Language Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Loader Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Controller Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:49 --> Session Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:15:49 --> Session routines successfully run
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:49 --> Config Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:15:49 --> URI Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Router Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Output Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Security Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Input Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:15:49 --> Language Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Loader Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Controller Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:49 --> Session Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:15:49 --> Session routines successfully run
DEBUG - 2014-02-12 08:15:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:15:49 --> Model Class Initialized
DEBUG - 2014-02-12 08:15:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:15:49 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:15:49 --> Final output sent to browser
DEBUG - 2014-02-12 08:15:49 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:19:59 --> Config Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:19:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:19:59 --> URI Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Router Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Output Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Security Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Input Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:19:59 --> Language Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Loader Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Controller Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:19:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:19:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:19:59 --> Session Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:19:59 --> Session routines successfully run
DEBUG - 2014-02-12 08:19:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:19:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:19:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:19:59 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:19:59 --> Final output sent to browser
DEBUG - 2014-02-12 08:19:59 --> Total execution time: 0.0290
DEBUG - 2014-02-12 08:20:11 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:11 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:11 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:11 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:11 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:16 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:16 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:16 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:16 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:16 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:16 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:16 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:20:16 --> Final output sent to browser
DEBUG - 2014-02-12 08:20:16 --> Total execution time: 0.0170
DEBUG - 2014-02-12 08:20:35 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:35 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:35 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:35 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:35 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:35 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:35 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:35 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:35 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:35 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:35 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:35 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:35 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:20:35 --> Final output sent to browser
DEBUG - 2014-02-12 08:20:35 --> Total execution time: 0.0140
DEBUG - 2014-02-12 08:20:46 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:46 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:46 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:46 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:46 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:46 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:46 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:46 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:46 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:46 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:46 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:46 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:20:46 --> Final output sent to browser
DEBUG - 2014-02-12 08:20:46 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:20:54 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:54 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:54 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:54 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:54 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:54 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:54 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:59 --> Config Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:20:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:20:59 --> URI Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Router Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Output Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Security Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Input Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:20:59 --> Language Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Loader Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Controller Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:20:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:20:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:59 --> Session Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:20:59 --> Session routines successfully run
DEBUG - 2014-02-12 08:20:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:20:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:20:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:20:59 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:20:59 --> Final output sent to browser
DEBUG - 2014-02-12 08:20:59 --> Total execution time: 0.0150
DEBUG - 2014-02-12 08:21:09 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:09 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:09 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:09 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:09 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:09 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:09 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:21:09 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:09 --> Total execution time: 0.0150
DEBUG - 2014-02-12 08:21:11 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:11 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:11 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:11 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:11 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:11 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:21:11 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:11 --> Total execution time: 0.0220
DEBUG - 2014-02-12 08:21:45 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:45 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:45 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:45 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:45 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:45 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:45 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:45 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-12 08:21:45 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:45 --> Total execution time: 0.0190
DEBUG - 2014-02-12 08:21:46 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:46 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:46 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:46 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:46 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:46 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:46 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:46 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-12 08:21:46 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:46 --> Total execution time: 0.0140
DEBUG - 2014-02-12 08:21:57 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:57 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:57 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:57 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:21:57 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:57 --> Total execution time: 0.0200
DEBUG - 2014-02-12 08:21:57 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:57 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:57 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:57 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:21:57 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:57 --> Total execution time: 0.0120
DEBUG - 2014-02-12 08:21:57 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:57 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:57 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:57 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:57 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:57 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:57 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:57 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:57 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:57 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:57 --> Total execution time: 0.0260
DEBUG - 2014-02-12 08:21:57 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:57 --> Total execution time: 0.0340
DEBUG - 2014-02-12 08:21:57 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:57 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:57 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:57 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:57 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:57 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:57 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:57 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:57 --> Total execution time: 0.0215
DEBUG - 2014-02-12 08:21:57 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:57 --> Total execution time: 0.0260
DEBUG - 2014-02-12 08:21:59 --> Config Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:21:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:21:59 --> URI Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Router Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Output Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Security Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Input Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:21:59 --> Language Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Loader Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Controller Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:21:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:21:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Model Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:21:59 --> Session Class Initialized
DEBUG - 2014-02-12 08:21:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:21:59 --> Session routines successfully run
DEBUG - 2014-02-12 08:21:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:21:59 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 08:21:59 --> Final output sent to browser
DEBUG - 2014-02-12 08:21:59 --> Total execution time: 0.0550
DEBUG - 2014-02-12 08:22:02 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:02 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:02 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:02 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:02 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:02 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 08:22:02 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:02 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:22:02 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:02 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:02 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:02 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:02 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:02 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:02 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:02 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:02 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:02 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:02 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:02 --> Total execution time: 0.0180
DEBUG - 2014-02-12 08:22:02 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:02 --> Total execution time: 0.0110
DEBUG - 2014-02-12 08:22:03 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:03 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:03 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:03 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:03 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:03 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:03 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 08:22:03 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:03 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:22:12 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:12 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:12 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:12 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:12 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:12 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 08:22:12 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:12 --> Total execution time: 0.0190
DEBUG - 2014-02-12 08:22:12 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:12 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:12 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:12 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:12 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:12 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:22:12 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:12 --> Total execution time: 0.0180
DEBUG - 2014-02-12 08:22:13 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:13 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:13 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:13 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:13 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:13 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:13 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:13 --> Total execution time: 0.0110
DEBUG - 2014-02-12 08:22:13 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:13 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:13 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:13 --> Total execution time: 0.0270
DEBUG - 2014-02-12 08:22:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:13 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:13 --> Total execution time: 0.0220
DEBUG - 2014-02-12 08:22:13 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:13 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:13 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:13 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:13 --> Total execution time: 0.0190
DEBUG - 2014-02-12 08:22:13 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:13 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:13 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:13 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:13 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:13 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 08:22:13 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:13 --> Total execution time: 0.0140
DEBUG - 2014-02-12 08:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:14 --> Total execution time: 0.0200
DEBUG - 2014-02-12 08:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:14 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Total execution time: 0.0170
DEBUG - 2014-02-12 08:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:14 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:14 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:14 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:14 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:14 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:14 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:14 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:14 --> Total execution time: 0.0240
DEBUG - 2014-02-12 08:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:14 --> Total execution time: 0.0300
DEBUG - 2014-02-12 08:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:14 --> Total execution time: 0.0320
DEBUG - 2014-02-12 08:22:14 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:14 --> Total execution time: 0.0370
DEBUG - 2014-02-12 08:22:16 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:16 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:16 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:16 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:16 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:16 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:16 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:16 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:22:16 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:16 --> Total execution time: 0.0190
DEBUG - 2014-02-12 08:22:18 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:18 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:18 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:18 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:18 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:18 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:18 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:18 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:18 --> Total execution time: 0.0210
DEBUG - 2014-02-12 08:22:20 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:20 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:20 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:20 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:20 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:20 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:20 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 08:22:20 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:20 --> Total execution time: 0.0120
DEBUG - 2014-02-12 08:22:20 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:20 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:20 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:20 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:20 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:20 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:20 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:20 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:20 --> Total execution time: 0.0090
DEBUG - 2014-02-12 08:22:21 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:21 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:21 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:21 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:21 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:21 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:21 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 08:22:21 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:21 --> Total execution time: 0.0230
DEBUG - 2014-02-12 08:22:31 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:31 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:31 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:31 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:31 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:31 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:31 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:22:31 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:31 --> Total execution time: 0.0120
DEBUG - 2014-02-12 08:22:32 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:32 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:32 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:32 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:32 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:32 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:32 --> Total execution time: 0.0220
DEBUG - 2014-02-12 08:22:32 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:32 --> Total execution time: 0.0280
DEBUG - 2014-02-12 08:22:32 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:32 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:32 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:32 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:32 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:32 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:32 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:32 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:32 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:32 --> Total execution time: 0.0150
DEBUG - 2014-02-12 08:22:32 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:32 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:32 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:32 --> Total execution time: 0.0200
DEBUG - 2014-02-12 08:22:42 --> Config Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:22:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:22:42 --> URI Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Router Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Output Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Security Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Input Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:22:42 --> Language Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Loader Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Controller Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:22:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:22:42 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:42 --> Session Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:22:42 --> Session routines successfully run
DEBUG - 2014-02-12 08:22:42 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:22:42 --> Model Class Initialized
DEBUG - 2014-02-12 08:22:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:22:42 --> Final output sent to browser
DEBUG - 2014-02-12 08:22:42 --> Total execution time: 0.0220
DEBUG - 2014-02-12 08:24:11 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:11 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:11 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:11 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:11 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:11 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 08:24:11 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:11 --> Total execution time: 0.0230
DEBUG - 2014-02-12 08:24:11 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:11 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:11 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:11 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:11 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:11 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:11 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:11 --> Total execution time: 0.0110
DEBUG - 2014-02-12 08:24:13 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:13 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:13 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:13 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:13 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:13 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 08:24:13 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:13 --> Total execution time: 0.0220
DEBUG - 2014-02-12 08:24:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:36 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:24:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:36 --> Total execution time: 0.0170
DEBUG - 2014-02-12 08:24:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:36 --> Total execution time: 0.0120
DEBUG - 2014-02-12 08:24:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:36 --> Total execution time: 0.0310
DEBUG - 2014-02-12 08:24:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:36 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 08:24:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:36 --> Total execution time: 0.0120
DEBUG - 2014-02-12 08:24:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:36 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:36 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:36 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:36 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:36 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:36 --> Total execution time: 0.0140
DEBUG - 2014-02-12 08:24:36 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:36 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:36 --> Total execution time: 0.0180
DEBUG - 2014-02-12 08:24:37 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:37 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:37 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:37 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:37 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:37 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:37 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:37 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:37 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 08:24:37 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:37 --> Total execution time: 0.0200
DEBUG - 2014-02-12 08:24:38 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:38 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:38 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:38 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:38 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:38 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:38 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:38 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:38 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:38 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:38 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:38 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:38 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:38 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:38 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Total execution time: 0.0160
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:38 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:38 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:38 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:38 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:38 --> Total execution time: 0.0230
DEBUG - 2014-02-12 08:24:38 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:38 --> Total execution time: 0.0430
DEBUG - 2014-02-12 08:24:38 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:38 --> Total execution time: 0.0440
DEBUG - 2014-02-12 08:24:41 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:41 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:41 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:41 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:41 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:41 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:41 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:41 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:41 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:41 --> Total execution time: 0.0290
DEBUG - 2014-02-12 08:24:43 --> Config Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Hooks Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Utf8 Class Initialized
DEBUG - 2014-02-12 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 08:24:43 --> URI Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Router Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Output Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Security Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Input Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 08:24:43 --> Language Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Loader Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Controller Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 08:24:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 08:24:43 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Database Driver Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:43 --> Session Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Helper loaded: string_helper
DEBUG - 2014-02-12 08:24:43 --> Session routines successfully run
DEBUG - 2014-02-12 08:24:43 --> Helper loaded: url_helper
DEBUG - 2014-02-12 08:24:43 --> Model Class Initialized
DEBUG - 2014-02-12 08:24:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 08:24:43 --> Final output sent to browser
DEBUG - 2014-02-12 08:24:43 --> Total execution time: 0.0230
DEBUG - 2014-02-12 18:06:25 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:25 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:25 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:25 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Database Driver Class Initialized
ERROR - 2014-02-12 18:06:25 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 18:06:25 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:25 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:25 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:25 --> A session cookie was not found.
DEBUG - 2014-02-12 18:06:25 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:25 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:30 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:30 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:30 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:30 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:30 --> Database Driver Class Initialized
ERROR - 2014-02-12 18:06:30 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 18:06:31 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:31 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:31 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:31 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:31 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:31 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-12 18:06:31 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:31 --> Total execution time: 0.0390
DEBUG - 2014-02-12 18:06:33 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:33 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:33 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Database Driver Class Initialized
ERROR - 2014-02-12 18:06:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:33 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:33 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:33 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:33 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:33 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Database Driver Class Initialized
ERROR - 2014-02-12 18:06:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:33 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:33 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:33 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:33 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:33 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Database Driver Class Initialized
ERROR - 2014-02-12 18:06:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-12 18:06:33 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:33 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:33 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:33 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 18:06:33 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:33 --> Total execution time: 0.0130
DEBUG - 2014-02-12 18:06:34 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:34 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:34 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:34 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:34 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:34 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:34 --> Total execution time: 0.0250
DEBUG - 2014-02-12 18:06:34 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:34 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:34 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:34 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:34 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:34 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:34 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:34 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:34 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:34 --> Total execution time: 0.0300
DEBUG - 2014-02-12 18:06:34 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:34 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:34 --> Total execution time: 0.0610
DEBUG - 2014-02-12 18:06:35 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:35 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:35 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:35 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:35 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:35 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:35 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:35 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:35 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 18:06:35 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:35 --> Total execution time: 0.0220
DEBUG - 2014-02-12 18:06:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:39 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:06:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:39 --> Total execution time: 0.0160
DEBUG - 2014-02-12 18:06:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:39 --> Total execution time: 0.0110
DEBUG - 2014-02-12 18:06:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:39 --> Total execution time: 0.0170
DEBUG - 2014-02-12 18:06:49 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:49 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:49 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:49 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:49 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:49 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:49 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 18:06:49 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:49 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:06:49 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:49 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:49 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:49 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:49 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:49 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:49 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:49 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:49 --> Total execution time: 0.0100
DEBUG - 2014-02-12 18:06:52 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:52 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:52 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:52 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:52 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 18:06:52 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:52 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:06:52 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:52 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:52 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:52 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:52 --> Total execution time: 0.0250
DEBUG - 2014-02-12 18:06:52 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:52 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:52 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:52 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:52 --> Total execution time: 0.0160
DEBUG - 2014-02-12 18:06:52 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:52 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:52 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:52 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:52 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:52 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:52 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:52 --> Total execution time: 0.0180
DEBUG - 2014-02-12 18:06:55 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:55 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:55 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:55 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:55 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:55 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:55 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:55 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:06:55 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:55 --> Total execution time: 0.0150
DEBUG - 2014-02-12 18:06:57 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Config Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:06:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:57 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:06:57 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:06:57 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:57 --> URI Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Router Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Output Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Security Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Input Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:57 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:06:57 --> Language Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Loader Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Controller Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:57 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Session Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:06:57 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:57 --> Session routines successfully run
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:57 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Model Class Initialized
DEBUG - 2014-02-12 18:06:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:06:57 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:57 --> Total execution time: 0.0220
DEBUG - 2014-02-12 18:06:57 --> Final output sent to browser
DEBUG - 2014-02-12 18:06:57 --> Total execution time: 0.0270
DEBUG - 2014-02-12 18:07:13 --> Config Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:07:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:07:13 --> URI Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Router Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Output Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Security Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Input Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:07:13 --> Language Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Loader Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Controller Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:07:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:07:13 --> Model Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Model Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Model Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:07:13 --> Session Class Initialized
DEBUG - 2014-02-12 18:07:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:07:13 --> Session routines successfully run
DEBUG - 2014-02-12 18:07:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:07:13 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 18:07:13 --> Final output sent to browser
DEBUG - 2014-02-12 18:07:13 --> Total execution time: 0.0220
DEBUG - 2014-02-12 18:08:28 --> Config Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:08:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:08:28 --> URI Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Router Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Output Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Security Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Input Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:08:28 --> Language Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Loader Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Controller Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:08:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:08:28 --> Model Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Model Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Model Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:08:28 --> Session Class Initialized
DEBUG - 2014-02-12 18:08:28 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:08:28 --> Session routines successfully run
DEBUG - 2014-02-12 18:08:28 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:08:28 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:08:28 --> Final output sent to browser
DEBUG - 2014-02-12 18:08:28 --> Total execution time: 0.0230
DEBUG - 2014-02-12 18:20:10 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:10 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:10 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:10 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:10 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:10 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:10 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:10 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:10 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 18:20:10 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:10 --> Total execution time: 0.0300
DEBUG - 2014-02-12 18:20:12 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:12 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:12 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:12 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:12 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:12 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:12 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:12 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:12 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:12 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:12 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:12 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:12 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:12 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:12 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:12 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Total execution time: 0.0120
DEBUG - 2014-02-12 18:20:12 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:12 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:12 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:12 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:12 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:12 --> Total execution time: 0.0230
DEBUG - 2014-02-12 18:20:12 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:12 --> Total execution time: 0.0350
DEBUG - 2014-02-12 18:20:12 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:12 --> Total execution time: 0.0410
DEBUG - 2014-02-12 18:20:19 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:19 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:19 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:19 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:19 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:19 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:19 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:19 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:19 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:19 --> Total execution time: 0.0200
DEBUG - 2014-02-12 18:20:22 --> Config Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:20:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:20:22 --> URI Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Router Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Output Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Security Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Input Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:20:22 --> Language Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Loader Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Controller Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:20:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:20:22 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:22 --> Session Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:20:22 --> Session routines successfully run
DEBUG - 2014-02-12 18:20:22 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:20:22 --> Model Class Initialized
DEBUG - 2014-02-12 18:20:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:20:22 --> Final output sent to browser
DEBUG - 2014-02-12 18:20:22 --> Total execution time: 0.0150
DEBUG - 2014-02-12 18:22:21 --> Config Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:22:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:22:21 --> URI Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Router Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Output Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Security Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Input Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:22:21 --> Language Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Loader Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Controller Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:22:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Model Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:22:21 --> Session Class Initialized
DEBUG - 2014-02-12 18:22:21 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:22:21 --> Session routines successfully run
DEBUG - 2014-02-12 18:22:21 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:22:21 --> Final output sent to browser
DEBUG - 2014-02-12 18:22:21 --> Total execution time: 0.0240
DEBUG - 2014-02-12 18:22:30 --> Config Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:22:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:22:30 --> URI Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Router Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Output Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Security Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Input Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:22:30 --> Language Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Loader Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Controller Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:22:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:22:30 --> Model Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Model Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Model Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:22:30 --> Session Class Initialized
DEBUG - 2014-02-12 18:22:30 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:22:30 --> Session routines successfully run
DEBUG - 2014-02-12 18:22:30 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:22:30 --> Final output sent to browser
DEBUG - 2014-02-12 18:22:30 --> Total execution time: 0.0200
DEBUG - 2014-02-12 18:25:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 18:25:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:39 --> Total execution time: 0.0270
DEBUG - 2014-02-12 18:25:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:39 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:39 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:39 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:39 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:39 --> Total execution time: 0.0170
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:39 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:39 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:39 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:39 --> Total execution time: 0.0230
DEBUG - 2014-02-12 18:25:39 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:39 --> Total execution time: 0.0360
DEBUG - 2014-02-12 18:25:43 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:43 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:43 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:43 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:43 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:43 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:43 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:43 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:43 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:43 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:25:44 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:44 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:44 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:44 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:44 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:44 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:44 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:44 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:44 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:44 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:44 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:44 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:25:44 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:44 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:44 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:44 --> Total execution time: 0.0200
DEBUG - 2014-02-12 18:25:50 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:50 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:50 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:50 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:50 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:50 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:50 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:50 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:50 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:50 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:25:59 --> Config Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:25:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:25:59 --> URI Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Router Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Output Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Security Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Input Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:25:59 --> Language Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Loader Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Controller Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:25:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:25:59 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Model Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:25:59 --> Session Class Initialized
DEBUG - 2014-02-12 18:25:59 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:25:59 --> Session routines successfully run
DEBUG - 2014-02-12 18:25:59 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:25:59 --> Final output sent to browser
DEBUG - 2014-02-12 18:25:59 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:26:01 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:01 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:01 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:01 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:01 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:01 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:01 --> Total execution time: 0.0120
DEBUG - 2014-02-12 18:26:04 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:04 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:04 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:04 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:04 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:04 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:04 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:04 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:04 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:04 --> Total execution time: 0.0170
DEBUG - 2014-02-12 18:26:09 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:09 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:09 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:09 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:09 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:09 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:09 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:09 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:09 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:09 --> Total execution time: 0.0170
DEBUG - 2014-02-12 18:26:17 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:17 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:17 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:17 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:17 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:17 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:17 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:17 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:17 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:17 --> Total execution time: 0.0160
DEBUG - 2014-02-12 18:26:29 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:29 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:29 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:29 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:29 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:29 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:29 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:29 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:29 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-12 18:26:29 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:29 --> Total execution time: 0.0170
DEBUG - 2014-02-12 18:26:55 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:55 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:55 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:55 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:55 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:55 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:55 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:55 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-12 18:26:55 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:55 --> Total execution time: 0.0440
DEBUG - 2014-02-12 18:26:56 --> Config Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:26:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:26:56 --> URI Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Router Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Output Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Security Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Input Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:26:56 --> Language Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Loader Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Controller Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:26:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:26:56 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Model Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:26:56 --> Session Class Initialized
DEBUG - 2014-02-12 18:26:56 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:26:56 --> Session routines successfully run
DEBUG - 2014-02-12 18:26:56 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:26:56 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-12 18:26:56 --> Final output sent to browser
DEBUG - 2014-02-12 18:26:56 --> Total execution time: 0.0140
DEBUG - 2014-02-12 18:27:01 --> Config Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:27:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:27:01 --> URI Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Router Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Output Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Security Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Input Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:27:01 --> Language Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Loader Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Controller Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:27:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:27:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:27:01 --> Session Class Initialized
DEBUG - 2014-02-12 18:27:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:27:01 --> Session routines successfully run
DEBUG - 2014-02-12 18:27:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:27:01 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 18:27:01 --> Final output sent to browser
DEBUG - 2014-02-12 18:27:01 --> Total execution time: 0.0130
DEBUG - 2014-02-12 18:27:04 --> Config Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:27:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:27:04 --> URI Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Router Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Output Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Security Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Input Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:27:04 --> Language Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Loader Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Controller Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:27:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:27:04 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:27:04 --> Session Class Initialized
DEBUG - 2014-02-12 18:27:04 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:27:04 --> Session routines successfully run
DEBUG - 2014-02-12 18:27:04 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:27:04 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:27:04 --> Final output sent to browser
DEBUG - 2014-02-12 18:27:04 --> Total execution time: 0.0470
DEBUG - 2014-02-12 18:27:06 --> Config Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:27:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:27:06 --> URI Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Router Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Output Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Security Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Input Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:27:06 --> Language Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Loader Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Controller Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:27:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:27:06 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:27:06 --> Session Class Initialized
DEBUG - 2014-02-12 18:27:06 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:27:06 --> Session routines successfully run
DEBUG - 2014-02-12 18:27:06 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:27:06 --> Final output sent to browser
DEBUG - 2014-02-12 18:27:06 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:27:13 --> Config Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:27:13 --> URI Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Router Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Output Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Security Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Input Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:27:13 --> Language Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Loader Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Controller Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:27:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:27:13 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:27:13 --> Session Class Initialized
DEBUG - 2014-02-12 18:27:13 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:27:13 --> Session routines successfully run
DEBUG - 2014-02-12 18:27:13 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:27:13 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 18:27:13 --> Final output sent to browser
DEBUG - 2014-02-12 18:27:13 --> Total execution time: 0.0230
DEBUG - 2014-02-12 18:27:25 --> Config Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:27:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:27:25 --> URI Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Router Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Output Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Security Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Input Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:27:25 --> Language Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Loader Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Controller Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:27:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:27:25 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Model Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:27:25 --> Session Class Initialized
DEBUG - 2014-02-12 18:27:25 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:27:25 --> Session routines successfully run
DEBUG - 2014-02-12 18:27:25 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:27:25 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:27:25 --> Final output sent to browser
DEBUG - 2014-02-12 18:27:25 --> Total execution time: 0.0200
DEBUG - 2014-02-12 18:28:26 --> Config Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:28:26 --> URI Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Router Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Output Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Security Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Input Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:28:26 --> Language Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Loader Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Controller Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:28:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:28:26 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:28:26 --> Session Class Initialized
DEBUG - 2014-02-12 18:28:26 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:28:26 --> Session routines successfully run
DEBUG - 2014-02-12 18:28:26 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:28:26 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:28:26 --> Final output sent to browser
DEBUG - 2014-02-12 18:28:26 --> Total execution time: 0.0500
DEBUG - 2014-02-12 18:28:28 --> Config Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:28:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:28:28 --> URI Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Router Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Output Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Security Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Input Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:28:28 --> Language Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Loader Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Controller Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:28:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:28:28 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:28:28 --> Session Class Initialized
DEBUG - 2014-02-12 18:28:28 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:28:28 --> Session routines successfully run
DEBUG - 2014-02-12 18:28:28 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:28:28 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:28:28 --> Final output sent to browser
DEBUG - 2014-02-12 18:28:28 --> Total execution time: 0.0160
DEBUG - 2014-02-12 18:28:54 --> Config Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:28:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:28:54 --> URI Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Router Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Output Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Security Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Input Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:28:54 --> Language Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Loader Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Controller Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:28:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:28:54 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Model Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:28:54 --> Session Class Initialized
DEBUG - 2014-02-12 18:28:54 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:28:54 --> Session routines successfully run
DEBUG - 2014-02-12 18:28:54 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:28:54 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 18:28:54 --> Final output sent to browser
DEBUG - 2014-02-12 18:28:54 --> Total execution time: 0.0210
DEBUG - 2014-02-12 18:29:00 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:00 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:00 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:00 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:00 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-12 18:29:00 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:00 --> Total execution time: 0.0130
DEBUG - 2014-02-12 18:29:00 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:00 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:00 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:00 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:00 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:00 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:00 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:00 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:00 --> Total execution time: 0.0120
DEBUG - 2014-02-12 18:29:00 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:00 --> Total execution time: 0.0240
DEBUG - 2014-02-12 18:29:00 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:00 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:00 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:00 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:00 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:00 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:00 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:00 --> Total execution time: 0.0160
DEBUG - 2014-02-12 18:29:01 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:01 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:01 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:01 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:01 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:01 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:01 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:01 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-12 18:29:01 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:01 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:29:02 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:02 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:02 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:02 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:02 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:02 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:02 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:02 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:02 --> Total execution time: 0.0100
DEBUG - 2014-02-12 18:29:03 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:03 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:03 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:03 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:03 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:03 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:03 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:03 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-12 18:29:03 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:03 --> Total execution time: 0.0190
DEBUG - 2014-02-12 18:29:05 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:05 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:05 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:05 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:05 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:05 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-12 18:29:05 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:05 --> Total execution time: 0.0180
DEBUG - 2014-02-12 18:29:05 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:05 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:05 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Config Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Hooks Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Utf8 Class Initialized
DEBUG - 2014-02-12 18:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-12 18:29:05 --> URI Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Router Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Output Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Security Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Input Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-12 18:29:05 --> Language Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Loader Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Controller Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Database Driver Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:05 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:05 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:05 --> Session Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: string_helper
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:05 --> Session routines successfully run
DEBUG - 2014-02-12 18:29:05 --> Helper loaded: url_helper
DEBUG - 2014-02-12 18:29:05 --> Model Class Initialized
DEBUG - 2014-02-12 18:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-12 18:29:05 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:05 --> Total execution time: 0.0290
DEBUG - 2014-02-12 18:29:05 --> Final output sent to browser
DEBUG - 2014-02-12 18:29:05 --> Total execution time: 0.0180
