<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-21 23:15:18 --> Config Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:15:18 --> URI Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Router Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Output Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Security Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Input Class Initialized
DEBUG - 2014-01-21 23:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:15:18 --> Language Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Loader Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Controller Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:15:19 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-21 23:15:22 --> Final output sent to browser
DEBUG - 2014-01-21 23:15:22 --> Total execution time: 4.1732
DEBUG - 2014-01-21 23:15:25 --> Config Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:15:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:15:25 --> URI Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Router Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Output Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Security Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Input Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:15:25 --> Language Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Loader Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Controller Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:15:25 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:15:25 --> Final output sent to browser
DEBUG - 2014-01-21 23:15:25 --> Total execution time: 0.0250
DEBUG - 2014-01-21 23:15:30 --> Config Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:15:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:15:30 --> URI Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Router Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Output Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Security Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Input Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:15:30 --> Language Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Loader Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Controller Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:15:30 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:15:30 --> Final output sent to browser
DEBUG - 2014-01-21 23:15:30 --> Total execution time: 0.0090
DEBUG - 2014-01-21 23:15:38 --> Config Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:15:38 --> URI Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Router Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Output Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Security Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Input Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:15:38 --> Language Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Loader Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Controller Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-21 23:15:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-21 23:15:38 --> Final output sent to browser
DEBUG - 2014-01-21 23:15:38 --> Total execution time: 0.0160
DEBUG - 2014-01-21 23:15:41 --> Config Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:15:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:15:41 --> URI Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Router Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Output Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Security Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Input Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:15:41 --> Language Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Loader Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Controller Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:15:41 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-21 23:15:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-21 23:15:41 --> Final output sent to browser
DEBUG - 2014-01-21 23:15:41 --> Total execution time: 0.0160
DEBUG - 2014-01-21 23:15:54 --> Config Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:15:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:15:54 --> URI Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Router Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Output Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Security Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Input Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:15:54 --> Language Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Loader Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Controller Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:15:54 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Model Class Initialized
DEBUG - 2014-01-21 23:15:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-21 23:15:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-21 23:15:58 --> Final output sent to browser
DEBUG - 2014-01-21 23:15:58 --> Total execution time: 3.9492
DEBUG - 2014-01-21 23:20:17 --> Config Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Hooks Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Utf8 Class Initialized
DEBUG - 2014-01-21 23:20:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-21 23:20:17 --> URI Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Router Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Output Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Security Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Input Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-21 23:20:17 --> Language Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Loader Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Controller Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-21 23:20:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-21 23:20:17 --> Model Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Model Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Database Driver Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Model Class Initialized
DEBUG - 2014-01-21 23:20:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-21 23:23:21 --> Final output sent to browser
DEBUG - 2014-01-21 23:23:21 --> Total execution time: 183.9735
