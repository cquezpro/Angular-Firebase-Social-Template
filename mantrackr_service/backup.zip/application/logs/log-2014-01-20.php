<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-20 04:53:04 --> Config Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:53:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:53:04 --> URI Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Router Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Output Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Security Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Input Class Initialized
DEBUG - 2014-01-20 04:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:53:04 --> Language Class Initialized
DEBUG - 2014-01-20 04:53:06 --> Loader Class Initialized
DEBUG - 2014-01-20 04:53:06 --> Controller Class Initialized
DEBUG - 2014-01-20 04:53:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:53:07 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:07 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:07 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:53:12 --> Final output sent to browser
DEBUG - 2014-01-20 04:53:12 --> Total execution time: 8.6375
DEBUG - 2014-01-20 04:53:16 --> Config Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:53:16 --> URI Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Router Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Output Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Security Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Input Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:53:16 --> Language Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Loader Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Controller Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:53:16 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:16 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:53:17 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 04:53:25 --> Final output sent to browser
DEBUG - 2014-01-20 04:53:25 --> Total execution time: 8.5345
DEBUG - 2014-01-20 04:53:43 --> Config Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:53:43 --> URI Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Router Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Output Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Security Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Input Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:53:43 --> Language Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Loader Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Controller Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:53:43 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:43 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:53:45 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 04:53:47 --> Final output sent to browser
DEBUG - 2014-01-20 04:53:47 --> Total execution time: 4.0872
DEBUG - 2014-01-20 04:53:54 --> Config Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:53:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:53:54 --> URI Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Router Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Output Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Security Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Input Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:53:54 --> Language Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Loader Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Controller Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:53:54 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 04:53:54 --> Final output sent to browser
DEBUG - 2014-01-20 04:53:54 --> Total execution time: 0.0150
DEBUG - 2014-01-20 04:53:58 --> Config Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:53:58 --> URI Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Router Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Output Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Security Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Input Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:53:58 --> Language Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Loader Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Controller Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:53:58 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Model Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:53:58 --> Final output sent to browser
DEBUG - 2014-01-20 04:53:58 --> Total execution time: 0.0140
DEBUG - 2014-01-20 04:54:08 --> Config Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:54:08 --> URI Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Router Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Output Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Security Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Input Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:54:08 --> Language Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Loader Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Controller Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:54:08 --> Model Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Model Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Model Class Initialized
DEBUG - 2014-01-20 04:54:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 04:54:09 --> Final output sent to browser
DEBUG - 2014-01-20 04:54:09 --> Total execution time: 0.5700
DEBUG - 2014-01-20 04:59:37 --> Config Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:59:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:59:37 --> URI Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Router Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Output Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Security Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Input Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:59:37 --> Language Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Loader Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Controller Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:59:37 --> Model Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Model Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:59:37 --> Final output sent to browser
DEBUG - 2014-01-20 04:59:37 --> Total execution time: 0.0150
DEBUG - 2014-01-20 04:59:42 --> Config Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Hooks Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Utf8 Class Initialized
DEBUG - 2014-01-20 04:59:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 04:59:42 --> URI Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Router Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Output Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Security Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Input Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 04:59:42 --> Language Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Loader Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Controller Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 04:59:42 --> Model Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Model Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Database Driver Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Model Class Initialized
DEBUG - 2014-01-20 04:59:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 04:59:45 --> Final output sent to browser
DEBUG - 2014-01-20 04:59:45 --> Total execution time: 2.9062
DEBUG - 2014-01-20 05:00:14 --> Config Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:00:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:00:14 --> URI Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Router Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Output Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Security Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Input Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:00:14 --> Language Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Loader Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Controller Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:00:14 --> Model Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Model Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Model Class Initialized
DEBUG - 2014-01-20 05:00:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:00:19 --> Final output sent to browser
DEBUG - 2014-01-20 05:00:19 --> Total execution time: 5.3633
DEBUG - 2014-01-20 05:01:48 --> Config Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:01:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:01:48 --> URI Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Router Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Output Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Security Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Input Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:01:48 --> Language Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Loader Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Controller Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:01:48 --> Model Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Model Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Model Class Initialized
DEBUG - 2014-01-20 05:01:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:01:52 --> Final output sent to browser
DEBUG - 2014-01-20 05:01:52 --> Total execution time: 3.2402
DEBUG - 2014-01-20 05:02:03 --> Config Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:02:03 --> URI Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Router Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Output Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Security Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Input Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:02:03 --> Language Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Loader Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Controller Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:02:03 --> Model Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Model Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Model Class Initialized
DEBUG - 2014-01-20 05:02:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:02:05 --> Final output sent to browser
DEBUG - 2014-01-20 05:02:05 --> Total execution time: 2.5661
DEBUG - 2014-01-20 05:02:19 --> Config Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:02:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:02:19 --> URI Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Router Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Output Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Security Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Input Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:02:19 --> Language Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Loader Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Controller Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:02:19 --> Model Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Model Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Model Class Initialized
DEBUG - 2014-01-20 05:02:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:02:21 --> Final output sent to browser
DEBUG - 2014-01-20 05:02:21 --> Total execution time: 2.3921
DEBUG - 2014-01-20 05:13:11 --> Config Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:13:11 --> URI Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Router Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Output Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Security Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Input Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:13:11 --> Language Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Loader Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Controller Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:13:11 --> Model Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Model Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Model Class Initialized
DEBUG - 2014-01-20 05:13:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:13:15 --> Final output sent to browser
DEBUG - 2014-01-20 05:13:15 --> Total execution time: 3.1622
DEBUG - 2014-01-20 05:15:17 --> Config Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:15:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:15:17 --> URI Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Router Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Output Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Security Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Input Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:15:17 --> Language Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Loader Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Controller Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:15:17 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:15:20 --> Final output sent to browser
DEBUG - 2014-01-20 05:15:20 --> Total execution time: 3.0322
DEBUG - 2014-01-20 05:15:23 --> Config Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:15:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:15:23 --> URI Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Router Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Output Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Security Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Input Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:15:23 --> Language Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Loader Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Controller Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:15:23 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:15:25 --> Final output sent to browser
DEBUG - 2014-01-20 05:15:25 --> Total execution time: 2.6102
DEBUG - 2014-01-20 05:15:40 --> Config Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:15:40 --> URI Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Router Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Output Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Security Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Input Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:15:40 --> Language Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Loader Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Controller Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:15:40 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:40 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:15:42 --> Model Class Initialized
DEBUG - 2014-01-20 05:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:15:45 --> Final output sent to browser
DEBUG - 2014-01-20 05:15:45 --> Total execution time: 5.5793
DEBUG - 2014-01-20 05:17:34 --> Config Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Hooks Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Utf8 Class Initialized
DEBUG - 2014-01-20 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 05:17:34 --> URI Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Router Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Output Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Security Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Input Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 05:17:34 --> Language Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Loader Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Controller Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 05:17:34 --> Model Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Model Class Initialized
DEBUG - 2014-01-20 05:17:34 --> Database Driver Class Initialized
DEBUG - 2014-01-20 05:17:35 --> Model Class Initialized
DEBUG - 2014-01-20 05:17:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 05:17:38 --> Final output sent to browser
DEBUG - 2014-01-20 05:17:38 --> Total execution time: 4.5753
DEBUG - 2014-01-20 06:29:36 --> Config Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:29:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:29:36 --> URI Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Router Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Output Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Security Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Input Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:29:36 --> Language Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Loader Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Controller Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:29:36 --> Model Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Model Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:29:36 --> Final output sent to browser
DEBUG - 2014-01-20 06:29:36 --> Total execution time: 0.0160
DEBUG - 2014-01-20 06:29:41 --> Config Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:29:41 --> URI Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Router Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Output Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Security Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Input Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:29:41 --> Language Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Loader Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Controller Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:29:41 --> Model Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Model Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:29:41 --> Final output sent to browser
DEBUG - 2014-01-20 06:29:41 --> Total execution time: 0.0160
DEBUG - 2014-01-20 06:30:00 --> Config Class Initialized
DEBUG - 2014-01-20 06:30:00 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:30:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:30:01 --> URI Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Router Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Output Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Security Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Input Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:30:01 --> Language Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Loader Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Controller Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:30:01 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:01 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:30:06 --> Final output sent to browser
DEBUG - 2014-01-20 06:30:06 --> Total execution time: 5.8003
DEBUG - 2014-01-20 06:30:22 --> Config Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:30:22 --> URI Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Router Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Output Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Security Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Input Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:30:22 --> Language Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Loader Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Controller Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:30:22 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:30:25 --> Final output sent to browser
DEBUG - 2014-01-20 06:30:25 --> Total execution time: 3.2732
DEBUG - 2014-01-20 06:30:46 --> Config Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:30:46 --> URI Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Router Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Output Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Security Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Input Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:30:46 --> Language Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Loader Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Controller Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:30:46 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:30:46 --> Upload Class Initialized
DEBUG - 2014-01-20 06:30:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:30:47 --> You did not select a file to upload.
DEBUG - 2014-01-20 06:30:47 --> Final output sent to browser
DEBUG - 2014-01-20 06:30:47 --> Total execution time: 0.4890
DEBUG - 2014-01-20 06:30:55 --> Config Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:30:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:30:55 --> URI Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Router Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Output Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Security Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Input Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:30:55 --> Language Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Loader Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Controller Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:30:55 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Model Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:30:55 --> Upload Class Initialized
DEBUG - 2014-01-20 06:30:55 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:30:55 --> You did not select a file to upload.
DEBUG - 2014-01-20 06:30:55 --> Final output sent to browser
DEBUG - 2014-01-20 06:30:55 --> Total execution time: 0.0560
DEBUG - 2014-01-20 06:31:20 --> Config Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:31:20 --> URI Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Router Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Output Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Security Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Input Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:31:20 --> Language Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Loader Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Controller Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:31:20 --> Model Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Model Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Model Class Initialized
DEBUG - 2014-01-20 06:31:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:31:21 --> Upload Class Initialized
DEBUG - 2014-01-20 06:31:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:31:21 --> You did not select a file to upload.
DEBUG - 2014-01-20 06:31:21 --> Final output sent to browser
DEBUG - 2014-01-20 06:31:21 --> Total execution time: 0.0950
DEBUG - 2014-01-20 06:31:40 --> Config Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:31:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:31:40 --> URI Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Router Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Output Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Security Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Input Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:31:40 --> Language Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Loader Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Controller Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:31:40 --> Model Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Model Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Model Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:31:40 --> Upload Class Initialized
DEBUG - 2014-01-20 06:31:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:31:40 --> You did not select a file to upload.
DEBUG - 2014-01-20 06:31:40 --> Final output sent to browser
DEBUG - 2014-01-20 06:31:40 --> Total execution time: 0.0170
DEBUG - 2014-01-20 06:32:06 --> Config Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:32:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:32:06 --> URI Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Router Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Output Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Security Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Input Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:32:06 --> Language Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Loader Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Controller Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:32:06 --> Model Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Model Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Model Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:32:06 --> Upload Class Initialized
DEBUG - 2014-01-20 06:32:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:32:06 --> You did not select a file to upload.
DEBUG - 2014-01-20 06:32:06 --> Final output sent to browser
DEBUG - 2014-01-20 06:32:06 --> Total execution time: 0.1060
DEBUG - 2014-01-20 06:32:24 --> Config Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:32:24 --> URI Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Router Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Output Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Security Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Input Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:32:24 --> Language Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Loader Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Controller Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:32:24 --> Model Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Model Class Initialized
DEBUG - 2014-01-20 06:32:24 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:32:26 --> Model Class Initialized
DEBUG - 2014-01-20 06:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:33:46 --> Upload Class Initialized
DEBUG - 2014-01-20 06:33:51 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:33:51 --> You did not select a file to upload.
DEBUG - 2014-01-20 06:33:51 --> Final output sent to browser
DEBUG - 2014-01-20 06:33:51 --> Total execution time: 87.1000
DEBUG - 2014-01-20 06:35:10 --> Config Class Initialized
DEBUG - 2014-01-20 06:35:10 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:35:10 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:35:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:35:10 --> URI Class Initialized
DEBUG - 2014-01-20 06:35:10 --> Router Class Initialized
DEBUG - 2014-01-20 06:35:10 --> Output Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Security Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Input Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:35:11 --> Language Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Loader Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Controller Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:35:11 --> Model Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Model Class Initialized
DEBUG - 2014-01-20 06:35:11 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:35:12 --> Model Class Initialized
DEBUG - 2014-01-20 06:35:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:35:15 --> Upload Class Initialized
DEBUG - 2014-01-20 06:35:36 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-01-20 06:35:36 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2014-01-20 06:35:36 --> Final output sent to browser
DEBUG - 2014-01-20 06:35:36 --> Total execution time: 25.1004
DEBUG - 2014-01-20 06:35:58 --> Config Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:35:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:35:58 --> URI Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Router Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Output Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Security Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Input Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:35:58 --> Language Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Loader Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Controller Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:35:58 --> Model Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Model Class Initialized
DEBUG - 2014-01-20 06:35:58 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:35:59 --> Model Class Initialized
DEBUG - 2014-01-20 06:35:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:36:02 --> Upload Class Initialized
DEBUG - 2014-01-20 06:37:56 --> Image Lib Class Initialized
DEBUG - 2014-01-20 06:38:29 --> Model Class Initialized
DEBUG - 2014-01-20 06:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 06:38:37 --> Severity: Notice  --> Undefined property: Member::$newPhoto F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 221
DEBUG - 2014-01-20 06:51:45 --> Config Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:51:45 --> URI Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Router Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Output Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Security Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Input Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:51:45 --> Language Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Loader Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Controller Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:51:45 --> Model Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Model Class Initialized
DEBUG - 2014-01-20 06:51:45 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:51:47 --> Model Class Initialized
DEBUG - 2014-01-20 06:51:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:51:49 --> Upload Class Initialized
DEBUG - 2014-01-20 06:51:54 --> Image Lib Class Initialized
DEBUG - 2014-01-20 06:51:56 --> Model Class Initialized
DEBUG - 2014-01-20 06:51:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:52:41 --> Final output sent to browser
DEBUG - 2014-01-20 06:52:41 --> Total execution time: 55.5582
DEBUG - 2014-01-20 06:54:15 --> Config Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:54:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:54:15 --> URI Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Router Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Output Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Security Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Input Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:54:15 --> Language Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Loader Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Controller Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:54:15 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:54:15 --> Upload Class Initialized
DEBUG - 2014-01-20 06:54:15 --> Image Lib Class Initialized
DEBUG - 2014-01-20 06:54:16 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:54:36 --> Config Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:54:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:54:36 --> URI Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Router Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Output Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Security Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Input Class Initialized
DEBUG - 2014-01-20 06:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:54:36 --> Language Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Loader Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Controller Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:54:37 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:54:37 --> Upload Class Initialized
DEBUG - 2014-01-20 06:54:37 --> Image Lib Class Initialized
DEBUG - 2014-01-20 06:54:38 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:54:40 --> Final output sent to browser
DEBUG - 2014-01-20 06:54:40 --> Total execution time: 4.0692
DEBUG - 2014-01-20 06:54:44 --> Config Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:54:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:54:44 --> URI Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Router Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Output Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Security Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Input Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:54:44 --> Language Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Loader Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Controller Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:54:44 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:54:44 --> Upload Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Image Lib Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Model Class Initialized
DEBUG - 2014-01-20 06:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:54:46 --> Final output sent to browser
DEBUG - 2014-01-20 06:54:46 --> Total execution time: 2.4381
DEBUG - 2014-01-20 06:57:35 --> Config Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:57:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:57:35 --> URI Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Router Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Output Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Security Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Input Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:57:35 --> Language Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Loader Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Controller Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:57:35 --> Model Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Model Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Model Class Initialized
DEBUG - 2014-01-20 06:57:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:57:38 --> Final output sent to browser
DEBUG - 2014-01-20 06:57:38 --> Total execution time: 3.1682
DEBUG - 2014-01-20 06:58:34 --> Config Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Hooks Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Utf8 Class Initialized
DEBUG - 2014-01-20 06:58:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 06:58:34 --> URI Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Router Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Output Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Security Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Input Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 06:58:34 --> Language Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Loader Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Controller Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 06:58:34 --> Model Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Model Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Database Driver Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Model Class Initialized
DEBUG - 2014-01-20 06:58:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 06:58:37 --> Final output sent to browser
DEBUG - 2014-01-20 06:58:37 --> Total execution time: 2.5901
DEBUG - 2014-01-20 07:11:28 --> Config Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:11:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:11:28 --> URI Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Router Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Output Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Security Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Input Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:11:28 --> Language Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Loader Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Controller Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:11:28 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:11:28 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:11:28 --> Final output sent to browser
DEBUG - 2014-01-20 07:11:28 --> Total execution time: 0.1200
DEBUG - 2014-01-20 07:11:30 --> Config Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:11:30 --> URI Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Router Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Output Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Security Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Input Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:11:30 --> Language Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Loader Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Controller Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:11:30 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:11:30 --> Final output sent to browser
DEBUG - 2014-01-20 07:11:30 --> Total execution time: 0.0120
DEBUG - 2014-01-20 07:11:31 --> Config Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:11:31 --> URI Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Router Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Output Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Security Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Input Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:11:31 --> Language Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Loader Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Controller Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:11:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:11:31 --> Final output sent to browser
DEBUG - 2014-01-20 07:11:31 --> Total execution time: 0.0120
DEBUG - 2014-01-20 07:11:39 --> Config Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:11:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:11:39 --> URI Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Router Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Output Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Security Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Input Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:11:39 --> Language Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Loader Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Controller Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:11:39 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:11:39 --> Final output sent to browser
DEBUG - 2014-01-20 07:11:39 --> Total execution time: 0.1860
DEBUG - 2014-01-20 07:11:48 --> Config Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:11:48 --> URI Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Router Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Output Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Security Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Input Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:11:48 --> Language Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Loader Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Controller Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:11:48 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:11:48 --> Model Class Initialized
DEBUG - 2014-01-20 07:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:11:48 --> Final output sent to browser
DEBUG - 2014-01-20 07:11:48 --> Total execution time: 0.1740
DEBUG - 2014-01-20 07:12:32 --> Config Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:12:32 --> URI Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Router Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Output Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Security Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Input Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:12:32 --> Language Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Loader Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Controller Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:12:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:12:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:12:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:13:03 --> Config Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:13:03 --> URI Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Router Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Output Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Security Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Input Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:13:03 --> Language Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Loader Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Controller Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:13:03 --> Model Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Model Class Initialized
DEBUG - 2014-01-20 07:13:03 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:13:05 --> Model Class Initialized
DEBUG - 2014-01-20 07:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:13:15 --> Model Class Initialized
DEBUG - 2014-01-20 07:13:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:14:41 --> Config Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:14:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:14:41 --> URI Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Router Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Output Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Security Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Input Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:14:41 --> Language Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Loader Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Controller Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:14:41 --> Model Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Model Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Model Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:14:41 --> Model Class Initialized
DEBUG - 2014-01-20 07:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:14:42 --> Final output sent to browser
DEBUG - 2014-01-20 07:14:42 --> Total execution time: 0.3770
DEBUG - 2014-01-20 07:15:04 --> Config Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:15:04 --> URI Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Router Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Output Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Security Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Input Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:15:04 --> Language Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Loader Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Controller Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:15:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:15:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:15:05 --> Final output sent to browser
DEBUG - 2014-01-20 07:15:05 --> Total execution time: 0.8420
DEBUG - 2014-01-20 07:15:13 --> Config Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:15:13 --> URI Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Router Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Output Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Security Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Input Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:15:13 --> Language Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Loader Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Controller Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:15:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:15:13 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:15:13 --> Final output sent to browser
DEBUG - 2014-01-20 07:15:13 --> Total execution time: 0.4110
DEBUG - 2014-01-20 07:15:20 --> Config Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:15:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:15:20 --> URI Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Router Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Output Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Security Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Input Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:15:20 --> Language Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Loader Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Controller Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:15:20 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:15:20 --> Model Class Initialized
DEBUG - 2014-01-20 07:15:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:15:20 --> Final output sent to browser
DEBUG - 2014-01-20 07:15:20 --> Total execution time: 0.3490
DEBUG - 2014-01-20 07:19:34 --> Config Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:19:34 --> URI Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Router Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Output Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Security Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Input Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:19:34 --> Language Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Loader Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Controller Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:19:34 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:19:35 --> Upload Class Initialized
DEBUG - 2014-01-20 07:19:35 --> Image Lib Class Initialized
DEBUG - 2014-01-20 07:19:35 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:19:38 --> Final output sent to browser
DEBUG - 2014-01-20 07:19:38 --> Total execution time: 3.1482
DEBUG - 2014-01-20 07:19:44 --> Config Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:19:44 --> URI Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Router Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Output Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Security Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Input Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:19:44 --> Language Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Loader Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Controller Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:19:44 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:19:44 --> Upload Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Image Lib Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Model Class Initialized
DEBUG - 2014-01-20 07:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:19:47 --> Final output sent to browser
DEBUG - 2014-01-20 07:19:47 --> Total execution time: 2.5001
DEBUG - 2014-01-20 07:20:40 --> Config Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:20:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:20:40 --> URI Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Router Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Output Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Security Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Input Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:20:40 --> Language Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Loader Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Controller Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:20:40 --> Model Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Model Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Model Class Initialized
DEBUG - 2014-01-20 07:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:20:43 --> Final output sent to browser
DEBUG - 2014-01-20 07:20:43 --> Total execution time: 3.0542
DEBUG - 2014-01-20 07:21:04 --> Config Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:21:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:21:04 --> URI Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Router Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Output Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Security Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Input Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:21:04 --> Language Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Loader Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Controller Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:21:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:21:04 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:21:04 --> Final output sent to browser
DEBUG - 2014-01-20 07:21:04 --> Total execution time: 0.0160
DEBUG - 2014-01-20 07:21:08 --> Config Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:21:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:21:08 --> URI Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Router Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Output Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Security Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Input Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:21:08 --> Language Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Loader Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Controller Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:21:08 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:21:08 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:21:14 --> Final output sent to browser
DEBUG - 2014-01-20 07:21:14 --> Total execution time: 5.5843
DEBUG - 2014-01-20 07:21:39 --> Config Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:21:39 --> URI Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Router Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Output Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Security Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Input Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:21:39 --> Language Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Loader Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Controller Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:21:39 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:21:40 --> Model Class Initialized
DEBUG - 2014-01-20 07:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:21:45 --> Final output sent to browser
DEBUG - 2014-01-20 07:21:45 --> Total execution time: 5.3433
DEBUG - 2014-01-20 07:22:38 --> Config Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:22:38 --> URI Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Router Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Output Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Security Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Input Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:22:38 --> Language Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Loader Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Controller Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:22:38 --> Model Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Model Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Model Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:22:38 --> Upload Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Image Lib Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Model Class Initialized
DEBUG - 2014-01-20 07:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:22:40 --> Final output sent to browser
DEBUG - 2014-01-20 07:22:40 --> Total execution time: 2.6011
DEBUG - 2014-01-20 07:51:17 --> Config Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:51:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:51:17 --> URI Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Router Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Output Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Security Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Input Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:51:17 --> Language Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Loader Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Controller Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:51:17 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:51:17 --> Final output sent to browser
DEBUG - 2014-01-20 07:51:17 --> Total execution time: 0.0100
DEBUG - 2014-01-20 07:51:25 --> Config Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:51:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:51:25 --> URI Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Router Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Output Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Security Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Input Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:51:25 --> Language Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Loader Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Controller Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:51:25 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:51:25 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-20 07:51:25 --> Final output sent to browser
DEBUG - 2014-01-20 07:51:25 --> Total execution time: 0.0790
DEBUG - 2014-01-20 07:51:31 --> Config Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:51:31 --> URI Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Router Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Output Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Security Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Input Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:51:31 --> Language Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Loader Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Controller Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:51:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:51:31 --> Model Class Initialized
DEBUG - 2014-01-20 07:51:31 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:51:32 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 98
DEBUG - 2014-01-20 07:51:32 --> Final output sent to browser
DEBUG - 2014-01-20 07:51:32 --> Total execution time: 0.6010
DEBUG - 2014-01-20 07:55:12 --> Config Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:55:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:55:12 --> URI Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Router Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Output Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Security Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Input Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:55:12 --> Language Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Loader Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Controller Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:55:12 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:55:12 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:12 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:55:15 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:55:15 --> Final output sent to browser
DEBUG - 2014-01-20 07:55:15 --> Total execution time: 3.0882
DEBUG - 2014-01-20 07:55:37 --> Config Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:55:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:55:37 --> URI Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Router Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Output Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Security Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Input Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:55:37 --> Language Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Loader Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Controller Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:55:37 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:55:37 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:37 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:55:41 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:55:41 --> Final output sent to browser
DEBUG - 2014-01-20 07:55:41 --> Total execution time: 3.1942
DEBUG - 2014-01-20 07:55:52 --> Config Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:55:52 --> URI Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Router Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Output Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Security Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Input Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:55:52 --> Language Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Loader Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Controller Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:55:52 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:55:52 --> Model Class Initialized
DEBUG - 2014-01-20 07:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:55:54 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:55:54 --> Final output sent to browser
DEBUG - 2014-01-20 07:55:54 --> Total execution time: 2.4911
DEBUG - 2014-01-20 07:56:54 --> Config Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:56:54 --> URI Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Router Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Output Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Security Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Input Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:56:54 --> Language Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Loader Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Controller Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:56:54 --> Model Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Model Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:56:54 --> Model Class Initialized
DEBUG - 2014-01-20 07:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:56:58 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:56:58 --> Final output sent to browser
DEBUG - 2014-01-20 07:56:58 --> Total execution time: 4.3022
DEBUG - 2014-01-20 07:57:03 --> Config Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:57:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:57:03 --> URI Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Router Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Output Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Security Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Input Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:57:03 --> Language Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Loader Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Controller Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:57:03 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:57:03 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:03 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:57:06 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:57:06 --> Final output sent to browser
DEBUG - 2014-01-20 07:57:06 --> Total execution time: 2.4041
DEBUG - 2014-01-20 07:57:15 --> Config Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:57:15 --> URI Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Router Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Output Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Security Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Input Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:57:15 --> Language Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Loader Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Controller Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:57:15 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:57:15 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:15 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:57:17 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:57:17 --> Final output sent to browser
DEBUG - 2014-01-20 07:57:17 --> Total execution time: 2.3901
DEBUG - 2014-01-20 07:57:32 --> Config Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:57:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:57:32 --> URI Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Router Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Output Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Security Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Input Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:57:32 --> Language Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Loader Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Controller Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:57:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:57:32 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:57:34 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:57:34 --> Final output sent to browser
DEBUG - 2014-01-20 07:57:34 --> Total execution time: 2.4091
DEBUG - 2014-01-20 07:57:49 --> Config Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:57:49 --> URI Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Router Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Output Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Security Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Input Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:57:49 --> Language Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Loader Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Controller Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:57:49 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:57:49 --> Model Class Initialized
DEBUG - 2014-01-20 07:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:57:51 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:57:51 --> Final output sent to browser
DEBUG - 2014-01-20 07:57:51 --> Total execution time: 2.5501
DEBUG - 2014-01-20 07:58:05 --> Config Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:58:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:58:05 --> URI Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Router Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Output Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Security Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Input Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:58:05 --> Language Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Loader Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Controller Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:58:05 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:58:05 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:05 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:58:08 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:58:08 --> Final output sent to browser
DEBUG - 2014-01-20 07:58:08 --> Total execution time: 2.4041
DEBUG - 2014-01-20 07:58:27 --> Config Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Hooks Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Utf8 Class Initialized
DEBUG - 2014-01-20 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-20 07:58:27 --> URI Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Router Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Output Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Security Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Input Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-20 07:58:27 --> Language Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Loader Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Controller Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-20 07:58:27 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Database Driver Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Helper loaded: email_helper
DEBUG - 2014-01-20 07:58:27 --> Model Class Initialized
DEBUG - 2014-01-20 07:58:27 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-20 07:58:30 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 100
DEBUG - 2014-01-20 07:58:30 --> Final output sent to browser
DEBUG - 2014-01-20 07:58:30 --> Total execution time: 2.4111
