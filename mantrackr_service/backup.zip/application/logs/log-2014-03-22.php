<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-22 02:28:40 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-22 02:28:40 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:40 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:40 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:40 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:40 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:40 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:40 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Database Driver Class Initialized
ERROR - 2014-03-22 02:28:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-22 02:28:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-22 02:28:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:40 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:40 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:40 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:40 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:40 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:40 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:40 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:40 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:40 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:40 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:40 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:40 --> Total execution time: 0.1560
DEBUG - 2014-03-22 02:28:40 --> Total execution time: 0.1570
DEBUG - 2014-03-22 02:28:40 --> Total execution time: 0.1560
DEBUG - 2014-03-22 02:28:41 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:41 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:41 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:41 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:41 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:41 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:41 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:41 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: service_errorcodes_helper
ERROR - 2014-03-22 02:28:41 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:41 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:41 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:41 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:41 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:41 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:41 --> Total execution time: 0.0160
DEBUG - 2014-03-22 02:28:41 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:41 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:41 --> Total execution time: 0.0960
ERROR - 2014-03-22 02:28:41 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:41 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:41 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:41 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:41 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:41 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:41 --> Total execution time: 0.2200
DEBUG - 2014-03-22 02:28:44 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:44 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:44 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Config Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:28:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:28:44 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:28:44 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:44 --> URI Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Router Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:44 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:44 --> Output Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:44 --> Security Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Input Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:28:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Language Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Loader Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:44 --> Controller Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:28:44 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Total execution time: 0.0130
DEBUG - 2014-03-22 02:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:44 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:44 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Session Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:28:44 --> A session cookie was not found.
DEBUG - 2014-03-22 02:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:44 --> Session routines successfully run
DEBUG - 2014-03-22 02:28:44 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:28:44 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:28:44 --> Total execution time: 0.0160
DEBUG - 2014-03-22 02:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:28:44 --> Final output sent to browser
DEBUG - 2014-03-22 02:28:44 --> Total execution time: 0.0170
DEBUG - 2014-03-22 02:30:02 --> Config Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:30:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:30:02 --> URI Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Router Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Output Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Security Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Input Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:30:02 --> Language Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Loader Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Controller Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:30:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:30:02 --> Model Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Model Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Model Class Initialized
DEBUG - 2014-03-22 02:30:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:30:03 --> Final output sent to browser
DEBUG - 2014-03-22 02:30:03 --> Total execution time: 1.2411
DEBUG - 2014-03-22 02:49:16 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:16 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:16 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:16 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:16 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:16 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:16 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:16 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:16 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Total execution time: 0.0130
DEBUG - 2014-03-22 02:49:16 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:16 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:16 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:16 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:16 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:16 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:16 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:16 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:16 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:16 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:16 --> Total execution time: 0.0160
DEBUG - 2014-03-22 02:49:16 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:16 --> Total execution time: 0.0260
DEBUG - 2014-03-22 02:49:18 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:18 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:18 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:18 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:18 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:18 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:18 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:18 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:18 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:18 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:18 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:18 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:18 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:18 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:18 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:18 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:18 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:18 --> Total execution time: 0.0210
DEBUG - 2014-03-22 02:49:18 --> Total execution time: 0.0150
DEBUG - 2014-03-22 02:49:18 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:18 --> Total execution time: 0.0230
DEBUG - 2014-03-22 02:49:26 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:26 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:26 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:26 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:27 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:27 --> Total execution time: 0.9541
DEBUG - 2014-03-22 02:49:38 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:38 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:38 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:38 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:38 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:38 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:38 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:38 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:38 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:38 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:38 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:38 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:38 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:38 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:38 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:38 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:38 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:38 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:38 --> Total execution time: 0.0170
DEBUG - 2014-03-22 02:49:38 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:38 --> Total execution time: 0.0170
DEBUG - 2014-03-22 02:49:38 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:38 --> Total execution time: 0.0160
DEBUG - 2014-03-22 02:49:39 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:39 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:39 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:39 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:39 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:39 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:39 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:39 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:39 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:39 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:39 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:39 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:39 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:39 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:39 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:39 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:39 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:39 --> Total execution time: 0.0130
DEBUG - 2014-03-22 02:49:39 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:39 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:39 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:39 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:39 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:39 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:39 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:39 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:39 --> Total execution time: 0.0150
DEBUG - 2014-03-22 02:49:39 --> Total execution time: 0.0170
DEBUG - 2014-03-22 02:49:59 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:59 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:59 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:59 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Config Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:59 --> URI Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:59 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Router Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Output Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Security Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:59 --> Input Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:49:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Language Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Loader Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Controller Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:59 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:59 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:59 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:59 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:59 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:59 --> Total execution time: 0.0180
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:59 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:59 --> Total execution time: 0.0230
DEBUG - 2014-03-22 02:49:59 --> Session Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:49:59 --> A session cookie was not found.
DEBUG - 2014-03-22 02:49:59 --> Session routines successfully run
DEBUG - 2014-03-22 02:49:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:49:59 --> Model Class Initialized
DEBUG - 2014-03-22 02:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:49:59 --> Final output sent to browser
DEBUG - 2014-03-22 02:49:59 --> Total execution time: 0.0205
DEBUG - 2014-03-22 02:50:06 --> Config Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:50:06 --> URI Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Router Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Output Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Security Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Input Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:50:06 --> Language Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Loader Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Controller Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:50:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:50:06 --> Model Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Model Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Model Class Initialized
DEBUG - 2014-03-22 02:50:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:50:07 --> Final output sent to browser
DEBUG - 2014-03-22 02:50:07 --> Total execution time: 1.0641
DEBUG - 2014-03-22 02:52:05 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:05 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:05 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:05 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:05 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:05 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:05 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:05 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:05 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:05 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:05 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:05 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:05 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:05 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:05 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:05 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:05 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:05 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:05 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:05 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:05 --> Total execution time: 0.0150
DEBUG - 2014-03-22 02:52:05 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:05 --> Total execution time: 0.0140
DEBUG - 2014-03-22 02:52:05 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:05 --> Total execution time: 0.0160
DEBUG - 2014-03-22 02:52:10 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:10 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:10 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:10 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:10 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:10 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:10 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:10 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:10 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:10 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:10 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:10 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:10 --> Total execution time: 0.0140
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:10 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:10 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:10 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:10 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:10 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:10 --> Total execution time: 0.0195
DEBUG - 2014-03-22 02:52:10 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:10 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:10 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:10 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:10 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:10 --> Total execution time: 0.0180
DEBUG - 2014-03-22 02:52:14 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:14 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:14 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:14 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:14 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:14 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:14 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:14 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:14 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:14 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:14 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:14 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:14 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:14 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:14 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:14 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:14 --> Total execution time: 0.0120
DEBUG - 2014-03-22 02:52:14 --> Session Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:52:14 --> Total execution time: 0.0140
DEBUG - 2014-03-22 02:52:14 --> A session cookie was not found.
DEBUG - 2014-03-22 02:52:14 --> Session routines successfully run
DEBUG - 2014-03-22 02:52:14 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:52:14 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:14 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:14 --> Total execution time: 0.0170
DEBUG - 2014-03-22 02:52:24 --> Config Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:52:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:52:24 --> URI Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Router Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Output Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Security Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Input Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:52:24 --> Language Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Loader Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Controller Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:52:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:52:24 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Model Class Initialized
DEBUG - 2014-03-22 02:52:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:52:25 --> Final output sent to browser
DEBUG - 2014-03-22 02:52:25 --> Total execution time: 0.9741
DEBUG - 2014-03-22 02:54:44 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:44 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:44 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:44 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:44 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:44 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Session Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:44 --> A session cookie was not found.
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Session routines successfully run
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:44 --> Session Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:54:44 --> A session cookie was not found.
DEBUG - 2014-03-22 02:54:44 --> Session routines successfully run
DEBUG - 2014-03-22 02:54:44 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:44 --> Total execution time: 0.0180
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:44 --> Total execution time: 0.0225
DEBUG - 2014-03-22 02:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:44 --> Session Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:54:44 --> A session cookie was not found.
DEBUG - 2014-03-22 02:54:44 --> Session routines successfully run
DEBUG - 2014-03-22 02:54:44 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:54:44 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:44 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:44 --> Total execution time: 0.0165
DEBUG - 2014-03-22 02:54:46 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:46 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:46 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:46 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:46 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:46 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:46 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:46 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:46 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:46 --> Session Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:54:46 --> A session cookie was not found.
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Session Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:46 --> Session routines successfully run
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:54:46 --> A session cookie was not found.
DEBUG - 2014-03-22 02:54:46 --> Session routines successfully run
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:46 --> Session Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:54:46 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:46 --> A session cookie was not found.
DEBUG - 2014-03-22 02:54:46 --> Total execution time: 0.0140
DEBUG - 2014-03-22 02:54:46 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:46 --> Total execution time: 0.0150
DEBUG - 2014-03-22 02:54:46 --> Session routines successfully run
DEBUG - 2014-03-22 02:54:46 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:54:46 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:46 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:46 --> Total execution time: 0.0150
DEBUG - 2014-03-22 02:54:57 --> Config Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:54:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:54:57 --> URI Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Router Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Output Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Security Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Input Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:54:57 --> Language Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Loader Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Controller Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:54:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:54:57 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Model Class Initialized
DEBUG - 2014-03-22 02:54:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:54:58 --> Final output sent to browser
DEBUG - 2014-03-22 02:54:58 --> Total execution time: 0.9391
DEBUG - 2014-03-22 02:55:11 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:11 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:11 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:11 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:11 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:11 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:11 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:11 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:11 --> Session Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Session Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Session Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:55:11 --> A session cookie was not found.
DEBUG - 2014-03-22 02:55:11 --> A session cookie was not found.
DEBUG - 2014-03-22 02:55:11 --> Session routines successfully run
DEBUG - 2014-03-22 02:55:11 --> Session routines successfully run
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:55:11 --> A session cookie was not found.
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Session routines successfully run
DEBUG - 2014-03-22 02:55:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:11 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:11 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:11 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:11 --> Total execution time: 0.0205
DEBUG - 2014-03-22 02:55:11 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:11 --> Total execution time: 0.0215
DEBUG - 2014-03-22 02:55:11 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:11 --> Total execution time: 0.0225
DEBUG - 2014-03-22 02:55:13 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:13 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:13 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:13 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:13 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:13 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:13 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:13 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:13 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:13 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Session Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:55:13 --> Session Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:55:13 --> A session cookie was not found.
DEBUG - 2014-03-22 02:55:13 --> A session cookie was not found.
DEBUG - 2014-03-22 02:55:13 --> Session routines successfully run
DEBUG - 2014-03-22 02:55:13 --> Session routines successfully run
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:13 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:13 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:13 --> Total execution time: 0.0130
DEBUG - 2014-03-22 02:55:13 --> Total execution time: 0.0140
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:13 --> Session Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 02:55:13 --> A session cookie was not found.
DEBUG - 2014-03-22 02:55:13 --> Session routines successfully run
DEBUG - 2014-03-22 02:55:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 02:55:13 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:13 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:13 --> Total execution time: 0.0280
DEBUG - 2014-03-22 02:55:20 --> Config Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Hooks Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Utf8 Class Initialized
DEBUG - 2014-03-22 02:55:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 02:55:20 --> URI Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Router Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Output Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Security Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Input Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 02:55:20 --> Language Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Loader Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Controller Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 02:55:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 02:55:20 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Database Driver Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Model Class Initialized
DEBUG - 2014-03-22 02:55:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 02:55:22 --> Final output sent to browser
DEBUG - 2014-03-22 02:55:22 --> Total execution time: 1.5861
DEBUG - 2014-03-22 03:05:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Session Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:05:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:13 --> A session cookie was not found.
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:13 --> Session routines successfully run
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:13 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:13 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:13 --> Session Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:05:13 --> A session cookie was not found.
DEBUG - 2014-03-22 03:05:13 --> Session routines successfully run
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:13 --> Session Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:05:13 --> A session cookie was not found.
DEBUG - 2014-03-22 03:05:13 --> Session routines successfully run
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:05:13 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:13 --> Total execution time: 0.0195
DEBUG - 2014-03-22 03:05:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:13 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:13 --> Total execution time: 0.0290
DEBUG - 2014-03-22 03:05:15 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:15 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:15 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:15 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:15 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:15 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:15 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:15 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:15 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Session Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:05:15 --> A session cookie was not found.
DEBUG - 2014-03-22 03:05:15 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Session routines successfully run
DEBUG - 2014-03-22 03:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:05:15 --> Session Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:15 --> A session cookie was not found.
DEBUG - 2014-03-22 03:05:15 --> Session routines successfully run
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:15 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:15 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:15 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:05:15 --> Session Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:05:15 --> A session cookie was not found.
DEBUG - 2014-03-22 03:05:15 --> Session routines successfully run
DEBUG - 2014-03-22 03:05:15 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:05:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:15 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:15 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:05:23 --> Config Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:05:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:05:23 --> URI Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Router Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Output Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Security Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Input Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:05:23 --> Language Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Loader Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Controller Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:05:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:05:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:05:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:05:24 --> Final output sent to browser
DEBUG - 2014-03-22 03:05:24 --> Total execution time: 1.1281
DEBUG - 2014-03-22 03:08:04 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:04 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:04 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:04 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:04 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:04 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:04 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:04 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:04 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:04 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:04 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:04 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:04 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:04 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:04 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:04 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:04 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:04 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:08:04 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:04 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:04 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:04 --> Total execution time: 0.0175
DEBUG - 2014-03-22 03:08:04 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:04 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:04 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:04 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:08:06 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:06 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:06 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:06 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:06 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:06 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:06 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:06 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:06 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:06 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:06 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:06 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:06 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:06 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:06 --> Total execution time: 0.0150
DEBUG - 2014-03-22 03:08:06 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:06 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:06 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:06 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:06 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:06 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:06 --> Total execution time: 0.0175
DEBUG - 2014-03-22 03:08:08 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:08 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:08 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:08 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:08 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:08 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:08 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:08 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:08 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:08 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:08 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:08 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:08 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:08 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:08 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:08 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:08 --> Session Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:08:08 --> A session cookie was not found.
DEBUG - 2014-03-22 03:08:08 --> Session routines successfully run
DEBUG - 2014-03-22 03:08:08 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:08:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:08 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:08 --> Total execution time: 0.0200
DEBUG - 2014-03-22 03:08:16 --> Config Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:08:16 --> URI Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Router Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Output Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Security Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Input Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:08:16 --> Language Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Loader Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Controller Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:08:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 03:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:08:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:08:18 --> Total execution time: 1.9391
DEBUG - 2014-03-22 03:09:46 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:46 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:46 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:46 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:46 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:46 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:46 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:46 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:46 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:46 --> Session Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> A session cookie was not found.
DEBUG - 2014-03-22 03:09:46 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Session routines successfully run
DEBUG - 2014-03-22 03:09:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:09:46 --> Session Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> A session cookie was not found.
DEBUG - 2014-03-22 03:09:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:46 --> Session routines successfully run
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:46 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:46 --> Total execution time: 0.0120
DEBUG - 2014-03-22 03:09:46 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:46 --> Total execution time: 0.0200
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:46 --> Session Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:09:46 --> A session cookie was not found.
DEBUG - 2014-03-22 03:09:46 --> Session routines successfully run
DEBUG - 2014-03-22 03:09:46 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:09:46 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:46 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:46 --> Total execution time: 0.0260
DEBUG - 2014-03-22 03:09:48 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:48 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:48 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:48 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:48 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:48 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:48 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:48 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Session Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:09:48 --> A session cookie was not found.
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Session routines successfully run
DEBUG - 2014-03-22 03:09:48 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:09:48 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:48 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Total execution time: 0.0210
DEBUG - 2014-03-22 03:09:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:48 --> Session Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:09:48 --> A session cookie was not found.
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Session routines successfully run
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:09:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:48 --> Session Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:09:48 --> A session cookie was not found.
DEBUG - 2014-03-22 03:09:48 --> Session routines successfully run
DEBUG - 2014-03-22 03:09:48 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:48 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:09:48 --> Total execution time: 0.0220
DEBUG - 2014-03-22 03:09:48 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:48 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:48 --> Total execution time: 0.0235
DEBUG - 2014-03-22 03:09:56 --> Config Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:09:56 --> URI Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Router Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Output Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Security Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Input Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:09:56 --> Language Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Loader Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Controller Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:09:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:09:56 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Model Class Initialized
DEBUG - 2014-03-22 03:09:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:09:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:09:57 --> Total execution time: 0.9611
DEBUG - 2014-03-22 03:10:57 --> Config Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Config Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:10:57 --> URI Class Initialized
DEBUG - 2014-03-22 03:10:57 --> URI Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Router Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Router Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Output Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Output Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Security Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Security Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Input Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Input Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:10:57 --> Language Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Language Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Loader Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Loader Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Controller Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Controller Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:10:57 --> Config Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:10:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:10:57 --> URI Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Session Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:10:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:10:57 --> A session cookie was not found.
DEBUG - 2014-03-22 03:10:57 --> Router Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Session routines successfully run
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:57 --> Output Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Session Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:10:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:10:57 --> A session cookie was not found.
DEBUG - 2014-03-22 03:10:57 --> Total execution time: 0.0150
DEBUG - 2014-03-22 03:10:57 --> Session routines successfully run
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Security Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:57 --> Input Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:10:57 --> Language Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Loader Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Controller Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:10:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:10:57 --> Total execution time: 0.0175
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:57 --> Session Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:10:57 --> A session cookie was not found.
DEBUG - 2014-03-22 03:10:57 --> Session routines successfully run
DEBUG - 2014-03-22 03:10:57 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:10:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:10:57 --> Total execution time: 0.0220
DEBUG - 2014-03-22 03:10:58 --> Config Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Config Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:10:58 --> URI Class Initialized
DEBUG - 2014-03-22 03:10:58 --> URI Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Router Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Router Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Output Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Config Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Output Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Security Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Security Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Input Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Input Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:10:58 --> Language Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Language Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Loader Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Loader Class Initialized
DEBUG - 2014-03-22 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:10:58 --> Controller Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Controller Class Initialized
DEBUG - 2014-03-22 03:10:58 --> URI Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:10:58 --> Router Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Output Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Security Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Input Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:58 --> Language Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Session Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Loader Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:10:58 --> Controller Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:10:58 --> A session cookie was not found.
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Session routines successfully run
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:58 --> Final output sent to browser
DEBUG - 2014-03-22 03:10:58 --> Session Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:10:58 --> A session cookie was not found.
DEBUG - 2014-03-22 03:10:58 --> Session routines successfully run
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:58 --> Session Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Final output sent to browser
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:10:58 --> A session cookie was not found.
DEBUG - 2014-03-22 03:10:58 --> Session routines successfully run
DEBUG - 2014-03-22 03:10:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:10:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:10:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:10:58 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:10:58 --> Final output sent to browser
DEBUG - 2014-03-22 03:10:58 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:11:06 --> Config Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:11:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:11:06 --> URI Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Router Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Output Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Security Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Input Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:11:06 --> Language Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Loader Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Controller Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:11:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:11:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Model Class Initialized
DEBUG - 2014-03-22 03:11:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:11:07 --> Final output sent to browser
DEBUG - 2014-03-22 03:11:07 --> Total execution time: 0.9301
DEBUG - 2014-03-22 03:13:58 --> Config Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:13:58 --> URI Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Config Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:13:58 --> URI Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Config Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Router Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Router Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Output Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Security Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Input Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:13:58 --> Output Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Language Class Initialized
DEBUG - 2014-03-22 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:13:58 --> Security Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Loader Class Initialized
DEBUG - 2014-03-22 03:13:58 --> URI Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Input Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:13:58 --> Language Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Controller Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:13:58 --> Loader Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Router Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Controller Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:13:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Session Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Output Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:13:58 --> Session Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Security Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:13:58 --> A session cookie was not found.
DEBUG - 2014-03-22 03:13:58 --> Input Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Session routines successfully run
DEBUG - 2014-03-22 03:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:13:58 --> A session cookie was not found.
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Language Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Session routines successfully run
DEBUG - 2014-03-22 03:13:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:13:58 --> Loader Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:13:58 --> Controller Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:13:58 --> Final output sent to browser
DEBUG - 2014-03-22 03:13:58 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:13:58 --> Final output sent to browser
DEBUG - 2014-03-22 03:13:58 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:13:58 --> Session Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:13:58 --> A session cookie was not found.
DEBUG - 2014-03-22 03:13:58 --> Session routines successfully run
DEBUG - 2014-03-22 03:13:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:13:58 --> Model Class Initialized
DEBUG - 2014-03-22 03:13:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:13:58 --> Final output sent to browser
DEBUG - 2014-03-22 03:13:58 --> Total execution time: 0.0250
DEBUG - 2014-03-22 03:14:00 --> Config Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:14:00 --> URI Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Config Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Config Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Router Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Output Class Initialized
DEBUG - 2014-03-22 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:14:00 --> URI Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Security Class Initialized
DEBUG - 2014-03-22 03:14:00 --> URI Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Router Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Input Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Router Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:14:00 --> Language Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Output Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Output Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Loader Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Security Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Security Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Input Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Controller Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:14:00 --> Language Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Input Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Language Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Loader Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Loader Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Controller Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Controller Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:00 --> Session Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:14:00 --> A session cookie was not found.
DEBUG - 2014-03-22 03:14:00 --> Session routines successfully run
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:00 --> Session Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:14:00 --> A session cookie was not found.
DEBUG - 2014-03-22 03:14:00 --> Session routines successfully run
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:00 --> Session Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:14:00 --> A session cookie was not found.
DEBUG - 2014-03-22 03:14:00 --> Session routines successfully run
DEBUG - 2014-03-22 03:14:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:14:00 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:00 --> Final output sent to browser
DEBUG - 2014-03-22 03:14:00 --> Final output sent to browser
DEBUG - 2014-03-22 03:14:00 --> Total execution time: 0.0150
DEBUG - 2014-03-22 03:14:00 --> Final output sent to browser
DEBUG - 2014-03-22 03:14:00 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:14:00 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:14:08 --> Config Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:14:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:14:08 --> URI Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Router Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Output Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Security Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Input Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:14:08 --> Language Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Loader Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Controller Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:14:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:14:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Model Class Initialized
DEBUG - 2014-03-22 03:14:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:14:09 --> Final output sent to browser
DEBUG - 2014-03-22 03:14:09 --> Total execution time: 1.0641
DEBUG - 2014-03-22 03:16:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:13 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:13 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:13 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:13 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:13 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:13 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:13 --> Total execution time: 0.0225
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:13 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:13 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:13 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:13 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:13 --> Total execution time: 0.0265
DEBUG - 2014-03-22 03:16:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:13 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:13 --> Total execution time: 0.0280
DEBUG - 2014-03-22 03:16:15 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:15 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:15 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:15 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:15 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:15 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:15 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:15 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:15 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:15 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:15 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:15 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:15 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:15 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:15 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:15 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:15 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:15 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:15 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:15 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:15 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:16:15 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:16:15 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:15 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:16:18 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:18 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:18 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:18 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:18 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:18 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:18 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:18 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:18 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:18 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:18 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:18 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:18 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:16:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:18 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:16:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:18 --> Session Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:16:18 --> A session cookie was not found.
DEBUG - 2014-03-22 03:16:18 --> Session routines successfully run
DEBUG - 2014-03-22 03:16:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:16:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:18 --> Total execution time: 0.0210
DEBUG - 2014-03-22 03:16:26 --> Config Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:16:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:16:26 --> URI Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Router Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Output Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Security Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Input Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:16:26 --> Language Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Loader Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Controller Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:16:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:16:26 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Model Class Initialized
DEBUG - 2014-03-22 03:16:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:16:27 --> Final output sent to browser
DEBUG - 2014-03-22 03:16:27 --> Total execution time: 1.1321
DEBUG - 2014-03-22 03:17:18 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:18 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:18 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:18 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:18 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:18 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:18 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:18 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:18 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:18 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:18 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:18 --> Total execution time: 0.0120
DEBUG - 2014-03-22 03:17:18 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:18 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:18 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:18 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:18 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:18 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:18 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:18 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:18 --> Total execution time: 0.0185
DEBUG - 2014-03-22 03:17:20 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:20 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:20 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:20 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:20 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:20 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:20 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:20 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:20 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:20 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:20 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:20 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:20 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:20 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:20 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:20 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:17:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:20 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:20 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:20 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:20 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:20 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:20 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:20 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:20 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:20 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:20 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:20 --> Total execution time: 0.0195
DEBUG - 2014-03-22 03:17:27 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:27 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:27 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:27 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:28 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:28 --> Total execution time: 1.1461
DEBUG - 2014-03-22 03:17:57 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:57 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:57 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:57 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:57 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:57 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:57 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:57 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:57 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:57 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:57 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:57 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:57 --> Total execution time: 0.0120
DEBUG - 2014-03-22 03:17:57 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:57 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:57 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:57 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:57 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:57 --> Total execution time: 0.0250
DEBUG - 2014-03-22 03:17:57 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:57 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:57 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:57 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:57 --> Total execution time: 0.0295
DEBUG - 2014-03-22 03:17:59 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:59 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:59 --> Config Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:17:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:17:59 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:59 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:59 --> URI Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Router Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:59 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Output Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Security Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Input Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:17:59 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Language Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Loader Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Controller Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:17:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:59 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:59 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:59 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:59 --> Session Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:17:59 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:59 --> A session cookie was not found.
DEBUG - 2014-03-22 03:17:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:59 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:17:59 --> Session routines successfully run
DEBUG - 2014-03-22 03:17:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:17:59 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:59 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:17:59 --> Model Class Initialized
DEBUG - 2014-03-22 03:17:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:17:59 --> Final output sent to browser
DEBUG - 2014-03-22 03:17:59 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:18:13 --> Config Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:18:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:18:13 --> URI Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Router Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Output Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Security Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Input Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:18:13 --> Language Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Loader Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Controller Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:18:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:18:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Model Class Initialized
DEBUG - 2014-03-22 03:18:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:18:14 --> Final output sent to browser
DEBUG - 2014-03-22 03:18:14 --> Total execution time: 0.9791
DEBUG - 2014-03-22 03:20:34 --> Config Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:20:34 --> URI Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Router Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Config Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Output Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Security Class Initialized
DEBUG - 2014-03-22 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:20:34 --> Config Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Input Class Initialized
DEBUG - 2014-03-22 03:20:34 --> URI Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Router Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:20:34 --> URI Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Output Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:20:34 --> Security Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Language Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Input Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:20:34 --> Language Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Router Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Loader Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Output Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Controller Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Security Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:20:34 --> Input Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Loader Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:20:34 --> Controller Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Language Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Loader Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Controller Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:34 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Session Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:20:34 --> A session cookie was not found.
DEBUG - 2014-03-22 03:20:34 --> Session routines successfully run
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:34 --> Session Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:20:34 --> Final output sent to browser
DEBUG - 2014-03-22 03:20:34 --> A session cookie was not found.
DEBUG - 2014-03-22 03:20:34 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:20:34 --> Session routines successfully run
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:34 --> Final output sent to browser
DEBUG - 2014-03-22 03:20:34 --> Total execution time: 0.0225
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:34 --> Session Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:20:34 --> A session cookie was not found.
DEBUG - 2014-03-22 03:20:34 --> Session routines successfully run
DEBUG - 2014-03-22 03:20:34 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:20:34 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:34 --> Final output sent to browser
DEBUG - 2014-03-22 03:20:34 --> Total execution time: 0.0240
DEBUG - 2014-03-22 03:20:36 --> Config Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:20:36 --> URI Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Router Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Output Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Security Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Input Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:20:36 --> Config Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Language Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:20:36 --> Loader Class Initialized
DEBUG - 2014-03-22 03:20:36 --> URI Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Controller Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Router Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Output Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Security Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Config Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Input Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:20:36 --> Language Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:20:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Loader Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Controller Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:20:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:20:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:20:36 --> URI Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Router Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Output Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Security Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Input Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:20:36 --> Language Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Loader Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Controller Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:36 --> Session Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:20:36 --> A session cookie was not found.
DEBUG - 2014-03-22 03:20:36 --> Session routines successfully run
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:36 --> Final output sent to browser
DEBUG - 2014-03-22 03:20:36 --> Total execution time: 0.0235
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:36 --> Session Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Session Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:20:36 --> A session cookie was not found.
DEBUG - 2014-03-22 03:20:36 --> A session cookie was not found.
DEBUG - 2014-03-22 03:20:36 --> Session routines successfully run
DEBUG - 2014-03-22 03:20:36 --> Session routines successfully run
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:20:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Model Class Initialized
DEBUG - 2014-03-22 03:20:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:20:36 --> Final output sent to browser
DEBUG - 2014-03-22 03:20:36 --> Final output sent to browser
DEBUG - 2014-03-22 03:20:36 --> Total execution time: 0.0330
DEBUG - 2014-03-22 03:20:36 --> Total execution time: 0.0260
DEBUG - 2014-03-22 03:21:03 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:03 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:03 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:03 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:04 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:04 --> Total execution time: 0.9591
DEBUG - 2014-03-22 03:21:51 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:51 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:51 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:51 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:51 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:51 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:51 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:51 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:51 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:51 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:51 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Session Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:21:51 --> A session cookie was not found.
DEBUG - 2014-03-22 03:21:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Session routines successfully run
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:51 --> Session Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:21:51 --> A session cookie was not found.
DEBUG - 2014-03-22 03:21:51 --> Session routines successfully run
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:51 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:51 --> Total execution time: 0.0150
DEBUG - 2014-03-22 03:21:51 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:51 --> Total execution time: 0.0180
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:51 --> Session Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:21:51 --> A session cookie was not found.
DEBUG - 2014-03-22 03:21:51 --> Session routines successfully run
DEBUG - 2014-03-22 03:21:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:21:51 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:51 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:51 --> Total execution time: 0.0250
DEBUG - 2014-03-22 03:21:53 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:53 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:53 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:53 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Config Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:53 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:21:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:21:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:53 --> URI Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Router Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Output Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:53 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Security Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Session Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Input Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:21:53 --> A session cookie was not found.
DEBUG - 2014-03-22 03:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:21:53 --> Session routines successfully run
DEBUG - 2014-03-22 03:21:53 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Language Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:53 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:53 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:53 --> Total execution time: 0.0110
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:53 --> Loader Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Controller Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:53 --> Session Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:21:53 --> A session cookie was not found.
DEBUG - 2014-03-22 03:21:53 --> Session routines successfully run
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:53 --> Session Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:21:53 --> A session cookie was not found.
DEBUG - 2014-03-22 03:21:53 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:53 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:21:53 --> Session routines successfully run
DEBUG - 2014-03-22 03:21:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:21:53 --> Model Class Initialized
DEBUG - 2014-03-22 03:21:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:21:53 --> Final output sent to browser
DEBUG - 2014-03-22 03:21:53 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:22:09 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:09 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:09 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:09 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:09 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:09 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:09 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:09 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:09 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:09 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:09 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:09 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:09 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:09 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:09 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:09 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:09 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:09 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:09 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:22:09 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:09 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:09 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:09 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:22:09 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:09 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:22:11 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:11 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:11 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:11 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:11 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:11 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:11 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:11 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:11 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:11 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:11 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:11 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:11 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:11 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:11 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:11 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:11 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:22:11 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:11 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:11 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:11 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:22:11 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:11 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:11 --> Total execution time: 0.0170
DEBUG - 2014-03-22 03:22:30 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:30 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:30 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:30 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:30 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:30 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:30 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:30 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:30 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:30 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:30 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:30 --> Total execution time: 0.0150
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:30 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:30 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:30 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:30 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:30 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:30 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:30 --> Total execution time: 0.0220
DEBUG - 2014-03-22 03:22:30 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:22:31 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:31 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:31 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:31 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:31 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:31 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:31 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:31 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:31 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:31 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:31 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:31 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:31 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:31 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:31 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:31 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:31 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:31 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:22:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:31 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:31 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:31 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:31 --> Total execution time: 0.0200
DEBUG - 2014-03-22 03:22:31 --> Total execution time: 0.0210
DEBUG - 2014-03-22 03:22:35 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:35 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:35 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:35 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Config Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:35 --> URI Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Router Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Output Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Security Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:35 --> Input Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:35 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:35 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:35 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:22:35 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Language Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:35 --> Loader Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:35 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:35 --> Controller Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:22:35 --> Total execution time: 0.0140
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:35 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:35 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:35 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:35 --> Session Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:22:35 --> A session cookie was not found.
DEBUG - 2014-03-22 03:22:35 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:35 --> Session routines successfully run
DEBUG - 2014-03-22 03:22:35 --> Total execution time: 0.0130
DEBUG - 2014-03-22 03:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 03:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:22:35 --> Final output sent to browser
DEBUG - 2014-03-22 03:22:35 --> Total execution time: 0.0200
DEBUG - 2014-03-22 03:27:21 --> Config Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Config Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:27:21 --> Config Class Initialized
DEBUG - 2014-03-22 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:27:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:27:21 --> URI Class Initialized
DEBUG - 2014-03-22 03:27:21 --> URI Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Router Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Router Class Initialized
DEBUG - 2014-03-22 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:27:21 --> URI Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Router Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Output Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Output Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Security Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Security Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Output Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Input Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Input Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Security Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:27:21 --> Input Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Language Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Language Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:27:21 --> Language Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Loader Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Loader Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Loader Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Controller Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Controller Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Controller Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:21 --> Session Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Session Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:27:21 --> A session cookie was not found.
DEBUG - 2014-03-22 03:27:21 --> A session cookie was not found.
DEBUG - 2014-03-22 03:27:21 --> Session routines successfully run
DEBUG - 2014-03-22 03:27:21 --> Session routines successfully run
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:21 --> Final output sent to browser
DEBUG - 2014-03-22 03:27:21 --> Final output sent to browser
DEBUG - 2014-03-22 03:27:21 --> Total execution time: 0.0160
DEBUG - 2014-03-22 03:27:21 --> Total execution time: 0.0150
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:21 --> Session Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:27:21 --> A session cookie was not found.
DEBUG - 2014-03-22 03:27:21 --> Session routines successfully run
DEBUG - 2014-03-22 03:27:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:27:21 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:21 --> Final output sent to browser
DEBUG - 2014-03-22 03:27:21 --> Total execution time: 0.0240
DEBUG - 2014-03-22 03:27:23 --> Config Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:27:23 --> URI Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Router Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Config Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Config Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Output Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Security Class Initialized
DEBUG - 2014-03-22 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:27:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 03:27:23 --> URI Class Initialized
DEBUG - 2014-03-22 03:27:23 --> URI Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Router Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Input Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Router Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Output Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Security Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Input Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:27:23 --> Language Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:27:23 --> Output Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Security Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Loader Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Language Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Input Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Controller Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Loader Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 03:27:23 --> Controller Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:27:23 --> Language Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:27:23 --> Loader Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Controller Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 03:27:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:23 --> Session Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:27:23 --> A session cookie was not found.
DEBUG - 2014-03-22 03:27:23 --> Session routines successfully run
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Session Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:27:23 --> A session cookie was not found.
DEBUG - 2014-03-22 03:27:23 --> Session routines successfully run
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:27:23 --> Session Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: string_helper
DEBUG - 2014-03-22 03:27:23 --> Final output sent to browser
DEBUG - 2014-03-22 03:27:23 --> Total execution time: 0.0180
DEBUG - 2014-03-22 03:27:23 --> A session cookie was not found.
DEBUG - 2014-03-22 03:27:23 --> Session routines successfully run
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:23 --> Helper loaded: url_helper
DEBUG - 2014-03-22 03:27:23 --> Model Class Initialized
DEBUG - 2014-03-22 03:27:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 03:27:23 --> Final output sent to browser
DEBUG - 2014-03-22 03:27:23 --> Final output sent to browser
DEBUG - 2014-03-22 03:27:23 --> Total execution time: 0.0190
DEBUG - 2014-03-22 03:27:23 --> Total execution time: 0.0190
DEBUG - 2014-03-22 05:37:24 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:24 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:24 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:24 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:24 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:24 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:24 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:24 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:24 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:24 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Session Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:37:24 --> A session cookie was not found.
DEBUG - 2014-03-22 05:37:24 --> Session routines successfully run
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:24 --> Session Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:37:24 --> A session cookie was not found.
DEBUG - 2014-03-22 05:37:24 --> Session routines successfully run
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:37:24 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:24 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:24 --> Session Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:37:24 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:37:24 --> A session cookie was not found.
DEBUG - 2014-03-22 05:37:24 --> Session routines successfully run
DEBUG - 2014-03-22 05:37:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:37:24 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:24 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:24 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:37:25 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:25 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:25 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:25 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:25 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:25 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:25 --> Session Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:37:25 --> A session cookie was not found.
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:25 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Session routines successfully run
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:25 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Total execution time: 0.0120
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:25 --> Session Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:25 --> A session cookie was not found.
DEBUG - 2014-03-22 05:37:25 --> Session Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Session routines successfully run
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:37:25 --> A session cookie was not found.
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Session routines successfully run
DEBUG - 2014-03-22 05:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:25 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:37:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:25 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:25 --> Total execution time: 0.0160
DEBUG - 2014-03-22 05:37:25 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:25 --> Total execution time: 0.0160
DEBUG - 2014-03-22 05:37:32 --> Config Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:37:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:37:32 --> URI Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Router Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Output Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Security Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Input Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:37:32 --> Language Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Loader Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Controller Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:37:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:37:32 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Model Class Initialized
DEBUG - 2014-03-22 05:37:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:37:33 --> Final output sent to browser
DEBUG - 2014-03-22 05:37:33 --> Total execution time: 1.0011
DEBUG - 2014-03-22 05:38:41 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:41 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:41 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:41 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:41 --> Session Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:38:41 --> A session cookie was not found.
DEBUG - 2014-03-22 05:38:41 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Session routines successfully run
DEBUG - 2014-03-22 05:38:41 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:38:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:41 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:41 --> Total execution time: 0.0130
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:41 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Session Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:41 --> A session cookie was not found.
DEBUG - 2014-03-22 05:38:41 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Session routines successfully run
DEBUG - 2014-03-22 05:38:41 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:38:41 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:41 --> Total execution time: 0.0200
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:41 --> Session Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:38:41 --> A session cookie was not found.
DEBUG - 2014-03-22 05:38:41 --> Session routines successfully run
DEBUG - 2014-03-22 05:38:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:38:41 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:41 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:41 --> Total execution time: 0.0240
DEBUG - 2014-03-22 05:38:43 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:43 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:43 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:43 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:43 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:43 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:43 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:43 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:43 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:43 --> Session Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:38:43 --> A session cookie was not found.
DEBUG - 2014-03-22 05:38:43 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Session routines successfully run
DEBUG - 2014-03-22 05:38:43 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:38:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:43 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:43 --> Total execution time: 0.0120
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Session Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:38:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:43 --> A session cookie was not found.
DEBUG - 2014-03-22 05:38:43 --> Session routines successfully run
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:43 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Total execution time: 0.0130
DEBUG - 2014-03-22 05:38:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:43 --> Session Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:38:43 --> A session cookie was not found.
DEBUG - 2014-03-22 05:38:43 --> Session routines successfully run
DEBUG - 2014-03-22 05:38:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:38:43 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:43 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:43 --> Total execution time: 0.0200
DEBUG - 2014-03-22 05:38:54 --> Config Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:38:54 --> URI Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Router Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Output Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Security Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Input Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:38:54 --> Language Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Loader Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Controller Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:38:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:38:54 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Model Class Initialized
DEBUG - 2014-03-22 05:38:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:38:54 --> Final output sent to browser
DEBUG - 2014-03-22 05:38:54 --> Total execution time: 0.9751
DEBUG - 2014-03-22 05:41:52 --> Config Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:41:52 --> URI Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Router Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Config Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Output Class Initialized
DEBUG - 2014-03-22 05:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:41:52 --> URI Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Security Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Router Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Input Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Config Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:41:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Output Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Language Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Security Class Initialized
DEBUG - 2014-03-22 05:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:41:52 --> Input Class Initialized
DEBUG - 2014-03-22 05:41:52 --> URI Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Loader Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:41:52 --> Controller Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Router Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Language Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:41:52 --> Loader Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Output Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Controller Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Security Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:41:52 --> Input Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:41:52 --> Language Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Loader Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Controller Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:52 --> Session Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:41:52 --> A session cookie was not found.
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Session routines successfully run
DEBUG - 2014-03-22 05:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Session Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> A session cookie was not found.
DEBUG - 2014-03-22 05:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:52 --> Session routines successfully run
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:41:52 --> Session Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:41:52 --> A session cookie was not found.
DEBUG - 2014-03-22 05:41:52 --> Final output sent to browser
DEBUG - 2014-03-22 05:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:52 --> Total execution time: 0.0130
DEBUG - 2014-03-22 05:41:52 --> Session routines successfully run
DEBUG - 2014-03-22 05:41:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:41:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:52 --> Final output sent to browser
DEBUG - 2014-03-22 05:41:52 --> Total execution time: 0.0130
DEBUG - 2014-03-22 05:41:52 --> Final output sent to browser
DEBUG - 2014-03-22 05:41:52 --> Total execution time: 0.0110
DEBUG - 2014-03-22 05:41:53 --> Config Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Config Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:41:53 --> URI Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Router Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Output Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Config Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Security Class Initialized
DEBUG - 2014-03-22 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:41:53 --> URI Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Input Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Router Class Initialized
DEBUG - 2014-03-22 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:41:53 --> URI Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Output Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Router Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:41:53 --> Security Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Input Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:41:53 --> Language Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Language Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Loader Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Loader Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Controller Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Controller Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Output Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Security Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Input Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:41:53 --> Language Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Loader Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:53 --> Controller Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Session Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:41:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> A session cookie was not found.
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Session Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Session routines successfully run
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:41:53 --> A session cookie was not found.
DEBUG - 2014-03-22 05:41:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Session routines successfully run
DEBUG - 2014-03-22 05:41:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Final output sent to browser
DEBUG - 2014-03-22 05:41:53 --> Total execution time: 0.0150
DEBUG - 2014-03-22 05:41:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:53 --> Session Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:41:53 --> A session cookie was not found.
DEBUG - 2014-03-22 05:41:53 --> Session routines successfully run
DEBUG - 2014-03-22 05:41:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:41:53 --> Model Class Initialized
DEBUG - 2014-03-22 05:41:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:41:53 --> Final output sent to browser
DEBUG - 2014-03-22 05:41:53 --> Total execution time: 0.0170
DEBUG - 2014-03-22 05:41:53 --> Final output sent to browser
DEBUG - 2014-03-22 05:41:53 --> Total execution time: 0.0260
DEBUG - 2014-03-22 05:42:01 --> Config Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:42:01 --> URI Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Router Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Output Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Security Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Input Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:42:01 --> Language Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Loader Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Controller Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:42:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:42:01 --> Model Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Model Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Model Class Initialized
DEBUG - 2014-03-22 05:42:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:42:02 --> Final output sent to browser
DEBUG - 2014-03-22 05:42:02 --> Total execution time: 1.1101
DEBUG - 2014-03-22 05:44:19 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:19 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:19 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:19 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:19 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:19 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:19 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:19 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:19 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:19 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Session Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:19 --> A session cookie was not found.
DEBUG - 2014-03-22 05:44:19 --> Session routines successfully run
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Session Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:44:19 --> A session cookie was not found.
DEBUG - 2014-03-22 05:44:19 --> Session routines successfully run
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:19 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:19 --> Session Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:44:19 --> A session cookie was not found.
DEBUG - 2014-03-22 05:44:19 --> Session routines successfully run
DEBUG - 2014-03-22 05:44:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:44:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:19 --> Total execution time: 0.0170
DEBUG - 2014-03-22 05:44:19 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:19 --> Total execution time: 0.0200
DEBUG - 2014-03-22 05:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:19 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:19 --> Total execution time: 0.0210
DEBUG - 2014-03-22 05:44:21 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:21 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:21 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:21 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:21 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:21 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:21 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:21 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:21 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:21 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Session Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:44:21 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> A session cookie was not found.
DEBUG - 2014-03-22 05:44:21 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Session routines successfully run
DEBUG - 2014-03-22 05:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:44:21 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:21 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:21 --> Total execution time: 0.0110
DEBUG - 2014-03-22 05:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Session Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:44:21 --> A session cookie was not found.
DEBUG - 2014-03-22 05:44:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Session routines successfully run
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:21 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:21 --> Total execution time: 0.0170
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:21 --> Session Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:44:21 --> A session cookie was not found.
DEBUG - 2014-03-22 05:44:21 --> Session routines successfully run
DEBUG - 2014-03-22 05:44:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:44:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:21 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:21 --> Total execution time: 0.0230
DEBUG - 2014-03-22 05:44:28 --> Config Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:44:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:44:28 --> URI Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Router Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Output Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Security Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Input Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:44:28 --> Language Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Loader Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Controller Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:44:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:44:28 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Model Class Initialized
DEBUG - 2014-03-22 05:44:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:44:29 --> Final output sent to browser
DEBUG - 2014-03-22 05:44:29 --> Total execution time: 1.2881
DEBUG - 2014-03-22 05:45:52 --> Config Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Config Class Initialized
DEBUG - 2014-03-22 05:45:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:45:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:45:52 --> URI Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:45:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:45:52 --> URI Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Router Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Router Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Config Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Output Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Output Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Security Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Input Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:45:52 --> Language Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Loader Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Controller Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> URI Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Router Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Output Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Security Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Input Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:45:52 --> Language Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Loader Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Controller Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Security Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Input Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:45:52 --> Language Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Loader Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:52 --> Controller Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Session Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:45:52 --> A session cookie was not found.
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Session routines successfully run
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:45:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Session Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:45:52 --> A session cookie was not found.
DEBUG - 2014-03-22 05:45:52 --> Session routines successfully run
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:45:52 --> Final output sent to browser
DEBUG - 2014-03-22 05:45:52 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:52 --> Final output sent to browser
DEBUG - 2014-03-22 05:45:52 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:45:52 --> Session Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:45:52 --> A session cookie was not found.
DEBUG - 2014-03-22 05:45:52 --> Session routines successfully run
DEBUG - 2014-03-22 05:45:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:45:52 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:52 --> Final output sent to browser
DEBUG - 2014-03-22 05:45:52 --> Total execution time: 0.0230
DEBUG - 2014-03-22 05:45:56 --> Config Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:45:56 --> Config Class Initialized
DEBUG - 2014-03-22 05:45:56 --> URI Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Router Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:45:56 --> Output Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Config Class Initialized
DEBUG - 2014-03-22 05:45:56 --> URI Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Security Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Router Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Input Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:45:56 --> Output Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Language Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Security Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Input Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Loader Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:45:56 --> Controller Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Language Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:45:56 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Loader Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Controller Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:45:56 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:45:56 --> URI Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Router Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Output Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Security Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Session Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Input Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:45:56 --> A session cookie was not found.
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:45:56 --> Session routines successfully run
DEBUG - 2014-03-22 05:45:56 --> Language Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:45:56 --> Loader Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:56 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Controller Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:45:56 --> Final output sent to browser
DEBUG - 2014-03-22 05:45:56 --> Total execution time: 0.0120
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:56 --> Session Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Session Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:45:56 --> A session cookie was not found.
DEBUG - 2014-03-22 05:45:56 --> A session cookie was not found.
DEBUG - 2014-03-22 05:45:56 --> Session routines successfully run
DEBUG - 2014-03-22 05:45:56 --> Session routines successfully run
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:45:56 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:45:56 --> Final output sent to browser
DEBUG - 2014-03-22 05:45:56 --> Final output sent to browser
DEBUG - 2014-03-22 05:45:56 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:45:56 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:46:05 --> Config Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:46:05 --> URI Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Router Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Output Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Security Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Input Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:46:05 --> Language Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Loader Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Controller Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:46:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:46:05 --> Model Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Model Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Model Class Initialized
DEBUG - 2014-03-22 05:46:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:46:09 --> Final output sent to browser
DEBUG - 2014-03-22 05:46:09 --> Total execution time: 3.9372
DEBUG - 2014-03-22 05:48:47 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:47 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:47 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:47 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:47 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:47 --> Session Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:48:47 --> A session cookie was not found.
DEBUG - 2014-03-22 05:48:47 --> Session routines successfully run
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:47 --> Session Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:48:47 --> A session cookie was not found.
DEBUG - 2014-03-22 05:48:47 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:47 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Session routines successfully run
DEBUG - 2014-03-22 05:48:47 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:48:47 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:48:47 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:47 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:47 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:47 --> Total execution time: 0.0230
DEBUG - 2014-03-22 05:48:47 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:47 --> Session Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:48:47 --> A session cookie was not found.
DEBUG - 2014-03-22 05:48:47 --> Session routines successfully run
DEBUG - 2014-03-22 05:48:47 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:48:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:47 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:47 --> Total execution time: 0.0175
DEBUG - 2014-03-22 05:48:49 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:49 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:49 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:49 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:49 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:49 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:49 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:49 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:49 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Session Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:48:49 --> A session cookie was not found.
DEBUG - 2014-03-22 05:48:49 --> Session routines successfully run
DEBUG - 2014-03-22 05:48:49 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:49 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:49 --> Total execution time: 0.0110
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:49 --> Session Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Session Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:48:49 --> A session cookie was not found.
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:48:49 --> Session routines successfully run
DEBUG - 2014-03-22 05:48:49 --> A session cookie was not found.
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:48:49 --> Session routines successfully run
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:48:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:49 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:49 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:49 --> Total execution time: 0.0160
DEBUG - 2014-03-22 05:48:49 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:49 --> Total execution time: 0.0130
DEBUG - 2014-03-22 05:48:57 --> Config Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:48:57 --> URI Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Router Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Output Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Security Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Input Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:48:57 --> Language Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Loader Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Controller Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:48:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:48:57 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Model Class Initialized
DEBUG - 2014-03-22 05:48:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:48:58 --> Final output sent to browser
DEBUG - 2014-03-22 05:48:58 --> Total execution time: 1.0371
DEBUG - 2014-03-22 05:49:45 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:45 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:45 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:45 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:45 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:45 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:45 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Session Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:49:45 --> A session cookie was not found.
DEBUG - 2014-03-22 05:49:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Session routines successfully run
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:49:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:45 --> Session Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:49:45 --> A session cookie was not found.
DEBUG - 2014-03-22 05:49:45 --> Session routines successfully run
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:45 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:45 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:45 --> Total execution time: 0.0225
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:45 --> Session Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Total execution time: 0.0235
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:49:45 --> A session cookie was not found.
DEBUG - 2014-03-22 05:49:45 --> Session routines successfully run
DEBUG - 2014-03-22 05:49:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:49:45 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:45 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:45 --> Total execution time: 0.0285
DEBUG - 2014-03-22 05:49:47 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:47 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:47 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:47 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:47 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:47 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:47 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:47 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:47 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:47 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:47 --> Session Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Session Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:49:47 --> A session cookie was not found.
DEBUG - 2014-03-22 05:49:47 --> A session cookie was not found.
DEBUG - 2014-03-22 05:49:47 --> Session routines successfully run
DEBUG - 2014-03-22 05:49:47 --> Session routines successfully run
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:47 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:47 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:47 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:49:47 --> Total execution time: 0.0150
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:47 --> Session Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:49:47 --> A session cookie was not found.
DEBUG - 2014-03-22 05:49:47 --> Session routines successfully run
DEBUG - 2014-03-22 05:49:47 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:49:47 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:47 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:47 --> Total execution time: 0.0220
DEBUG - 2014-03-22 05:49:55 --> Config Class Initialized
DEBUG - 2014-03-22 05:49:55 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:49:55 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:49:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:49:56 --> URI Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Router Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Output Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Security Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Input Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:49:56 --> Language Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Loader Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Controller Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:49:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:49:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Model Class Initialized
DEBUG - 2014-03-22 05:49:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:49:57 --> Final output sent to browser
DEBUG - 2014-03-22 05:49:57 --> Total execution time: 1.1261
DEBUG - 2014-03-22 05:53:17 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:17 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:17 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:17 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:17 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:17 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:17 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:17 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:17 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:17 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:17 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Total execution time: 0.0160
DEBUG - 2014-03-22 05:53:17 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:17 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:17 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:17 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:17 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:17 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:17 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:17 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:17 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:17 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:17 --> Total execution time: 0.0270
DEBUG - 2014-03-22 05:53:17 --> Total execution time: 0.0280
DEBUG - 2014-03-22 05:53:18 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:18 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:18 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:18 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:18 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:18 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:18 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:18 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:18 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:18 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:18 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:18 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:18 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:18 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:18 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:18 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:18 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:18 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:18 --> Total execution time: 0.0120
DEBUG - 2014-03-22 05:53:18 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:18 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:18 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:18 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:53:18 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:18 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:53:25 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:25 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:25 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:26 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:26 --> Total execution time: 1.1991
DEBUG - 2014-03-22 05:53:58 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:58 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:58 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:58 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:58 --> Config Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:53:58 --> URI Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Router Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Output Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Security Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Input Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:58 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:53:58 --> Language Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Loader Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Controller Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:58 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:58 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:58 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:58 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:58 --> Session Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:53:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:58 --> A session cookie was not found.
DEBUG - 2014-03-22 05:53:58 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:58 --> Session routines successfully run
DEBUG - 2014-03-22 05:53:58 --> Total execution time: 0.0175
DEBUG - 2014-03-22 05:53:58 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:58 --> Total execution time: 0.0215
DEBUG - 2014-03-22 05:53:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:53:58 --> Model Class Initialized
DEBUG - 2014-03-22 05:53:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:53:58 --> Final output sent to browser
DEBUG - 2014-03-22 05:53:58 --> Total execution time: 0.0265
DEBUG - 2014-03-22 05:54:00 --> Config Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:54:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:54:00 --> URI Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Router Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Output Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Security Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Input Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:54:00 --> Language Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Loader Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Controller Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:00 --> Session Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:54:00 --> A session cookie was not found.
DEBUG - 2014-03-22 05:54:00 --> Session routines successfully run
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:00 --> Config Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:54:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:54:00 --> URI Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Router Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Final output sent to browser
DEBUG - 2014-03-22 05:54:00 --> Total execution time: 0.0195
DEBUG - 2014-03-22 05:54:00 --> Output Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Security Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Input Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:54:00 --> Language Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Loader Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Controller Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:00 --> Session Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:54:00 --> A session cookie was not found.
DEBUG - 2014-03-22 05:54:00 --> Session routines successfully run
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:00 --> Final output sent to browser
DEBUG - 2014-03-22 05:54:00 --> Config Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Total execution time: 0.0115
DEBUG - 2014-03-22 05:54:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:54:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:54:00 --> URI Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Router Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Output Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Security Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Input Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:54:00 --> Language Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Loader Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Controller Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:00 --> Session Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:54:00 --> A session cookie was not found.
DEBUG - 2014-03-22 05:54:00 --> Session routines successfully run
DEBUG - 2014-03-22 05:54:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:54:00 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:00 --> Final output sent to browser
DEBUG - 2014-03-22 05:54:00 --> Total execution time: 0.0105
DEBUG - 2014-03-22 05:54:07 --> Config Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:54:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:54:07 --> URI Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Router Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Output Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Security Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Input Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:54:07 --> Language Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Loader Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Controller Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:54:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:54:07 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Model Class Initialized
DEBUG - 2014-03-22 05:54:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:54:08 --> Final output sent to browser
DEBUG - 2014-03-22 05:54:08 --> Total execution time: 0.9641
DEBUG - 2014-03-22 05:59:19 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:19 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:19 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:19 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:19 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:19 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:19 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:19 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:19 --> Session Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:59:19 --> A session cookie was not found.
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:19 --> Session routines successfully run
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:19 --> Session Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:59:19 --> A session cookie was not found.
DEBUG - 2014-03-22 05:59:19 --> Session routines successfully run
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:19 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:19 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:19 --> Session Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:59:19 --> A session cookie was not found.
DEBUG - 2014-03-22 05:59:19 --> Session routines successfully run
DEBUG - 2014-03-22 05:59:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:59:19 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:19 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:19 --> Total execution time: 0.0200
DEBUG - 2014-03-22 05:59:21 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:21 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:21 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:21 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:21 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:21 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:21 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:21 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:21 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:21 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:21 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Session Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:21 --> Session Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> A session cookie was not found.
DEBUG - 2014-03-22 05:59:21 --> A session cookie was not found.
DEBUG - 2014-03-22 05:59:21 --> Session routines successfully run
DEBUG - 2014-03-22 05:59:21 --> Session routines successfully run
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:21 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:21 --> Total execution time: 0.0120
DEBUG - 2014-03-22 05:59:21 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:21 --> Total execution time: 0.0140
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:21 --> Session Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 05:59:21 --> A session cookie was not found.
DEBUG - 2014-03-22 05:59:21 --> Session routines successfully run
DEBUG - 2014-03-22 05:59:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 05:59:21 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:21 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:21 --> Total execution time: 0.0180
DEBUG - 2014-03-22 05:59:27 --> Config Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Hooks Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Utf8 Class Initialized
DEBUG - 2014-03-22 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 05:59:27 --> URI Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Router Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Output Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Security Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Input Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 05:59:27 --> Language Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Loader Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Controller Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 05:59:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 05:59:27 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Database Driver Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Model Class Initialized
DEBUG - 2014-03-22 05:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 05:59:28 --> Final output sent to browser
DEBUG - 2014-03-22 05:59:28 --> Total execution time: 0.9901
DEBUG - 2014-03-22 06:00:58 --> Config Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Config Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:00:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:00:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:00:58 --> URI Class Initialized
DEBUG - 2014-03-22 06:00:58 --> URI Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Router Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Router Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Output Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Output Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Security Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Security Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Input Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Input Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:00:58 --> Language Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Language Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Loader Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Loader Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Controller Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Controller Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:00:58 --> Config Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:00:58 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:00:58 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> URI Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Router Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Output Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Security Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Input Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Language Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Session Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:00:58 --> A session cookie was not found.
DEBUG - 2014-03-22 06:00:58 --> Session Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Session routines successfully run
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Loader Class Initialized
DEBUG - 2014-03-22 06:00:58 --> A session cookie was not found.
DEBUG - 2014-03-22 06:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:58 --> Controller Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Session routines successfully run
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:00:58 --> Final output sent to browser
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:00:58 --> Total execution time: 0.0140
DEBUG - 2014-03-22 06:00:58 --> Final output sent to browser
DEBUG - 2014-03-22 06:00:58 --> Total execution time: 0.0155
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:58 --> Session Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:00:58 --> A session cookie was not found.
DEBUG - 2014-03-22 06:00:58 --> Session routines successfully run
DEBUG - 2014-03-22 06:00:58 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:00:58 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:58 --> Final output sent to browser
DEBUG - 2014-03-22 06:00:58 --> Total execution time: 0.0175
DEBUG - 2014-03-22 06:00:59 --> Config Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Config Class Initialized
DEBUG - 2014-03-22 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:00:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:00:59 --> URI Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Router Class Initialized
DEBUG - 2014-03-22 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:00:59 --> URI Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Output Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Router Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Security Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Input Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Output Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:00:59 --> Language Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Config Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Security Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Loader Class Initialized
DEBUG - 2014-03-22 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:00:59 --> Controller Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Input Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:00:59 --> Language Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:00:59 --> URI Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Router Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Output Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Security Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Input Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Language Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Loader Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:59 --> Controller Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Loader Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:00:59 --> Session Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:00:59 --> A session cookie was not found.
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Session routines successfully run
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:59 --> Controller Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:00:59 --> Final output sent to browser
DEBUG - 2014-03-22 06:00:59 --> Total execution time: 0.0110
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Session Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:00:59 --> A session cookie was not found.
DEBUG - 2014-03-22 06:00:59 --> Session routines successfully run
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:59 --> Session Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> A session cookie was not found.
DEBUG - 2014-03-22 06:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:59 --> Session routines successfully run
DEBUG - 2014-03-22 06:00:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:00:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:00:59 --> Final output sent to browser
DEBUG - 2014-03-22 06:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:00:59 --> Total execution time: 0.0170
DEBUG - 2014-03-22 06:00:59 --> Final output sent to browser
DEBUG - 2014-03-22 06:00:59 --> Total execution time: 0.0150
DEBUG - 2014-03-22 06:01:10 --> Config Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:01:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:01:10 --> URI Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Router Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Output Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Security Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Input Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:01:10 --> Language Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Loader Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Controller Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:01:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:01:10 --> Model Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Model Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Model Class Initialized
DEBUG - 2014-03-22 06:01:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:01:11 --> Final output sent to browser
DEBUG - 2014-03-22 06:01:11 --> Total execution time: 0.9471
DEBUG - 2014-03-22 06:02:00 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:00 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:00 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:00 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:00 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:00 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:00 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:00 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:00 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:00 --> Session Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:00 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> A session cookie was not found.
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Session routines successfully run
DEBUG - 2014-03-22 06:02:00 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:02:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:00 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:00 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:00 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:00 --> Session Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Total execution time: 0.0150
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:02:00 --> A session cookie was not found.
DEBUG - 2014-03-22 06:02:00 --> Session routines successfully run
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:00 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Total execution time: 0.0155
DEBUG - 2014-03-22 06:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:00 --> Session Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:02:00 --> A session cookie was not found.
DEBUG - 2014-03-22 06:02:00 --> Session routines successfully run
DEBUG - 2014-03-22 06:02:00 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:02:00 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:00 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:00 --> Total execution time: 0.0230
DEBUG - 2014-03-22 06:02:02 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:02 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:02 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:02 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:02 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:02 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:02 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:02 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:02 --> Session Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:02:02 --> A session cookie was not found.
DEBUG - 2014-03-22 06:02:02 --> Session routines successfully run
DEBUG - 2014-03-22 06:02:02 --> Session Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> A session cookie was not found.
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Session routines successfully run
DEBUG - 2014-03-22 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:02:02 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:02 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:02 --> Total execution time: 0.0150
DEBUG - 2014-03-22 06:02:02 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Total execution time: 0.0170
DEBUG - 2014-03-22 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:02 --> Session Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:02:02 --> A session cookie was not found.
DEBUG - 2014-03-22 06:02:02 --> Session routines successfully run
DEBUG - 2014-03-22 06:02:02 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:02:02 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:02 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:02 --> Total execution time: 0.0170
DEBUG - 2014-03-22 06:02:09 --> Config Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:02:09 --> URI Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Router Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Output Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Security Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Input Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:02:09 --> Language Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Loader Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Controller Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:02:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:02:09 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Model Class Initialized
DEBUG - 2014-03-22 06:02:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:02:10 --> Final output sent to browser
DEBUG - 2014-03-22 06:02:10 --> Total execution time: 0.9611
DEBUG - 2014-03-22 06:43:31 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:31 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:31 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:31 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:31 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:31 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:31 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:31 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:31 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:31 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:31 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:31 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:31 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:31 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:31 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:31 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:31 --> Total execution time: 0.0245
DEBUG - 2014-03-22 06:43:31 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:31 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:31 --> Total execution time: 0.0245
DEBUG - 2014-03-22 06:43:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:31 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:31 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:31 --> Total execution time: 0.0270
DEBUG - 2014-03-22 06:43:33 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:33 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:33 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:33 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:33 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:33 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:33 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:33 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:33 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:33 --> Total execution time: 0.0180
DEBUG - 2014-03-22 06:43:33 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:33 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:33 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:33 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:33 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:33 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:33 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:33 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:33 --> Total execution time: 0.0240
DEBUG - 2014-03-22 06:43:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:33 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:33 --> Total execution time: 0.0250
DEBUG - 2014-03-22 06:43:36 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:36 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:36 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:36 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:36 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:36 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:36 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:36 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:36 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:36 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:36 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:36 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:36 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:36 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:36 --> Session Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:43:36 --> A session cookie was not found.
DEBUG - 2014-03-22 06:43:36 --> Session routines successfully run
DEBUG - 2014-03-22 06:43:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:43:36 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:36 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:36 --> Total execution time: 0.0140
DEBUG - 2014-03-22 06:43:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:36 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:36 --> Total execution time: 0.0130
DEBUG - 2014-03-22 06:43:36 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:36 --> Total execution time: 0.0140
DEBUG - 2014-03-22 06:43:44 --> Config Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:43:44 --> URI Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Router Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Output Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Security Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Input Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:43:44 --> Language Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Loader Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Controller Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:43:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:43:44 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Model Class Initialized
DEBUG - 2014-03-22 06:43:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:43:45 --> Final output sent to browser
DEBUG - 2014-03-22 06:43:45 --> Total execution time: 1.0581
DEBUG - 2014-03-22 06:45:59 --> Config Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:45:59 --> URI Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Router Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Output Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Security Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Input Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:45:59 --> Language Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Loader Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Controller Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Config Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Config Class Initialized
DEBUG - 2014-03-22 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:45:59 --> URI Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:45:59 --> Router Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:45:59 --> Output Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Security Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Session Class Initialized
DEBUG - 2014-03-22 06:45:59 --> URI Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Input Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:45:59 --> Router Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Language Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:45:59 --> Loader Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Controller Class Initialized
DEBUG - 2014-03-22 06:45:59 --> A session cookie was not found.
DEBUG - 2014-03-22 06:45:59 --> Output Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:45:59 --> Session routines successfully run
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:45:59 --> Security Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:45:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Input Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:45:59 --> Final output sent to browser
DEBUG - 2014-03-22 06:45:59 --> Total execution time: 0.0160
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:45:59 --> Language Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Session Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:45:59 --> A session cookie was not found.
DEBUG - 2014-03-22 06:45:59 --> Loader Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Session routines successfully run
DEBUG - 2014-03-22 06:45:59 --> Controller Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Final output sent to browser
DEBUG - 2014-03-22 06:45:59 --> Total execution time: 0.0165
DEBUG - 2014-03-22 06:45:59 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:45:59 --> Session Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:45:59 --> A session cookie was not found.
DEBUG - 2014-03-22 06:45:59 --> Session routines successfully run
DEBUG - 2014-03-22 06:45:59 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:45:59 --> Model Class Initialized
DEBUG - 2014-03-22 06:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:45:59 --> Final output sent to browser
DEBUG - 2014-03-22 06:45:59 --> Total execution time: 0.0220
DEBUG - 2014-03-22 06:46:01 --> Config Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Config Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:46:01 --> URI Class Initialized
DEBUG - 2014-03-22 06:46:01 --> URI Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Router Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Router Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Output Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Config Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Output Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Security Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Security Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Input Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Input Class Initialized
DEBUG - 2014-03-22 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:46:01 --> Language Class Initialized
DEBUG - 2014-03-22 06:46:01 --> URI Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Loader Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Router Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Language Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Controller Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Loader Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:46:01 --> Controller Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:46:01 --> Output Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Security Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Input Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Language Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Loader Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Controller Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:01 --> Session Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Session Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:46:01 --> A session cookie was not found.
DEBUG - 2014-03-22 06:46:01 --> A session cookie was not found.
DEBUG - 2014-03-22 06:46:01 --> Session routines successfully run
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:46:01 --> Session routines successfully run
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:01 --> Session Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:46:01 --> A session cookie was not found.
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:46:01 --> Session routines successfully run
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:46:01 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:01 --> Final output sent to browser
DEBUG - 2014-03-22 06:46:01 --> Total execution time: 0.0170
DEBUG - 2014-03-22 06:46:01 --> Final output sent to browser
DEBUG - 2014-03-22 06:46:01 --> Total execution time: 0.0150
DEBUG - 2014-03-22 06:46:01 --> Final output sent to browser
DEBUG - 2014-03-22 06:46:01 --> Total execution time: 0.0195
DEBUG - 2014-03-22 06:46:10 --> Config Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:46:10 --> URI Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Router Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Output Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Security Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Input Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:46:10 --> Language Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Loader Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Controller Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:46:10 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Model Class Initialized
DEBUG - 2014-03-22 06:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:46:11 --> Final output sent to browser
DEBUG - 2014-03-22 06:46:11 --> Total execution time: 0.9601
DEBUG - 2014-03-22 06:50:30 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:30 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:30 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:30 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:30 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:30 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:30 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:30 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:30 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:30 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:30 --> Total execution time: 0.0140
DEBUG - 2014-03-22 06:50:30 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:30 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:30 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:30 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:30 --> Total execution time: 0.0150
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:30 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:30 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:30 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:30 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:30 --> Total execution time: 0.0220
DEBUG - 2014-03-22 06:50:32 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:32 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:32 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:32 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:32 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:32 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:32 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:32 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:32 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:32 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:32 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:32 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:32 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:32 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:32 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:32 --> Total execution time: 0.0150
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:32 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:32 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:32 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:32 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:32 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:32 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:32 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:32 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:32 --> Total execution time: 0.0190
DEBUG - 2014-03-22 06:50:32 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:32 --> Total execution time: 0.0165
DEBUG - 2014-03-22 06:50:33 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:33 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:33 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:33 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:33 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:33 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:33 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:33 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:33 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:33 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:33 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:33 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:33 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:33 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:33 --> Total execution time: 0.0130
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:33 --> Total execution time: 0.0180
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:33 --> Session Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:50:33 --> A session cookie was not found.
DEBUG - 2014-03-22 06:50:33 --> Session routines successfully run
DEBUG - 2014-03-22 06:50:33 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:50:33 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:33 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:33 --> Total execution time: 0.0210
DEBUG - 2014-03-22 06:50:41 --> Config Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:50:41 --> URI Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Router Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Output Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Security Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Input Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:50:41 --> Language Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Loader Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Controller Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:50:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:50:41 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Model Class Initialized
DEBUG - 2014-03-22 06:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:50:45 --> Final output sent to browser
DEBUG - 2014-03-22 06:50:45 --> Total execution time: 4.0552
DEBUG - 2014-03-22 06:55:16 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:16 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:16 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:16 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:16 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:16 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:16 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:16 --> Session Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:55:16 --> A session cookie was not found.
DEBUG - 2014-03-22 06:55:16 --> Session routines successfully run
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:16 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:16 --> Total execution time: 0.0140
DEBUG - 2014-03-22 06:55:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:17 --> Session Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:55:17 --> A session cookie was not found.
DEBUG - 2014-03-22 06:55:17 --> Session routines successfully run
DEBUG - 2014-03-22 06:55:17 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:55:17 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:17 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:17 --> Session Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:17 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:55:17 --> A session cookie was not found.
DEBUG - 2014-03-22 06:55:17 --> Total execution time: 0.0265
DEBUG - 2014-03-22 06:55:17 --> Session routines successfully run
DEBUG - 2014-03-22 06:55:17 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:55:17 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:17 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:17 --> Total execution time: 0.0290
DEBUG - 2014-03-22 06:55:19 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:19 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:19 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:19 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:19 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:19 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:19 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:19 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:19 --> Session Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:55:19 --> A session cookie was not found.
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Session routines successfully run
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:55:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:19 --> Total execution time: 0.0175
DEBUG - 2014-03-22 06:55:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:19 --> Session Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:55:19 --> A session cookie was not found.
DEBUG - 2014-03-22 06:55:19 --> Session routines successfully run
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:19 --> Session Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 06:55:19 --> A session cookie was not found.
DEBUG - 2014-03-22 06:55:19 --> Session routines successfully run
DEBUG - 2014-03-22 06:55:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 06:55:19 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:19 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:19 --> Total execution time: 0.0245
DEBUG - 2014-03-22 06:55:19 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:19 --> Total execution time: 0.0290
DEBUG - 2014-03-22 06:55:27 --> Config Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Hooks Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Utf8 Class Initialized
DEBUG - 2014-03-22 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 06:55:27 --> URI Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Router Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Output Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Security Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Input Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 06:55:27 --> Language Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Loader Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Controller Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 06:55:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 06:55:27 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Database Driver Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Model Class Initialized
DEBUG - 2014-03-22 06:55:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 06:55:28 --> Final output sent to browser
DEBUG - 2014-03-22 06:55:28 --> Total execution time: 0.9551
DEBUG - 2014-03-22 07:06:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:06:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:06:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:06:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:06:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:06:13 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:06:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:06:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:06:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:13 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:06:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:13 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:06:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:06:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:06:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:06:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:06:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:06:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:16 --> Total execution time: 0.0180
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:06:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:06:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:06:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:06:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:16 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:06:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:06:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:06:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:06:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:06:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:06:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:06:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:06:25 --> Final output sent to browser
DEBUG - 2014-03-22 07:06:25 --> Total execution time: 0.9541
DEBUG - 2014-03-22 07:08:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:08:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:08:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:08:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:08:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:08:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:08:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:08:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:08:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:08:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:13 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:08:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:13 --> Total execution time: 0.0180
DEBUG - 2014-03-22 07:08:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:08:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:08:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:08:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:16 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:08:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:08:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Total execution time: 0.0260
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:08:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:08:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:08:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:08:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:16 --> Total execution time: 0.0290
DEBUG - 2014-03-22 07:08:27 --> Config Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:08:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:08:27 --> URI Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Router Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Output Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Security Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Input Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:08:27 --> Language Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Loader Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Controller Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:08:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:08:27 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Model Class Initialized
DEBUG - 2014-03-22 07:08:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:08:27 --> Final output sent to browser
DEBUG - 2014-03-22 07:08:27 --> Total execution time: 0.9591
DEBUG - 2014-03-22 07:11:01 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:01 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:01 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:01 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:01 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:01 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:01 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:01 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:01 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:01 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:01 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:01 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:01 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:01 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:01 --> Total execution time: 0.0185
DEBUG - 2014-03-22 07:11:01 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:01 --> Total execution time: 0.0195
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:01 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:01 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:01 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:01 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:01 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:01 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:01 --> Total execution time: 0.0270
DEBUG - 2014-03-22 07:11:03 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:03 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:03 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:03 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:03 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:03 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:03 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:03 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:03 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:03 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:03 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:03 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:11:03 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:03 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:03 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:03 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:03 --> Total execution time: 0.0165
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:03 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:03 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:03 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:03 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:03 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:03 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:03 --> Total execution time: 0.0245
DEBUG - 2014-03-22 07:11:11 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:11 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:11 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:11 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:12 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:12 --> Total execution time: 0.9631
DEBUG - 2014-03-22 07:11:43 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:43 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:43 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:43 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:43 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:43 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:43 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:43 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:43 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:43 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:43 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:43 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:43 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:43 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:43 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:43 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:43 --> Total execution time: 0.0250
DEBUG - 2014-03-22 07:11:43 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:43 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:43 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:43 --> Total execution time: 0.0295
DEBUG - 2014-03-22 07:11:43 --> Total execution time: 0.0305
DEBUG - 2014-03-22 07:11:45 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:45 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:45 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:45 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:45 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:45 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:45 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:45 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:45 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:45 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:45 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:45 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:45 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:45 --> Total execution time: 0.0120
DEBUG - 2014-03-22 07:11:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:45 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:45 --> Session Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:11:45 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:45 --> A session cookie was not found.
DEBUG - 2014-03-22 07:11:45 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:45 --> Session routines successfully run
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:11:45 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:45 --> Final output sent to browser
DEBUG - 2014-03-22 07:11:45 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:11:45 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:11:57 --> Config Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:11:57 --> URI Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Router Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Output Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Security Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Input Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:11:57 --> Language Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Loader Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Controller Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:11:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:11:57 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Model Class Initialized
DEBUG - 2014-03-22 07:11:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:12:01 --> Final output sent to browser
DEBUG - 2014-03-22 07:12:01 --> Total execution time: 4.0472
DEBUG - 2014-03-22 07:14:38 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:38 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:38 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:38 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:38 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:38 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:38 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:38 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:38 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:38 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:38 --> Session Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Session Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> A session cookie was not found.
DEBUG - 2014-03-22 07:14:38 --> A session cookie was not found.
DEBUG - 2014-03-22 07:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:38 --> Session routines successfully run
DEBUG - 2014-03-22 07:14:38 --> Session Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:14:38 --> A session cookie was not found.
DEBUG - 2014-03-22 07:14:38 --> Session routines successfully run
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Session routines successfully run
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:38 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:38 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:38 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:38 --> Total execution time: 0.0245
DEBUG - 2014-03-22 07:14:38 --> Total execution time: 0.0215
DEBUG - 2014-03-22 07:14:38 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:38 --> Total execution time: 0.0190
DEBUG - 2014-03-22 07:14:40 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:40 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:40 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:40 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:40 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:40 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:40 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:40 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:40 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:40 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:40 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:40 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Session Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:14:40 --> A session cookie was not found.
DEBUG - 2014-03-22 07:14:40 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Session routines successfully run
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:40 --> Session Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:14:40 --> A session cookie was not found.
DEBUG - 2014-03-22 07:14:40 --> Session Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Session routines successfully run
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:14:40 --> A session cookie was not found.
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:14:40 --> Session routines successfully run
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:40 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:40 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:40 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:14:40 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:40 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:40 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:14:40 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:14:48 --> Config Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:14:48 --> URI Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Router Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Output Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Security Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Input Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:14:48 --> Language Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Loader Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Controller Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:14:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:14:48 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Model Class Initialized
DEBUG - 2014-03-22 07:14:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:14:49 --> Final output sent to browser
DEBUG - 2014-03-22 07:14:49 --> Total execution time: 0.9531
DEBUG - 2014-03-22 07:17:29 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:29 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:29 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:29 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:29 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:29 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:29 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:29 --> Session Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> A session cookie was not found.
DEBUG - 2014-03-22 07:17:29 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Session routines successfully run
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:29 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:29 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:17:29 --> Session Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:17:29 --> A session cookie was not found.
DEBUG - 2014-03-22 07:17:29 --> Session routines successfully run
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:29 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:29 --> Total execution time: 0.0130
DEBUG - 2014-03-22 07:17:29 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:29 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:29 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:29 --> Session Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:17:29 --> A session cookie was not found.
DEBUG - 2014-03-22 07:17:29 --> Session routines successfully run
DEBUG - 2014-03-22 07:17:29 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:17:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:29 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:29 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:17:31 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:31 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:31 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:31 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:31 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:31 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:31 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:31 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:31 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:31 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Session Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:17:31 --> A session cookie was not found.
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:31 --> Session routines successfully run
DEBUG - 2014-03-22 07:17:31 --> Session Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:17:31 --> A session cookie was not found.
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Session routines successfully run
DEBUG - 2014-03-22 07:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:31 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:31 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:17:31 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:31 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:31 --> Session Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:17:31 --> A session cookie was not found.
DEBUG - 2014-03-22 07:17:31 --> Session routines successfully run
DEBUG - 2014-03-22 07:17:31 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:17:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:31 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:31 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:17:39 --> Config Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:17:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:17:39 --> URI Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Router Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Output Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Security Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Input Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:17:39 --> Language Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Loader Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Controller Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:17:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:17:39 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Model Class Initialized
DEBUG - 2014-03-22 07:17:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:17:40 --> Final output sent to browser
DEBUG - 2014-03-22 07:17:40 --> Total execution time: 0.9521
DEBUG - 2014-03-22 07:21:41 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:41 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:41 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:41 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:41 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:41 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:41 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:41 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:41 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:41 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:41 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:41 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:41 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:41 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:41 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:41 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:41 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:41 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:21:41 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:41 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:41 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:41 --> Total execution time: 0.0210
DEBUG - 2014-03-22 07:21:41 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:41 --> Total execution time: 0.0235
DEBUG - 2014-03-22 07:21:43 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:43 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:43 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:43 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:43 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:43 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:43 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:43 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:43 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:43 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:43 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:43 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:43 --> Total execution time: 0.0260
DEBUG - 2014-03-22 07:21:43 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:43 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:43 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:43 --> Total execution time: 0.0305
DEBUG - 2014-03-22 07:21:43 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:43 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:43 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:43 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:43 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:43 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:43 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:43 --> Total execution time: 0.0260
DEBUG - 2014-03-22 07:21:45 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:45 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:45 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:45 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:45 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:45 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:45 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:45 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:45 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:45 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:45 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:45 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:45 --> Session Class Initialized
DEBUG - 2014-03-22 07:21:45 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:45 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:45 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:21:45 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> A session cookie was not found.
DEBUG - 2014-03-22 07:21:45 --> Session routines successfully run
DEBUG - 2014-03-22 07:21:45 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:45 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:45 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:45 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:21:45 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:45 --> Total execution time: 0.0190
DEBUG - 2014-03-22 07:21:52 --> Config Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:21:52 --> URI Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Router Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Output Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Security Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Input Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:21:52 --> Language Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Loader Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Controller Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:21:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:21:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:21:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:21:53 --> Final output sent to browser
DEBUG - 2014-03-22 07:21:53 --> Total execution time: 1.0441
DEBUG - 2014-03-22 07:22:50 --> Config Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Config Class Initialized
DEBUG - 2014-03-22 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:22:50 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:22:50 --> URI Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Router Class Initialized
DEBUG - 2014-03-22 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:22:50 --> Config Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:22:50 --> URI Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Router Class Initialized
DEBUG - 2014-03-22 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:22:50 --> URI Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Output Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Router Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Security Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Output Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Input Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Security Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:22:50 --> Language Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Output Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Loader Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Security Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Controller Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Input Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:22:50 --> Language Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:22:50 --> Loader Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Input Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Controller Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:22:50 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:22:50 --> Language Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Loader Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Controller Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:22:50 --> Session Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:22:50 --> A session cookie was not found.
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Session routines successfully run
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Final output sent to browser
DEBUG - 2014-03-22 07:22:50 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:50 --> Session Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:22:50 --> A session cookie was not found.
DEBUG - 2014-03-22 07:22:50 --> Session routines successfully run
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:50 --> Final output sent to browser
DEBUG - 2014-03-22 07:22:50 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:50 --> Session Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:22:50 --> A session cookie was not found.
DEBUG - 2014-03-22 07:22:50 --> Session routines successfully run
DEBUG - 2014-03-22 07:22:50 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:22:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:50 --> Final output sent to browser
DEBUG - 2014-03-22 07:22:50 --> Total execution time: 0.0265
DEBUG - 2014-03-22 07:22:51 --> Config Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:22:51 --> Config Class Initialized
DEBUG - 2014-03-22 07:22:51 --> URI Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Router Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:22:51 --> URI Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Output Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Config Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Router Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Security Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Input Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Output Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:22:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:22:51 --> Language Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Security Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Input Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Loader Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:22:51 --> Controller Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Language Class Initialized
DEBUG - 2014-03-22 07:22:51 --> URI Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:22:51 --> Router Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:22:51 --> Loader Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Controller Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Output Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:22:51 --> Security Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Input Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Language Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Loader Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Controller Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:51 --> Session Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:22:51 --> Session Class Initialized
DEBUG - 2014-03-22 07:22:51 --> A session cookie was not found.
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:22:51 --> Session routines successfully run
DEBUG - 2014-03-22 07:22:51 --> A session cookie was not found.
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Session routines successfully run
DEBUG - 2014-03-22 07:22:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Final output sent to browser
DEBUG - 2014-03-22 07:22:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:22:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Final output sent to browser
DEBUG - 2014-03-22 07:22:51 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:51 --> Session Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:22:51 --> A session cookie was not found.
DEBUG - 2014-03-22 07:22:51 --> Session routines successfully run
DEBUG - 2014-03-22 07:22:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:22:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:22:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:22:51 --> Final output sent to browser
DEBUG - 2014-03-22 07:22:51 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:23:02 --> Config Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:23:02 --> URI Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Router Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Output Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Security Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Input Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:23:02 --> Language Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Loader Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Controller Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:23:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:23:02 --> Model Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Model Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Model Class Initialized
DEBUG - 2014-03-22 07:23:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:23:03 --> Final output sent to browser
DEBUG - 2014-03-22 07:23:03 --> Total execution time: 0.9831
DEBUG - 2014-03-22 07:26:28 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:28 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:28 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:28 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:28 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:28 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:28 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:28 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:28 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:28 --> Session Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:28 --> A session cookie was not found.
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Session routines successfully run
DEBUG - 2014-03-22 07:26:28 --> Session Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:26:28 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:28 --> A session cookie was not found.
DEBUG - 2014-03-22 07:26:28 --> Session routines successfully run
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:28 --> Session Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:28 --> Total execution time: 0.0130
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:26:28 --> A session cookie was not found.
DEBUG - 2014-03-22 07:26:28 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:28 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:26:28 --> Session routines successfully run
DEBUG - 2014-03-22 07:26:28 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:26:28 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:28 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:28 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:26:30 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:30 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:30 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:30 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:30 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:30 --> Session Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:26:30 --> A session cookie was not found.
DEBUG - 2014-03-22 07:26:30 --> Session routines successfully run
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:30 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:30 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:30 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:30 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:30 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:30 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:30 --> Session Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:30 --> A session cookie was not found.
DEBUG - 2014-03-22 07:26:30 --> Session routines successfully run
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:30 --> Session Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:26:30 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:30 --> A session cookie was not found.
DEBUG - 2014-03-22 07:26:30 --> Total execution time: 0.0240
DEBUG - 2014-03-22 07:26:30 --> Session routines successfully run
DEBUG - 2014-03-22 07:26:30 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:26:30 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:30 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:30 --> Total execution time: 0.0240
DEBUG - 2014-03-22 07:26:36 --> Config Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:26:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:26:36 --> URI Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Router Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Output Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Security Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Input Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:26:36 --> Language Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Loader Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Controller Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:26:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:26:36 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Model Class Initialized
DEBUG - 2014-03-22 07:26:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:26:37 --> Final output sent to browser
DEBUG - 2014-03-22 07:26:37 --> Total execution time: 0.9721
DEBUG - 2014-03-22 07:29:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:24 --> Session Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:29:24 --> A session cookie was not found.
DEBUG - 2014-03-22 07:29:24 --> Session routines successfully run
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:24 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:29:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Session Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:29:24 --> A session cookie was not found.
DEBUG - 2014-03-22 07:29:24 --> Session routines successfully run
DEBUG - 2014-03-22 07:29:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:29:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Total execution time: 0.0235
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:24 --> Session Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:29:24 --> A session cookie was not found.
DEBUG - 2014-03-22 07:29:24 --> Session routines successfully run
DEBUG - 2014-03-22 07:29:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:29:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:24 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:24 --> Total execution time: 0.0315
DEBUG - 2014-03-22 07:29:25 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:25 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:25 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:25 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:25 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:25 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:25 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:25 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:25 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Session Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:29:25 --> A session cookie was not found.
DEBUG - 2014-03-22 07:29:25 --> Session routines successfully run
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:25 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:25 --> Session Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:29:25 --> Session Class Initialized
DEBUG - 2014-03-22 07:29:25 --> A session cookie was not found.
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:29:25 --> Session routines successfully run
DEBUG - 2014-03-22 07:29:25 --> A session cookie was not found.
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Session routines successfully run
DEBUG - 2014-03-22 07:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:25 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:29:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:25 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:25 --> Total execution time: 0.0190
DEBUG - 2014-03-22 07:29:25 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:25 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:29:33 --> Config Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:29:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:29:33 --> URI Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Router Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Output Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Security Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Input Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:29:33 --> Language Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Loader Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Controller Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:29:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:29:33 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Model Class Initialized
DEBUG - 2014-03-22 07:29:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:29:34 --> Final output sent to browser
DEBUG - 2014-03-22 07:29:34 --> Total execution time: 1.0271
DEBUG - 2014-03-22 07:30:23 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:23 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:23 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:23 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:23 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:23 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:23 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Session Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:30:23 --> A session cookie was not found.
DEBUG - 2014-03-22 07:30:23 --> Session routines successfully run
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Session Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:30:23 --> A session cookie was not found.
DEBUG - 2014-03-22 07:30:23 --> Session routines successfully run
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:30:23 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:23 --> Session Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:30:23 --> A session cookie was not found.
DEBUG - 2014-03-22 07:30:23 --> Session routines successfully run
DEBUG - 2014-03-22 07:30:23 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:23 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:30:23 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:30:23 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:23 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:23 --> Total execution time: 0.0190
DEBUG - 2014-03-22 07:30:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:24 --> Session Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:30:24 --> A session cookie was not found.
DEBUG - 2014-03-22 07:30:24 --> Session routines successfully run
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:24 --> Session Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:30:24 --> A session cookie was not found.
DEBUG - 2014-03-22 07:30:24 --> Session routines successfully run
DEBUG - 2014-03-22 07:30:24 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:24 --> Total execution time: 0.0240
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:30:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:24 --> Total execution time: 0.0245
DEBUG - 2014-03-22 07:30:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:24 --> Session Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:30:24 --> A session cookie was not found.
DEBUG - 2014-03-22 07:30:24 --> Session routines successfully run
DEBUG - 2014-03-22 07:30:24 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:30:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:24 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:24 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:30:31 --> Config Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:30:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:30:31 --> URI Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Router Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Output Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Security Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Input Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:30:31 --> Language Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Loader Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Controller Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:30:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:30:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Model Class Initialized
DEBUG - 2014-03-22 07:30:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:30:33 --> Final output sent to browser
DEBUG - 2014-03-22 07:30:33 --> Total execution time: 2.0851
DEBUG - 2014-03-22 07:31:49 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:49 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:49 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:49 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:49 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:49 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:49 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:49 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:49 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:49 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:49 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:49 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:49 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:49 --> Total execution time: 0.0190
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:49 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:49 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:49 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:49 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:49 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:49 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:49 --> Total execution time: 0.0230
DEBUG - 2014-03-22 07:31:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:49 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:49 --> Total execution time: 0.0220
DEBUG - 2014-03-22 07:31:51 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:51 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:51 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:51 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:51 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:51 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:51 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:51 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:51 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:51 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:51 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:51 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:51 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:51 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:51 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:51 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:51 --> Total execution time: 0.0195
DEBUG - 2014-03-22 07:31:52 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:52 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:52 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Config Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:31:52 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:52 --> URI Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:52 --> Router Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:52 --> Output Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Security Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Input Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:31:52 --> Language Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:52 --> Loader Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Controller Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:31:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:52 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:52 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:52 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:52 --> Session Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:52 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> A session cookie was not found.
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:52 --> Session routines successfully run
DEBUG - 2014-03-22 07:31:52 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:31:52 --> Model Class Initialized
DEBUG - 2014-03-22 07:31:52 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:31:52 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:52 --> Total execution time: 0.0190
DEBUG - 2014-03-22 07:31:52 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:31:52 --> Final output sent to browser
DEBUG - 2014-03-22 07:31:52 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:36:25 --> Config Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:36:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:36:25 --> URI Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Router Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Output Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Security Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Input Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:36:25 --> Language Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Loader Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Controller Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:36:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:36:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Model Class Initialized
DEBUG - 2014-03-22 07:36:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:36:27 --> Final output sent to browser
DEBUG - 2014-03-22 07:36:27 --> Total execution time: 1.5291
DEBUG - 2014-03-22 07:38:50 --> Config Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:38:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:38:50 --> URI Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Router Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Output Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Security Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Input Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:38:50 --> Language Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Loader Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Controller Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:38:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:38:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Model Class Initialized
DEBUG - 2014-03-22 07:38:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:38:51 --> Final output sent to browser
DEBUG - 2014-03-22 07:38:51 --> Total execution time: 1.2181
DEBUG - 2014-03-22 07:39:48 --> Config Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:39:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:39:48 --> URI Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Router Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Output Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Security Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Input Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:39:48 --> Language Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Loader Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Controller Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:39:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:39:48 --> Model Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Model Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Model Class Initialized
DEBUG - 2014-03-22 07:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:39:49 --> Final output sent to browser
DEBUG - 2014-03-22 07:39:49 --> Total execution time: 0.9701
DEBUG - 2014-03-22 07:42:53 --> Config Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Config Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Config Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:42:53 --> URI Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Router Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Output Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Security Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Input Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:42:53 --> Language Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Loader Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Controller Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:53 --> Session Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:42:53 --> A session cookie was not found.
DEBUG - 2014-03-22 07:42:53 --> Session routines successfully run
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:53 --> URI Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Router Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Output Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Security Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Input Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:42:53 --> Language Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Loader Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Controller Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:42:53 --> Final output sent to browser
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:42:53 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> URI Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Router Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Output Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Security Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Input Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:42:53 --> Session Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Language Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:42:53 --> A session cookie was not found.
DEBUG - 2014-03-22 07:42:53 --> Session routines successfully run
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:53 --> Final output sent to browser
DEBUG - 2014-03-22 07:42:53 --> Total execution time: 0.0230
DEBUG - 2014-03-22 07:42:53 --> Loader Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Controller Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:53 --> Session Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:42:53 --> A session cookie was not found.
DEBUG - 2014-03-22 07:42:53 --> Session routines successfully run
DEBUG - 2014-03-22 07:42:53 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:42:53 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:53 --> Final output sent to browser
DEBUG - 2014-03-22 07:42:53 --> Total execution time: 0.0315
DEBUG - 2014-03-22 07:42:55 --> Config Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:42:55 --> URI Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Router Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Config Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Output Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:42:55 --> Security Class Initialized
DEBUG - 2014-03-22 07:42:55 --> URI Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Input Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Config Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:42:55 --> Router Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Language Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:42:55 --> Loader Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Controller Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Output Class Initialized
DEBUG - 2014-03-22 07:42:55 --> URI Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:42:55 --> Router Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Security Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:42:55 --> Input Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Output Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Language Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Security Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Loader Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Input Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:42:55 --> Language Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Controller Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Loader Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Controller Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:42:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Session Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:42:55 --> A session cookie was not found.
DEBUG - 2014-03-22 07:42:55 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Session routines successfully run
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Final output sent to browser
DEBUG - 2014-03-22 07:42:55 --> Session Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Total execution time: 0.0120
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:42:55 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:42:55 --> A session cookie was not found.
DEBUG - 2014-03-22 07:42:55 --> Session routines successfully run
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:55 --> Session Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:42:55 --> A session cookie was not found.
DEBUG - 2014-03-22 07:42:55 --> Session routines successfully run
DEBUG - 2014-03-22 07:42:55 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:42:55 --> Model Class Initialized
DEBUG - 2014-03-22 07:42:55 --> Final output sent to browser
DEBUG - 2014-03-22 07:42:55 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:42:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:42:55 --> Final output sent to browser
DEBUG - 2014-03-22 07:42:55 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:43:04 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:04 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:04 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:04 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:05 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:05 --> Total execution time: 0.9711
DEBUG - 2014-03-22 07:43:19 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:19 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:19 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:19 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:19 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:19 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:19 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:19 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:19 --> Session Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:19 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:43:19 --> Session Class Initialized
DEBUG - 2014-03-22 07:43:19 --> A session cookie was not found.
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:43:19 --> Session routines successfully run
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:19 --> A session cookie was not found.
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Session routines successfully run
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:19 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:19 --> Total execution time: 0.0160
DEBUG - 2014-03-22 07:43:19 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:19 --> Total execution time: 0.0130
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:19 --> Session Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:43:19 --> A session cookie was not found.
DEBUG - 2014-03-22 07:43:19 --> Session routines successfully run
DEBUG - 2014-03-22 07:43:19 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:43:19 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:19 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:19 --> Total execution time: 0.0215
DEBUG - 2014-03-22 07:43:21 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:21 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:21 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:21 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:21 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:21 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:21 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:21 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:21 --> Session Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:43:21 --> A session cookie was not found.
DEBUG - 2014-03-22 07:43:21 --> Session routines successfully run
DEBUG - 2014-03-22 07:43:21 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:21 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:21 --> Total execution time: 0.0120
DEBUG - 2014-03-22 07:43:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:21 --> Session Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:21 --> A session cookie was not found.
DEBUG - 2014-03-22 07:43:21 --> Session Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Session routines successfully run
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:43:21 --> A session cookie was not found.
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Session routines successfully run
DEBUG - 2014-03-22 07:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:43:21 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:21 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:21 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:43:21 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:21 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:43:29 --> Config Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:43:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:43:29 --> URI Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Router Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Output Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Security Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Input Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:43:29 --> Language Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Loader Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Controller Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:43:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:43:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Model Class Initialized
DEBUG - 2014-03-22 07:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:43:30 --> Final output sent to browser
DEBUG - 2014-03-22 07:43:30 --> Total execution time: 1.5651
DEBUG - 2014-03-22 07:44:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:13 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:13 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:13 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:13 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:44:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:44:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:44:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:44:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:44:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:44:13 --> Session Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:13 --> A session cookie was not found.
DEBUG - 2014-03-22 07:44:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:13 --> Session routines successfully run
DEBUG - 2014-03-22 07:44:13 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:44:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:13 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:13 --> Total execution time: 0.0150
DEBUG - 2014-03-22 07:44:13 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:13 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:44:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:14 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:14 --> Total execution time: 0.0200
DEBUG - 2014-03-22 07:44:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:16 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:16 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:16 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:44:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:44:16 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Total execution time: 0.0140
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:44:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:44:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:16 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:16 --> Total execution time: 0.0180
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:16 --> Session Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: string_helper
DEBUG - 2014-03-22 07:44:16 --> A session cookie was not found.
DEBUG - 2014-03-22 07:44:16 --> Session routines successfully run
DEBUG - 2014-03-22 07:44:16 --> Helper loaded: url_helper
DEBUG - 2014-03-22 07:44:16 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:16 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:16 --> Total execution time: 0.0170
DEBUG - 2014-03-22 07:44:24 --> Config Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Hooks Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Utf8 Class Initialized
DEBUG - 2014-03-22 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 07:44:24 --> URI Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Router Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Output Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Security Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Input Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 07:44:24 --> Language Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Loader Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Controller Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 07:44:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 07:44:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Database Driver Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Model Class Initialized
DEBUG - 2014-03-22 07:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 07:44:25 --> Final output sent to browser
DEBUG - 2014-03-22 07:44:25 --> Total execution time: 0.9701
DEBUG - 2014-03-22 08:22:35 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:35 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:35 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:35 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:35 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:35 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:35 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:35 --> Session Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:35 --> Session Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:22:35 --> A session cookie was not found.
DEBUG - 2014-03-22 08:22:35 --> Session routines successfully run
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:22:35 --> A session cookie was not found.
DEBUG - 2014-03-22 08:22:35 --> Session routines successfully run
DEBUG - 2014-03-22 08:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:22:35 --> Total execution time: 0.0240
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:35 --> Session Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:22:35 --> A session cookie was not found.
DEBUG - 2014-03-22 08:22:35 --> Session routines successfully run
DEBUG - 2014-03-22 08:22:35 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:22:35 --> Total execution time: 0.0270
DEBUG - 2014-03-22 08:22:35 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:35 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:35 --> Total execution time: 0.0300
DEBUG - 2014-03-22 08:22:36 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:36 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:36 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:36 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:36 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:36 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:36 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:36 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:36 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:36 --> Session Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Session Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> A session cookie was not found.
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:22:36 --> A session cookie was not found.
DEBUG - 2014-03-22 08:22:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:36 --> Session routines successfully run
DEBUG - 2014-03-22 08:22:36 --> Session routines successfully run
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:22:36 --> Session Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> A session cookie was not found.
DEBUG - 2014-03-22 08:22:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:36 --> Session routines successfully run
DEBUG - 2014-03-22 08:22:36 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:22:36 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:36 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:36 --> Total execution time: 0.0140
DEBUG - 2014-03-22 08:22:36 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:36 --> Total execution time: 0.0120
DEBUG - 2014-03-22 08:22:36 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:36 --> Total execution time: 0.0150
DEBUG - 2014-03-22 08:22:44 --> Config Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:22:44 --> URI Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Router Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Output Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Security Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Input Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:22:44 --> Language Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Loader Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Controller Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:22:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:22:44 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Model Class Initialized
DEBUG - 2014-03-22 08:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:22:45 --> Final output sent to browser
DEBUG - 2014-03-22 08:22:45 --> Total execution time: 1.0221
DEBUG - 2014-03-22 08:23:08 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:08 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:08 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:08 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:08 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:08 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:08 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:08 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:08 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:08 --> Session Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:23:08 --> A session cookie was not found.
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Session routines successfully run
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:08 --> Session Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:23:08 --> A session cookie was not found.
DEBUG - 2014-03-22 08:23:08 --> Session routines successfully run
DEBUG - 2014-03-22 08:23:08 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:08 --> Total execution time: 0.0180
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Session Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:23:08 --> A session cookie was not found.
DEBUG - 2014-03-22 08:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:08 --> Session routines successfully run
DEBUG - 2014-03-22 08:23:08 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:23:08 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:08 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:08 --> Total execution time: 0.0180
DEBUG - 2014-03-22 08:23:08 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:08 --> Total execution time: 0.0180
DEBUG - 2014-03-22 08:23:09 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:09 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:09 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:09 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:09 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:09 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:09 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:09 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:09 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:09 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:09 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:09 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:09 --> Session Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> A session cookie was not found.
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Session routines successfully run
DEBUG - 2014-03-22 08:23:09 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:23:09 --> Session Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:23:09 --> A session cookie was not found.
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Session routines successfully run
DEBUG - 2014-03-22 08:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:09 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:23:09 --> Total execution time: 0.0130
DEBUG - 2014-03-22 08:23:09 --> Session Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:23:09 --> A session cookie was not found.
DEBUG - 2014-03-22 08:23:09 --> Session routines successfully run
DEBUG - 2014-03-22 08:23:09 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:09 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:23:09 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:09 --> Total execution time: 0.0150
DEBUG - 2014-03-22 08:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:09 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:09 --> Total execution time: 0.0160
DEBUG - 2014-03-22 08:23:18 --> Config Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:23:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:23:18 --> URI Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Router Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Output Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Security Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Input Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:23:18 --> Language Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Loader Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Controller Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:23:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:23:18 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Model Class Initialized
DEBUG - 2014-03-22 08:23:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:23:19 --> Final output sent to browser
DEBUG - 2014-03-22 08:23:19 --> Total execution time: 1.2121
DEBUG - 2014-03-22 08:28:21 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:21 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:21 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:21 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:21 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:21 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:21 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:21 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:21 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:21 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:21 --> Session Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:28:21 --> A session cookie was not found.
DEBUG - 2014-03-22 08:28:21 --> Session routines successfully run
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:21 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:21 --> Total execution time: 0.0170
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:21 --> Session Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:28:21 --> A session cookie was not found.
DEBUG - 2014-03-22 08:28:21 --> Session routines successfully run
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:21 --> Session Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:28:21 --> A session cookie was not found.
DEBUG - 2014-03-22 08:28:21 --> Session routines successfully run
DEBUG - 2014-03-22 08:28:21 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:21 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:28:21 --> Total execution time: 0.0210
DEBUG - 2014-03-22 08:28:21 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:21 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:21 --> Total execution time: 0.0190
DEBUG - 2014-03-22 08:28:22 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:22 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:22 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:22 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:22 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:22 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:22 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:22 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:22 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:22 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Session Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Session Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:28:22 --> A session cookie was not found.
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:28:22 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:22 --> A session cookie was not found.
DEBUG - 2014-03-22 08:28:22 --> Session routines successfully run
DEBUG - 2014-03-22 08:28:22 --> Session routines successfully run
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:22 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:22 --> Session Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Total execution time: 0.0120
DEBUG - 2014-03-22 08:28:22 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: string_helper
DEBUG - 2014-03-22 08:28:22 --> Total execution time: 0.0140
DEBUG - 2014-03-22 08:28:22 --> A session cookie was not found.
DEBUG - 2014-03-22 08:28:22 --> Session routines successfully run
DEBUG - 2014-03-22 08:28:22 --> Helper loaded: url_helper
DEBUG - 2014-03-22 08:28:22 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:22 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:22 --> Total execution time: 0.0160
DEBUG - 2014-03-22 08:28:29 --> Config Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Hooks Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Utf8 Class Initialized
DEBUG - 2014-03-22 08:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-22 08:28:29 --> URI Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Router Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Output Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Security Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Input Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-22 08:28:29 --> Language Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Loader Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Controller Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-22 08:28:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-22 08:28:29 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Database Driver Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Model Class Initialized
DEBUG - 2014-03-22 08:28:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-22 08:28:30 --> Final output sent to browser
DEBUG - 2014-03-22 08:28:30 --> Total execution time: 0.9571
