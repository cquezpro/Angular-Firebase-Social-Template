<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-08 07:44:31 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-08 07:44:31 --> Config Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Config Class Initialized
DEBUG - 2014-05-08 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 07:44:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 07:44:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 07:44:31 --> URI Class Initialized
DEBUG - 2014-05-08 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 07:44:31 --> URI Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Router Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Router Class Initialized
DEBUG - 2014-05-08 07:44:31 --> URI Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Router Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Output Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Output Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Output Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Security Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Security Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Input Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 07:44:31 --> Language Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Input Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 07:44:31 --> Language Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Security Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Input Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 07:44:31 --> Loader Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Language Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Controller Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Loader Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 07:44:31 --> Controller Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Loader Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Controller Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:31 --> Session Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: string_helper
DEBUG - 2014-05-08 07:44:31 --> A session cookie was not found.
DEBUG - 2014-05-08 07:44:31 --> Session routines successfully run
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: url_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-05-08 07:44:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-05-08 07:44:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:31 --> Session Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: string_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> A session cookie was not found.
DEBUG - 2014-05-08 07:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:31 --> Session routines successfully run
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: url_helper
DEBUG - 2014-05-08 07:44:31 --> Session Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: string_helper
DEBUG - 2014-05-08 07:44:31 --> A session cookie was not found.
DEBUG - 2014-05-08 07:44:31 --> Session routines successfully run
DEBUG - 2014-05-08 07:44:31 --> Helper loaded: url_helper
DEBUG - 2014-05-08 07:44:31 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:31 --> Final output sent to browser
DEBUG - 2014-05-08 07:44:31 --> Total execution time: 0.0540
DEBUG - 2014-05-08 07:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:31 --> Final output sent to browser
DEBUG - 2014-05-08 07:44:31 --> Final output sent to browser
DEBUG - 2014-05-08 07:44:31 --> Total execution time: 0.0600
DEBUG - 2014-05-08 07:44:31 --> Total execution time: 0.0590
DEBUG - 2014-05-08 07:44:42 --> Config Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 07:44:42 --> URI Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Router Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Output Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Security Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Input Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 07:44:42 --> Language Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Loader Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Controller Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 07:44:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 07:44:42 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Database Driver Class Initialized
ERROR - 2014-05-08 07:44:42 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 07:44:42 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:43 --> Model Class Initialized
DEBUG - 2014-05-08 07:44:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 07:44:43 --> Final output sent to browser
DEBUG - 2014-05-08 07:44:43 --> Total execution time: 1.0101
DEBUG - 2014-05-08 17:58:02 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:02 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:02 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Database Driver Class Initialized
ERROR - 2014-05-08 17:58:02 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:02 --> Session Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:58:02 --> A session cookie was not found.
DEBUG - 2014-05-08 17:58:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:02 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:02 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:02 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Session routines successfully run
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:02 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:02 --> Total execution time: 0.0810
ERROR - 2014-05-08 17:58:02 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:02 --> Session Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:58:02 --> A session cookie was not found.
ERROR - 2014-05-08 17:58:02 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:58:02 --> Session routines successfully run
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:02 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:02 --> Total execution time: 0.1370
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:02 --> Session Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:58:02 --> A session cookie was not found.
DEBUG - 2014-05-08 17:58:02 --> Session routines successfully run
DEBUG - 2014-05-08 17:58:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:58:02 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:02 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:02 --> Total execution time: 0.1760
DEBUG - 2014-05-08 17:58:08 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:08 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:08 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:08 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:08 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:08 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Database Driver Class Initialized
ERROR - 2014-05-08 17:58:08 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:08 --> Session Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:58:08 --> A session cookie was not found.
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Session routines successfully run
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:08 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:08 --> Total execution time: 0.1300
DEBUG - 2014-05-08 17:58:08 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:08 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:08 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:08 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:08 --> Database Driver Class Initialized
ERROR - 2014-05-08 17:58:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:58:09 --> Model Class Initialized
ERROR - 2014-05-08 17:58:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:58:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:09 --> Session Class Initialized
DEBUG - 2014-05-08 17:58:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:58:09 --> A session cookie was not found.
DEBUG - 2014-05-08 17:58:09 --> Session routines successfully run
DEBUG - 2014-05-08 17:58:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:58:09 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:09 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:09 --> Total execution time: 0.1970
DEBUG - 2014-05-08 17:58:09 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:09 --> Session Class Initialized
DEBUG - 2014-05-08 17:58:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:58:09 --> A session cookie was not found.
DEBUG - 2014-05-08 17:58:09 --> Session routines successfully run
DEBUG - 2014-05-08 17:58:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:58:09 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:09 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:09 --> Total execution time: 0.4330
DEBUG - 2014-05-08 17:58:26 --> Config Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:58:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:58:26 --> URI Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Router Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Output Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Security Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Input Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:58:26 --> Language Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Loader Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Controller Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:58:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:58:26 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:28 --> Model Class Initialized
DEBUG - 2014-05-08 17:58:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:58:28 --> Final output sent to browser
DEBUG - 2014-05-08 17:58:28 --> Total execution time: 1.3961
DEBUG - 2014-05-08 17:59:01 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:01 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:01 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:01 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:01 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:01 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:01 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:01 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:01 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:01 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:01 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:01 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
ERROR - 2014-05-08 17:59:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10054 An existing connection was forcibly closed by the remote host.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-05-08 17:59:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:01 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:01 --> Total execution time: 0.0310
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:01 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:01 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:01 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:01 --> Total execution time: 0.0360
DEBUG - 2014-05-08 17:59:01 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:01 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:01 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:01 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:01 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:01 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:01 --> Total execution time: 0.0650
DEBUG - 2014-05-08 17:59:04 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:04 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:04 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:04 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:04 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:04 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:04 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:04 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:04 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:04 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:04 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:04 --> Total execution time: 0.0270
DEBUG - 2014-05-08 17:59:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:04 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:04 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:04 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:04 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:04 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:04 --> Total execution time: 0.0380
DEBUG - 2014-05-08 17:59:04 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:04 --> Total execution time: 0.0440
DEBUG - 2014-05-08 17:59:13 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:13 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:13 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:13 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:14 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:14 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:14 --> Total execution time: 1.0031
DEBUG - 2014-05-08 17:59:58 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:58 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:58 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:58 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:58 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:58 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:58 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:58 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:58 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:58 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:58 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:58 --> Config Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Total execution time: 0.0300
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:58 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 17:59:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 17:59:58 --> URI Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:58 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:58 --> Router Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:58 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:58 --> Total execution time: 0.0320
DEBUG - 2014-05-08 17:59:58 --> Output Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Security Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Input Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 17:59:58 --> Language Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Loader Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Controller Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:58 --> Session Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: string_helper
DEBUG - 2014-05-08 17:59:58 --> A session cookie was not found.
DEBUG - 2014-05-08 17:59:58 --> Session routines successfully run
DEBUG - 2014-05-08 17:59:58 --> Helper loaded: url_helper
DEBUG - 2014-05-08 17:59:58 --> Model Class Initialized
DEBUG - 2014-05-08 17:59:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 17:59:58 --> Final output sent to browser
DEBUG - 2014-05-08 17:59:58 --> Total execution time: 0.0570
DEBUG - 2014-05-08 18:00:05 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:05 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:05 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:05 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:05 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:07 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:07 --> Total execution time: 1.8151
DEBUG - 2014-05-08 18:00:55 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:55 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:55 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:55 --> Session Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:00:55 --> A session cookie was not found.
DEBUG - 2014-05-08 18:00:55 --> Session routines successfully run
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:00:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:55 --> Total execution time: 0.0330
DEBUG - 2014-05-08 18:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:55 --> Session Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:00:55 --> A session cookie was not found.
DEBUG - 2014-05-08 18:00:55 --> Session routines successfully run
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:55 --> Total execution time: 0.0430
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:55 --> Session Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:00:55 --> A session cookie was not found.
DEBUG - 2014-05-08 18:00:55 --> Session routines successfully run
DEBUG - 2014-05-08 18:00:55 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:00:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:55 --> Total execution time: 0.0550
DEBUG - 2014-05-08 18:00:57 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:57 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:57 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:57 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:57 --> Session Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Session Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:00:57 --> A session cookie was not found.
DEBUG - 2014-05-08 18:00:57 --> A session cookie was not found.
DEBUG - 2014-05-08 18:00:57 --> Session routines successfully run
DEBUG - 2014-05-08 18:00:57 --> Session routines successfully run
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:57 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:57 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:57 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:00:57 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:00:57 --> Config Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:00:57 --> URI Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Router Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Output Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Security Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Input Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:00:57 --> Language Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Loader Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Controller Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:57 --> Session Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:00:57 --> A session cookie was not found.
DEBUG - 2014-05-08 18:00:57 --> Session routines successfully run
DEBUG - 2014-05-08 18:00:57 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:00:57 --> Model Class Initialized
DEBUG - 2014-05-08 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:00:57 --> Final output sent to browser
DEBUG - 2014-05-08 18:00:57 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:01:04 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:04 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:04 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:05 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:05 --> Total execution time: 1.0851
DEBUG - 2014-05-08 18:01:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:16 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:16 --> Total execution time: 0.0230
DEBUG - 2014-05-08 18:01:51 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:51 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:51 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:51 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:51 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:51 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:51 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:51 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Session Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:01:51 --> A session cookie was not found.
DEBUG - 2014-05-08 18:01:51 --> Session routines successfully run
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:51 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:51 --> Total execution time: 0.0380
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:51 --> Session Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:01:51 --> A session cookie was not found.
DEBUG - 2014-05-08 18:01:51 --> Session routines successfully run
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:51 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:51 --> Total execution time: 0.0380
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:51 --> Session Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:01:51 --> A session cookie was not found.
DEBUG - 2014-05-08 18:01:51 --> Session routines successfully run
DEBUG - 2014-05-08 18:01:51 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:01:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:51 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:51 --> Total execution time: 0.0390
DEBUG - 2014-05-08 18:01:53 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:53 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Config Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:53 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:01:53 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:53 --> URI Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Router Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:53 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Output Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:53 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Security Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Input Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:01:53 --> Language Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:53 --> Session Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Session Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:01:53 --> Loader Class Initialized
DEBUG - 2014-05-08 18:01:53 --> A session cookie was not found.
DEBUG - 2014-05-08 18:01:53 --> Controller Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:01:53 --> Session routines successfully run
DEBUG - 2014-05-08 18:01:53 --> A session cookie was not found.
DEBUG - 2014-05-08 18:01:53 --> Session routines successfully run
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:53 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:53 --> Total execution time: 0.0310
DEBUG - 2014-05-08 18:01:53 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:53 --> Total execution time: 0.0330
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:53 --> Session Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:01:53 --> A session cookie was not found.
DEBUG - 2014-05-08 18:01:53 --> Session routines successfully run
DEBUG - 2014-05-08 18:01:53 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:01:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:01:53 --> Final output sent to browser
DEBUG - 2014-05-08 18:01:53 --> Total execution time: 0.0580
DEBUG - 2014-05-08 18:02:00 --> Config Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:02:00 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:02:00 --> URI Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Router Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Output Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Security Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Input Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:02:00 --> Language Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Loader Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Controller Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:02:00 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:02:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:02:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:02:02 --> Final output sent to browser
DEBUG - 2014-05-08 18:02:02 --> Total execution time: 2.2701
DEBUG - 2014-05-08 18:02:13 --> Config Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:02:13 --> URI Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Router Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Output Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Security Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Input Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:02:13 --> Language Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Loader Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Controller Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:02:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:02:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:02:27 --> Config Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:02:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:02:27 --> URI Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Router Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Output Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Security Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Input Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:02:27 --> Language Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Loader Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Controller Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:02:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:02:27 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Model Class Initialized
DEBUG - 2014-05-08 18:02:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:14 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:14 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:14 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:14 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:14 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:14 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:14 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:14 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:14 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:14 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:14 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:14 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:14 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Session Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:03:14 --> A session cookie was not found.
DEBUG - 2014-05-08 18:03:14 --> Session Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Session routines successfully run
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:03:14 --> A session cookie was not found.
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:03:14 --> Session routines successfully run
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:03:14 --> Session Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:03:14 --> A session cookie was not found.
DEBUG - 2014-05-08 18:03:14 --> Session routines successfully run
DEBUG - 2014-05-08 18:03:14 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:14 --> Total execution time: 0.0290
DEBUG - 2014-05-08 18:03:14 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:14 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:03:14 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:03:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:14 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:14 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:03:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:16 --> Session Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> A session cookie was not found.
DEBUG - 2014-05-08 18:03:16 --> Session Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Session routines successfully run
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:03:16 --> A session cookie was not found.
DEBUG - 2014-05-08 18:03:16 --> Session routines successfully run
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:16 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:16 --> Total execution time: 0.0290
DEBUG - 2014-05-08 18:03:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:16 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:16 --> Session Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:03:16 --> A session cookie was not found.
DEBUG - 2014-05-08 18:03:16 --> Session routines successfully run
DEBUG - 2014-05-08 18:03:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:03:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:16 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:16 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:03:21 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:21 --> Database Driver Class Initialized
ERROR - 2014-05-08 18:03:21 --> 404 Page Not Found --> member/index
DEBUG - 2014-05-08 18:03:27 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:27 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:27 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:27 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:27 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:27 --> Total execution time: 0.0200
DEBUG - 2014-05-08 18:03:33 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:33 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:33 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:33 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:33 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:33 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:33 --> Total execution time: 0.0210
DEBUG - 2014-05-08 18:03:42 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:42 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:42 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:42 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:42 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:03:52 --> Config Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:03:52 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:03:52 --> URI Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Router Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Output Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Security Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Input Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:03:52 --> Language Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Loader Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Controller Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:03:52 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:03:52 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:03:53 --> Final output sent to browser
DEBUG - 2014-05-08 18:03:53 --> Total execution time: 1.0081
DEBUG - 2014-05-08 18:04:04 --> Config Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:04:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:04:04 --> URI Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Router Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Output Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Security Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Input Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:04:04 --> Language Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Loader Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Controller Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:04:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:04:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:04:19 --> Config Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:04:19 --> URI Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Router Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Output Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Security Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Input Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:04:19 --> Language Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Loader Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Controller Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:04:19 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:04:55 --> Config Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:04:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:04:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:04:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:04:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:04:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:04:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:04:55 --> Total execution time: 0.0250
DEBUG - 2014-05-08 18:04:58 --> Config Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:04:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:04:58 --> URI Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Router Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Output Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Security Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Input Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:04:58 --> Language Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Loader Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Controller Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:04:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:04:58 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Model Class Initialized
DEBUG - 2014-05-08 18:04:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:04:58 --> Final output sent to browser
DEBUG - 2014-05-08 18:04:58 --> Total execution time: 0.0240
DEBUG - 2014-05-08 18:05:00 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:00 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:00 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:00 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:00 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:00 --> Total execution time: 0.0280
DEBUG - 2014-05-08 18:05:10 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:10 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:10 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:11 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:11 --> Total execution time: 0.9231
DEBUG - 2014-05-08 18:05:31 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:31 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:31 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:31 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:32 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:32 --> Total execution time: 1.0451
DEBUG - 2014-05-08 18:05:35 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:35 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:35 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:35 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:35 --> Total execution time: 0.0270
DEBUG - 2014-05-08 18:05:39 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:39 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:39 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:39 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:40 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:40 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:40 --> Total execution time: 1.0501
DEBUG - 2014-05-08 18:05:46 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:46 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:46 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:47 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:47 --> Total execution time: 0.0280
DEBUG - 2014-05-08 18:05:49 --> Config Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:05:49 --> URI Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Router Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Output Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Security Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Input Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:05:49 --> Language Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Loader Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Controller Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:05:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:05:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:05:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:05:50 --> Final output sent to browser
DEBUG - 2014-05-08 18:05:50 --> Total execution time: 0.9021
DEBUG - 2014-05-08 18:06:01 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:01 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:01 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:01 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:01 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:01 --> Total execution time: 0.0560
DEBUG - 2014-05-08 18:06:04 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:04 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:04 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:04 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:04 --> Total execution time: 0.0270
DEBUG - 2014-05-08 18:06:07 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:07 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:07 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:07 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:07 --> Total execution time: 0.0290
DEBUG - 2014-05-08 18:06:10 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:10 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:10 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:10 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:10 --> Total execution time: 0.0250
DEBUG - 2014-05-08 18:06:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:16 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:16 --> Total execution time: 0.0270
DEBUG - 2014-05-08 18:06:18 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:18 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:18 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:18 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:18 --> Total execution time: 0.0310
DEBUG - 2014-05-08 18:06:21 --> Config Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:06:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:06:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:06:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:06:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:06:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:06:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:06:22 --> Final output sent to browser
DEBUG - 2014-05-08 18:06:22 --> Total execution time: 1.0641
DEBUG - 2014-05-08 18:13:28 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:28 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:28 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:28 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:28 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:28 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:28 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:28 --> Session Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Session Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:13:28 --> A session cookie was not found.
DEBUG - 2014-05-08 18:13:28 --> Session routines successfully run
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:13:28 --> A session cookie was not found.
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Session routines successfully run
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:28 --> Session Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:28 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:13:28 --> Total execution time: 0.0380
DEBUG - 2014-05-08 18:13:28 --> A session cookie was not found.
DEBUG - 2014-05-08 18:13:28 --> Session routines successfully run
DEBUG - 2014-05-08 18:13:28 --> Total execution time: 0.0380
DEBUG - 2014-05-08 18:13:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:13:28 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:28 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:28 --> Total execution time: 0.0430
DEBUG - 2014-05-08 18:13:30 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:30 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:30 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:30 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:30 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:30 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:30 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:30 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:30 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:30 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Session Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Session Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:13:30 --> A session cookie was not found.
DEBUG - 2014-05-08 18:13:30 --> A session cookie was not found.
DEBUG - 2014-05-08 18:13:30 --> Session routines successfully run
DEBUG - 2014-05-08 18:13:30 --> Session routines successfully run
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Session Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:13:30 --> A session cookie was not found.
DEBUG - 2014-05-08 18:13:30 --> Session routines successfully run
DEBUG - 2014-05-08 18:13:30 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:30 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:30 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:13:30 --> Total execution time: 0.0320
DEBUG - 2014-05-08 18:13:30 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:13:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:30 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:30 --> Total execution time: 0.0370
DEBUG - 2014-05-08 18:13:42 --> Config Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:13:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:13:42 --> URI Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Router Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Output Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Security Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Input Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:13:42 --> Language Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Loader Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Controller Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:13:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:13:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:43 --> Model Class Initialized
DEBUG - 2014-05-08 18:13:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:13:43 --> Final output sent to browser
DEBUG - 2014-05-08 18:13:43 --> Total execution time: 0.9521
DEBUG - 2014-05-08 18:15:13 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:13 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:13 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:13 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:13 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:13 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:13 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:14 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:14 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:14 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:14 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:14 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:14 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:14 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:14 --> Total execution time: 0.0370
DEBUG - 2014-05-08 18:15:14 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:14 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:14 --> Total execution time: 0.0380
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:14 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:14 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:14 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:14 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:14 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:14 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:14 --> Total execution time: 0.0490
DEBUG - 2014-05-08 18:15:15 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:15 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:15 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:15 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:15 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:15 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:15 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:15 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:15 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:15 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:15 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:15 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:15 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:15 --> Total execution time: 0.0320
DEBUG - 2014-05-08 18:15:15 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:15 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:15 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:15 --> Total execution time: 0.0370
DEBUG - 2014-05-08 18:15:15 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:15 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:15 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:15 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:15 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:15 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:15 --> Total execution time: 0.0480
DEBUG - 2014-05-08 18:15:18 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:18 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:18 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:18 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:18 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:18 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:18 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:18 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:18 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:18 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:18 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:18 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:18 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:18 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:18 --> Session Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:18 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:15:18 --> A session cookie was not found.
DEBUG - 2014-05-08 18:15:18 --> Session routines successfully run
DEBUG - 2014-05-08 18:15:18 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:15:18 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:18 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:18 --> Total execution time: 0.0330
DEBUG - 2014-05-08 18:15:18 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:18 --> Total execution time: 0.0310
DEBUG - 2014-05-08 18:15:26 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:26 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:26 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:26 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:30 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:30 --> Total execution time: 3.9832
DEBUG - 2014-05-08 18:15:53 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:53 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:53 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:53 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:53 --> Total execution time: 0.0250
DEBUG - 2014-05-08 18:15:55 --> Config Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:15:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:15:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:15:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:15:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:15:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:15:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:15:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:15:55 --> Total execution time: 0.0240
DEBUG - 2014-05-08 18:16:34 --> Config Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:16:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:16:34 --> URI Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Router Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Output Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Security Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Input Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:16:34 --> Language Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Loader Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Controller Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:16:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:16:34 --> Model Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Model Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Model Class Initialized
DEBUG - 2014-05-08 18:16:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:16:34 --> Final output sent to browser
DEBUG - 2014-05-08 18:16:34 --> Total execution time: 0.0260
DEBUG - 2014-05-08 18:20:42 --> Config Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:20:42 --> Config Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:20:42 --> URI Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Router Class Initialized
DEBUG - 2014-05-08 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:20:42 --> Config Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:20:42 --> URI Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:20:42 --> Output Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Router Class Initialized
DEBUG - 2014-05-08 18:20:42 --> URI Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Security Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Router Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Output Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Input Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:20:42 --> Security Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Language Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Output Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Input Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:20:42 --> Security Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Language Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Input Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:20:42 --> Language Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Loader Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Controller Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:20:42 --> Loader Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:20:42 --> Controller Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:20:42 --> Loader Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:20:42 --> Controller Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Session Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:20:42 --> A session cookie was not found.
DEBUG - 2014-05-08 18:20:42 --> Session routines successfully run
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:42 --> Final output sent to browser
DEBUG - 2014-05-08 18:20:42 --> Total execution time: 0.0310
DEBUG - 2014-05-08 18:20:42 --> Session Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Session Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:20:42 --> A session cookie was not found.
DEBUG - 2014-05-08 18:20:42 --> A session cookie was not found.
DEBUG - 2014-05-08 18:20:42 --> Session routines successfully run
DEBUG - 2014-05-08 18:20:42 --> Session routines successfully run
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:20:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:42 --> Final output sent to browser
DEBUG - 2014-05-08 18:20:42 --> Final output sent to browser
DEBUG - 2014-05-08 18:20:42 --> Total execution time: 0.0330
DEBUG - 2014-05-08 18:20:42 --> Total execution time: 0.0360
DEBUG - 2014-05-08 18:20:50 --> Config Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:20:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:20:50 --> URI Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Router Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Output Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Security Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Input Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:20:50 --> Language Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Loader Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Controller Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:20:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:20:50 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:20:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:20:51 --> Final output sent to browser
DEBUG - 2014-05-08 18:20:51 --> Total execution time: 0.9521
DEBUG - 2014-05-08 18:21:35 --> Config Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:21:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:21:35 --> URI Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Router Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Output Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Security Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Input Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:21:35 --> Language Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Loader Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Controller Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:21:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:21:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:21:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:21:35 --> Final output sent to browser
DEBUG - 2014-05-08 18:21:35 --> Total execution time: 0.0270
DEBUG - 2014-05-08 18:22:55 --> Config Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:22:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:22:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:22:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:22:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:22:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:22:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:22:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:22:55 --> Total execution time: 0.0250
DEBUG - 2014-05-08 18:23:44 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:44 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:44 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:44 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:44 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:44 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:44 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:44 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:44 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:44 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:44 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Session Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:44 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:23:44 --> A session cookie was not found.
DEBUG - 2014-05-08 18:23:44 --> Session routines successfully run
DEBUG - 2014-05-08 18:23:44 --> Session Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:23:44 --> A session cookie was not found.
DEBUG - 2014-05-08 18:23:44 --> Session routines successfully run
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:44 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:44 --> Total execution time: 0.0460
DEBUG - 2014-05-08 18:23:44 --> Session Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:23:44 --> A session cookie was not found.
DEBUG - 2014-05-08 18:23:44 --> Session routines successfully run
DEBUG - 2014-05-08 18:23:44 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:23:44 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:44 --> Total execution time: 0.0490
DEBUG - 2014-05-08 18:23:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:44 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:44 --> Total execution time: 0.0490
DEBUG - 2014-05-08 18:23:47 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:47 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:47 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:47 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:47 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:47 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:47 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:47 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:47 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Session Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:23:47 --> A session cookie was not found.
DEBUG - 2014-05-08 18:23:47 --> Session routines successfully run
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:47 --> Session Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:23:47 --> A session cookie was not found.
DEBUG - 2014-05-08 18:23:47 --> Session routines successfully run
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:47 --> Total execution time: 0.0480
DEBUG - 2014-05-08 18:23:47 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:47 --> Total execution time: 0.0540
DEBUG - 2014-05-08 18:23:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:47 --> Session Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:23:47 --> A session cookie was not found.
DEBUG - 2014-05-08 18:23:47 --> Session routines successfully run
DEBUG - 2014-05-08 18:23:47 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:23:47 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:47 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:47 --> Total execution time: 0.0550
DEBUG - 2014-05-08 18:23:54 --> Config Class Initialized
DEBUG - 2014-05-08 18:23:54 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:23:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:23:55 --> URI Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Router Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Output Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Security Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Input Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:23:55 --> Language Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Loader Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Controller Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:23:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:23:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:55 --> Model Class Initialized
DEBUG - 2014-05-08 18:23:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:23:55 --> Final output sent to browser
DEBUG - 2014-05-08 18:23:55 --> Total execution time: 0.9991
DEBUG - 2014-05-08 18:25:38 --> Config Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:25:38 --> URI Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Router Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Output Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Security Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Input Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:25:38 --> Language Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Loader Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Controller Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:25:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:25:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:25:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:25:38 --> Final output sent to browser
DEBUG - 2014-05-08 18:25:38 --> Total execution time: 0.0250
DEBUG - 2014-05-08 18:26:00 --> Config Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:26:00 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:26:00 --> URI Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Router Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Output Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Security Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Input Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:26:00 --> Language Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Loader Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Controller Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:26:00 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:26:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:26:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:26:12 --> Config Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:26:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:26:12 --> URI Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Router Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Output Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Security Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Input Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:26:12 --> Language Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Loader Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Controller Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:26:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:26:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:02 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:02 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:02 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:02 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:02 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:02 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:02 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Session Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Session Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Session Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:27:02 --> A session cookie was not found.
DEBUG - 2014-05-08 18:27:02 --> A session cookie was not found.
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:27:02 --> Session routines successfully run
DEBUG - 2014-05-08 18:27:02 --> A session cookie was not found.
DEBUG - 2014-05-08 18:27:02 --> Session routines successfully run
DEBUG - 2014-05-08 18:27:02 --> Session routines successfully run
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:27:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:02 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:02 --> Total execution time: 0.0390
DEBUG - 2014-05-08 18:27:02 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:02 --> Total execution time: 0.0400
DEBUG - 2014-05-08 18:27:02 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:02 --> Total execution time: 0.0430
DEBUG - 2014-05-08 18:27:03 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:03 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:03 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:03 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:03 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:03 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:03 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:03 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:03 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:03 --> Session Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:27:03 --> A session cookie was not found.
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Session routines successfully run
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:03 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Session Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:03 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:27:03 --> A session cookie was not found.
DEBUG - 2014-05-08 18:27:03 --> Session routines successfully run
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:03 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:03 --> Total execution time: 0.0310
DEBUG - 2014-05-08 18:27:03 --> Session Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:27:03 --> A session cookie was not found.
DEBUG - 2014-05-08 18:27:03 --> Session routines successfully run
DEBUG - 2014-05-08 18:27:03 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:27:03 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:03 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:03 --> Total execution time: 0.0460
DEBUG - 2014-05-08 18:27:12 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:12 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:12 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:13 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:13 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:13 --> Total execution time: 0.9841
DEBUG - 2014-05-08 18:27:32 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:32 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:32 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:32 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:32 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:32 --> Total execution time: 0.0250
DEBUG - 2014-05-08 18:27:38 --> Config Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:27:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:27:38 --> URI Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Router Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Output Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Security Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Input Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:27:38 --> Language Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Loader Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Controller Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:27:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:27:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:27:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:27:38 --> Final output sent to browser
DEBUG - 2014-05-08 18:27:38 --> Total execution time: 0.0260
DEBUG - 2014-05-08 18:28:07 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:07 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:07 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:07 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:07 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:07 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:07 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:07 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:07 --> Session Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Session Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:28:07 --> A session cookie was not found.
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:28:07 --> A session cookie was not found.
DEBUG - 2014-05-08 18:28:07 --> Session routines successfully run
DEBUG - 2014-05-08 18:28:07 --> Session routines successfully run
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:07 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:28:07 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:07 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:07 --> Session Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:28:07 --> A session cookie was not found.
DEBUG - 2014-05-08 18:28:07 --> Session routines successfully run
DEBUG - 2014-05-08 18:28:07 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:28:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:07 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:07 --> Total execution time: 0.0440
DEBUG - 2014-05-08 18:28:09 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:09 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:09 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:09 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:09 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:09 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:09 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:09 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:09 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:09 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:09 --> Session Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:28:09 --> A session cookie was not found.
DEBUG - 2014-05-08 18:28:09 --> Session routines successfully run
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:09 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:09 --> Total execution time: 0.0370
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:09 --> Session Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:28:09 --> A session cookie was not found.
DEBUG - 2014-05-08 18:28:09 --> Session routines successfully run
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:09 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:09 --> Total execution time: 0.0440
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:09 --> Session Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:28:09 --> A session cookie was not found.
DEBUG - 2014-05-08 18:28:09 --> Session routines successfully run
DEBUG - 2014-05-08 18:28:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:28:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:09 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:09 --> Total execution time: 0.0520
DEBUG - 2014-05-08 18:28:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:17 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:17 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:17 --> Total execution time: 1.2591
DEBUG - 2014-05-08 18:28:44 --> Config Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:28:44 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:28:44 --> URI Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Router Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Output Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Security Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Input Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:28:44 --> Language Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Loader Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Controller Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:28:44 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:28:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:28:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:28:44 --> Helper loaded: email_helper
ERROR - 2014-05-08 18:28:44 --> Severity: Notice  --> Undefined index: count F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\member_model.php 231
DEBUG - 2014-05-08 18:28:44 --> Final output sent to browser
DEBUG - 2014-05-08 18:28:44 --> Total execution time: 0.9031
DEBUG - 2014-05-08 18:30:24 --> Config Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:30:24 --> URI Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Router Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Output Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Security Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Input Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:30:24 --> Language Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Loader Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Controller Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:30:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:30:24 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:30:24 --> Helper loaded: email_helper
ERROR - 2014-05-08 18:30:24 --> Severity: Notice  --> Undefined index: count F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\member_model.php 231
DEBUG - 2014-05-08 18:30:25 --> Final output sent to browser
DEBUG - 2014-05-08 18:30:25 --> Total execution time: 0.8620
DEBUG - 2014-05-08 18:30:32 --> Config Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:30:32 --> URI Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Router Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Output Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Security Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Input Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:30:32 --> Language Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Loader Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Controller Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:30:32 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:30:32 --> Helper loaded: email_helper
ERROR - 2014-05-08 18:30:32 --> Severity: Notice  --> Undefined index: count F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\member_model.php 231
DEBUG - 2014-05-08 18:30:33 --> Final output sent to browser
DEBUG - 2014-05-08 18:30:33 --> Total execution time: 0.8760
DEBUG - 2014-05-08 18:30:37 --> Config Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:30:37 --> URI Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Router Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Output Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Security Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Input Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:30:37 --> Language Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Loader Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Controller Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:30:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:30:37 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:30:37 --> Final output sent to browser
DEBUG - 2014-05-08 18:30:37 --> Total execution time: 0.0200
DEBUG - 2014-05-08 18:30:41 --> Config Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:30:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:30:41 --> URI Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Router Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Output Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Security Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Input Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:30:41 --> Language Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Loader Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Controller Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:30:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:30:41 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:30:41 --> Final output sent to browser
DEBUG - 2014-05-08 18:30:41 --> Total execution time: 0.0280
DEBUG - 2014-05-08 18:30:51 --> Config Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:30:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:30:51 --> URI Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Router Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Output Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Security Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Input Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:30:51 --> Language Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Loader Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Controller Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:30:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:30:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:30:51 --> Final output sent to browser
DEBUG - 2014-05-08 18:30:51 --> Total execution time: 0.0290
DEBUG - 2014-05-08 18:31:09 --> Config Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:31:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:31:09 --> URI Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Router Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Output Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Security Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Input Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:31:09 --> Language Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Loader Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Controller Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:31:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:31:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Model Class Initialized
DEBUG - 2014-05-08 18:31:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:31:09 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:32:10 --> Config Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:32:10 --> URI Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Router Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Output Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Security Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Input Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:32:10 --> Language Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Loader Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Controller Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:32:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:32:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:32:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:32:10 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:32:10 --> Final output sent to browser
DEBUG - 2014-05-08 18:32:10 --> Total execution time: 0.0300
DEBUG - 2014-05-08 18:32:21 --> Config Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:32:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:32:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:32:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:32:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:32:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:32:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:32:21 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:32:22 --> Final output sent to browser
DEBUG - 2014-05-08 18:32:22 --> Total execution time: 0.9581
DEBUG - 2014-05-08 18:34:36 --> Config Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:34:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:34:36 --> URI Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Router Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Output Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Security Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Input Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:34:36 --> Language Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Loader Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Controller Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:34:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:34:36 --> Model Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Model Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Model Class Initialized
DEBUG - 2014-05-08 18:34:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:34:36 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:34:37 --> Final output sent to browser
DEBUG - 2014-05-08 18:34:37 --> Total execution time: 0.9311
DEBUG - 2014-05-08 18:35:19 --> Config Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:35:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:35:19 --> URI Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Router Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Output Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Security Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Input Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:35:19 --> Language Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Loader Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Controller Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:35:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:35:19 --> Model Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Model Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Model Class Initialized
DEBUG - 2014-05-08 18:35:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:35:19 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:35:20 --> Final output sent to browser
DEBUG - 2014-05-08 18:35:20 --> Total execution time: 0.9311
DEBUG - 2014-05-08 18:36:35 --> Config Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:36:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:36:35 --> URI Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Router Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Output Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Security Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Input Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:36:35 --> Language Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Loader Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Controller Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:36:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:36:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Model Class Initialized
DEBUG - 2014-05-08 18:36:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:36:35 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:36:36 --> Final output sent to browser
DEBUG - 2014-05-08 18:36:36 --> Total execution time: 0.9041
DEBUG - 2014-05-08 18:36:51 --> Config Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:36:51 --> URI Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Router Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Output Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Security Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Input Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:36:51 --> Language Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Loader Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Controller Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:36:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Model Class Initialized
DEBUG - 2014-05-08 18:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:36:52 --> Final output sent to browser
DEBUG - 2014-05-08 18:36:52 --> Total execution time: 0.9701
DEBUG - 2014-05-08 18:37:02 --> Config Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:37:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:37:02 --> URI Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Router Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Output Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Security Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Input Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:37:02 --> Language Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Loader Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Controller Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:37:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:37:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:37:02 --> Final output sent to browser
DEBUG - 2014-05-08 18:37:02 --> Total execution time: 0.0280
DEBUG - 2014-05-08 18:37:07 --> Config Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:37:07 --> URI Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Router Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Output Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Security Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Input Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:37:07 --> Language Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Loader Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Controller Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:37:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:37:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:37:07 --> Final output sent to browser
DEBUG - 2014-05-08 18:37:07 --> Total execution time: 0.0340
DEBUG - 2014-05-08 18:37:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:37:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:37:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:37:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:37:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:37:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:37:16 --> Final output sent to browser
DEBUG - 2014-05-08 18:37:16 --> Total execution time: 0.0280
DEBUG - 2014-05-08 18:37:21 --> Config Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:37:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:37:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:37:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:37:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:37:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:37:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:37:21 --> Final output sent to browser
DEBUG - 2014-05-08 18:37:21 --> Total execution time: 0.0290
DEBUG - 2014-05-08 18:47:10 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:10 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:10 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:10 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:10 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:10 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:10 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:10 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:10 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:10 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:10 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:10 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:10 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:10 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:10 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:10 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:10 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:10 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:10 --> Total execution time: 0.0370
DEBUG - 2014-05-08 18:47:10 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:10 --> Total execution time: 0.0380
DEBUG - 2014-05-08 18:47:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:10 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:10 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:10 --> Total execution time: 0.0430
DEBUG - 2014-05-08 18:47:12 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:12 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:12 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:12 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:12 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:12 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:12 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:12 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:12 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:12 --> Total execution time: 0.0310
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:12 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:12 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:12 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:12 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:12 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:12 --> Total execution time: 0.0540
DEBUG - 2014-05-08 18:47:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:12 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:12 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:12 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:12 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:12 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:12 --> Total execution time: 0.0540
DEBUG - 2014-05-08 18:47:25 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:25 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:25 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:25 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:26 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:26 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:26 --> Total execution time: 1.1501
DEBUG - 2014-05-08 18:47:38 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:38 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:38 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:38 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:47:39 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:39 --> Total execution time: 1.5941
DEBUG - 2014-05-08 18:47:49 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:49 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Config Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:49 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:49 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:47:49 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:49 --> URI Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Router Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:49 --> Output Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Security Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Input Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Language Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Loader Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Controller Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:49 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:49 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:49 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:49 --> Total execution time: 0.0280
DEBUG - 2014-05-08 18:47:49 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:49 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:49 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:49 --> Session Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:47:49 --> A session cookie was not found.
DEBUG - 2014-05-08 18:47:49 --> Session routines successfully run
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:47:49 --> Model Class Initialized
DEBUG - 2014-05-08 18:47:49 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:47:49 --> Total execution time: 0.0320
DEBUG - 2014-05-08 18:47:49 --> Final output sent to browser
DEBUG - 2014-05-08 18:47:49 --> Total execution time: 0.0320
DEBUG - 2014-05-08 18:48:00 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:00 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:00 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:00 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:01 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:01 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:01 --> Total execution time: 0.9291
DEBUG - 2014-05-08 18:48:08 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:08 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:08 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:08 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:08 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:08 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:12 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:12 --> Total execution time: 3.9072
DEBUG - 2014-05-08 18:48:20 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:20 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:20 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:20 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:20 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:21 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:21 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Session Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> A session cookie was not found.
DEBUG - 2014-05-08 18:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:21 --> Session routines successfully run
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:48:21 --> Session Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:48:21 --> A session cookie was not found.
DEBUG - 2014-05-08 18:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:21 --> Session routines successfully run
DEBUG - 2014-05-08 18:48:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:48:21 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:21 --> Total execution time: 0.1080
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:21 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:21 --> Total execution time: 0.1100
DEBUG - 2014-05-08 18:48:21 --> Session Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:48:21 --> A session cookie was not found.
DEBUG - 2014-05-08 18:48:21 --> Session routines successfully run
DEBUG - 2014-05-08 18:48:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:48:21 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:21 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:21 --> Total execution time: 0.1170
DEBUG - 2014-05-08 18:48:29 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:29 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:29 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:29 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:30 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:30 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:30 --> Total execution time: 0.9641
DEBUG - 2014-05-08 18:48:58 --> Config Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:48:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:48:58 --> URI Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Router Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Output Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Security Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Input Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:48:58 --> Language Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Loader Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Controller Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:48:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:48:58 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Model Class Initialized
DEBUG - 2014-05-08 18:48:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:48:59 --> Final output sent to browser
DEBUG - 2014-05-08 18:48:59 --> Total execution time: 0.9031
DEBUG - 2014-05-08 18:49:07 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:07 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:07 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:08 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:08 --> Total execution time: 0.9151
DEBUG - 2014-05-08 18:49:12 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:12 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:12 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:12 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:12 --> Total execution time: 0.0320
DEBUG - 2014-05-08 18:49:16 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:16 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:16 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:20 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:20 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:20 --> Total execution time: 3.9732
DEBUG - 2014-05-08 18:49:23 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:23 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:23 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:23 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:23 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:23 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:23 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:23 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:23 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Session Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:49:23 --> A session cookie was not found.
DEBUG - 2014-05-08 18:49:23 --> Session routines successfully run
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:23 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:23 --> Total execution time: 0.0370
DEBUG - 2014-05-08 18:49:23 --> Session Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:49:23 --> A session cookie was not found.
DEBUG - 2014-05-08 18:49:23 --> Session routines successfully run
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:23 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Total execution time: 0.0350
DEBUG - 2014-05-08 18:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:23 --> Session Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 18:49:23 --> A session cookie was not found.
DEBUG - 2014-05-08 18:49:23 --> Session routines successfully run
DEBUG - 2014-05-08 18:49:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 18:49:23 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:23 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:23 --> Total execution time: 0.0470
DEBUG - 2014-05-08 18:49:33 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:33 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:33 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:33 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:33 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:33 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Helper loaded: email_helper
DEBUG - 2014-05-08 18:49:33 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:34 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:35 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:35 --> Total execution time: 1.9331
DEBUG - 2014-05-08 18:49:41 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:41 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:41 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:41 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Image Lib Class Initialized
DEBUG - 2014-05-08 18:49:41 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:41 --> Total execution time: 0.2540
DEBUG - 2014-05-08 18:49:43 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:43 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:43 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:43 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:43 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:43 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:43 --> Image Lib Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:44 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:44 --> Total execution time: 1.3181
DEBUG - 2014-05-08 18:49:44 --> Config Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:49:44 --> URI Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Router Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Output Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Security Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Input Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:49:44 --> Language Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Loader Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Controller Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:49:44 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:49:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Model Class Initialized
DEBUG - 2014-05-08 18:49:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:49:45 --> Final output sent to browser
DEBUG - 2014-05-08 18:49:45 --> Total execution time: 0.9301
DEBUG - 2014-05-08 18:50:05 --> Config Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:50:05 --> URI Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Router Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Output Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Security Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Input Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:50:05 --> Language Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Loader Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Controller Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:50:05 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:50:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:50:06 --> Final output sent to browser
DEBUG - 2014-05-08 18:50:06 --> Total execution time: 0.9431
DEBUG - 2014-05-08 18:50:22 --> Config Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:50:22 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:50:22 --> URI Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Router Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Output Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Security Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Input Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:50:22 --> Language Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Loader Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Controller Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:50:22 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:50:22 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:50:26 --> Final output sent to browser
DEBUG - 2014-05-08 18:50:26 --> Total execution time: 3.9102
DEBUG - 2014-05-08 18:50:36 --> Config Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Hooks Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Utf8 Class Initialized
DEBUG - 2014-05-08 18:50:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 18:50:36 --> URI Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Router Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Output Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Security Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Input Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 18:50:36 --> Language Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Loader Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Controller Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 18:50:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 18:50:36 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Database Driver Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:50:37 --> Model Class Initialized
DEBUG - 2014-05-08 18:50:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 18:50:37 --> Final output sent to browser
DEBUG - 2014-05-08 18:50:37 --> Total execution time: 0.9521
DEBUG - 2014-05-08 20:44:24 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:24 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:24 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:24 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:24 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:24 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:24 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:24 --> Session Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Session Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:44:24 --> A session cookie was not found.
DEBUG - 2014-05-08 20:44:24 --> Session routines successfully run
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:44:24 --> A session cookie was not found.
DEBUG - 2014-05-08 20:44:24 --> Session routines successfully run
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:44:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:24 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:24 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Total execution time: 0.0310
DEBUG - 2014-05-08 20:44:24 --> Total execution time: 0.0310
DEBUG - 2014-05-08 20:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:24 --> Session Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:44:24 --> A session cookie was not found.
DEBUG - 2014-05-08 20:44:24 --> Session routines successfully run
DEBUG - 2014-05-08 20:44:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:44:24 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:24 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:24 --> Total execution time: 0.0370
DEBUG - 2014-05-08 20:44:26 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:26 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:26 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:26 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:26 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:26 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:26 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:26 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:26 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:26 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:26 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Session Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:44:26 --> A session cookie was not found.
DEBUG - 2014-05-08 20:44:26 --> Session routines successfully run
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:26 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:26 --> Total execution time: 0.0300
DEBUG - 2014-05-08 20:44:26 --> Session Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Session Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:44:26 --> A session cookie was not found.
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:44:26 --> Session routines successfully run
DEBUG - 2014-05-08 20:44:26 --> A session cookie was not found.
DEBUG - 2014-05-08 20:44:26 --> Session routines successfully run
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:44:26 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:26 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:26 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:26 --> Total execution time: 0.0330
DEBUG - 2014-05-08 20:44:26 --> Total execution time: 0.0350
DEBUG - 2014-05-08 20:44:35 --> Config Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:44:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:44:35 --> URI Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Router Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Output Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Security Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Input Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:44:35 --> Language Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Loader Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Controller Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:44:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:44:35 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:36 --> Model Class Initialized
DEBUG - 2014-05-08 20:44:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:44:36 --> Final output sent to browser
DEBUG - 2014-05-08 20:44:36 --> Total execution time: 0.9991
DEBUG - 2014-05-08 20:46:02 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:02 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:02 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:02 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:02 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:02 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:02 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:02 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:02 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:02 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:02 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:02 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:02 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:02 --> Total execution time: 0.0490
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:02 --> Total execution time: 0.0580
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:02 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:02 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:02 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:02 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:02 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:02 --> Total execution time: 0.0440
DEBUG - 2014-05-08 20:46:04 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:04 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:04 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:04 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:04 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:04 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:04 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:04 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:04 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:04 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:04 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:04 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:04 --> Total execution time: 0.0300
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:04 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:04 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:04 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:04 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Total execution time: 0.0440
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:04 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:04 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:04 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:04 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:04 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:04 --> Total execution time: 0.0330
DEBUG - 2014-05-08 20:46:12 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:12 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:12 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:12 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:13 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:13 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:13 --> Total execution time: 0.9941
DEBUG - 2014-05-08 20:46:48 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:48 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:48 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:48 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:48 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:48 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:48 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:48 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:48 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:48 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:48 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:48 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:48 --> Total execution time: 0.0280
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:48 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:48 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:48 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:48 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:48 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:48 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:48 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:48 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:48 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:48 --> Total execution time: 0.0420
DEBUG - 2014-05-08 20:46:48 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:48 --> Total execution time: 0.0560
DEBUG - 2014-05-08 20:46:49 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:49 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:49 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:49 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:49 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:49 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:49 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:49 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:49 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:49 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:49 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:49 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:49 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:49 --> Session Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:46:49 --> A session cookie was not found.
DEBUG - 2014-05-08 20:46:49 --> Session routines successfully run
DEBUG - 2014-05-08 20:46:49 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:46:49 --> Total execution time: 0.0370
DEBUG - 2014-05-08 20:46:49 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:46:49 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:49 --> Final output sent to browser
DEBUG - 2014-05-08 20:46:49 --> Total execution time: 0.0400
DEBUG - 2014-05-08 20:46:49 --> Total execution time: 0.0400
DEBUG - 2014-05-08 20:46:59 --> Config Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:46:59 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:46:59 --> URI Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Router Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Output Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Security Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Input Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:46:59 --> Language Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Loader Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Controller Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:46:59 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:46:59 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Model Class Initialized
DEBUG - 2014-05-08 20:46:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:00 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:00 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:00 --> Total execution time: 0.9391
DEBUG - 2014-05-08 20:47:17 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:17 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:17 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:17 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:17 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:17 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:17 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:17 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:17 --> Session Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:47:17 --> A session cookie was not found.
DEBUG - 2014-05-08 20:47:17 --> Session routines successfully run
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:47:17 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:17 --> Session Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:47:17 --> A session cookie was not found.
DEBUG - 2014-05-08 20:47:17 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:17 --> Session routines successfully run
DEBUG - 2014-05-08 20:47:17 --> Total execution time: 0.0320
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:17 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:17 --> Total execution time: 0.0350
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:17 --> Session Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:47:17 --> A session cookie was not found.
DEBUG - 2014-05-08 20:47:17 --> Session routines successfully run
DEBUG - 2014-05-08 20:47:17 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:47:17 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:17 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:17 --> Total execution time: 0.0470
DEBUG - 2014-05-08 20:47:19 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:19 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:19 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:19 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:19 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:19 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:19 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:19 --> Session Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:47:19 --> A session cookie was not found.
DEBUG - 2014-05-08 20:47:19 --> Session Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Session routines successfully run
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:47:19 --> A session cookie was not found.
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:47:19 --> Session routines successfully run
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:19 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:19 --> Total execution time: 0.0280
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:19 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:19 --> Session Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Total execution time: 0.0300
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: string_helper
DEBUG - 2014-05-08 20:47:19 --> A session cookie was not found.
DEBUG - 2014-05-08 20:47:19 --> Session routines successfully run
DEBUG - 2014-05-08 20:47:19 --> Helper loaded: url_helper
DEBUG - 2014-05-08 20:47:19 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:19 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:19 --> Total execution time: 0.0340
DEBUG - 2014-05-08 20:47:26 --> Config Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Hooks Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Utf8 Class Initialized
DEBUG - 2014-05-08 20:47:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 20:47:26 --> URI Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Router Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Output Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Security Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Input Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 20:47:26 --> Language Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Loader Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Controller Class Initialized
DEBUG - 2014-05-08 20:47:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 20:47:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 20:47:26 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:27 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:27 --> Database Driver Class Initialized
DEBUG - 2014-05-08 20:47:27 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:27 --> Model Class Initialized
DEBUG - 2014-05-08 20:47:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 20:47:27 --> Final output sent to browser
DEBUG - 2014-05-08 20:47:27 --> Total execution time: 0.9611
DEBUG - 2014-05-08 21:07:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:23 --> Session Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Session Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:07:23 --> A session cookie was not found.
DEBUG - 2014-05-08 21:07:23 --> A session cookie was not found.
DEBUG - 2014-05-08 21:07:23 --> Session routines successfully run
DEBUG - 2014-05-08 21:07:23 --> Session routines successfully run
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:23 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:23 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:23 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:07:23 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:07:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:23 --> Session Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:07:23 --> A session cookie was not found.
DEBUG - 2014-05-08 21:07:23 --> Session routines successfully run
DEBUG - 2014-05-08 21:07:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:07:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:23 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:23 --> Total execution time: 0.0280
DEBUG - 2014-05-08 21:07:28 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:28 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:28 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:28 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:28 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:28 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:28 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:28 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:28 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:28 --> Session Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:07:28 --> A session cookie was not found.
DEBUG - 2014-05-08 21:07:28 --> Session routines successfully run
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:28 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:28 --> Session Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:07:28 --> A session cookie was not found.
DEBUG - 2014-05-08 21:07:28 --> Session routines successfully run
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:28 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:28 --> Total execution time: 0.0480
DEBUG - 2014-05-08 21:07:28 --> Session Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:07:28 --> A session cookie was not found.
DEBUG - 2014-05-08 21:07:28 --> Session routines successfully run
DEBUG - 2014-05-08 21:07:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:07:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:28 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:28 --> Total execution time: 0.0540
DEBUG - 2014-05-08 21:07:37 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:37 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:37 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:37 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:37 --> Total execution time: 0.0240
DEBUG - 2014-05-08 21:07:40 --> Config Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:07:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:07:40 --> URI Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Router Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Output Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Security Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Input Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:07:40 --> Language Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Loader Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Controller Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:07:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:07:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:07:42 --> Final output sent to browser
DEBUG - 2014-05-08 21:07:42 --> Total execution time: 1.6081
DEBUG - 2014-05-08 21:10:25 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:25 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:25 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:25 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:25 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:25 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:25 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:25 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:25 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:25 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Session Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:10:25 --> A session cookie was not found.
DEBUG - 2014-05-08 21:10:25 --> Session routines successfully run
DEBUG - 2014-05-08 21:10:25 --> Session Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:10:25 --> A session cookie was not found.
DEBUG - 2014-05-08 21:10:25 --> Session routines successfully run
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:25 --> Session Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:10:25 --> A session cookie was not found.
DEBUG - 2014-05-08 21:10:25 --> Session routines successfully run
DEBUG - 2014-05-08 21:10:25 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:10:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:25 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:25 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:25 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:25 --> Total execution time: 0.0430
DEBUG - 2014-05-08 21:10:25 --> Total execution time: 0.0420
DEBUG - 2014-05-08 21:10:25 --> Total execution time: 0.0430
DEBUG - 2014-05-08 21:10:28 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:28 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:28 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:28 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:28 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:28 --> Session Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:10:28 --> A session cookie was not found.
DEBUG - 2014-05-08 21:10:28 --> Session routines successfully run
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:10:28 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:28 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:28 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:28 --> Total execution time: 0.0290
DEBUG - 2014-05-08 21:10:28 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:28 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Session Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:10:28 --> A session cookie was not found.
DEBUG - 2014-05-08 21:10:28 --> Session routines successfully run
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:28 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:28 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:28 --> Total execution time: 0.0370
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:28 --> Session Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:10:28 --> A session cookie was not found.
DEBUG - 2014-05-08 21:10:28 --> Session routines successfully run
DEBUG - 2014-05-08 21:10:28 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:10:28 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:28 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:28 --> Total execution time: 0.0540
DEBUG - 2014-05-08 21:10:39 --> Config Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:10:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:10:39 --> URI Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Router Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Output Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Security Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Input Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:10:39 --> Language Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Loader Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Controller Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:10:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:10:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:10:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:10:40 --> Final output sent to browser
DEBUG - 2014-05-08 21:10:40 --> Total execution time: 0.9591
DEBUG - 2014-05-08 21:11:34 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:34 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:34 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:34 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:34 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:34 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:34 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:34 --> Session Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:11:34 --> A session cookie was not found.
DEBUG - 2014-05-08 21:11:34 --> Session routines successfully run
DEBUG - 2014-05-08 21:11:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:34 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:34 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:11:34 --> Session Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:11:34 --> A session cookie was not found.
DEBUG - 2014-05-08 21:11:34 --> Session routines successfully run
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:34 --> Session Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:11:34 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:34 --> A session cookie was not found.
DEBUG - 2014-05-08 21:11:34 --> Total execution time: 0.0360
DEBUG - 2014-05-08 21:11:34 --> Session routines successfully run
DEBUG - 2014-05-08 21:11:34 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:11:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:34 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:34 --> Total execution time: 0.0400
DEBUG - 2014-05-08 21:11:37 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:37 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:37 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:37 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:37 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:37 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:37 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:37 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:37 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:37 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:37 --> Session Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:11:37 --> A session cookie was not found.
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Session routines successfully run
DEBUG - 2014-05-08 21:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:11:37 --> Session Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:11:37 --> A session cookie was not found.
DEBUG - 2014-05-08 21:11:37 --> Session routines successfully run
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:37 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:37 --> Total execution time: 0.0390
DEBUG - 2014-05-08 21:11:37 --> Session Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:11:37 --> A session cookie was not found.
DEBUG - 2014-05-08 21:11:37 --> Session routines successfully run
DEBUG - 2014-05-08 21:11:37 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:11:37 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:37 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:37 --> Total execution time: 0.0430
DEBUG - 2014-05-08 21:11:37 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:37 --> Total execution time: 0.0410
DEBUG - 2014-05-08 21:11:48 --> Config Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:11:48 --> URI Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Router Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Output Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Security Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Input Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:11:48 --> Language Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Loader Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Controller Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:11:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:11:48 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:11:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:11:49 --> Final output sent to browser
DEBUG - 2014-05-08 21:11:49 --> Total execution time: 0.9621
DEBUG - 2014-05-08 21:12:51 --> Config Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Config Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:12:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:12:51 --> URI Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Router Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Output Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Security Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Input Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:12:51 --> Language Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Config Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:12:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:12:51 --> Loader Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:12:51 --> URI Class Initialized
DEBUG - 2014-05-08 21:12:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:12:51 --> Controller Class Initialized
DEBUG - 2014-05-08 21:12:51 --> URI Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:12:51 --> Router Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Router Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Output Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Output Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Security Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Security Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Input Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:12:51 --> Language Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Input Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Loader Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Controller Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Language Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Loader Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Controller Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:51 --> Session Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:12:51 --> A session cookie was not found.
DEBUG - 2014-05-08 21:12:51 --> Session routines successfully run
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Final output sent to browser
DEBUG - 2014-05-08 21:12:51 --> Total execution time: 0.0400
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:51 --> Session Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:12:51 --> A session cookie was not found.
DEBUG - 2014-05-08 21:12:51 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Session routines successfully run
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:51 --> Session Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:12:51 --> A session cookie was not found.
DEBUG - 2014-05-08 21:12:51 --> Session routines successfully run
DEBUG - 2014-05-08 21:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:51 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:12:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:51 --> Final output sent to browser
DEBUG - 2014-05-08 21:12:51 --> Total execution time: 0.0560
DEBUG - 2014-05-08 21:12:51 --> Final output sent to browser
DEBUG - 2014-05-08 21:12:51 --> Total execution time: 0.0480
DEBUG - 2014-05-08 21:12:54 --> Config Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Config Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Config Class Initialized
DEBUG - 2014-05-08 21:12:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:12:54 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:12:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:12:54 --> URI Class Initialized
DEBUG - 2014-05-08 21:12:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:12:54 --> URI Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Router Class Initialized
DEBUG - 2014-05-08 21:12:54 --> URI Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Router Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Router Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Output Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Output Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Output Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Security Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Security Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Security Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Input Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:12:54 --> Input Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:12:54 --> Language Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Input Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:12:54 --> Language Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Loader Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Controller Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Loader Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:12:54 --> Controller Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:12:54 --> Language Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Loader Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Controller Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:54 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Session Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:12:54 --> A session cookie was not found.
DEBUG - 2014-05-08 21:12:54 --> Session routines successfully run
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:54 --> Session Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:12:54 --> A session cookie was not found.
DEBUG - 2014-05-08 21:12:54 --> Session routines successfully run
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:54 --> Session Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Final output sent to browser
DEBUG - 2014-05-08 21:12:54 --> Total execution time: 0.0410
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:12:54 --> A session cookie was not found.
DEBUG - 2014-05-08 21:12:54 --> Session routines successfully run
DEBUG - 2014-05-08 21:12:54 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:12:54 --> Model Class Initialized
DEBUG - 2014-05-08 21:12:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:12:54 --> Final output sent to browser
DEBUG - 2014-05-08 21:12:54 --> Final output sent to browser
DEBUG - 2014-05-08 21:12:54 --> Total execution time: 0.0450
DEBUG - 2014-05-08 21:12:54 --> Total execution time: 0.0450
DEBUG - 2014-05-08 21:13:01 --> Config Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:13:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:13:01 --> URI Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Router Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Output Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Security Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Input Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:13:01 --> Language Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Loader Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Controller Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:13:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:13:01 --> Model Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Model Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Model Class Initialized
DEBUG - 2014-05-08 21:13:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:13:05 --> Model Class Initialized
DEBUG - 2014-05-08 21:13:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:13:05 --> Final output sent to browser
DEBUG - 2014-05-08 21:13:05 --> Total execution time: 3.9692
DEBUG - 2014-05-08 21:14:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:23 --> Session Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Session Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:14:23 --> A session cookie was not found.
DEBUG - 2014-05-08 21:14:23 --> A session cookie was not found.
DEBUG - 2014-05-08 21:14:23 --> Session routines successfully run
DEBUG - 2014-05-08 21:14:23 --> Session routines successfully run
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:23 --> Session Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:14:23 --> A session cookie was not found.
DEBUG - 2014-05-08 21:14:23 --> Session routines successfully run
DEBUG - 2014-05-08 21:14:23 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:23 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:23 --> Total execution time: 0.0510
DEBUG - 2014-05-08 21:14:23 --> Total execution time: 0.0510
DEBUG - 2014-05-08 21:14:23 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:14:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:23 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:23 --> Total execution time: 0.0550
DEBUG - 2014-05-08 21:14:27 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:27 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:27 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:27 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:27 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:27 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:27 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:27 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:27 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:27 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:27 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:27 --> Session Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:14:27 --> A session cookie was not found.
DEBUG - 2014-05-08 21:14:27 --> Session routines successfully run
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:14:27 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:27 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:27 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:27 --> Session Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Session Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:14:27 --> A session cookie was not found.
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:14:27 --> Session routines successfully run
DEBUG - 2014-05-08 21:14:27 --> A session cookie was not found.
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:14:27 --> Session routines successfully run
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:27 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:14:27 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:27 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:27 --> Total execution time: 0.0410
DEBUG - 2014-05-08 21:14:27 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:27 --> Total execution time: 0.0440
DEBUG - 2014-05-08 21:14:39 --> Config Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:14:39 --> URI Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Router Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Output Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Security Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Input Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:14:39 --> Language Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Loader Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Controller Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:14:40 --> Final output sent to browser
DEBUG - 2014-05-08 21:14:40 --> Total execution time: 0.9371
DEBUG - 2014-05-08 21:15:03 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:03 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:03 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:03 --> Session Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:15:03 --> A session cookie was not found.
DEBUG - 2014-05-08 21:15:03 --> Session routines successfully run
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:03 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:03 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:03 --> Total execution time: 0.0290
DEBUG - 2014-05-08 21:15:03 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:03 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:03 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:03 --> Session Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:15:03 --> A session cookie was not found.
DEBUG - 2014-05-08 21:15:03 --> Session routines successfully run
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:03 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:03 --> Total execution time: 0.0280
DEBUG - 2014-05-08 21:15:03 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:03 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:03 --> Session Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:15:03 --> A session cookie was not found.
DEBUG - 2014-05-08 21:15:03 --> Session routines successfully run
DEBUG - 2014-05-08 21:15:03 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:15:03 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:03 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:03 --> Total execution time: 0.0950
DEBUG - 2014-05-08 21:15:04 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:04 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:04 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:04 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:04 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:04 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:04 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:04 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:04 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:04 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Session Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:15:04 --> A session cookie was not found.
DEBUG - 2014-05-08 21:15:04 --> Session routines successfully run
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:04 --> Session Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Session Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:15:04 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:04 --> A session cookie was not found.
DEBUG - 2014-05-08 21:15:04 --> Total execution time: 0.0280
DEBUG - 2014-05-08 21:15:04 --> A session cookie was not found.
DEBUG - 2014-05-08 21:15:04 --> Session routines successfully run
DEBUG - 2014-05-08 21:15:04 --> Session routines successfully run
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:15:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:04 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:04 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:15:04 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:04 --> Total execution time: 0.0290
DEBUG - 2014-05-08 21:15:13 --> Config Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:15:13 --> URI Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Router Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Output Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Security Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Input Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:15:13 --> Language Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Loader Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Controller Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:15:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:15:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:15:15 --> Final output sent to browser
DEBUG - 2014-05-08 21:15:15 --> Total execution time: 1.1841
DEBUG - 2014-05-08 21:28:39 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:39 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:39 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:39 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:39 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:39 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:39 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:39 --> Session Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Session Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Session Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:28:39 --> A session cookie was not found.
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:28:39 --> A session cookie was not found.
DEBUG - 2014-05-08 21:28:39 --> A session cookie was not found.
DEBUG - 2014-05-08 21:28:39 --> Session routines successfully run
DEBUG - 2014-05-08 21:28:39 --> Session routines successfully run
DEBUG - 2014-05-08 21:28:39 --> Session routines successfully run
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:39 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:39 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:39 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:28:39 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:39 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:28:39 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:39 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:28:41 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:41 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:41 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:41 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:41 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:41 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:41 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:41 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:41 --> Session Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:28:41 --> A session cookie was not found.
DEBUG - 2014-05-08 21:28:41 --> Session routines successfully run
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:28:41 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:41 --> Total execution time: 0.0390
DEBUG - 2014-05-08 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:41 --> Session Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:28:41 --> A session cookie was not found.
DEBUG - 2014-05-08 21:28:41 --> Session routines successfully run
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:41 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:41 --> Total execution time: 0.0400
DEBUG - 2014-05-08 21:28:41 --> Session Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:28:41 --> A session cookie was not found.
DEBUG - 2014-05-08 21:28:41 --> Session routines successfully run
DEBUG - 2014-05-08 21:28:41 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:28:41 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:41 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:41 --> Total execution time: 0.0540
DEBUG - 2014-05-08 21:28:50 --> Config Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:28:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:28:50 --> URI Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Router Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Output Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Security Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Input Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:28:50 --> Language Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Loader Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Controller Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:28:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:28:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:51 --> Model Class Initialized
DEBUG - 2014-05-08 21:28:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:28:51 --> Final output sent to browser
DEBUG - 2014-05-08 21:28:51 --> Total execution time: 0.9491
DEBUG - 2014-05-08 21:32:13 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:13 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:13 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:13 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:13 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:13 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:13 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:13 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Session Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:32:13 --> A session cookie was not found.
DEBUG - 2014-05-08 21:32:13 --> Session routines successfully run
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Session Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:32:13 --> A session cookie was not found.
DEBUG - 2014-05-08 21:32:13 --> Session routines successfully run
DEBUG - 2014-05-08 21:32:13 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:13 --> Total execution time: 0.0290
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:13 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:13 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:13 --> Session Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:32:13 --> A session cookie was not found.
DEBUG - 2014-05-08 21:32:13 --> Session routines successfully run
DEBUG - 2014-05-08 21:32:13 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:32:13 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:13 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:13 --> Total execution time: 0.0450
DEBUG - 2014-05-08 21:32:15 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:15 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:15 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:15 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:15 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:15 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:15 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:15 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:15 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:15 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Session Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:32:15 --> A session cookie was not found.
DEBUG - 2014-05-08 21:32:15 --> Session routines successfully run
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:15 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:15 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:15 --> Session Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:32:15 --> A session cookie was not found.
DEBUG - 2014-05-08 21:32:15 --> Session routines successfully run
DEBUG - 2014-05-08 21:32:15 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:15 --> Total execution time: 0.0380
DEBUG - 2014-05-08 21:32:15 --> Session Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:32:15 --> A session cookie was not found.
DEBUG - 2014-05-08 21:32:15 --> Session routines successfully run
DEBUG - 2014-05-08 21:32:15 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:32:15 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:15 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:15 --> Total execution time: 0.0450
DEBUG - 2014-05-08 21:32:23 --> Config Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:32:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:32:23 --> URI Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Router Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Output Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Security Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Input Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:32:23 --> Language Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Loader Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Controller Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:32:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:32:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:32:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:32:24 --> Final output sent to browser
DEBUG - 2014-05-08 21:32:24 --> Total execution time: 0.9421
DEBUG - 2014-05-08 21:33:10 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:10 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:10 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:10 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:10 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Session Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:33:10 --> A session cookie was not found.
DEBUG - 2014-05-08 21:33:10 --> Session routines successfully run
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:10 --> Session Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:10 --> Total execution time: 0.0350
DEBUG - 2014-05-08 21:33:10 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:10 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:33:10 --> A session cookie was not found.
DEBUG - 2014-05-08 21:33:10 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Session routines successfully run
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:33:10 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:10 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:10 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:10 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:33:10 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:10 --> Session Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:33:10 --> A session cookie was not found.
DEBUG - 2014-05-08 21:33:10 --> Session routines successfully run
DEBUG - 2014-05-08 21:33:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:33:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:10 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:10 --> Total execution time: 0.0370
DEBUG - 2014-05-08 21:33:12 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:12 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:12 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:12 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:12 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:12 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:12 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:12 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:12 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:12 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:12 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:12 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:12 --> Session Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Session Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:33:12 --> A session cookie was not found.
DEBUG - 2014-05-08 21:33:12 --> A session cookie was not found.
DEBUG - 2014-05-08 21:33:12 --> Session routines successfully run
DEBUG - 2014-05-08 21:33:12 --> Session routines successfully run
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:33:12 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:12 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Total execution time: 0.0320
DEBUG - 2014-05-08 21:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:12 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:12 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:33:12 --> Session Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:33:12 --> A session cookie was not found.
DEBUG - 2014-05-08 21:33:12 --> Session routines successfully run
DEBUG - 2014-05-08 21:33:12 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:33:12 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:12 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:12 --> Total execution time: 0.0340
DEBUG - 2014-05-08 21:33:20 --> Config Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:33:20 --> URI Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Router Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Output Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Security Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Input Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:33:20 --> Language Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Loader Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Controller Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:33:20 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:33:20 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:33:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:33:21 --> Final output sent to browser
DEBUG - 2014-05-08 21:33:21 --> Total execution time: 0.9871
DEBUG - 2014-05-08 21:36:16 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:16 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:16 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:16 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:16 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:16 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:16 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:16 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:16 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:16 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:16 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:16 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:16 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:16 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:16 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:16 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:16 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:16 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:16 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:16 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:16 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:16 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:36:16 --> Total execution time: 0.0340
DEBUG - 2014-05-08 21:36:16 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:16 --> Total execution time: 0.0320
DEBUG - 2014-05-08 21:36:18 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:18 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:18 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:18 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:18 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:18 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:18 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:18 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:18 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:18 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:18 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:18 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:18 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:18 --> Total execution time: 0.0420
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:18 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:18 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:18 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:18 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:18 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:18 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:18 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:18 --> Total execution time: 0.0500
DEBUG - 2014-05-08 21:36:18 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:18 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:18 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:18 --> Total execution time: 0.0560
DEBUG - 2014-05-08 21:36:21 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:21 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:21 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:21 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:21 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:21 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:21 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:21 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:21 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:21 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:21 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:21 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:21 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:21 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:21 --> Total execution time: 0.0380
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:21 --> Session Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:21 --> Total execution time: 0.0370
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:36:21 --> A session cookie was not found.
DEBUG - 2014-05-08 21:36:21 --> Session routines successfully run
DEBUG - 2014-05-08 21:36:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:36:21 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:21 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:21 --> Total execution time: 0.0440
DEBUG - 2014-05-08 21:36:29 --> Config Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:36:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:36:29 --> URI Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Router Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Output Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Security Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Input Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:36:29 --> Language Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Loader Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Controller Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:36:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:36:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:30 --> Model Class Initialized
DEBUG - 2014-05-08 21:36:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:36:30 --> Final output sent to browser
DEBUG - 2014-05-08 21:36:30 --> Total execution time: 0.9911
DEBUG - 2014-05-08 21:38:04 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:04 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:04 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:04 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:04 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:04 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:04 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:04 --> Session Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:04 --> A session cookie was not found.
DEBUG - 2014-05-08 21:38:04 --> Session routines successfully run
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:04 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:04 --> Total execution time: 0.0380
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:04 --> Session Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:38:04 --> A session cookie was not found.
DEBUG - 2014-05-08 21:38:04 --> Session routines successfully run
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:04 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:04 --> Total execution time: 0.0440
DEBUG - 2014-05-08 21:38:04 --> Session Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:38:04 --> A session cookie was not found.
DEBUG - 2014-05-08 21:38:04 --> Session routines successfully run
DEBUG - 2014-05-08 21:38:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:38:04 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:04 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:04 --> Total execution time: 0.0500
DEBUG - 2014-05-08 21:38:24 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:24 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:24 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:24 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:24 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:24 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:24 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:24 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:24 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:24 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:24 --> Session Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Session Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Session Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:38:24 --> A session cookie was not found.
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:38:24 --> Session routines successfully run
DEBUG - 2014-05-08 21:38:24 --> A session cookie was not found.
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:38:24 --> A session cookie was not found.
DEBUG - 2014-05-08 21:38:24 --> Session routines successfully run
DEBUG - 2014-05-08 21:38:24 --> Session routines successfully run
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:38:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:24 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:24 --> Total execution time: 0.0280
DEBUG - 2014-05-08 21:38:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:24 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:24 --> Total execution time: 0.0270
DEBUG - 2014-05-08 21:38:24 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:24 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:38:31 --> Config Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:38:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:38:31 --> URI Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Router Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Output Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Security Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Input Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:38:31 --> Language Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Loader Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Controller Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:38:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:38:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:38:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:38:32 --> Final output sent to browser
DEBUG - 2014-05-08 21:38:32 --> Total execution time: 0.9671
DEBUG - 2014-05-08 21:39:36 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:36 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:36 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:36 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:36 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:36 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:36 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:36 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:36 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:36 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Session Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:39:36 --> A session cookie was not found.
DEBUG - 2014-05-08 21:39:36 --> Session routines successfully run
DEBUG - 2014-05-08 21:39:36 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:36 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:36 --> Total execution time: 0.0340
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Session Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:39:36 --> A session cookie was not found.
DEBUG - 2014-05-08 21:39:36 --> Session routines successfully run
DEBUG - 2014-05-08 21:39:36 --> Session Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:39:36 --> A session cookie was not found.
DEBUG - 2014-05-08 21:39:36 --> Session routines successfully run
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:36 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:39:36 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:36 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:36 --> Total execution time: 0.0380
DEBUG - 2014-05-08 21:39:36 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:36 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:39:38 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:38 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:38 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:38 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:38 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:38 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:38 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:38 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Session Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:39:38 --> A session cookie was not found.
DEBUG - 2014-05-08 21:39:38 --> Session routines successfully run
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:39:38 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:38 --> Total execution time: 0.0400
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:38 --> Session Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:39:38 --> A session cookie was not found.
DEBUG - 2014-05-08 21:39:38 --> Session routines successfully run
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:39:38 --> Session Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:38 --> A session cookie was not found.
DEBUG - 2014-05-08 21:39:38 --> Session routines successfully run
DEBUG - 2014-05-08 21:39:38 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:39:38 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:38 --> Total execution time: 0.0530
DEBUG - 2014-05-08 21:39:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:38 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:38 --> Total execution time: 0.0490
DEBUG - 2014-05-08 21:39:45 --> Config Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:39:45 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:39:45 --> URI Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Router Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Output Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Security Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Input Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:39:45 --> Language Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Loader Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Controller Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:39:45 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:39:45 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:39:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:39:46 --> Final output sent to browser
DEBUG - 2014-05-08 21:39:46 --> Total execution time: 0.9551
DEBUG - 2014-05-08 21:40:29 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:29 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:29 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:29 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:29 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:29 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:29 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:29 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:29 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:29 --> Session Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> A session cookie was not found.
DEBUG - 2014-05-08 21:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:29 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Session routines successfully run
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:29 --> Session Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:29 --> A session cookie was not found.
DEBUG - 2014-05-08 21:40:29 --> Session routines successfully run
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:29 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:29 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:29 --> Total execution time: 0.0350
DEBUG - 2014-05-08 21:40:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:29 --> Session Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:40:29 --> A session cookie was not found.
DEBUG - 2014-05-08 21:40:29 --> Session routines successfully run
DEBUG - 2014-05-08 21:40:29 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:40:29 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:29 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:29 --> Total execution time: 0.0540
DEBUG - 2014-05-08 21:40:31 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:31 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:31 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:31 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:31 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:31 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:31 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:31 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:31 --> Session Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:40:31 --> A session cookie was not found.
DEBUG - 2014-05-08 21:40:31 --> Session routines successfully run
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:31 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:31 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:31 --> Session Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Session Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:40:31 --> A session cookie was not found.
DEBUG - 2014-05-08 21:40:31 --> Session routines successfully run
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:40:31 --> A session cookie was not found.
DEBUG - 2014-05-08 21:40:31 --> Session routines successfully run
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:40:31 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:31 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:31 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:31 --> Total execution time: 0.0410
DEBUG - 2014-05-08 21:40:31 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:31 --> Total execution time: 0.0410
DEBUG - 2014-05-08 21:40:38 --> Config Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:40:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:40:38 --> URI Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Router Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Output Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Security Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Input Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:40:38 --> Language Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Loader Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Controller Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:40:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:40:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:39 --> Model Class Initialized
DEBUG - 2014-05-08 21:40:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:40:39 --> Final output sent to browser
DEBUG - 2014-05-08 21:40:39 --> Total execution time: 0.9221
DEBUG - 2014-05-08 21:41:50 --> Config Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Config Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:41:50 --> Config Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:41:50 --> URI Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:41:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:41:50 --> Router Class Initialized
DEBUG - 2014-05-08 21:41:50 --> URI Class Initialized
DEBUG - 2014-05-08 21:41:50 --> URI Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Router Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Router Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Output Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Output Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Security Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Output Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Security Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Input Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Security Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:41:50 --> Input Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Language Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:41:50 --> Input Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:41:50 --> Language Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Language Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Loader Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Loader Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Loader Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Controller Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Controller Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:41:50 --> Controller Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Session Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:41:50 --> A session cookie was not found.
DEBUG - 2014-05-08 21:41:50 --> Session routines successfully run
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Final output sent to browser
DEBUG - 2014-05-08 21:41:50 --> Total execution time: 0.0360
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:50 --> Session Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Session Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:41:50 --> A session cookie was not found.
DEBUG - 2014-05-08 21:41:50 --> A session cookie was not found.
DEBUG - 2014-05-08 21:41:50 --> Session routines successfully run
DEBUG - 2014-05-08 21:41:50 --> Session routines successfully run
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:50 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:50 --> Final output sent to browser
DEBUG - 2014-05-08 21:41:50 --> Total execution time: 0.0460
DEBUG - 2014-05-08 21:41:50 --> Final output sent to browser
DEBUG - 2014-05-08 21:41:50 --> Total execution time: 0.0460
DEBUG - 2014-05-08 21:41:52 --> Config Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Config Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:41:52 --> URI Class Initialized
DEBUG - 2014-05-08 21:41:52 --> URI Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Router Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Router Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Output Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Output Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Security Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Security Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Input Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Input Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:41:52 --> Language Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Language Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Loader Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Controller Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Loader Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Config Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:41:52 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Controller Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:41:52 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:41:52 --> URI Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Router Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Output Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Security Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Input Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:41:52 --> Language Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:52 --> Loader Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Controller Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Session Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:41:52 --> A session cookie was not found.
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:41:52 --> Session routines successfully run
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:52 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Final output sent to browser
DEBUG - 2014-05-08 21:41:52 --> Total execution time: 0.0410
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:52 --> Session Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:41:52 --> A session cookie was not found.
DEBUG - 2014-05-08 21:41:52 --> Session routines successfully run
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:52 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Final output sent to browser
DEBUG - 2014-05-08 21:41:52 --> Total execution time: 0.0530
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:52 --> Session Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:41:52 --> A session cookie was not found.
DEBUG - 2014-05-08 21:41:52 --> Session routines successfully run
DEBUG - 2014-05-08 21:41:52 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:41:52 --> Model Class Initialized
DEBUG - 2014-05-08 21:41:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:41:52 --> Final output sent to browser
DEBUG - 2014-05-08 21:41:52 --> Total execution time: 0.0500
DEBUG - 2014-05-08 21:42:00 --> Config Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:42:00 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:42:00 --> URI Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Router Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Output Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Security Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Input Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:42:00 --> Language Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Loader Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Controller Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:42:00 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:42:00 --> Model Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Model Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Model Class Initialized
DEBUG - 2014-05-08 21:42:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:42:01 --> Model Class Initialized
DEBUG - 2014-05-08 21:42:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:42:01 --> Final output sent to browser
DEBUG - 2014-05-08 21:42:01 --> Total execution time: 0.9301
DEBUG - 2014-05-08 21:53:10 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:10 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:10 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:10 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:10 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:10 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:10 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:10 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:10 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:10 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:10 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:10 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:10 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:10 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:10 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:10 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:10 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:10 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:10 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:10 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:10 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:10 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:53:10 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:10 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:10 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:53:10 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:53:11 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:11 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:11 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:11 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:11 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:11 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:11 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:11 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:11 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:11 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:11 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:11 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:11 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:11 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:11 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Total execution time: 0.0290
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:11 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:11 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:11 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:11 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:11 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:11 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:11 --> Total execution time: 0.0350
DEBUG - 2014-05-08 21:53:11 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:11 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:11 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:11 --> Total execution time: 0.0430
DEBUG - 2014-05-08 21:53:16 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:16 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:16 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:16 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:16 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:16 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:16 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:16 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:16 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:16 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:16 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:16 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:16 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:16 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:16 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:16 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:16 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:16 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:16 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:53:16 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:53:16 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:16 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:53:24 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:24 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:24 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:25 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:25 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:25 --> Total execution time: 1.0141
DEBUG - 2014-05-08 21:53:32 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:32 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:32 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:32 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Config Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:53:32 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:53:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:53:32 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:32 --> URI Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Router Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:32 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Output Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:32 --> Security Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Input Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:53:32 --> Language Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:32 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:32 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:32 --> Loader Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:32 --> Controller Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:32 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:32 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:32 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:32 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:32 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:32 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:32 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:32 --> Total execution time: 0.0320
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:32 --> Session Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:53:32 --> A session cookie was not found.
DEBUG - 2014-05-08 21:53:32 --> Session routines successfully run
DEBUG - 2014-05-08 21:53:32 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:53:32 --> Model Class Initialized
DEBUG - 2014-05-08 21:53:32 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:53:32 --> Total execution time: 0.0360
DEBUG - 2014-05-08 21:53:32 --> Final output sent to browser
DEBUG - 2014-05-08 21:53:32 --> Total execution time: 0.0360
DEBUG - 2014-05-08 21:55:34 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:34 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:34 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:34 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:34 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:34 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:34 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:34 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Session Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:55:34 --> A session cookie was not found.
DEBUG - 2014-05-08 21:55:34 --> Session routines successfully run
DEBUG - 2014-05-08 21:55:34 --> Session Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:55:34 --> A session cookie was not found.
DEBUG - 2014-05-08 21:55:34 --> Session routines successfully run
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:34 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:34 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:55:34 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:34 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:55:34 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:34 --> Session Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:55:34 --> A session cookie was not found.
DEBUG - 2014-05-08 21:55:34 --> Session routines successfully run
DEBUG - 2014-05-08 21:55:34 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:55:34 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:34 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:34 --> Total execution time: 0.0430
DEBUG - 2014-05-08 21:55:47 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:47 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:47 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:47 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:48 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:48 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:48 --> Total execution time: 0.9481
DEBUG - 2014-05-08 21:55:56 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:56 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:56 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Config Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:56 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:55:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:55:56 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:56 --> URI Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:56 --> Router Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Output Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:56 --> Security Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:56 --> Input Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:55:56 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Language Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Loader Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Controller Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:55:56 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:56 --> Session Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> A session cookie was not found.
DEBUG - 2014-05-08 21:55:56 --> Session routines successfully run
DEBUG - 2014-05-08 21:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:55:56 --> Session Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:55:56 --> A session cookie was not found.
DEBUG - 2014-05-08 21:55:56 --> Session routines successfully run
DEBUG - 2014-05-08 21:55:56 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:55:56 --> Total execution time: 0.0310
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:56 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:56 --> Session Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Total execution time: 0.0340
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:55:56 --> A session cookie was not found.
DEBUG - 2014-05-08 21:55:56 --> Session routines successfully run
DEBUG - 2014-05-08 21:55:56 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:55:56 --> Model Class Initialized
DEBUG - 2014-05-08 21:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:55:56 --> Final output sent to browser
DEBUG - 2014-05-08 21:55:56 --> Total execution time: 0.0330
DEBUG - 2014-05-08 21:56:42 --> Config Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Config Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:56:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:56:42 --> URI Class Initialized
DEBUG - 2014-05-08 21:56:42 --> URI Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Router Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Router Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Output Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Output Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Security Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Security Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Input Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Config Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Input Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:56:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Language Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:56:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:56:42 --> URI Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Router Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Loader Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Controller Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Output Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:56:42 --> Security Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Input Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:56:42 --> Language Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Loader Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Controller Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:56:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:56:42 --> Language Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:56:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Session Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Loader Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:56:42 --> A session cookie was not found.
DEBUG - 2014-05-08 21:56:42 --> Controller Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Session routines successfully run
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Final output sent to browser
DEBUG - 2014-05-08 21:56:42 --> Total execution time: 0.0370
DEBUG - 2014-05-08 21:56:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:56:42 --> Session Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Session Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:56:42 --> A session cookie was not found.
DEBUG - 2014-05-08 21:56:42 --> Session routines successfully run
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:56:42 --> A session cookie was not found.
DEBUG - 2014-05-08 21:56:42 --> Session routines successfully run
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:56:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:56:42 --> Model Class Initialized
DEBUG - 2014-05-08 21:56:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:56:42 --> Final output sent to browser
DEBUG - 2014-05-08 21:56:42 --> Total execution time: 0.0500
DEBUG - 2014-05-08 21:56:42 --> Final output sent to browser
DEBUG - 2014-05-08 21:56:42 --> Total execution time: 0.0470
DEBUG - 2014-05-08 21:57:19 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:19 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:19 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:19 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:19 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:19 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:19 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:19 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:19 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:19 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:19 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:19 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:19 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:19 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:19 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:19 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:19 --> Total execution time: 0.0420
DEBUG - 2014-05-08 21:57:19 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:19 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:19 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:19 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:19 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:19 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:19 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:19 --> Total execution time: 0.0510
DEBUG - 2014-05-08 21:57:19 --> Total execution time: 0.0500
DEBUG - 2014-05-08 21:57:46 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:46 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:46 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:46 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:46 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:46 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:46 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:46 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:46 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:46 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:46 --> Total execution time: 0.0280
DEBUG - 2014-05-08 21:57:46 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:46 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:46 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:46 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:46 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:46 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:46 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:46 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:46 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:46 --> Total execution time: 0.0840
DEBUG - 2014-05-08 21:57:46 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:46 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:46 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:46 --> Total execution time: 0.0320
DEBUG - 2014-05-08 21:57:49 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:49 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:49 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:49 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:49 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:49 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:49 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:49 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:49 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:49 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:49 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:49 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:49 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:49 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:49 --> Total execution time: 0.0320
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:49 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:49 --> Total execution time: 0.0360
DEBUG - 2014-05-08 21:57:49 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:49 --> Session Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:57:49 --> A session cookie was not found.
DEBUG - 2014-05-08 21:57:49 --> Session routines successfully run
DEBUG - 2014-05-08 21:57:49 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:57:49 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:49 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:49 --> Total execution time: 0.0320
DEBUG - 2014-05-08 21:57:57 --> Config Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:57:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:57:57 --> URI Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Router Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Output Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Security Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Input Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:57:57 --> Language Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Loader Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Controller Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:57:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:57:57 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:58 --> Model Class Initialized
DEBUG - 2014-05-08 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:57:58 --> Final output sent to browser
DEBUG - 2014-05-08 21:57:58 --> Total execution time: 0.9671
DEBUG - 2014-05-08 21:58:40 --> Config Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Config Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Config Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:58:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:58:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 21:58:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:58:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 21:58:40 --> URI Class Initialized
DEBUG - 2014-05-08 21:58:40 --> URI Class Initialized
DEBUG - 2014-05-08 21:58:40 --> URI Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Router Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Router Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Router Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Output Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Output Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Output Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Security Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Security Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Security Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Input Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Input Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:58:40 --> Input Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 21:58:40 --> Language Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Language Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Language Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Loader Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Loader Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Controller Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Loader Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Controller Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Controller Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:58:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:58:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:58:40 --> Session Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Session Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Session Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: string_helper
DEBUG - 2014-05-08 21:58:40 --> A session cookie was not found.
DEBUG - 2014-05-08 21:58:40 --> A session cookie was not found.
DEBUG - 2014-05-08 21:58:40 --> A session cookie was not found.
DEBUG - 2014-05-08 21:58:40 --> Session routines successfully run
DEBUG - 2014-05-08 21:58:40 --> Session routines successfully run
DEBUG - 2014-05-08 21:58:40 --> Session routines successfully run
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:58:40 --> Helper loaded: url_helper
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Model Class Initialized
DEBUG - 2014-05-08 21:58:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:58:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:58:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 21:58:40 --> Final output sent to browser
DEBUG - 2014-05-08 21:58:40 --> Final output sent to browser
DEBUG - 2014-05-08 21:58:40 --> Final output sent to browser
DEBUG - 2014-05-08 21:58:40 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:58:40 --> Total execution time: 0.0300
DEBUG - 2014-05-08 21:58:40 --> Total execution time: 0.0310
DEBUG - 2014-05-08 22:00:02 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:02 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:02 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:02 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:02 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:02 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:02 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:02 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:02 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:02 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:02 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:02 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Session Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:00:02 --> A session cookie was not found.
DEBUG - 2014-05-08 22:00:02 --> Session routines successfully run
DEBUG - 2014-05-08 22:00:02 --> Session Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:00:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:02 --> A session cookie was not found.
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Session routines successfully run
DEBUG - 2014-05-08 22:00:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:02 --> Session Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:00:02 --> A session cookie was not found.
DEBUG - 2014-05-08 22:00:02 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Session routines successfully run
DEBUG - 2014-05-08 22:00:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:02 --> Total execution time: 0.0290
DEBUG - 2014-05-08 22:00:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:00:02 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:02 --> Total execution time: 0.0290
DEBUG - 2014-05-08 22:00:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:02 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:02 --> Total execution time: 0.0330
DEBUG - 2014-05-08 22:00:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:04 --> Session Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:00:04 --> A session cookie was not found.
DEBUG - 2014-05-08 22:00:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:04 --> Session Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Session routines successfully run
DEBUG - 2014-05-08 22:00:04 --> Session Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:00:04 --> A session cookie was not found.
DEBUG - 2014-05-08 22:00:04 --> A session cookie was not found.
DEBUG - 2014-05-08 22:00:04 --> Session routines successfully run
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:00:04 --> Session routines successfully run
DEBUG - 2014-05-08 22:00:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:00:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:04 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:04 --> Total execution time: 0.0370
DEBUG - 2014-05-08 22:00:04 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:04 --> Total execution time: 0.0430
DEBUG - 2014-05-08 22:00:04 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:04 --> Total execution time: 0.0480
DEBUG - 2014-05-08 22:00:13 --> Config Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:00:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:00:13 --> URI Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Router Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Output Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Security Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Input Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:00:13 --> Language Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Loader Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Controller Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:00:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:00:13 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:14 --> Model Class Initialized
DEBUG - 2014-05-08 22:00:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:00:14 --> Final output sent to browser
DEBUG - 2014-05-08 22:00:14 --> Total execution time: 0.9421
DEBUG - 2014-05-08 22:01:02 --> Config Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Config Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:01:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:01:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:01:02 --> URI Class Initialized
DEBUG - 2014-05-08 22:01:02 --> URI Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Config Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Router Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Router Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Output Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Output Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Security Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Security Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Input Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Input Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:01:02 --> Language Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Language Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Loader Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Loader Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Controller Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Controller Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:01:02 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:01:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> URI Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Router Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Output Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Security Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Input Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:01:02 --> Language Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:01:02 --> Loader Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Controller Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Session Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:01:02 --> A session cookie was not found.
DEBUG - 2014-05-08 22:01:02 --> Session routines successfully run
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:01:02 --> Session Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Final output sent to browser
DEBUG - 2014-05-08 22:01:02 --> Total execution time: 0.0290
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:01:02 --> A session cookie was not found.
DEBUG - 2014-05-08 22:01:02 --> Session routines successfully run
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:01:02 --> Final output sent to browser
DEBUG - 2014-05-08 22:01:02 --> Total execution time: 0.0330
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:01:02 --> Session Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:01:02 --> A session cookie was not found.
DEBUG - 2014-05-08 22:01:02 --> Session routines successfully run
DEBUG - 2014-05-08 22:01:02 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:01:02 --> Model Class Initialized
DEBUG - 2014-05-08 22:01:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:01:02 --> Final output sent to browser
DEBUG - 2014-05-08 22:01:02 --> Total execution time: 0.0380
DEBUG - 2014-05-08 22:06:07 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:07 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:07 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:07 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:07 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:07 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:07 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:07 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:07 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:07 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:07 --> Session Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:06:07 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:07 --> A session cookie was not found.
DEBUG - 2014-05-08 22:06:07 --> Session routines successfully run
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:07 --> Total execution time: 0.0320
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:07 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Session Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:06:07 --> A session cookie was not found.
DEBUG - 2014-05-08 22:06:07 --> Session routines successfully run
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:07 --> Session Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:06:07 --> A session cookie was not found.
DEBUG - 2014-05-08 22:06:07 --> Session routines successfully run
DEBUG - 2014-05-08 22:06:07 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:06:07 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:07 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:07 --> Total execution time: 0.0490
DEBUG - 2014-05-08 22:06:07 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:07 --> Total execution time: 0.0500
DEBUG - 2014-05-08 22:06:09 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:09 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:09 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:09 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:09 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:09 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:09 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:09 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:09 --> Session Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:06:09 --> A session cookie was not found.
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:09 --> Session routines successfully run
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:09 --> Total execution time: 0.0290
DEBUG - 2014-05-08 22:06:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:09 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Session Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:06:09 --> A session cookie was not found.
DEBUG - 2014-05-08 22:06:09 --> Session routines successfully run
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:09 --> Total execution time: 0.0410
DEBUG - 2014-05-08 22:06:09 --> Session Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:06:09 --> A session cookie was not found.
DEBUG - 2014-05-08 22:06:09 --> Session routines successfully run
DEBUG - 2014-05-08 22:06:09 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:06:09 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:09 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:09 --> Total execution time: 0.0550
DEBUG - 2014-05-08 22:06:20 --> Config Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:06:20 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:06:20 --> URI Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Router Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Output Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Security Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Input Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:06:20 --> Language Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Loader Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Controller Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:06:20 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:06:20 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:06:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:06:21 --> Final output sent to browser
DEBUG - 2014-05-08 22:06:21 --> Total execution time: 0.9821
DEBUG - 2014-05-08 22:09:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:04 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:04 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:04 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:04 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:04 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:04 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:04 --> Total execution time: 0.0300
DEBUG - 2014-05-08 22:09:04 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:04 --> Total execution time: 0.0310
DEBUG - 2014-05-08 22:09:04 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:04 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:04 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:04 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:04 --> Total execution time: 0.0360
DEBUG - 2014-05-08 22:09:06 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:06 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:06 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:06 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:06 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:06 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:06 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:06 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:06 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:06 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:06 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:06 --> Total execution time: 0.0290
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:06 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:06 --> Total execution time: 0.0320
DEBUG - 2014-05-08 22:09:06 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:06 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:06 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:06 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:06 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:06 --> Total execution time: 0.0400
DEBUG - 2014-05-08 22:09:20 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:20 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:20 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:20 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:20 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:20 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:21 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:21 --> Total execution time: 1.0211
DEBUG - 2014-05-08 22:09:29 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:29 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:29 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Config Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:09:29 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:29 --> URI Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:29 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:29 --> Router Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Output Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Security Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Input Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:09:29 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Language Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:29 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:29 --> Loader Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Controller Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:29 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:29 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:29 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:29 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:29 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:29 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Total execution time: 0.0280
DEBUG - 2014-05-08 22:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:29 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:29 --> Total execution time: 0.0300
DEBUG - 2014-05-08 22:09:29 --> Session Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:09:29 --> A session cookie was not found.
DEBUG - 2014-05-08 22:09:29 --> Session routines successfully run
DEBUG - 2014-05-08 22:09:29 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:09:29 --> Model Class Initialized
DEBUG - 2014-05-08 22:09:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:09:29 --> Final output sent to browser
DEBUG - 2014-05-08 22:09:29 --> Total execution time: 0.0300
DEBUG - 2014-05-08 22:14:35 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:35 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:35 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:35 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:35 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:35 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:35 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:35 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:35 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Session Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:14:35 --> A session cookie was not found.
DEBUG - 2014-05-08 22:14:35 --> Session routines successfully run
DEBUG - 2014-05-08 22:14:35 --> Session Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:14:35 --> A session cookie was not found.
DEBUG - 2014-05-08 22:14:35 --> Session routines successfully run
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:14:35 --> Session Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:14:35 --> A session cookie was not found.
DEBUG - 2014-05-08 22:14:35 --> Session routines successfully run
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:14:35 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:35 --> Final output sent to browser
DEBUG - 2014-05-08 22:14:35 --> Final output sent to browser
DEBUG - 2014-05-08 22:14:35 --> Total execution time: 0.0450
DEBUG - 2014-05-08 22:14:35 --> Total execution time: 0.0470
DEBUG - 2014-05-08 22:14:36 --> Final output sent to browser
DEBUG - 2014-05-08 22:14:36 --> Total execution time: 0.0500
DEBUG - 2014-05-08 22:14:39 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:39 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:39 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:39 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:39 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:39 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:39 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:39 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:39 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:39 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Session Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:14:39 --> A session cookie was not found.
DEBUG - 2014-05-08 22:14:39 --> Session routines successfully run
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:39 --> Final output sent to browser
DEBUG - 2014-05-08 22:14:39 --> Total execution time: 0.0280
DEBUG - 2014-05-08 22:14:39 --> Session Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:14:39 --> A session cookie was not found.
DEBUG - 2014-05-08 22:14:39 --> Session routines successfully run
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:39 --> Final output sent to browser
DEBUG - 2014-05-08 22:14:39 --> Total execution time: 0.0310
DEBUG - 2014-05-08 22:14:39 --> Session Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:14:39 --> A session cookie was not found.
DEBUG - 2014-05-08 22:14:39 --> Session routines successfully run
DEBUG - 2014-05-08 22:14:39 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:14:39 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:14:39 --> Final output sent to browser
DEBUG - 2014-05-08 22:14:39 --> Total execution time: 0.0370
DEBUG - 2014-05-08 22:14:59 --> Config Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:14:59 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:14:59 --> URI Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Router Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Output Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Security Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Input Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:14:59 --> Language Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Loader Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Controller Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:14:59 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:14:59 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Model Class Initialized
DEBUG - 2014-05-08 22:14:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:00 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:00 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:00 --> Total execution time: 0.9831
DEBUG - 2014-05-08 22:15:40 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:40 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:40 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:40 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:40 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:40 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Session Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:15:40 --> A session cookie was not found.
DEBUG - 2014-05-08 22:15:40 --> Session routines successfully run
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:40 --> Total execution time: 0.0370
DEBUG - 2014-05-08 22:15:40 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:40 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:40 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:40 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Session Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:15:40 --> A session cookie was not found.
DEBUG - 2014-05-08 22:15:40 --> Session routines successfully run
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:40 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:40 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:40 --> Total execution time: 0.0430
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:40 --> Session Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:15:40 --> A session cookie was not found.
DEBUG - 2014-05-08 22:15:40 --> Session routines successfully run
DEBUG - 2014-05-08 22:15:40 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:15:40 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:40 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:40 --> Total execution time: 0.0530
DEBUG - 2014-05-08 22:15:42 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:42 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:42 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:42 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:42 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:42 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:42 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:42 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:42 --> Session Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:15:42 --> A session cookie was not found.
DEBUG - 2014-05-08 22:15:42 --> Session routines successfully run
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:42 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:42 --> Total execution time: 0.0490
DEBUG - 2014-05-08 22:15:42 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:42 --> Session Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:15:42 --> A session cookie was not found.
DEBUG - 2014-05-08 22:15:42 --> Session routines successfully run
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:42 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:42 --> Total execution time: 0.0670
DEBUG - 2014-05-08 22:15:42 --> Session Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:15:42 --> A session cookie was not found.
DEBUG - 2014-05-08 22:15:42 --> Session routines successfully run
DEBUG - 2014-05-08 22:15:42 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:15:42 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:42 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:42 --> Total execution time: 0.0730
DEBUG - 2014-05-08 22:15:55 --> Config Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:15:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:15:55 --> URI Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Router Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Output Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Security Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Input Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:15:55 --> Language Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Loader Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Controller Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:15:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:15:55 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:56 --> Model Class Initialized
DEBUG - 2014-05-08 22:15:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:15:56 --> Final output sent to browser
DEBUG - 2014-05-08 22:15:56 --> Total execution time: 0.9801
DEBUG - 2014-05-08 22:18:47 --> Config Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:18:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:18:47 --> URI Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Router Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Output Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Security Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Input Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:18:47 --> Language Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Loader Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Config Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Controller Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Config Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:18:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:18:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:18:47 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:18:47 --> URI Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Router Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Output Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Security Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Input Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:18:47 --> Language Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Loader Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Controller Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:18:47 --> URI Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Router Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Output Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Security Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Input Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:18:47 --> Language Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:47 --> Session Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Loader Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Controller Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:18:47 --> A session cookie was not found.
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:18:47 --> Session routines successfully run
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:47 --> Final output sent to browser
DEBUG - 2014-05-08 22:18:47 --> Session Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Total execution time: 0.0350
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:18:47 --> A session cookie was not found.
DEBUG - 2014-05-08 22:18:47 --> Session routines successfully run
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Final output sent to browser
DEBUG - 2014-05-08 22:18:47 --> Total execution time: 0.0470
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:47 --> Session Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:18:47 --> A session cookie was not found.
DEBUG - 2014-05-08 22:18:47 --> Session routines successfully run
DEBUG - 2014-05-08 22:18:47 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:18:47 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:47 --> Final output sent to browser
DEBUG - 2014-05-08 22:18:47 --> Total execution time: 0.0520
DEBUG - 2014-05-08 22:18:50 --> Config Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:18:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:18:50 --> URI Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Config Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Config Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Router Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:18:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:18:50 --> Output Class Initialized
DEBUG - 2014-05-08 22:18:50 --> URI Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Router Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Security Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Output Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Input Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:18:50 --> Security Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Language Class Initialized
DEBUG - 2014-05-08 22:18:50 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:18:50 --> Input Class Initialized
DEBUG - 2014-05-08 22:18:50 --> URI Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:18:50 --> Language Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Loader Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Controller Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Loader Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Controller Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Router Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Output Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Security Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Input Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:50 --> Session Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Language Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:18:50 --> A session cookie was not found.
DEBUG - 2014-05-08 22:18:50 --> Session routines successfully run
DEBUG - 2014-05-08 22:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:18:50 --> Session Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:18:50 --> A session cookie was not found.
DEBUG - 2014-05-08 22:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:50 --> Session routines successfully run
DEBUG - 2014-05-08 22:18:50 --> Loader Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Controller Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Final output sent to browser
DEBUG - 2014-05-08 22:18:50 --> Total execution time: 0.0410
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:50 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Final output sent to browser
DEBUG - 2014-05-08 22:18:50 --> Total execution time: 0.0450
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:50 --> Session Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:18:50 --> A session cookie was not found.
DEBUG - 2014-05-08 22:18:50 --> Session routines successfully run
DEBUG - 2014-05-08 22:18:50 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:18:50 --> Model Class Initialized
DEBUG - 2014-05-08 22:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:18:50 --> Final output sent to browser
DEBUG - 2014-05-08 22:18:50 --> Total execution time: 0.0530
DEBUG - 2014-05-08 22:19:04 --> Config Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:19:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:19:04 --> URI Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Router Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Output Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Security Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Input Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:19:04 --> Language Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Loader Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Controller Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:19:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:19:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Model Class Initialized
DEBUG - 2014-05-08 22:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:19:06 --> Model Class Initialized
DEBUG - 2014-05-08 22:19:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:19:06 --> Final output sent to browser
DEBUG - 2014-05-08 22:19:06 --> Total execution time: 1.6411
DEBUG - 2014-05-08 22:20:58 --> Config Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Config Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Config Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:20:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:20:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:20:58 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:20:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:20:58 --> URI Class Initialized
DEBUG - 2014-05-08 22:20:58 --> URI Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Router Class Initialized
DEBUG - 2014-05-08 22:20:58 --> URI Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Router Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Router Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Output Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Output Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Output Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Security Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Security Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Security Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Input Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Input Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:20:58 --> Input Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Language Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Language Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:20:58 --> Language Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Loader Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Loader Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Controller Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Controller Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:20:58 --> Loader Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:20:58 --> Controller Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:20:58 --> Session Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Session Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:20:58 --> A session cookie was not found.
DEBUG - 2014-05-08 22:20:58 --> Session routines successfully run
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:20:58 --> Session Class Initialized
DEBUG - 2014-05-08 22:20:58 --> A session cookie was not found.
DEBUG - 2014-05-08 22:20:58 --> Session routines successfully run
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:20:58 --> A session cookie was not found.
DEBUG - 2014-05-08 22:20:58 --> Session routines successfully run
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:20:58 --> Model Class Initialized
DEBUG - 2014-05-08 22:20:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:20:58 --> Final output sent to browser
DEBUG - 2014-05-08 22:20:58 --> Total execution time: 0.0340
DEBUG - 2014-05-08 22:20:58 --> Final output sent to browser
DEBUG - 2014-05-08 22:20:58 --> Total execution time: 0.0340
DEBUG - 2014-05-08 22:20:58 --> Final output sent to browser
DEBUG - 2014-05-08 22:20:58 --> Total execution time: 0.0350
DEBUG - 2014-05-08 22:24:21 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:21 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:21 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:21 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:21 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:21 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:21 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:21 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:21 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:21 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:21 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Session Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:24:21 --> A session cookie was not found.
DEBUG - 2014-05-08 22:24:21 --> Session routines successfully run
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:21 --> Session Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Session Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:24:21 --> A session cookie was not found.
DEBUG - 2014-05-08 22:24:21 --> Session routines successfully run
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:24:21 --> A session cookie was not found.
DEBUG - 2014-05-08 22:24:21 --> Session routines successfully run
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:21 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:24:21 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:21 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:21 --> Total execution time: 0.0420
DEBUG - 2014-05-08 22:24:21 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:21 --> Total execution time: 0.0420
DEBUG - 2014-05-08 22:24:21 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:21 --> Total execution time: 0.0440
DEBUG - 2014-05-08 22:24:24 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:24 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:24 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:24 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:24 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:24 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:24 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:24 --> Session Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:24 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:24 --> A session cookie was not found.
DEBUG - 2014-05-08 22:24:24 --> Session routines successfully run
DEBUG - 2014-05-08 22:24:24 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:24 --> Session Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> A session cookie was not found.
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:24 --> Session routines successfully run
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Total execution time: 0.0310
DEBUG - 2014-05-08 22:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:24 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:24 --> Total execution time: 0.0320
DEBUG - 2014-05-08 22:24:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:24 --> Session Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 22:24:24 --> A session cookie was not found.
DEBUG - 2014-05-08 22:24:24 --> Session routines successfully run
DEBUG - 2014-05-08 22:24:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 22:24:24 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:24 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:24 --> Total execution time: 0.0360
DEBUG - 2014-05-08 22:24:32 --> Config Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Hooks Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Utf8 Class Initialized
DEBUG - 2014-05-08 22:24:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 22:24:32 --> URI Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Router Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Output Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Security Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Input Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 22:24:32 --> Language Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Loader Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Controller Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 22:24:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 22:24:32 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Database Driver Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:34 --> Model Class Initialized
DEBUG - 2014-05-08 22:24:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 22:24:34 --> Final output sent to browser
DEBUG - 2014-05-08 22:24:34 --> Total execution time: 1.5501
DEBUG - 2014-05-08 23:46:24 --> Config Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Config Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 23:46:24 --> Config Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Hooks Class Initialized
DEBUG - 2014-05-08 23:46:24 --> URI Class Initialized
DEBUG - 2014-05-08 23:46:24 --> URI Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Utf8 Class Initialized
DEBUG - 2014-05-08 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 23:46:24 --> Router Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Router Class Initialized
DEBUG - 2014-05-08 23:46:24 --> URI Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Router Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Output Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Output Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Output Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Security Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Security Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Security Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Input Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Input Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 23:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 23:46:24 --> Language Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Input Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Language Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 23:46:24 --> Language Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Loader Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Loader Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Controller Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Controller Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Loader Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Controller Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 23:46:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:24 --> Session Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Session Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 23:46:24 --> A session cookie was not found.
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 23:46:24 --> A session cookie was not found.
DEBUG - 2014-05-08 23:46:24 --> Session routines successfully run
DEBUG - 2014-05-08 23:46:24 --> Session routines successfully run
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 23:46:24 --> Database Driver Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:24 --> Final output sent to browser
DEBUG - 2014-05-08 23:46:24 --> Final output sent to browser
DEBUG - 2014-05-08 23:46:24 --> Total execution time: 0.0310
DEBUG - 2014-05-08 23:46:24 --> Total execution time: 0.0300
DEBUG - 2014-05-08 23:46:24 --> Session Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: string_helper
DEBUG - 2014-05-08 23:46:24 --> A session cookie was not found.
DEBUG - 2014-05-08 23:46:24 --> Session routines successfully run
DEBUG - 2014-05-08 23:46:24 --> Helper loaded: url_helper
DEBUG - 2014-05-08 23:46:24 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:24 --> Final output sent to browser
DEBUG - 2014-05-08 23:46:24 --> Total execution time: 0.0350
DEBUG - 2014-05-08 23:46:42 --> Config Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Hooks Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Utf8 Class Initialized
DEBUG - 2014-05-08 23:46:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-08 23:46:42 --> URI Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Router Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Output Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Security Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Input Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-08 23:46:42 --> Language Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Loader Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Controller Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-08 23:46:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-08 23:46:42 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Database Driver Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:43 --> Model Class Initialized
DEBUG - 2014-05-08 23:46:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-08 23:46:43 --> Final output sent to browser
DEBUG - 2014-05-08 23:46:43 --> Total execution time: 1.0411
