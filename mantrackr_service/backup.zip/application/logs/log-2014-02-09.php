<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-09 05:19:09 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:09 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:09 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:09 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:09 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:09 --> A session cookie was not found.
DEBUG - 2014-02-09 05:19:09 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:09 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:09 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:09 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:09 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:10 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:10 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:10 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:10 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:10 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:10 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:10 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-09 05:19:10 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:10 --> Total execution time: 0.0110
DEBUG - 2014-02-09 05:19:11 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:11 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:11 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:11 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:11 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:11 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:11 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:11 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:16 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:16 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:16 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:16 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:16 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:16 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:16 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:16 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:21 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:21 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:21 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:21 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:21 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:21 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:21 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:21 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-09 05:19:21 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:21 --> Total execution time: 0.0230
DEBUG - 2014-02-09 05:19:23 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:23 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:23 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:23 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:23 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:23 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:23 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:23 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:23 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:23 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:23 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:23 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:23 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:23 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:23 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:23 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:23 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:24 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:24 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:24 --> Total execution time: 0.0260
DEBUG - 2014-02-09 05:19:24 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:24 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:24 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:24 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:24 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:24 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:24 --> Total execution time: 0.0220
DEBUG - 2014-02-09 05:19:24 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:24 --> Total execution time: 0.0320
DEBUG - 2014-02-09 05:19:24 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:24 --> Total execution time: 0.0320
DEBUG - 2014-02-09 05:19:28 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:28 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:28 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:28 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:28 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:28 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:28 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:28 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:28 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:28 --> Total execution time: 0.0170
DEBUG - 2014-02-09 05:19:30 --> Config Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:19:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:19:30 --> URI Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Router Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Output Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Security Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Input Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:19:30 --> Language Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Loader Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Controller Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:19:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:19:30 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Model Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:19:30 --> Session Class Initialized
DEBUG - 2014-02-09 05:19:30 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:19:30 --> Session routines successfully run
DEBUG - 2014-02-09 05:19:30 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:19:30 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-09 05:19:30 --> Final output sent to browser
DEBUG - 2014-02-09 05:19:30 --> Total execution time: 0.0180
DEBUG - 2014-02-09 05:20:38 --> Config Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Hooks Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Utf8 Class Initialized
DEBUG - 2014-02-09 05:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 05:20:38 --> URI Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Router Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Output Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Security Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Input Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 05:20:38 --> Language Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Loader Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Controller Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 05:20:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 05:20:38 --> Model Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Model Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Database Driver Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Model Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 05:20:38 --> Session Class Initialized
DEBUG - 2014-02-09 05:20:38 --> Helper loaded: string_helper
DEBUG - 2014-02-09 05:20:38 --> Session routines successfully run
DEBUG - 2014-02-09 05:20:38 --> Helper loaded: url_helper
DEBUG - 2014-02-09 05:20:38 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-09 05:20:38 --> Final output sent to browser
DEBUG - 2014-02-09 05:20:38 --> Total execution time: 0.0220
DEBUG - 2014-02-09 22:54:09 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:09 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:09 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:09 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Database Driver Class Initialized
ERROR - 2014-02-09 22:54:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-09 22:54:09 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:09 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:09 --> A session cookie was not found.
DEBUG - 2014-02-09 22:54:09 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:09 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:09 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:09 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:09 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Database Driver Class Initialized
ERROR - 2014-02-09 22:54:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-09 22:54:09 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:09 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:09 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:09 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:09 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-09 22:54:09 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:09 --> Total execution time: 0.0120
DEBUG - 2014-02-09 22:54:12 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:12 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:12 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:12 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Database Driver Class Initialized
ERROR - 2014-02-09 22:54:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-09 22:54:12 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:12 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:12 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:12 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:12 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:17 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:17 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:17 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:17 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Database Driver Class Initialized
ERROR - 2014-02-09 22:54:17 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-09 22:54:17 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:17 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:17 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:17 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:17 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:22 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:22 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:22 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Database Driver Class Initialized
ERROR - 2014-02-09 22:54:22 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:22 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:22 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-09 22:54:22 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:22 --> Total execution time: 0.0240
DEBUG - 2014-02-09 22:54:22 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:22 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:22 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:22 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:22 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:22 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:22 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Database Driver Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Database Driver Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:22 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:22 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:22 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Database Driver Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:22 --> Database Driver Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:22 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:22 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:22 --> Total execution time: 0.0250
DEBUG - 2014-02-09 22:54:22 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:22 --> Total execution time: 0.0270
DEBUG - 2014-02-09 22:54:22 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:22 --> Total execution time: 0.0240
DEBUG - 2014-02-09 22:54:22 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:22 --> Total execution time: 0.0280
DEBUG - 2014-02-09 22:54:32 --> Config Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-09 22:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-09 22:54:32 --> URI Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Router Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Output Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Security Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Input Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-09 22:54:32 --> Language Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Loader Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Controller Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-09 22:54:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-09 22:54:32 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Database Driver Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:32 --> Session Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-09 22:54:32 --> Session routines successfully run
DEBUG - 2014-02-09 22:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-09 22:54:32 --> Model Class Initialized
DEBUG - 2014-02-09 22:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-09 22:54:32 --> Final output sent to browser
DEBUG - 2014-02-09 22:54:32 --> Total execution time: 0.0420
