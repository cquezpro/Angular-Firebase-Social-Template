<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-14 06:40:16 --> Config Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:40:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:40:16 --> URI Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Router Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Output Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Security Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Input Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:40:16 --> Language Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Loader Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Controller Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:40:16 --> Model Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Model Class Initialized
DEBUG - 2014-01-14 06:40:16 --> Final output sent to browser
DEBUG - 2014-01-14 06:40:16 --> Total execution time: 0.0140
DEBUG - 2014-01-14 06:40:39 --> Config Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:40:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:40:39 --> URI Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Router Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Output Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Security Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Input Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:40:39 --> Language Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Loader Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Controller Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:40:39 --> Model Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Model Class Initialized
DEBUG - 2014-01-14 06:40:39 --> Helper loaded: email_helper
DEBUG - 2014-01-14 06:40:39 --> Model Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Config Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:41:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:41:58 --> URI Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Router Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Output Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Security Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Input Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:41:58 --> Language Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Loader Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Controller Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:41:58 --> Model Class Initialized
DEBUG - 2014-01-14 06:41:58 --> Model Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Config Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:43:46 --> URI Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Router Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Output Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Security Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Input Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:43:46 --> Language Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Loader Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Database Driver Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Controller Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:43:46 --> Model Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Model Class Initialized
DEBUG - 2014-01-14 06:43:46 --> Helper loaded: email_helper
DEBUG - 2014-01-14 06:43:46 --> Model Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Config Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:47:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:47:25 --> URI Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Router Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Output Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Security Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Input Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:47:25 --> Language Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Loader Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Controller Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:47:25 --> Model Class Initialized
DEBUG - 2014-01-14 06:47:25 --> Model Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Config Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:51:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:51:24 --> URI Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Router Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Output Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Security Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Input Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:51:24 --> Language Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Loader Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Controller Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:51:24 --> Model Class Initialized
DEBUG - 2014-01-14 06:51:24 --> Model Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Config Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:52:57 --> URI Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Router Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Output Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Security Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Input Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:52:57 --> Language Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Loader Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Controller Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:52:57 --> Model Class Initialized
DEBUG - 2014-01-14 06:52:57 --> Model Class Initialized
DEBUG - 2014-01-14 06:52:59 --> Database Driver Class Initialized
DEBUG - 2014-01-14 06:53:09 --> Helper loaded: email_helper
DEBUG - 2014-01-14 06:53:09 --> Model Class Initialized
DEBUG - 2014-01-14 06:53:28 --> Final output sent to browser
DEBUG - 2014-01-14 06:53:28 --> Total execution time: 31.4758
DEBUG - 2014-01-14 06:56:24 --> Config Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Hooks Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Utf8 Class Initialized
DEBUG - 2014-01-14 06:56:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 06:56:24 --> URI Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Router Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Output Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Security Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Input Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 06:56:24 --> Language Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Loader Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Controller Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 06:56:24 --> Model Class Initialized
DEBUG - 2014-01-14 06:56:24 --> Model Class Initialized
DEBUG - 2014-01-14 06:56:27 --> Database Driver Class Initialized
DEBUG - 2014-01-14 06:56:27 --> Helper loaded: email_helper
DEBUG - 2014-01-14 06:56:27 --> Model Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Config Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:24:28 --> URI Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Router Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Output Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Security Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Input Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:24:28 --> Language Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Loader Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Controller Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:24:28 --> Model Class Initialized
DEBUG - 2014-01-14 07:24:28 --> Model Class Initialized
DEBUG - 2014-01-14 07:24:29 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:24:29 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:24:29 --> Model Class Initialized
DEBUG - 2014-01-14 07:24:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:25:30 --> Config Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:25:30 --> URI Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Router Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Output Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Security Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Input Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:25:30 --> Language Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Loader Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Controller Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:25:30 --> Model Class Initialized
DEBUG - 2014-01-14 07:25:30 --> Model Class Initialized
DEBUG - 2014-01-14 07:25:34 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:25:34 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:25:34 --> Model Class Initialized
DEBUG - 2014-01-14 07:25:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:26:53 --> Config Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:26:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:26:53 --> URI Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Router Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Output Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Security Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Input Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:26:53 --> Language Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Loader Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Controller Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:26:53 --> Model Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Model Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:26:53 --> Model Class Initialized
DEBUG - 2014-01-14 07:26:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:27:16 --> Final output sent to browser
DEBUG - 2014-01-14 07:27:16 --> Total execution time: 23.0993
DEBUG - 2014-01-14 07:27:52 --> Config Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:27:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:27:52 --> URI Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Router Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Output Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Security Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Input Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:27:52 --> Language Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Loader Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Controller Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:27:52 --> Model Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Model Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:27:52 --> Model Class Initialized
DEBUG - 2014-01-14 07:27:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:28:56 --> Final output sent to browser
DEBUG - 2014-01-14 07:28:56 --> Total execution time: 63.3076
DEBUG - 2014-01-14 07:45:13 --> Config Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:45:13 --> URI Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Router Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Output Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Security Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Input Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:45:13 --> Language Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Loader Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Controller Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:45:13 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:45:13 --> Final output sent to browser
DEBUG - 2014-01-14 07:45:13 --> Total execution time: 0.2020
DEBUG - 2014-01-14 07:45:23 --> Config Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:45:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:45:23 --> URI Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Router Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Output Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Security Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Input Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:45:23 --> Language Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Loader Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Controller Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:45:23 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:45:23 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:45:56 --> Config Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:45:56 --> URI Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Router Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Output Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Security Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Input Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:45:56 --> Language Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Loader Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Controller Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:45:56 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:45:56 --> Model Class Initialized
DEBUG - 2014-01-14 07:45:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:46:00 --> Final output sent to browser
DEBUG - 2014-01-14 07:46:00 --> Total execution time: 3.6362
DEBUG - 2014-01-14 07:46:13 --> Config Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:46:13 --> URI Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Router Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Output Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Security Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Input Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:46:13 --> Language Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Loader Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Controller Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:46:13 --> Model Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Model Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:46:13 --> Model Class Initialized
DEBUG - 2014-01-14 07:46:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:46:13 --> Final output sent to browser
DEBUG - 2014-01-14 07:46:13 --> Total execution time: 0.0190
DEBUG - 2014-01-14 07:46:16 --> Config Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:46:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:46:16 --> URI Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Router Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Output Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Security Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Input Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:46:16 --> Language Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Loader Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Controller Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:46:16 --> Model Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Model Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:46:16 --> Model Class Initialized
DEBUG - 2014-01-14 07:46:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:46:16 --> Final output sent to browser
DEBUG - 2014-01-14 07:46:16 --> Total execution time: 0.0180
DEBUG - 2014-01-14 07:55:42 --> Config Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:55:42 --> URI Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Router Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Output Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Security Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Input Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:55:42 --> Language Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Loader Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Controller Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:55:42 --> Model Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Model Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:55:42 --> Model Class Initialized
DEBUG - 2014-01-14 07:55:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:55:45 --> Final output sent to browser
DEBUG - 2014-01-14 07:55:45 --> Total execution time: 2.7852
DEBUG - 2014-01-14 07:56:53 --> Config Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Hooks Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Utf8 Class Initialized
DEBUG - 2014-01-14 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 07:56:53 --> URI Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Router Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Output Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Security Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Input Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 07:56:53 --> Language Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Loader Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Controller Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 07:56:53 --> Model Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Model Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Database Driver Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Helper loaded: email_helper
DEBUG - 2014-01-14 07:56:53 --> Model Class Initialized
DEBUG - 2014-01-14 07:56:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 07:56:53 --> Final output sent to browser
DEBUG - 2014-01-14 07:56:53 --> Total execution time: 0.0170
DEBUG - 2014-01-14 08:35:51 --> Config Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:35:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:35:51 --> URI Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Router Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Output Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Security Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Input Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:35:51 --> Language Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Loader Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Controller Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:35:51 --> Model Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Model Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Helper loaded: email_helper
DEBUG - 2014-01-14 08:35:51 --> Model Class Initialized
DEBUG - 2014-01-14 08:35:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 08:35:51 --> Final output sent to browser
DEBUG - 2014-01-14 08:35:51 --> Total execution time: 0.0200
DEBUG - 2014-01-14 08:35:58 --> Config Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:35:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:35:58 --> URI Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Router Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Output Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Security Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Input Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:35:58 --> Language Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Loader Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Controller Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:35:58 --> Model Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Model Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:35:58 --> Final output sent to browser
DEBUG - 2014-01-14 08:35:58 --> Total execution time: 0.0080
DEBUG - 2014-01-14 08:36:05 --> Config Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:36:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:36:05 --> URI Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Router Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Output Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Security Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Input Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:36:05 --> Language Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Loader Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Controller Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:36:05 --> Model Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Model Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:36:05 --> Final output sent to browser
DEBUG - 2014-01-14 08:36:05 --> Total execution time: 0.0140
DEBUG - 2014-01-14 08:36:12 --> Config Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:36:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:36:12 --> URI Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Router Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Output Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Security Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Input Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:36:12 --> Language Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Loader Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Controller Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:36:12 --> Model Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Model Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Model Class Initialized
DEBUG - 2014-01-14 08:36:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 08:36:12 --> Final output sent to browser
DEBUG - 2014-01-14 08:36:12 --> Total execution time: 0.0360
DEBUG - 2014-01-14 08:37:03 --> Config Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:37:03 --> URI Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Router Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Output Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Security Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Input Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:37:03 --> Language Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Loader Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Controller Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:37:03 --> Model Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Model Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Model Class Initialized
DEBUG - 2014-01-14 08:37:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 08:37:03 --> Final output sent to browser
DEBUG - 2014-01-14 08:37:03 --> Total execution time: 0.0170
DEBUG - 2014-01-14 08:37:15 --> Config Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:37:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:37:15 --> URI Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Router Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Output Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Security Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Input Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:37:15 --> Language Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Loader Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Controller Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:37:15 --> Model Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Model Class Initialized
DEBUG - 2014-01-14 08:37:15 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:37:35 --> Model Class Initialized
DEBUG - 2014-01-14 08:37:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 08:37:49 --> Final output sent to browser
DEBUG - 2014-01-14 08:37:49 --> Total execution time: 34.3050
DEBUG - 2014-01-14 08:38:01 --> Config Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:38:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:38:01 --> URI Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Router Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Output Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Security Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Input Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:38:01 --> Language Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Loader Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Controller Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:38:01 --> Model Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Model Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Helper loaded: email_helper
DEBUG - 2014-01-14 08:38:01 --> Model Class Initialized
DEBUG - 2014-01-14 08:38:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 08:38:04 --> DB Transaction Failure
ERROR - 2014-01-14 08:38:04 --> Query error: Unknown column 'memeber_id' in 'where clause'
DEBUG - 2014-01-14 08:38:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-14 08:38:27 --> Config Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Hooks Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Utf8 Class Initialized
DEBUG - 2014-01-14 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 08:38:27 --> URI Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Router Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Output Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Security Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Input Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 08:38:27 --> Language Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Loader Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Controller Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 08:38:27 --> Model Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Model Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Database Driver Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Helper loaded: email_helper
DEBUG - 2014-01-14 08:38:27 --> Model Class Initialized
DEBUG - 2014-01-14 08:38:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 08:38:27 --> Final output sent to browser
DEBUG - 2014-01-14 08:38:27 --> Total execution time: 0.0100
DEBUG - 2014-01-14 11:18:12 --> Config Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:18:12 --> URI Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Router Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Output Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Security Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Input Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:18:12 --> Language Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Loader Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Controller Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:18:12 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Helper loaded: email_helper
DEBUG - 2014-01-14 11:18:12 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:18:15 --> Final output sent to browser
DEBUG - 2014-01-14 11:18:15 --> Total execution time: 2.8762
DEBUG - 2014-01-14 11:18:31 --> Config Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:18:31 --> URI Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Router Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Output Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Security Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Input Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:18:31 --> Language Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Loader Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Controller Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:18:31 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Helper loaded: email_helper
DEBUG - 2014-01-14 11:18:31 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:18:31 --> Final output sent to browser
DEBUG - 2014-01-14 11:18:31 --> Total execution time: 0.0160
DEBUG - 2014-01-14 11:18:37 --> Config Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:18:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:18:37 --> URI Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Router Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Output Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Security Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Input Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:18:37 --> Language Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Loader Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Controller Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:18:37 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:18:37 --> Final output sent to browser
DEBUG - 2014-01-14 11:18:37 --> Total execution time: 0.2270
DEBUG - 2014-01-14 11:18:44 --> Config Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:18:44 --> URI Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Router Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Output Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Security Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Input Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:18:44 --> Language Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Loader Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Controller Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:18:44 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Model Class Initialized
DEBUG - 2014-01-14 11:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:18:44 --> Final output sent to browser
DEBUG - 2014-01-14 11:18:44 --> Total execution time: 0.0790
DEBUG - 2014-01-14 11:20:55 --> Config Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:20:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:20:55 --> URI Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Router Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Output Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Security Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Input Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:20:55 --> Language Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Loader Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Controller Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:20:55 --> Model Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Model Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Model Class Initialized
DEBUG - 2014-01-14 11:20:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:20:58 --> Final output sent to browser
DEBUG - 2014-01-14 11:20:58 --> Total execution time: 2.4471
DEBUG - 2014-01-14 11:22:29 --> Config Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:22:29 --> URI Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Router Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Output Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Security Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Input Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:22:29 --> Language Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Loader Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Controller Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:22:29 --> Model Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Model Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Helper loaded: email_helper
DEBUG - 2014-01-14 11:22:29 --> Model Class Initialized
DEBUG - 2014-01-14 11:22:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:22:35 --> Final output sent to browser
DEBUG - 2014-01-14 11:22:35 --> Total execution time: 6.3554
DEBUG - 2014-01-14 11:24:52 --> Config Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:24:52 --> URI Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Router Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Output Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Security Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Input Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:24:52 --> Language Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Loader Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Controller Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:24:52 --> Model Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Model Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Model Class Initialized
DEBUG - 2014-01-14 11:24:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:24:54 --> Final output sent to browser
DEBUG - 2014-01-14 11:24:54 --> Total execution time: 2.3561
DEBUG - 2014-01-14 11:32:50 --> Config Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:32:50 --> URI Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Router Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Output Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Security Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Input Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:32:50 --> Language Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Loader Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Controller Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:32:50 --> Model Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Model Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:32:50 --> Final output sent to browser
DEBUG - 2014-01-14 11:32:50 --> Total execution time: 0.0170
DEBUG - 2014-01-14 11:32:55 --> Config Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:32:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:32:55 --> URI Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Router Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Output Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Security Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Input Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:32:55 --> Language Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Loader Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Controller Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:32:55 --> Model Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Model Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Model Class Initialized
DEBUG - 2014-01-14 11:32:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:32:55 --> DB Transaction Failure
ERROR - 2014-01-14 11:32:55 --> Query error: Unknown column 'memeber_id' in 'field list'
DEBUG - 2014-01-14 11:32:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-01-14 11:33:11 --> Config Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:33:11 --> URI Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Router Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Output Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Security Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Input Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:33:11 --> Language Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Loader Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Controller Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:33:11 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:33:11 --> Final output sent to browser
DEBUG - 2014-01-14 11:33:11 --> Total execution time: 0.0160
DEBUG - 2014-01-14 11:33:14 --> Config Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:33:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:33:14 --> URI Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Router Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Output Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Security Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Input Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:33:14 --> Language Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Loader Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Controller Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:33:14 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:33:14 --> Final output sent to browser
DEBUG - 2014-01-14 11:33:14 --> Total execution time: 0.0160
DEBUG - 2014-01-14 11:33:33 --> Config Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:33:33 --> URI Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Router Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Output Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Security Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Input Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:33:33 --> Language Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Loader Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Controller Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:33:33 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:33 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:33:38 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:33:59 --> Config Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:33:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:33:59 --> URI Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Router Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Output Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Security Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Input Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:33:59 --> Language Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Loader Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Controller Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:33:59 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Model Class Initialized
DEBUG - 2014-01-14 11:33:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:33:59 --> Final output sent to browser
DEBUG - 2014-01-14 11:33:59 --> Total execution time: 0.6420
DEBUG - 2014-01-14 11:34:03 --> Config Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:34:03 --> URI Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Router Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Output Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Security Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Input Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:34:03 --> Language Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Loader Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Controller Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:34:03 --> Model Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Model Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Model Class Initialized
DEBUG - 2014-01-14 11:34:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:34:03 --> Final output sent to browser
DEBUG - 2014-01-14 11:34:03 --> Total execution time: 0.0140
DEBUG - 2014-01-14 11:38:04 --> Config Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:38:04 --> URI Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Router Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Output Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Security Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Input Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:38:04 --> Language Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Loader Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Controller Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:38:04 --> Model Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Model Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Model Class Initialized
DEBUG - 2014-01-14 11:38:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:38:07 --> Final output sent to browser
DEBUG - 2014-01-14 11:38:07 --> Total execution time: 2.8222
DEBUG - 2014-01-14 11:39:13 --> Config Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:39:13 --> URI Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Router Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Output Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Security Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Input Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:39:13 --> Language Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Loader Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Controller Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:39:13 --> Model Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Model Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Model Class Initialized
DEBUG - 2014-01-14 11:39:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:39:16 --> Final output sent to browser
DEBUG - 2014-01-14 11:39:16 --> Total execution time: 2.3571
DEBUG - 2014-01-14 11:39:34 --> Config Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:39:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:39:34 --> URI Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Router Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Output Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Security Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Input Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:39:34 --> Language Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Loader Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Controller Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:39:34 --> Model Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Model Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Model Class Initialized
DEBUG - 2014-01-14 11:39:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:39:34 --> Final output sent to browser
DEBUG - 2014-01-14 11:39:34 --> Total execution time: 0.0160
DEBUG - 2014-01-14 11:56:46 --> Config Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:56:46 --> URI Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Router Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Output Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Security Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Input Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:56:46 --> Language Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Loader Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Controller Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:56:46 --> Model Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Model Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Model Class Initialized
DEBUG - 2014-01-14 11:56:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 11:56:49 --> Final output sent to browser
DEBUG - 2014-01-14 11:56:49 --> Total execution time: 2.6352
DEBUG - 2014-01-14 11:57:06 --> Config Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:57:06 --> URI Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Router Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Output Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Security Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Input Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:57:06 --> Language Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Loader Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Controller Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:57:06 --> Model Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Model Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:57:06 --> Final output sent to browser
DEBUG - 2014-01-14 11:57:06 --> Total execution time: 0.0150
DEBUG - 2014-01-14 11:59:32 --> Config Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Hooks Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Utf8 Class Initialized
DEBUG - 2014-01-14 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 11:59:32 --> URI Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Router Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Output Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Security Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Input Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 11:59:32 --> Language Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Loader Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Controller Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 11:59:32 --> Model Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Model Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Database Driver Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Model Class Initialized
DEBUG - 2014-01-14 11:59:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:00:15 --> Final output sent to browser
DEBUG - 2014-01-14 12:00:15 --> Total execution time: 43.0695
DEBUG - 2014-01-14 12:08:19 --> Config Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:08:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:08:19 --> URI Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Router Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Output Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Security Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Input Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:08:19 --> Language Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Loader Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Controller Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:08:19 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:08:19 --> Final output sent to browser
DEBUG - 2014-01-14 12:08:19 --> Total execution time: 0.0490
DEBUG - 2014-01-14 12:08:21 --> Config Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:08:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:08:21 --> URI Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Router Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Output Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Security Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Input Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:08:21 --> Language Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Loader Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Controller Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:08:21 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:08:21 --> Final output sent to browser
DEBUG - 2014-01-14 12:08:21 --> Total execution time: 0.0420
DEBUG - 2014-01-14 12:08:23 --> Config Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:08:23 --> URI Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Router Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Output Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Security Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Input Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:08:23 --> Language Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Loader Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Controller Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:08:23 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:08:23 --> Final output sent to browser
DEBUG - 2014-01-14 12:08:23 --> Total execution time: 0.0520
DEBUG - 2014-01-14 12:08:28 --> Config Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:08:28 --> URI Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Router Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Output Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Security Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Input Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:08:28 --> Language Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Loader Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Controller Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:08:28 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:08:30 --> Final output sent to browser
DEBUG - 2014-01-14 12:08:30 --> Total execution time: 2.4181
DEBUG - 2014-01-14 12:08:56 --> Config Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:08:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:08:56 --> URI Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Router Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Output Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Security Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Input Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:08:56 --> Language Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Loader Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Controller Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:08:56 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Model Class Initialized
DEBUG - 2014-01-14 12:08:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:08:58 --> Final output sent to browser
DEBUG - 2014-01-14 12:08:58 --> Total execution time: 2.3051
DEBUG - 2014-01-14 12:09:20 --> Config Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:09:20 --> URI Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Router Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Output Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Security Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Input Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:09:20 --> Language Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Loader Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Controller Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:09:20 --> Model Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Model Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Model Class Initialized
DEBUG - 2014-01-14 12:09:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:09:25 --> Final output sent to browser
DEBUG - 2014-01-14 12:09:25 --> Total execution time: 5.3293
DEBUG - 2014-01-14 12:14:48 --> Config Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:14:48 --> URI Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Router Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Output Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Security Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Input Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:14:48 --> Language Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Loader Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Controller Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:14:48 --> Model Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Model Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Model Class Initialized
DEBUG - 2014-01-14 12:14:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:14:48 --> Final output sent to browser
DEBUG - 2014-01-14 12:14:48 --> Total execution time: 0.0170
DEBUG - 2014-01-14 12:35:50 --> Config Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:35:50 --> URI Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Router Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Output Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Security Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Input Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:35:50 --> Language Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Loader Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Controller Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:35:50 --> Model Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Model Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:35:50 --> Final output sent to browser
DEBUG - 2014-01-14 12:35:50 --> Total execution time: 0.0150
DEBUG - 2014-01-14 12:37:01 --> Config Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:37:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:37:01 --> URI Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Router Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Output Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Security Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Input Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:37:01 --> Language Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Loader Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Controller Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:37:01 --> Model Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Model Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:37:01 --> Final output sent to browser
DEBUG - 2014-01-14 12:37:01 --> Total execution time: 0.0150
DEBUG - 2014-01-14 12:37:41 --> Config Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:37:41 --> URI Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Router Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Output Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Security Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Input Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:37:41 --> Language Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Loader Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Controller Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:37:41 --> Model Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Model Class Initialized
DEBUG - 2014-01-14 12:37:41 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:37:53 --> Final output sent to browser
DEBUG - 2014-01-14 12:37:53 --> Total execution time: 12.4807
DEBUG - 2014-01-14 12:38:49 --> Config Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:38:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:38:49 --> URI Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Router Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Output Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Security Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Input Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:38:49 --> Language Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Loader Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Controller Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:38:49 --> Model Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Model Class Initialized
DEBUG - 2014-01-14 12:38:49 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:38:51 --> Helper loaded: email_helper
DEBUG - 2014-01-14 12:38:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:38:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:38:52 --> Final output sent to browser
DEBUG - 2014-01-14 12:38:52 --> Total execution time: 3.2942
DEBUG - 2014-01-14 12:41:51 --> Config Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:41:51 --> URI Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Router Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Output Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Security Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Input Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:41:51 --> Language Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Loader Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Controller Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:41:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Helper loaded: email_helper
DEBUG - 2014-01-14 12:41:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:41:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:41:56 --> Final output sent to browser
DEBUG - 2014-01-14 12:41:56 --> Total execution time: 5.0723
DEBUG - 2014-01-14 12:42:51 --> Config Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:42:51 --> URI Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Router Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Output Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Security Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Input Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:42:51 --> Language Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Loader Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Controller Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:42:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Helper loaded: email_helper
DEBUG - 2014-01-14 12:42:51 --> Model Class Initialized
DEBUG - 2014-01-14 12:42:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:42:56 --> Final output sent to browser
DEBUG - 2014-01-14 12:42:56 --> Total execution time: 4.6703
DEBUG - 2014-01-14 12:54:24 --> Config Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Hooks Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Utf8 Class Initialized
DEBUG - 2014-01-14 12:54:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 12:54:24 --> URI Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Router Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Output Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Security Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Input Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 12:54:24 --> Language Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Loader Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Controller Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 12:54:24 --> Model Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Model Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Database Driver Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Helper loaded: email_helper
DEBUG - 2014-01-14 12:54:24 --> Model Class Initialized
DEBUG - 2014-01-14 12:54:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 12:54:28 --> Final output sent to browser
DEBUG - 2014-01-14 12:54:28 --> Total execution time: 4.6023
DEBUG - 2014-01-14 13:10:18 --> Config Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Hooks Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Utf8 Class Initialized
DEBUG - 2014-01-14 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 13:10:18 --> URI Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Router Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Output Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Security Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Input Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 13:10:18 --> Language Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Loader Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Controller Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 13:10:18 --> Model Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Model Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Database Driver Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Helper loaded: email_helper
DEBUG - 2014-01-14 13:10:18 --> Model Class Initialized
DEBUG - 2014-01-14 13:10:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 13:10:18 --> Final output sent to browser
DEBUG - 2014-01-14 13:10:18 --> Total execution time: 0.0180
DEBUG - 2014-01-14 13:10:23 --> Config Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Hooks Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Utf8 Class Initialized
DEBUG - 2014-01-14 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 13:10:23 --> URI Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Router Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Output Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Security Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Input Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 13:10:23 --> Language Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Loader Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Controller Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 13:10:23 --> Model Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Model Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Database Driver Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Helper loaded: email_helper
DEBUG - 2014-01-14 13:10:23 --> Model Class Initialized
DEBUG - 2014-01-14 13:10:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 13:10:29 --> Final output sent to browser
DEBUG - 2014-01-14 13:10:29 --> Total execution time: 6.5274
DEBUG - 2014-01-14 13:26:03 --> Config Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Hooks Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Utf8 Class Initialized
DEBUG - 2014-01-14 13:26:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 13:26:03 --> URI Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Router Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Output Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Security Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Input Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 13:26:03 --> Language Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Loader Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Controller Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 13:26:03 --> Model Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Model Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Database Driver Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Helper loaded: email_helper
DEBUG - 2014-01-14 13:26:03 --> Model Class Initialized
DEBUG - 2014-01-14 13:26:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 13:26:03 --> Final output sent to browser
DEBUG - 2014-01-14 13:26:03 --> Total execution time: 0.0120
DEBUG - 2014-01-14 13:26:08 --> Config Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Hooks Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Utf8 Class Initialized
DEBUG - 2014-01-14 13:26:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 13:26:08 --> URI Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Router Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Output Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Security Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Input Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 13:26:08 --> Language Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Loader Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Controller Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 13:26:08 --> Model Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Model Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Database Driver Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Helper loaded: email_helper
DEBUG - 2014-01-14 13:26:08 --> Model Class Initialized
DEBUG - 2014-01-14 13:26:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 13:26:12 --> Final output sent to browser
DEBUG - 2014-01-14 13:26:12 --> Total execution time: 4.6273
DEBUG - 2014-01-14 14:11:03 --> Config Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Hooks Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Utf8 Class Initialized
DEBUG - 2014-01-14 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 14:11:03 --> URI Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Router Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Output Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Security Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Input Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 14:11:03 --> Language Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Loader Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Controller Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 14:11:03 --> Model Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Model Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Database Driver Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Helper loaded: email_helper
DEBUG - 2014-01-14 14:11:03 --> Model Class Initialized
DEBUG - 2014-01-14 14:11:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 14:11:08 --> Final output sent to browser
DEBUG - 2014-01-14 14:11:08 --> Total execution time: 5.0953
DEBUG - 2014-01-14 16:26:54 --> Config Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Hooks Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Utf8 Class Initialized
DEBUG - 2014-01-14 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 16:26:54 --> URI Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Router Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Output Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Security Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Input Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 16:26:54 --> Language Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Loader Class Initialized
DEBUG - 2014-01-14 16:26:54 --> Controller Class Initialized
DEBUG - 2014-01-14 16:26:54 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-01-14 16:26:54 --> Final output sent to browser
DEBUG - 2014-01-14 16:26:54 --> Total execution time: 0.0110
DEBUG - 2014-01-14 16:27:11 --> Config Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Hooks Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Utf8 Class Initialized
DEBUG - 2014-01-14 16:27:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 16:27:11 --> URI Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Router Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Output Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Security Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Input Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 16:27:11 --> Language Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Loader Class Initialized
DEBUG - 2014-01-14 16:27:11 --> Controller Class Initialized
DEBUG - 2014-01-14 16:27:11 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-01-14 16:27:11 --> Final output sent to browser
DEBUG - 2014-01-14 16:27:11 --> Total execution time: 0.0100
DEBUG - 2014-01-14 16:57:45 --> Config Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Hooks Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Utf8 Class Initialized
DEBUG - 2014-01-14 16:57:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-14 16:57:45 --> URI Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Router Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Output Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Security Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Input Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-14 16:57:45 --> Language Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Loader Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Controller Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-14 16:57:45 --> Model Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Model Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Database Driver Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Helper loaded: email_helper
DEBUG - 2014-01-14 16:57:45 --> Model Class Initialized
DEBUG - 2014-01-14 16:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-14 16:57:45 --> Final output sent to browser
DEBUG - 2014-01-14 16:57:45 --> Total execution time: 0.0160
