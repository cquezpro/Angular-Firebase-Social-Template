<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-04-27 11:03:28 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-04-27 11:03:28 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-04-27 11:03:28 --> Config Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:03:28 --> URI Class Initialized
DEBUG - 2014-04-27 11:03:28 --> URI Class Initialized
DEBUG - 2014-04-27 11:03:28 --> URI Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Router Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Router Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Router Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Output Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Output Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Output Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Security Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Security Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Security Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Input Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Input Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Input Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:03:28 --> Language Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Language Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Language Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Loader Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Loader Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Loader Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Controller Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Controller Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Controller Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:03:28 --> Session Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Session Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Session Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: string_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: string_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: string_helper
DEBUG - 2014-04-27 11:03:28 --> A session cookie was not found.
DEBUG - 2014-04-27 11:03:28 --> A session cookie was not found.
DEBUG - 2014-04-27 11:03:28 --> A session cookie was not found.
DEBUG - 2014-04-27 11:03:28 --> Session routines successfully run
DEBUG - 2014-04-27 11:03:28 --> Session routines successfully run
DEBUG - 2014-04-27 11:03:28 --> Session routines successfully run
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: url_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: url_helper
DEBUG - 2014-04-27 11:03:28 --> Helper loaded: url_helper
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Model Class Initialized
DEBUG - 2014-04-27 11:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:03:28 --> Final output sent to browser
DEBUG - 2014-04-27 11:03:28 --> Final output sent to browser
DEBUG - 2014-04-27 11:03:28 --> Final output sent to browser
DEBUG - 2014-04-27 11:03:28 --> Total execution time: 0.7730
DEBUG - 2014-04-27 11:03:28 --> Total execution time: 0.7730
DEBUG - 2014-04-27 11:03:28 --> Total execution time: 0.7730
DEBUG - 2014-04-27 11:04:05 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:05 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:05 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:05 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:05 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Helper loaded: email_helper
DEBUG - 2014-04-27 11:04:05 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:06 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:06 --> Total execution time: 1.7951
DEBUG - 2014-04-27 11:04:11 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:11 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:11 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:11 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:11 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Image Lib Class Initialized
DEBUG - 2014-04-27 11:04:11 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:11 --> Total execution time: 0.2020
DEBUG - 2014-04-27 11:04:13 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:13 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:13 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:13 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:13 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:13 --> Image Lib Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:14 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:14 --> Total execution time: 0.9591
DEBUG - 2014-04-27 11:04:14 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:14 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:14 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:14 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:15 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:15 --> Total execution time: 1.1111
DEBUG - 2014-04-27 11:04:27 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Config Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:04:27 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:27 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:27 --> URI Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Router Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:27 --> Output Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Security Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Input Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:04:27 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Language Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:27 --> Loader Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:27 --> Controller Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:04:27 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:27 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Session Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: string_helper
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Session Class Initialized
DEBUG - 2014-04-27 11:04:27 --> A session cookie was not found.
DEBUG - 2014-04-27 11:04:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: string_helper
DEBUG - 2014-04-27 11:04:27 --> Session routines successfully run
DEBUG - 2014-04-27 11:04:27 --> A session cookie was not found.
DEBUG - 2014-04-27 11:04:27 --> Session Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: url_helper
DEBUG - 2014-04-27 11:04:27 --> Session routines successfully run
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: string_helper
DEBUG - 2014-04-27 11:04:27 --> A session cookie was not found.
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: url_helper
DEBUG - 2014-04-27 11:04:27 --> Session routines successfully run
DEBUG - 2014-04-27 11:04:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Helper loaded: url_helper
DEBUG - 2014-04-27 11:04:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:27 --> Model Class Initialized
DEBUG - 2014-04-27 11:04:27 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:04:27 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:27 --> Total execution time: 0.0140
DEBUG - 2014-04-27 11:04:27 --> Total execution time: 0.0140
DEBUG - 2014-04-27 11:04:27 --> Final output sent to browser
DEBUG - 2014-04-27 11:04:27 --> Total execution time: 0.0140
DEBUG - 2014-04-27 11:06:08 --> Config Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:06:08 --> URI Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Router Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Output Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Security Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Input Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:06:08 --> Language Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Loader Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Controller Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:06:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:06:08 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Helper loaded: email_helper
DEBUG - 2014-04-27 11:06:08 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:06:10 --> Final output sent to browser
DEBUG - 2014-04-27 11:06:10 --> Total execution time: 1.8031
DEBUG - 2014-04-27 11:06:14 --> Config Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:06:14 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:06:14 --> URI Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Router Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Output Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Security Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Input Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:06:14 --> Language Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Loader Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Controller Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:06:14 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:06:14 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Image Lib Class Initialized
DEBUG - 2014-04-27 11:06:14 --> Final output sent to browser
DEBUG - 2014-04-27 11:06:14 --> Total execution time: 0.1340
DEBUG - 2014-04-27 11:06:16 --> Config Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:06:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:06:16 --> URI Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Router Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Output Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Security Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Input Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:06:16 --> Language Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Loader Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Controller Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:06:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:06:16 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:06:16 --> Image Lib Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:06:17 --> Final output sent to browser
DEBUG - 2014-04-27 11:06:17 --> Total execution time: 0.9361
DEBUG - 2014-04-27 11:06:17 --> Config Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Hooks Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Utf8 Class Initialized
DEBUG - 2014-04-27 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 11:06:17 --> URI Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Router Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Output Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Security Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Input Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 11:06:17 --> Language Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Loader Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Controller Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 11:06:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 11:06:17 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Database Driver Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Model Class Initialized
DEBUG - 2014-04-27 11:06:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 11:06:18 --> Final output sent to browser
DEBUG - 2014-04-27 11:06:18 --> Total execution time: 0.9021
DEBUG - 2014-04-27 12:19:10 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:10 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:10 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:10 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:10 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:10 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:10 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:10 --> Session Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> A session cookie was not found.
DEBUG - 2014-04-27 12:19:10 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Session routines successfully run
DEBUG - 2014-04-27 12:19:10 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:19:10 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:10 --> Session Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Total execution time: 0.0210
DEBUG - 2014-04-27 12:19:10 --> A session cookie was not found.
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Session routines successfully run
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:10 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:10 --> Total execution time: 0.0250
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:10 --> Session Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:19:10 --> A session cookie was not found.
DEBUG - 2014-04-27 12:19:10 --> Session routines successfully run
DEBUG - 2014-04-27 12:19:10 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:19:10 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:10 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:10 --> Total execution time: 0.0320
DEBUG - 2014-04-27 12:19:12 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:12 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:12 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:12 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:12 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:12 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:12 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:12 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:12 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:12 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:12 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:12 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:12 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Session Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:19:12 --> A session cookie was not found.
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Session routines successfully run
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:12 --> Session Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Session Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:19:12 --> A session cookie was not found.
DEBUG - 2014-04-27 12:19:12 --> A session cookie was not found.
DEBUG - 2014-04-27 12:19:12 --> Session routines successfully run
DEBUG - 2014-04-27 12:19:12 --> Session routines successfully run
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:12 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:12 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:12 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:12 --> Total execution time: 0.0120
DEBUG - 2014-04-27 12:19:12 --> Total execution time: 0.0160
DEBUG - 2014-04-27 12:19:12 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:12 --> Total execution time: 0.0150
DEBUG - 2014-04-27 12:19:20 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:20 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:20 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:20 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:20 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:20 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:20 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:20 --> Total execution time: 0.0130
DEBUG - 2014-04-27 12:19:30 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:30 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:30 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:30 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:30 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:30 --> Total execution time: 0.0190
DEBUG - 2014-04-27 12:19:33 --> Config Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:19:33 --> URI Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Router Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Output Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Security Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Input Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:19:33 --> Language Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Loader Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Controller Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:19:33 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:19:33 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Model Class Initialized
DEBUG - 2014-04-27 12:19:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:19:33 --> Final output sent to browser
DEBUG - 2014-04-27 12:19:33 --> Total execution time: 0.0140
DEBUG - 2014-04-27 12:20:01 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:01 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:01 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:01 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:01 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:02 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:02 --> Total execution time: 0.9621
DEBUG - 2014-04-27 12:20:40 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:40 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:40 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:40 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:40 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:40 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:40 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:40 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:40 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Session Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:20:40 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:40 --> A session cookie was not found.
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Session routines successfully run
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:20:40 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:40 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:40 --> Total execution time: 0.0120
DEBUG - 2014-04-27 12:20:40 --> Session Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:20:40 --> A session cookie was not found.
DEBUG - 2014-04-27 12:20:40 --> Session routines successfully run
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:40 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:40 --> Total execution time: 0.0160
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:40 --> Session Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:20:40 --> A session cookie was not found.
DEBUG - 2014-04-27 12:20:40 --> Session routines successfully run
DEBUG - 2014-04-27 12:20:40 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:20:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:40 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:40 --> Total execution time: 0.0190
DEBUG - 2014-04-27 12:20:42 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:42 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:42 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:42 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Session Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:20:42 --> A session cookie was not found.
DEBUG - 2014-04-27 12:20:42 --> Session routines successfully run
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:42 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:42 --> Total execution time: 0.0100
DEBUG - 2014-04-27 12:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:42 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:42 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:42 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:42 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:42 --> Session Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:20:42 --> A session cookie was not found.
DEBUG - 2014-04-27 12:20:42 --> Session routines successfully run
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:42 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:42 --> Total execution time: 0.0230
DEBUG - 2014-04-27 12:20:42 --> Session Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:20:42 --> A session cookie was not found.
DEBUG - 2014-04-27 12:20:42 --> Session routines successfully run
DEBUG - 2014-04-27 12:20:42 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:20:42 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:42 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:42 --> Total execution time: 0.0280
DEBUG - 2014-04-27 12:20:48 --> Config Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:20:48 --> URI Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Router Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Output Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Security Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Input Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:20:48 --> Language Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Loader Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Controller Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:20:48 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:20:48 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Model Class Initialized
DEBUG - 2014-04-27 12:20:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:20:49 --> Final output sent to browser
DEBUG - 2014-04-27 12:20:49 --> Total execution time: 0.9501
DEBUG - 2014-04-27 12:21:39 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:39 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:39 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:39 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:39 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:39 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:39 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:39 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:39 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:39 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:39 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:39 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:39 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Total execution time: 0.0140
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:39 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:39 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:39 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:39 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:39 --> Total execution time: 0.0220
DEBUG - 2014-04-27 12:21:39 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:39 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:39 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:39 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:39 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:39 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:39 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:39 --> Total execution time: 0.0310
DEBUG - 2014-04-27 12:21:40 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:40 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:40 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:40 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:40 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:40 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:40 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:40 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:40 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:40 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:40 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:40 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:40 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:40 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Total execution time: 0.0120
DEBUG - 2014-04-27 12:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:40 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:40 --> Total execution time: 0.0130
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:40 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:40 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:40 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:40 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:40 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:40 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:40 --> Total execution time: 0.0190
DEBUG - 2014-04-27 12:21:55 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:55 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:55 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:55 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:55 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:55 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:55 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:55 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:55 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:55 --> Total execution time: 0.0100
DEBUG - 2014-04-27 12:21:55 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:55 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:55 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:55 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:55 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:55 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:55 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:55 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:55 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:55 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:55 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:55 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:55 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:55 --> Total execution time: 0.0310
DEBUG - 2014-04-27 12:21:55 --> Total execution time: 0.0160
DEBUG - 2014-04-27 12:21:56 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Config Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Hooks Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:56 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:56 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:56 --> Utf8 Class Initialized
DEBUG - 2014-04-27 12:21:56 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:56 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 12:21:56 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:56 --> URI Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Router Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Output Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Security Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Input Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 12:21:56 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Language Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Loader Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Controller Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Database Driver Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:56 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:56 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Session Class Initialized
DEBUG - 2014-04-27 12:21:56 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: string_helper
DEBUG - 2014-04-27 12:21:56 --> A session cookie was not found.
DEBUG - 2014-04-27 12:21:56 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:56 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:56 --> Total execution time: 0.0130
DEBUG - 2014-04-27 12:21:56 --> Session routines successfully run
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:56 --> Helper loaded: url_helper
DEBUG - 2014-04-27 12:21:56 --> Model Class Initialized
DEBUG - 2014-04-27 12:21:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 12:21:56 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:56 --> Total execution time: 0.0170
DEBUG - 2014-04-27 12:21:56 --> Final output sent to browser
DEBUG - 2014-04-27 12:21:56 --> Total execution time: 0.0200
DEBUG - 2014-04-27 15:56:23 --> Config Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Hooks Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Utf8 Class Initialized
DEBUG - 2014-04-27 15:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 15:56:23 --> Config Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Hooks Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Utf8 Class Initialized
DEBUG - 2014-04-27 15:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 15:56:23 --> URI Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Router Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Config Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Hooks Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Utf8 Class Initialized
DEBUG - 2014-04-27 15:56:23 --> URI Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Router Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Output Class Initialized
DEBUG - 2014-04-27 15:56:23 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 15:56:23 --> Output Class Initialized
DEBUG - 2014-04-27 15:56:23 --> URI Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Security Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Router Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Input Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 15:56:23 --> Output Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Security Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Security Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Input Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Input Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 15:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 15:56:23 --> Language Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Language Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Language Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Loader Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Loader Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Controller Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Loader Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Controller Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Controller Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Database Driver Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Database Driver Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:56:23 --> Session Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Database Driver Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: string_helper
DEBUG - 2014-04-27 15:56:23 --> A session cookie was not found.
DEBUG - 2014-04-27 15:56:23 --> Session routines successfully run
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: url_helper
DEBUG - 2014-04-27 15:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Session Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: string_helper
DEBUG - 2014-04-27 15:56:23 --> A session cookie was not found.
DEBUG - 2014-04-27 15:56:23 --> Session routines successfully run
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: url_helper
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:56:23 --> Final output sent to browser
DEBUG - 2014-04-27 15:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:56:23 --> Total execution time: 0.0140
DEBUG - 2014-04-27 15:56:23 --> Session Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Final output sent to browser
DEBUG - 2014-04-27 15:56:23 --> Total execution time: 0.0160
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: string_helper
DEBUG - 2014-04-27 15:56:23 --> A session cookie was not found.
DEBUG - 2014-04-27 15:56:23 --> Session routines successfully run
DEBUG - 2014-04-27 15:56:23 --> Helper loaded: url_helper
DEBUG - 2014-04-27 15:56:23 --> Model Class Initialized
DEBUG - 2014-04-27 15:56:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:56:23 --> Final output sent to browser
DEBUG - 2014-04-27 15:56:23 --> Total execution time: 0.0210
DEBUG - 2014-04-27 15:58:08 --> Config Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Hooks Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Utf8 Class Initialized
DEBUG - 2014-04-27 15:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 15:58:08 --> URI Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Router Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Output Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Security Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Input Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 15:58:08 --> Language Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Loader Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Controller Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Config Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Hooks Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Utf8 Class Initialized
DEBUG - 2014-04-27 15:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 15:58:08 --> URI Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Router Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Database Driver Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:58:08 --> Session Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: string_helper
DEBUG - 2014-04-27 15:58:08 --> A session cookie was not found.
DEBUG - 2014-04-27 15:58:08 --> Session routines successfully run
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: url_helper
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:58:08 --> Final output sent to browser
DEBUG - 2014-04-27 15:58:08 --> Total execution time: 0.0150
DEBUG - 2014-04-27 15:58:08 --> Output Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Security Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Input Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 15:58:08 --> Language Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Loader Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Controller Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Database Driver Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:58:08 --> Session Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: string_helper
DEBUG - 2014-04-27 15:58:08 --> A session cookie was not found.
DEBUG - 2014-04-27 15:58:08 --> Session routines successfully run
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: url_helper
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:58:08 --> Final output sent to browser
DEBUG - 2014-04-27 15:58:08 --> Total execution time: 0.0160
DEBUG - 2014-04-27 15:58:08 --> Config Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Hooks Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Utf8 Class Initialized
DEBUG - 2014-04-27 15:58:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-27 15:58:08 --> URI Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Router Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Output Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Security Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Input Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-27 15:58:08 --> Language Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Loader Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Controller Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Database Driver Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:58:08 --> Session Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: string_helper
DEBUG - 2014-04-27 15:58:08 --> A session cookie was not found.
DEBUG - 2014-04-27 15:58:08 --> Session routines successfully run
DEBUG - 2014-04-27 15:58:08 --> Helper loaded: url_helper
DEBUG - 2014-04-27 15:58:08 --> Model Class Initialized
DEBUG - 2014-04-27 15:58:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-27 15:58:08 --> Final output sent to browser
DEBUG - 2014-04-27 15:58:08 --> Total execution time: 0.0130
