<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-04-26 14:25:15 --> Config Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Config Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:25:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:25:15 --> URI Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Router Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:25:15 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:25:15 --> URI Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Router Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Output Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Output Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Security Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Security Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Input Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Input Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:25:15 --> Language Class Initialized
DEBUG - 2014-04-26 14:25:15 --> Language Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Loader Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Loader Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Controller Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Controller Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:25:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:25:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:25:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:25:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:25:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:25:17 --> Session Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Session Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:25:17 --> A session cookie was not found.
DEBUG - 2014-04-26 14:25:17 --> Session routines successfully run
DEBUG - 2014-04-26 14:25:17 --> A session cookie was not found.
DEBUG - 2014-04-26 14:25:17 --> Session routines successfully run
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:25:17 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:25:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:25:17 --> Final output sent to browser
DEBUG - 2014-04-26 14:25:17 --> Total execution time: 1.9381
DEBUG - 2014-04-26 14:25:17 --> Final output sent to browser
DEBUG - 2014-04-26 14:25:17 --> Total execution time: 1.9631
DEBUG - 2014-04-26 14:25:17 --> Config Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:25:17 --> URI Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Router Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Output Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Security Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Input Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:25:17 --> Language Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Loader Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Controller Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:25:17 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:25:17 --> Session Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:25:17 --> A session cookie was not found.
DEBUG - 2014-04-26 14:25:17 --> Session routines successfully run
DEBUG - 2014-04-26 14:25:17 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:25:17 --> Model Class Initialized
DEBUG - 2014-04-26 14:25:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:25:17 --> Final output sent to browser
DEBUG - 2014-04-26 14:25:17 --> Total execution time: 0.0280
DEBUG - 2014-04-26 14:26:30 --> Config Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Config Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Config Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:26:30 --> URI Class Initialized
DEBUG - 2014-04-26 14:26:30 --> URI Class Initialized
DEBUG - 2014-04-26 14:26:30 --> URI Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Router Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Router Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Router Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Output Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Output Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Security Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Security Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Input Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Input Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:26:30 --> Output Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Language Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Security Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Input Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:26:30 --> Loader Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Language Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Controller Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Language Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:26:30 --> Loader Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Loader Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Controller Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:26:30 --> Controller Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:26:30 --> Session Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:26:30 --> Session Class Initialized
DEBUG - 2014-04-26 14:26:30 --> A session cookie was not found.
DEBUG - 2014-04-26 14:26:30 --> Session routines successfully run
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:26:30 --> A session cookie was not found.
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Session routines successfully run
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:26:30 --> Final output sent to browser
DEBUG - 2014-04-26 14:26:30 --> Total execution time: 0.0160
DEBUG - 2014-04-26 14:26:30 --> Final output sent to browser
DEBUG - 2014-04-26 14:26:30 --> Total execution time: 0.0170
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:26:30 --> Session Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:26:30 --> A session cookie was not found.
DEBUG - 2014-04-26 14:26:30 --> Session routines successfully run
DEBUG - 2014-04-26 14:26:30 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:26:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:26:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:26:30 --> Final output sent to browser
DEBUG - 2014-04-26 14:26:30 --> Total execution time: 0.0250
DEBUG - 2014-04-26 14:39:08 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:08 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:08 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:08 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:08 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Session Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:39:08 --> A session cookie was not found.
DEBUG - 2014-04-26 14:39:08 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Session routines successfully run
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:08 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:08 --> Total execution time: 0.0130
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:08 --> Session Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:39:08 --> A session cookie was not found.
DEBUG - 2014-04-26 14:39:08 --> Session routines successfully run
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:08 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:08 --> Total execution time: 0.0250
DEBUG - 2014-04-26 14:39:08 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:08 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:08 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:08 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:08 --> Session Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:39:08 --> A session cookie was not found.
DEBUG - 2014-04-26 14:39:08 --> Session routines successfully run
DEBUG - 2014-04-26 14:39:08 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:39:08 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:08 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:08 --> Total execution time: 0.0530
DEBUG - 2014-04-26 14:39:16 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:16 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:16 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:16 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:16 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:16 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Session Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:39:16 --> A session cookie was not found.
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Session routines successfully run
DEBUG - 2014-04-26 14:39:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:39:16 --> Session Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:39:16 --> A session cookie was not found.
DEBUG - 2014-04-26 14:39:16 --> Session routines successfully run
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:16 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:16 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:16 --> Total execution time: 0.0150
DEBUG - 2014-04-26 14:39:16 --> Total execution time: 0.0150
DEBUG - 2014-04-26 14:39:16 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:16 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:16 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:16 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:16 --> Session Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:39:16 --> A session cookie was not found.
DEBUG - 2014-04-26 14:39:16 --> Session routines successfully run
DEBUG - 2014-04-26 14:39:16 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:39:16 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:16 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:16 --> Total execution time: 0.0120
DEBUG - 2014-04-26 14:39:29 --> Config Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:39:29 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:39:29 --> URI Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Router Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Output Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Security Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Input Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:39:29 --> Language Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Loader Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Controller Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:39:29 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:39:29 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:29 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:39:30 --> Model Class Initialized
DEBUG - 2014-04-26 14:39:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:39:30 --> Final output sent to browser
DEBUG - 2014-04-26 14:39:30 --> Total execution time: 0.6840
DEBUG - 2014-04-26 14:40:42 --> Config Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:40:42 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:40:42 --> URI Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Router Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Output Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Security Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Input Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:40:42 --> Language Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Loader Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Controller Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:40:42 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:40:42 --> Model Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Model Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Helper loaded: email_helper
DEBUG - 2014-04-26 14:40:42 --> Model Class Initialized
DEBUG - 2014-04-26 14:40:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:40:45 --> Final output sent to browser
DEBUG - 2014-04-26 14:40:45 --> Total execution time: 3.1072
DEBUG - 2014-04-26 14:41:36 --> Config Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Config Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:41:36 --> URI Class Initialized
DEBUG - 2014-04-26 14:41:36 --> URI Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Router Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Router Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Output Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Output Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Security Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Security Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Input Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Input Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:41:36 --> Language Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:41:36 --> Language Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Loader Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Loader Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Controller Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Controller Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:36 --> Session Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Session Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:41:36 --> A session cookie was not found.
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:41:36 --> Session routines successfully run
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:41:36 --> A session cookie was not found.
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:36 --> Session routines successfully run
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:41:36 --> Final output sent to browser
DEBUG - 2014-04-26 14:41:36 --> Total execution time: 0.0170
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:36 --> Final output sent to browser
DEBUG - 2014-04-26 14:41:36 --> Total execution time: 0.0180
DEBUG - 2014-04-26 14:41:36 --> Config Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:41:36 --> URI Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Router Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Output Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Security Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Input Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:41:36 --> Language Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Loader Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Controller Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:36 --> Session Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: string_helper
DEBUG - 2014-04-26 14:41:36 --> A session cookie was not found.
DEBUG - 2014-04-26 14:41:36 --> Session routines successfully run
DEBUG - 2014-04-26 14:41:36 --> Helper loaded: url_helper
DEBUG - 2014-04-26 14:41:36 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:36 --> Final output sent to browser
DEBUG - 2014-04-26 14:41:36 --> Total execution time: 0.0750
DEBUG - 2014-04-26 14:41:49 --> Config Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Hooks Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Utf8 Class Initialized
DEBUG - 2014-04-26 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2014-04-26 14:41:49 --> URI Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Router Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Output Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Security Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Input Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-04-26 14:41:49 --> Language Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Loader Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Controller Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-04-26 14:41:49 --> Helper loaded: utilities_helper
DEBUG - 2014-04-26 14:41:49 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Database Driver Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Model Class Initialized
DEBUG - 2014-04-26 14:41:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-04-26 14:41:51 --> Final output sent to browser
DEBUG - 2014-04-26 14:41:51 --> Total execution time: 1.4081
