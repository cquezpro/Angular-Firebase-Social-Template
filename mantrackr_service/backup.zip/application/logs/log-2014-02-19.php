<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-19 05:35:38 --> Config Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 05:35:38 --> URI Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Router Class Initialized
DEBUG - 2014-02-19 05:35:38 --> No URI present. Default controller set.
DEBUG - 2014-02-19 05:35:38 --> Output Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Security Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Input Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 05:35:38 --> Language Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Loader Class Initialized
DEBUG - 2014-02-19 05:35:38 --> Controller Class Initialized
DEBUG - 2014-02-19 05:35:38 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-02-19 05:35:38 --> Final output sent to browser
DEBUG - 2014-02-19 05:35:38 --> Total execution time: 0.0070
DEBUG - 2014-02-19 05:35:45 --> Config Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 05:35:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 05:35:45 --> URI Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Router Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Output Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Security Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Input Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 05:35:45 --> Language Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Loader Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Controller Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 05:35:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 05:35:45 --> Model Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Model Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 05:35:45 --> Final output sent to browser
DEBUG - 2014-02-19 05:35:45 --> Total execution time: 0.0490
DEBUG - 2014-02-19 06:25:00 --> Config Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:25:00 --> URI Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Router Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Output Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Security Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Input Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:25:00 --> Language Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Loader Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Controller Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:25:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:25:00 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Database Driver Class Initialized
ERROR - 2014-02-19 06:25:00 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-19 06:25:00 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:25:00 --> Session Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:25:00 --> A session cookie was not found.
DEBUG - 2014-02-19 06:25:00 --> Session routines successfully run
DEBUG - 2014-02-19 06:25:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:25:00 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:25:00 --> Final output sent to browser
DEBUG - 2014-02-19 06:25:00 --> Total execution time: 0.4850
DEBUG - 2014-02-19 06:25:06 --> Config Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:25:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:25:06 --> URI Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Router Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Output Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Security Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Input Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:25:06 --> Language Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Loader Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Controller Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:25:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:25:06 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:25:06 --> Session Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:25:06 --> Session routines successfully run
DEBUG - 2014-02-19 06:25:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:25:06 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:25:06 --> Final output sent to browser
DEBUG - 2014-02-19 06:25:06 --> Total execution time: 0.0170
DEBUG - 2014-02-19 06:25:26 --> Config Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:25:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:25:26 --> URI Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Router Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Output Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Security Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Input Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:25:26 --> Language Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Loader Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Controller Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:25:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:25:26 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:25:26 --> Session Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:25:26 --> Session routines successfully run
DEBUG - 2014-02-19 06:25:26 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:25:26 --> Model Class Initialized
DEBUG - 2014-02-19 06:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:25:26 --> Final output sent to browser
DEBUG - 2014-02-19 06:25:26 --> Total execution time: 0.0210
DEBUG - 2014-02-19 06:29:08 --> Config Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:29:08 --> URI Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Router Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Output Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Security Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Input Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:29:08 --> Language Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Loader Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Controller Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:29:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:29:08 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:29:08 --> Session Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:29:08 --> Session routines successfully run
DEBUG - 2014-02-19 06:29:08 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:29:08 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:29:08 --> Final output sent to browser
DEBUG - 2014-02-19 06:29:08 --> Total execution time: 0.0210
DEBUG - 2014-02-19 06:29:23 --> Config Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:29:23 --> URI Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Router Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Output Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Security Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Input Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:29:23 --> Language Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Loader Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Controller Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:29:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:29:23 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:29:23 --> Session Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:29:23 --> Session routines successfully run
DEBUG - 2014-02-19 06:29:23 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:29:23 --> Model Class Initialized
DEBUG - 2014-02-19 06:29:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:29:23 --> Final output sent to browser
DEBUG - 2014-02-19 06:29:23 --> Total execution time: 0.0170
DEBUG - 2014-02-19 06:30:52 --> Config Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:30:52 --> URI Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Router Class Initialized
DEBUG - 2014-02-19 06:30:52 --> No URI present. Default controller set.
DEBUG - 2014-02-19 06:30:52 --> Output Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Security Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Input Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:30:52 --> Language Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Loader Class Initialized
DEBUG - 2014-02-19 06:30:52 --> Controller Class Initialized
DEBUG - 2014-02-19 06:30:52 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-02-19 06:30:52 --> Final output sent to browser
DEBUG - 2014-02-19 06:30:52 --> Total execution time: 0.0110
DEBUG - 2014-02-19 06:30:58 --> Config Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:30:58 --> URI Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Router Class Initialized
DEBUG - 2014-02-19 06:30:58 --> No URI present. Default controller set.
DEBUG - 2014-02-19 06:30:58 --> Output Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Security Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Input Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:30:58 --> Language Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Loader Class Initialized
DEBUG - 2014-02-19 06:30:58 --> Controller Class Initialized
DEBUG - 2014-02-19 06:30:58 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-02-19 06:30:58 --> Final output sent to browser
DEBUG - 2014-02-19 06:30:58 --> Total execution time: 0.0100
DEBUG - 2014-02-19 06:31:00 --> Config Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:31:00 --> URI Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Router Class Initialized
DEBUG - 2014-02-19 06:31:00 --> No URI present. Default controller set.
DEBUG - 2014-02-19 06:31:00 --> Output Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Security Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Input Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:31:00 --> Language Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Loader Class Initialized
DEBUG - 2014-02-19 06:31:00 --> Controller Class Initialized
DEBUG - 2014-02-19 06:31:00 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-02-19 06:31:00 --> Final output sent to browser
DEBUG - 2014-02-19 06:31:00 --> Total execution time: 0.0050
DEBUG - 2014-02-19 06:46:36 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:36 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:36 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:36 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:36 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:36 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:36 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:36 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:36 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:36 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:36 --> Total execution time: 0.0200
DEBUG - 2014-02-19 06:46:41 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:41 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:41 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:41 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:41 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:41 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:41 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:41 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:41 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:41 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:41 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:41 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:41 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:41 --> Total execution time: 0.0230
DEBUG - 2014-02-19 06:46:41 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:41 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:41 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:41 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:41 --> Total execution time: 0.0200
DEBUG - 2014-02-19 06:46:45 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:45 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:45 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:45 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:45 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:45 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:45 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:45 --> Total execution time: 0.0180
DEBUG - 2014-02-19 06:46:50 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:50 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:50 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:50 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:50 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:50 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:50 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:50 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:50 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:50 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:50 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:50 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:50 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:50 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:50 --> Total execution time: 0.0110
DEBUG - 2014-02-19 06:46:50 --> Total execution time: 0.0120
DEBUG - 2014-02-19 06:46:54 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:54 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:54 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:54 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:54 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:54 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:54 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:54 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:54 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:54 --> Total execution time: 0.0190
DEBUG - 2014-02-19 06:46:59 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:59 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Config Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:46:59 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:59 --> URI Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Router Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Output Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:59 --> Security Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:59 --> Input Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Language Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Loader Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Controller Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:59 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:59 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:59 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:59 --> Session Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:46:59 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:59 --> A session cookie was not found.
DEBUG - 2014-02-19 06:46:59 --> Total execution time: 0.0220
DEBUG - 2014-02-19 06:46:59 --> Session routines successfully run
DEBUG - 2014-02-19 06:46:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:46:59 --> Model Class Initialized
DEBUG - 2014-02-19 06:46:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:46:59 --> Final output sent to browser
DEBUG - 2014-02-19 06:46:59 --> Total execution time: 0.0190
DEBUG - 2014-02-19 06:52:22 --> Config Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:52:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:52:22 --> URI Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Router Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Output Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Security Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Input Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:52:22 --> Language Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Loader Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Controller Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:52:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:52:22 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:22 --> Session Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:52:22 --> A session cookie was not found.
DEBUG - 2014-02-19 06:52:22 --> Session routines successfully run
DEBUG - 2014-02-19 06:52:22 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:52:22 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:22 --> Final output sent to browser
DEBUG - 2014-02-19 06:52:22 --> Total execution time: 0.0160
DEBUG - 2014-02-19 06:52:27 --> Config Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:52:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:52:27 --> Config Class Initialized
DEBUG - 2014-02-19 06:52:27 --> URI Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Router Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:52:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:52:27 --> URI Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Output Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Router Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Security Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Output Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Input Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:52:27 --> Security Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Language Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Input Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:52:27 --> Language Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Loader Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Controller Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Loader Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Controller Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:27 --> Session Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Session Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 06:52:27 --> A session cookie was not found.
DEBUG - 2014-02-19 06:52:27 --> A session cookie was not found.
DEBUG - 2014-02-19 06:52:27 --> Session routines successfully run
DEBUG - 2014-02-19 06:52:27 --> Session routines successfully run
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:52:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:27 --> Final output sent to browser
DEBUG - 2014-02-19 06:52:27 --> Final output sent to browser
DEBUG - 2014-02-19 06:52:27 --> Total execution time: 0.0220
DEBUG - 2014-02-19 06:52:27 --> Total execution time: 0.0240
DEBUG - 2014-02-19 06:52:48 --> Config Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 06:52:48 --> URI Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Router Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Output Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Security Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Input Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 06:52:48 --> Language Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Loader Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Controller Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 06:52:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 06:52:48 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Model Class Initialized
DEBUG - 2014-02-19 06:52:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 06:52:48 --> Final output sent to browser
DEBUG - 2014-02-19 06:52:48 --> Total execution time: 0.0560
DEBUG - 2014-02-19 07:26:19 --> Config Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:26:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:26:19 --> URI Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Router Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Output Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Security Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Input Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:26:19 --> Language Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Loader Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Controller Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:26:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:26:19 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:26:19 --> Session Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:26:19 --> A session cookie was not found.
DEBUG - 2014-02-19 07:26:19 --> Session routines successfully run
DEBUG - 2014-02-19 07:26:19 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:26:19 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:26:19 --> Final output sent to browser
DEBUG - 2014-02-19 07:26:19 --> Total execution time: 0.0240
DEBUG - 2014-02-19 07:26:24 --> Config Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:26:24 --> URI Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Router Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Output Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Security Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Input Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Config Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:26:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Language Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:26:24 --> Loader Class Initialized
DEBUG - 2014-02-19 07:26:24 --> URI Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Router Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Controller Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:26:24 --> Output Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:26:24 --> Security Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Input Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:26:24 --> Language Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Loader Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Controller Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Session Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:26:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:26:24 --> A session cookie was not found.
DEBUG - 2014-02-19 07:26:24 --> Session routines successfully run
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:26:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:26:24 --> Session Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:26:24 --> Final output sent to browser
DEBUG - 2014-02-19 07:26:24 --> A session cookie was not found.
DEBUG - 2014-02-19 07:26:24 --> Total execution time: 0.0190
DEBUG - 2014-02-19 07:26:24 --> Session routines successfully run
DEBUG - 2014-02-19 07:26:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:26:24 --> Model Class Initialized
DEBUG - 2014-02-19 07:26:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:26:24 --> Final output sent to browser
DEBUG - 2014-02-19 07:26:24 --> Total execution time: 0.0170
DEBUG - 2014-02-19 07:40:34 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:34 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:34 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:34 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:34 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:34 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:34 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:34 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:34 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:34 --> Total execution time: 0.0200
DEBUG - 2014-02-19 07:40:35 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:35 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:35 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:35 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:35 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:35 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:35 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:35 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:35 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Total execution time: 0.0180
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:35 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:35 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:35 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:35 --> Total execution time: 0.0170
DEBUG - 2014-02-19 07:40:35 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:35 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:35 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:35 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:35 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:35 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:35 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:35 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:35 --> Total execution time: 0.0120
DEBUG - 2014-02-19 07:40:38 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:38 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:38 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:38 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:38 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:38 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:38 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:38 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:38 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:38 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:38 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:38 --> Total execution time: 0.0210
DEBUG - 2014-02-19 07:40:38 --> Total execution time: 0.0210
DEBUG - 2014-02-19 07:40:38 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:38 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:38 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:38 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:38 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:38 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:38 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:38 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:38 --> Total execution time: 0.0140
DEBUG - 2014-02-19 07:40:39 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:39 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:39 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:39 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:39 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:39 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:39 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:39 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:39 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:39 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:39 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:39 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:39 --> Total execution time: 0.0120
DEBUG - 2014-02-19 07:40:39 --> Total execution time: 0.0120
DEBUG - 2014-02-19 07:40:40 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:40 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:40 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:40 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:40 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:40 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:40 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:40 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:40 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:40 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:40 --> Total execution time: 0.0160
DEBUG - 2014-02-19 07:40:45 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:45 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:45 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Config Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:40:45 --> URI Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Router Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Output Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:45 --> Security Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Input Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:45 --> Language Class Initialized
DEBUG - 2014-02-19 07:40:45 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:45 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:45 --> Loader Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Controller Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:45 --> Total execution time: 0.0190
DEBUG - 2014-02-19 07:40:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:45 --> Session Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:40:45 --> A session cookie was not found.
DEBUG - 2014-02-19 07:40:45 --> Session routines successfully run
DEBUG - 2014-02-19 07:40:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 07:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:40:45 --> Final output sent to browser
DEBUG - 2014-02-19 07:40:45 --> Total execution time: 0.0170
DEBUG - 2014-02-19 07:41:14 --> Config Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:41:14 --> URI Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Router Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Output Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Security Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Input Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:41:14 --> Language Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Loader Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Controller Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:41:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:41:14 --> Model Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Model Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:41:14 --> Model Class Initialized
DEBUG - 2014-02-19 07:41:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:41:23 --> Final output sent to browser
DEBUG - 2014-02-19 07:41:23 --> Total execution time: 8.3615
DEBUG - 2014-02-19 07:43:27 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:27 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:27 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:27 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:27 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:27 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:27 --> Session Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:43:27 --> A session cookie was not found.
DEBUG - 2014-02-19 07:43:27 --> Session routines successfully run
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:27 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:27 --> Total execution time: 0.0230
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:27 --> Session Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:43:27 --> A session cookie was not found.
DEBUG - 2014-02-19 07:43:27 --> Session routines successfully run
DEBUG - 2014-02-19 07:43:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:27 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:27 --> Total execution time: 0.0320
DEBUG - 2014-02-19 07:43:28 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:28 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:28 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:28 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:28 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:28 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:28 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:28 --> Session Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:28 --> A session cookie was not found.
DEBUG - 2014-02-19 07:43:28 --> Session routines successfully run
DEBUG - 2014-02-19 07:43:28 --> Session Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:43:28 --> A session cookie was not found.
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Session routines successfully run
DEBUG - 2014-02-19 07:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:43:28 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:28 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:28 --> Total execution time: 0.0200
DEBUG - 2014-02-19 07:43:28 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:28 --> Total execution time: 0.0190
DEBUG - 2014-02-19 07:43:32 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:32 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:32 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:32 --> Session Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:43:32 --> A session cookie was not found.
DEBUG - 2014-02-19 07:43:32 --> Session routines successfully run
DEBUG - 2014-02-19 07:43:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:32 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:32 --> Total execution time: 0.0190
DEBUG - 2014-02-19 07:43:33 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:33 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:33 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:33 --> Session Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:43:33 --> A session cookie was not found.
DEBUG - 2014-02-19 07:43:33 --> Session routines successfully run
DEBUG - 2014-02-19 07:43:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:33 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:33 --> Total execution time: 0.0170
DEBUG - 2014-02-19 07:43:44 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:44 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:44 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:44 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:43:44 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:44 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:44 --> Total execution time: 0.0120
DEBUG - 2014-02-19 07:43:47 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:47 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:47 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:47 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:43:47 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:47 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:47 --> Total execution time: 0.0180
DEBUG - 2014-02-19 07:43:49 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:49 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:49 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:49 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:43:49 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:49 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:49 --> Total execution time: 0.0130
DEBUG - 2014-02-19 07:43:56 --> Config Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:43:56 --> URI Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Router Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Output Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Security Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Input Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:43:56 --> Language Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Loader Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Controller Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:43:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:43:56 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:43:56 --> Model Class Initialized
DEBUG - 2014-02-19 07:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:43:56 --> Final output sent to browser
DEBUG - 2014-02-19 07:43:56 --> Total execution time: 0.0150
DEBUG - 2014-02-19 07:44:20 --> Config Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:44:20 --> URI Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Router Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Output Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Security Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Input Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:44:20 --> Language Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Loader Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Controller Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:44:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:44:20 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:44:20 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:44:24 --> Final output sent to browser
DEBUG - 2014-02-19 07:44:24 --> Total execution time: 4.6923
DEBUG - 2014-02-19 07:44:59 --> Config Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Config Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:44:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:44:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:44:59 --> URI Class Initialized
DEBUG - 2014-02-19 07:44:59 --> URI Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Router Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Router Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Output Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Output Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Security Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Security Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Input Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Input Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:44:59 --> Language Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Language Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Loader Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Loader Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Controller Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Controller Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:44:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:44:59 --> Session Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Session Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:44:59 --> A session cookie was not found.
DEBUG - 2014-02-19 07:44:59 --> A session cookie was not found.
DEBUG - 2014-02-19 07:44:59 --> Session routines successfully run
DEBUG - 2014-02-19 07:44:59 --> Session routines successfully run
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:44:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Model Class Initialized
DEBUG - 2014-02-19 07:44:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:44:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:44:59 --> Final output sent to browser
DEBUG - 2014-02-19 07:44:59 --> Final output sent to browser
DEBUG - 2014-02-19 07:44:59 --> Total execution time: 0.0220
DEBUG - 2014-02-19 07:44:59 --> Total execution time: 0.0220
DEBUG - 2014-02-19 07:45:04 --> Config Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:45:04 --> URI Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Router Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Output Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Security Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Input Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:45:04 --> Language Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Loader Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Controller Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:45:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:45:04 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:45:04 --> Session Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:45:04 --> A session cookie was not found.
DEBUG - 2014-02-19 07:45:04 --> Session routines successfully run
DEBUG - 2014-02-19 07:45:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:45:04 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:45:04 --> Final output sent to browser
DEBUG - 2014-02-19 07:45:04 --> Total execution time: 0.0110
DEBUG - 2014-02-19 07:45:18 --> Config Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:45:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:45:18 --> URI Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Router Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Output Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Security Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Input Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:45:18 --> Language Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Loader Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Controller Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:45:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:45:18 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Helper loaded: email_helper
DEBUG - 2014-02-19 07:45:18 --> Model Class Initialized
DEBUG - 2014-02-19 07:45:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:45:23 --> Final output sent to browser
DEBUG - 2014-02-19 07:45:23 --> Total execution time: 4.6523
DEBUG - 2014-02-19 07:49:42 --> Config Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:49:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:49:42 --> URI Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Router Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Output Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Security Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Input Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:49:42 --> Language Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Loader Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Controller Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:49:42 --> Model Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Model Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Model Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:49:42 --> Session Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:49:42 --> Session routines successfully run
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:49:42 --> Config Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 07:49:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 07:49:42 --> URI Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Router Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Output Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Security Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Input Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 07:49:42 --> Language Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Loader Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Controller Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 07:49:42 --> Model Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Model Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Model Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 07:49:42 --> Session Class Initialized
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 07:49:42 --> Session routines successfully run
DEBUG - 2014-02-19 07:49:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 07:49:42 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-19 07:49:42 --> Final output sent to browser
DEBUG - 2014-02-19 07:49:42 --> Total execution time: 0.0100
DEBUG - 2014-02-19 10:19:09 --> Config Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Config Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Config Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:19:09 --> URI Class Initialized
DEBUG - 2014-02-19 10:19:09 --> URI Class Initialized
DEBUG - 2014-02-19 10:19:09 --> URI Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Router Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Router Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Router Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Output Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Output Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Output Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Security Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Security Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Security Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Input Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Input Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Input Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:19:09 --> Language Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Language Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Language Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Loader Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Loader Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Loader Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Controller Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Controller Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Controller Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:09 --> Session Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Session Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Session Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:19:09 --> A session cookie was not found.
DEBUG - 2014-02-19 10:19:09 --> A session cookie was not found.
DEBUG - 2014-02-19 10:19:09 --> A session cookie was not found.
DEBUG - 2014-02-19 10:19:09 --> Session routines successfully run
DEBUG - 2014-02-19 10:19:09 --> Session routines successfully run
DEBUG - 2014-02-19 10:19:09 --> Session routines successfully run
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:19:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:09 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:09 --> Final output sent to browser
DEBUG - 2014-02-19 10:19:09 --> Final output sent to browser
DEBUG - 2014-02-19 10:19:09 --> Final output sent to browser
DEBUG - 2014-02-19 10:19:09 --> Total execution time: 0.0260
DEBUG - 2014-02-19 10:19:09 --> Total execution time: 0.0250
DEBUG - 2014-02-19 10:19:09 --> Total execution time: 0.0250
DEBUG - 2014-02-19 10:19:29 --> Config Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:19:29 --> URI Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Router Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Output Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Security Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Input Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:19:29 --> Language Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Loader Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Controller Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:19:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:19:29 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Helper loaded: email_helper
DEBUG - 2014-02-19 10:19:29 --> Model Class Initialized
DEBUG - 2014-02-19 10:19:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:19:35 --> Final output sent to browser
DEBUG - 2014-02-19 10:19:35 --> Total execution time: 6.1754
DEBUG - 2014-02-19 10:25:34 --> Config Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:25:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:25:34 --> URI Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Router Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Output Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Security Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Input Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:25:34 --> Language Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Loader Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Controller Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:25:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:25:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:25:34 --> Session Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:25:34 --> A session cookie was not found.
DEBUG - 2014-02-19 10:25:34 --> Session routines successfully run
DEBUG - 2014-02-19 10:25:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:25:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:25:34 --> Final output sent to browser
DEBUG - 2014-02-19 10:25:34 --> Total execution time: 0.0210
DEBUG - 2014-02-19 10:25:39 --> Config Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Config Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:25:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:25:39 --> URI Class Initialized
DEBUG - 2014-02-19 10:25:39 --> URI Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Router Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Router Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Output Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Output Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Security Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Security Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Input Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Input Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:25:39 --> Language Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Language Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Loader Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Loader Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Controller Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Controller Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:25:39 --> Session Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Session Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:25:39 --> A session cookie was not found.
DEBUG - 2014-02-19 10:25:39 --> A session cookie was not found.
DEBUG - 2014-02-19 10:25:39 --> Session routines successfully run
DEBUG - 2014-02-19 10:25:39 --> Session routines successfully run
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:25:39 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Model Class Initialized
DEBUG - 2014-02-19 10:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:25:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:25:39 --> Final output sent to browser
DEBUG - 2014-02-19 10:25:39 --> Final output sent to browser
DEBUG - 2014-02-19 10:25:39 --> Total execution time: 0.0210
DEBUG - 2014-02-19 10:25:39 --> Total execution time: 0.0210
DEBUG - 2014-02-19 10:26:06 --> Config Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:26:06 --> URI Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Router Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Output Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Security Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Input Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:26:06 --> Language Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Loader Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Controller Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:26:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:26:06 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:26:06 --> Session Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:26:06 --> A session cookie was not found.
DEBUG - 2014-02-19 10:26:06 --> Session routines successfully run
DEBUG - 2014-02-19 10:26:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:26:06 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:26:06 --> Final output sent to browser
DEBUG - 2014-02-19 10:26:06 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:26:11 --> Config Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Config Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:26:11 --> URI Class Initialized
DEBUG - 2014-02-19 10:26:11 --> URI Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Router Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Router Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Output Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Output Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Security Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Security Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Input Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Input Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:26:11 --> Language Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Language Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Loader Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Loader Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Controller Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Controller Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:26:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:26:11 --> Session Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Session Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:26:11 --> A session cookie was not found.
DEBUG - 2014-02-19 10:26:11 --> A session cookie was not found.
DEBUG - 2014-02-19 10:26:11 --> Session routines successfully run
DEBUG - 2014-02-19 10:26:11 --> Session routines successfully run
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:26:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:26:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:26:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:26:11 --> Final output sent to browser
DEBUG - 2014-02-19 10:26:11 --> Final output sent to browser
DEBUG - 2014-02-19 10:26:11 --> Total execution time: 0.0210
DEBUG - 2014-02-19 10:26:11 --> Total execution time: 0.0210
DEBUG - 2014-02-19 10:27:32 --> Config Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Config Class Initialized
DEBUG - 2014-02-19 10:27:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:27:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:27:32 --> URI Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:27:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:27:32 --> Router Class Initialized
DEBUG - 2014-02-19 10:27:32 --> URI Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Router Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Output Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Output Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Security Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Input Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Security Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:27:32 --> Input Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Language Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:27:32 --> Language Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Loader Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Controller Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Loader Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Controller Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:32 --> Session Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:27:32 --> Session Class Initialized
DEBUG - 2014-02-19 10:27:32 --> A session cookie was not found.
DEBUG - 2014-02-19 10:27:32 --> Session routines successfully run
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:27:32 --> A session cookie was not found.
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:27:32 --> Session routines successfully run
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:27:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:32 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:32 --> Final output sent to browser
DEBUG - 2014-02-19 10:27:32 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:27:32 --> Final output sent to browser
DEBUG - 2014-02-19 10:27:32 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:27:34 --> Config Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:27:34 --> URI Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Config Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Router Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Output Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Config Class Initialized
DEBUG - 2014-02-19 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:27:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Security Class Initialized
DEBUG - 2014-02-19 10:27:34 --> URI Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Input Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Router Class Initialized
DEBUG - 2014-02-19 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:27:34 --> URI Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Language Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Router Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Output Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Loader Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Controller Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Security Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Output Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Input Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:27:34 --> Security Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:27:34 --> Language Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Loader Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Input Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Controller Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:27:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Language Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:27:34 --> Loader Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Controller Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:27:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:27:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Session Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:27:34 --> A session cookie was not found.
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Session routines successfully run
DEBUG - 2014-02-19 10:27:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:27:34 --> Session Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:27:34 --> A session cookie was not found.
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Session routines successfully run
DEBUG - 2014-02-19 10:27:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:27:34 --> Session Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Final output sent to browser
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:27:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:34 --> A session cookie was not found.
DEBUG - 2014-02-19 10:27:34 --> Session routines successfully run
DEBUG - 2014-02-19 10:27:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:27:34 --> Final output sent to browser
DEBUG - 2014-02-19 10:27:34 --> Total execution time: 0.0180
DEBUG - 2014-02-19 10:27:34 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:34 --> Final output sent to browser
DEBUG - 2014-02-19 10:27:34 --> Total execution time: 0.0180
DEBUG - 2014-02-19 10:27:37 --> Config Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:27:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:27:37 --> URI Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Router Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Output Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Security Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Input Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:27:37 --> Language Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Loader Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Controller Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:27:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:27:37 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:37 --> Session Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:27:37 --> A session cookie was not found.
DEBUG - 2014-02-19 10:27:37 --> Session routines successfully run
DEBUG - 2014-02-19 10:27:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:27:37 --> Model Class Initialized
DEBUG - 2014-02-19 10:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:27:37 --> Final output sent to browser
DEBUG - 2014-02-19 10:27:37 --> Total execution time: 0.0190
DEBUG - 2014-02-19 10:29:42 --> Config Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Config Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:29:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:29:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:29:42 --> URI Class Initialized
DEBUG - 2014-02-19 10:29:42 --> URI Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Router Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Router Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Output Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Output Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Security Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Security Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Input Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Input Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:29:42 --> Language Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Language Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Loader Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Loader Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Controller Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Controller Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:29:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:29:42 --> Session Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Session Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:29:42 --> A session cookie was not found.
DEBUG - 2014-02-19 10:29:42 --> A session cookie was not found.
DEBUG - 2014-02-19 10:29:42 --> Session routines successfully run
DEBUG - 2014-02-19 10:29:42 --> Session routines successfully run
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:29:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:29:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:29:42 --> Final output sent to browser
DEBUG - 2014-02-19 10:29:42 --> Final output sent to browser
DEBUG - 2014-02-19 10:29:42 --> Total execution time: 0.0250
DEBUG - 2014-02-19 10:29:42 --> Total execution time: 0.0250
DEBUG - 2014-02-19 10:29:47 --> Config Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:29:47 --> URI Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Router Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Output Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Security Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Input Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:29:47 --> Language Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Loader Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Controller Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:29:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:29:47 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:29:47 --> Session Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:29:47 --> A session cookie was not found.
DEBUG - 2014-02-19 10:29:47 --> Session routines successfully run
DEBUG - 2014-02-19 10:29:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:29:47 --> Model Class Initialized
DEBUG - 2014-02-19 10:29:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:29:47 --> Final output sent to browser
DEBUG - 2014-02-19 10:29:47 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:32:56 --> Config Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Config Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Config Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:32:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:32:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:32:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:32:56 --> URI Class Initialized
DEBUG - 2014-02-19 10:32:56 --> URI Class Initialized
DEBUG - 2014-02-19 10:32:56 --> URI Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Router Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Router Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Router Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Output Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Output Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Output Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Security Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Security Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Security Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Input Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Input Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Input Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:32:56 --> Language Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Language Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Language Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Loader Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Loader Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Loader Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Controller Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Controller Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Controller Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:32:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:32:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:32:56 --> Session Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Session Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Session Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:32:56 --> A session cookie was not found.
DEBUG - 2014-02-19 10:32:56 --> A session cookie was not found.
DEBUG - 2014-02-19 10:32:56 --> A session cookie was not found.
DEBUG - 2014-02-19 10:32:56 --> Session routines successfully run
DEBUG - 2014-02-19 10:32:56 --> Session routines successfully run
DEBUG - 2014-02-19 10:32:56 --> Session routines successfully run
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:32:56 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Model Class Initialized
DEBUG - 2014-02-19 10:32:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:32:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:32:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:32:56 --> Final output sent to browser
DEBUG - 2014-02-19 10:32:56 --> Final output sent to browser
DEBUG - 2014-02-19 10:32:56 --> Final output sent to browser
DEBUG - 2014-02-19 10:32:56 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:32:56 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:32:56 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:47:23 --> Config Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Config Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:47:23 --> URI Class Initialized
DEBUG - 2014-02-19 10:47:23 --> URI Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Router Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Router Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Config Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Output Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Output Class Initialized
DEBUG - 2014-02-19 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:47:23 --> URI Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Security Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Security Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Router Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Input Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Input Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:47:23 --> Output Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Language Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Language Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Security Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Input Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Loader Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Loader Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:47:23 --> Controller Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Controller Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Language Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:47:23 --> Loader Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:47:23 --> Controller Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Session Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Session Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:47:23 --> A session cookie was not found.
DEBUG - 2014-02-19 10:47:23 --> Session Class Initialized
DEBUG - 2014-02-19 10:47:23 --> A session cookie was not found.
DEBUG - 2014-02-19 10:47:23 --> Session routines successfully run
DEBUG - 2014-02-19 10:47:23 --> Session routines successfully run
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:47:23 --> A session cookie was not found.
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Session routines successfully run
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:23 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:47:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:23 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:23 --> Final output sent to browser
DEBUG - 2014-02-19 10:47:23 --> Final output sent to browser
DEBUG - 2014-02-19 10:47:23 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:47:23 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:47:23 --> Final output sent to browser
DEBUG - 2014-02-19 10:47:23 --> Total execution time: 0.0190
DEBUG - 2014-02-19 10:47:59 --> Config Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Config Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:47:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:47:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:47:59 --> URI Class Initialized
DEBUG - 2014-02-19 10:47:59 --> URI Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Router Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Router Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Output Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Output Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Security Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Security Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Input Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Input Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:47:59 --> Language Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Language Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Loader Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Loader Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Controller Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Controller Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:59 --> Session Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Session Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:47:59 --> A session cookie was not found.
DEBUG - 2014-02-19 10:47:59 --> A session cookie was not found.
DEBUG - 2014-02-19 10:47:59 --> Session routines successfully run
DEBUG - 2014-02-19 10:47:59 --> Session routines successfully run
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:47:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Model Class Initialized
DEBUG - 2014-02-19 10:47:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:47:59 --> Final output sent to browser
DEBUG - 2014-02-19 10:47:59 --> Final output sent to browser
DEBUG - 2014-02-19 10:47:59 --> Total execution time: 0.0230
DEBUG - 2014-02-19 10:47:59 --> Total execution time: 0.0230
DEBUG - 2014-02-19 10:48:04 --> Config Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:48:04 --> URI Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Router Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Output Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Security Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Input Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:48:04 --> Language Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Loader Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Controller Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:48:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:04 --> Session Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:48:04 --> A session cookie was not found.
DEBUG - 2014-02-19 10:48:04 --> Session routines successfully run
DEBUG - 2014-02-19 10:48:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:04 --> Final output sent to browser
DEBUG - 2014-02-19 10:48:04 --> Total execution time: 0.0120
DEBUG - 2014-02-19 10:48:18 --> Config Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:48:18 --> URI Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Router Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Config Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:48:18 --> Output Class Initialized
DEBUG - 2014-02-19 10:48:18 --> URI Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Security Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Router Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Input Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:48:18 --> Output Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Language Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Security Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Input Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Loader Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:48:18 --> Language Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Controller Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:48:18 --> Loader Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Controller Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:18 --> Session Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Session Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:48:18 --> A session cookie was not found.
DEBUG - 2014-02-19 10:48:18 --> A session cookie was not found.
DEBUG - 2014-02-19 10:48:18 --> Session routines successfully run
DEBUG - 2014-02-19 10:48:18 --> Session routines successfully run
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:48:18 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:18 --> Final output sent to browser
DEBUG - 2014-02-19 10:48:18 --> Final output sent to browser
DEBUG - 2014-02-19 10:48:18 --> Total execution time: 0.0230
DEBUG - 2014-02-19 10:48:18 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:48:28 --> Config Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:48:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:48:28 --> URI Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Router Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Output Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Security Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Input Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:48:28 --> Language Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Loader Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Controller Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:48:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:48:28 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:28 --> Session Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:48:28 --> A session cookie was not found.
DEBUG - 2014-02-19 10:48:28 --> Session routines successfully run
DEBUG - 2014-02-19 10:48:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:48:28 --> Model Class Initialized
DEBUG - 2014-02-19 10:48:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:48:28 --> Final output sent to browser
DEBUG - 2014-02-19 10:48:28 --> Total execution time: 0.0190
DEBUG - 2014-02-19 10:56:11 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:11 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:11 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:11 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:11 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:11 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:11 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:11 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:11 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:11 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:11 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:11 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:11 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:11 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:11 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:11 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:56:11 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:56:11 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:56:21 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:21 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:21 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:21 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:21 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:21 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:21 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:21 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:21 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:21 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:21 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:21 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:56:21 --> Total execution time: 0.0200
DEBUG - 2014-02-19 10:56:26 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:26 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:26 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:26 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:26 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:26 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:26 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:26 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:26 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:26 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:26 --> Total execution time: 0.0110
DEBUG - 2014-02-19 10:56:49 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:49 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:49 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:49 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:49 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:49 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:49 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:49 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:49 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:56:49 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:49 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:49 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:49 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:49 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:49 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:49 --> Total execution time: 0.0180
DEBUG - 2014-02-19 10:56:50 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:50 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:50 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:50 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:50 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:50 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:50 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:50 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:50 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:50 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:50 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:50 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:50 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:50 --> Total execution time: 0.0190
DEBUG - 2014-02-19 10:56:50 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:50 --> Total execution time: 0.0180
DEBUG - 2014-02-19 10:56:51 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:51 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:51 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:51 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:51 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:51 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:51 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:51 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:51 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:51 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:51 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:51 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:51 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:51 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:51 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:51 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:51 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:51 --> Total execution time: 0.0120
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Total execution time: 0.0120
DEBUG - 2014-02-19 10:56:51 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:51 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:51 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:51 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:52 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:52 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:52 --> Total execution time: 0.0100
DEBUG - 2014-02-19 10:56:54 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:54 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:54 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:54 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:54 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:54 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:54 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:54 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:54 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:54 --> Total execution time: 0.0190
DEBUG - 2014-02-19 10:56:55 --> Config Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:56:55 --> URI Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Router Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Output Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Security Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Input Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:56:55 --> Language Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Loader Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Controller Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:56:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:56:55 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:55 --> Session Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:56:55 --> A session cookie was not found.
DEBUG - 2014-02-19 10:56:55 --> Session routines successfully run
DEBUG - 2014-02-19 10:56:55 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:56:55 --> Model Class Initialized
DEBUG - 2014-02-19 10:56:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:56:55 --> Final output sent to browser
DEBUG - 2014-02-19 10:56:55 --> Total execution time: 0.0180
DEBUG - 2014-02-19 10:59:20 --> Config Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:59:20 --> URI Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Router Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Output Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Security Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Input Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:59:20 --> Language Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Loader Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Controller Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:59:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:59:20 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:59:20 --> Session Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:59:20 --> A session cookie was not found.
DEBUG - 2014-02-19 10:59:20 --> Session routines successfully run
DEBUG - 2014-02-19 10:59:20 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:59:20 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:59:20 --> Final output sent to browser
DEBUG - 2014-02-19 10:59:20 --> Total execution time: 0.0210
DEBUG - 2014-02-19 10:59:25 --> Config Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:59:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:59:25 --> URI Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Router Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Output Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Security Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Config Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Input Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:59:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Language Class Initialized
DEBUG - 2014-02-19 10:59:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 10:59:25 --> URI Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Loader Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Controller Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Router Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:59:25 --> Output Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Security Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Input Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 10:59:25 --> Language Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Loader Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Controller Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 10:59:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Session Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:59:25 --> A session cookie was not found.
DEBUG - 2014-02-19 10:59:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Session routines successfully run
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:59:25 --> Session Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Final output sent to browser
DEBUG - 2014-02-19 10:59:25 --> Total execution time: 0.0220
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 10:59:25 --> A session cookie was not found.
DEBUG - 2014-02-19 10:59:25 --> Session routines successfully run
DEBUG - 2014-02-19 10:59:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 10:59:25 --> Model Class Initialized
DEBUG - 2014-02-19 10:59:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 10:59:25 --> Final output sent to browser
DEBUG - 2014-02-19 10:59:25 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:01:43 --> Config Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:01:43 --> URI Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Config Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Router Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:01:43 --> URI Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Output Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Router Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Security Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Output Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Input Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Security Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:01:43 --> Input Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Language Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:01:43 --> Language Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Loader Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Loader Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Controller Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Controller Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:01:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:01:43 --> Session Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Session Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:01:43 --> A session cookie was not found.
DEBUG - 2014-02-19 11:01:43 --> A session cookie was not found.
DEBUG - 2014-02-19 11:01:43 --> Session routines successfully run
DEBUG - 2014-02-19 11:01:43 --> Session routines successfully run
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:01:43 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:01:43 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:01:43 --> Final output sent to browser
DEBUG - 2014-02-19 11:01:43 --> Total execution time: 0.0210
DEBUG - 2014-02-19 11:01:43 --> Final output sent to browser
DEBUG - 2014-02-19 11:01:43 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:01:53 --> Config Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:01:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:01:53 --> URI Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Router Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Output Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Security Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Input Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:01:53 --> Language Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Loader Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Controller Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:01:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:01:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:01:53 --> Session Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:01:53 --> A session cookie was not found.
DEBUG - 2014-02-19 11:01:53 --> Session routines successfully run
DEBUG - 2014-02-19 11:01:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:01:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:01:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:01:53 --> Final output sent to browser
DEBUG - 2014-02-19 11:01:53 --> Total execution time: 0.0160
DEBUG - 2014-02-19 11:03:17 --> Config Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:03:17 --> URI Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Router Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Output Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Security Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Input Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:03:17 --> Config Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Language Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:03:17 --> Loader Class Initialized
DEBUG - 2014-02-19 11:03:17 --> URI Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Controller Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Router Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:03:17 --> Output Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:03:17 --> Security Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Input Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:03:17 --> Language Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Loader Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Controller Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Session Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:03:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:03:17 --> A session cookie was not found.
DEBUG - 2014-02-19 11:03:17 --> Session routines successfully run
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:03:17 --> Session Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Final output sent to browser
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:03:17 --> Total execution time: 0.0240
DEBUG - 2014-02-19 11:03:17 --> A session cookie was not found.
DEBUG - 2014-02-19 11:03:17 --> Session routines successfully run
DEBUG - 2014-02-19 11:03:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:03:17 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:03:17 --> Final output sent to browser
DEBUG - 2014-02-19 11:03:17 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:03:22 --> Config Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:03:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:03:22 --> URI Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Router Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Output Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Security Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Input Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:03:22 --> Language Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Loader Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Controller Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:03:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:03:22 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:03:22 --> Session Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:03:22 --> A session cookie was not found.
DEBUG - 2014-02-19 11:03:22 --> Session routines successfully run
DEBUG - 2014-02-19 11:03:22 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:03:22 --> Model Class Initialized
DEBUG - 2014-02-19 11:03:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:03:22 --> Final output sent to browser
DEBUG - 2014-02-19 11:03:22 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:04:25 --> Config Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Config Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:04:25 --> URI Class Initialized
DEBUG - 2014-02-19 11:04:25 --> URI Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Router Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Router Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Output Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Output Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Security Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Security Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Input Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Input Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:04:25 --> Language Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Language Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Loader Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Loader Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Controller Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Controller Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:04:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:04:25 --> Session Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Session Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:04:25 --> A session cookie was not found.
DEBUG - 2014-02-19 11:04:25 --> A session cookie was not found.
DEBUG - 2014-02-19 11:04:25 --> Session routines successfully run
DEBUG - 2014-02-19 11:04:25 --> Session routines successfully run
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:04:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:04:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:04:25 --> Final output sent to browser
DEBUG - 2014-02-19 11:04:25 --> Final output sent to browser
DEBUG - 2014-02-19 11:04:25 --> Total execution time: 0.0180
DEBUG - 2014-02-19 11:04:25 --> Total execution time: 0.0180
DEBUG - 2014-02-19 11:04:30 --> Config Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:04:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:04:30 --> URI Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Router Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Output Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Security Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Input Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:04:30 --> Language Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Loader Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Controller Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:04:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:04:30 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:04:30 --> Session Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:04:30 --> A session cookie was not found.
DEBUG - 2014-02-19 11:04:30 --> Session routines successfully run
DEBUG - 2014-02-19 11:04:30 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:04:30 --> Model Class Initialized
DEBUG - 2014-02-19 11:04:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:04:30 --> Final output sent to browser
DEBUG - 2014-02-19 11:04:30 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:05:42 --> Config Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Config Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:05:42 --> URI Class Initialized
DEBUG - 2014-02-19 11:05:42 --> URI Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Router Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Router Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Output Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Output Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Security Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Security Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Input Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Input Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:05:42 --> Language Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Language Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Loader Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Loader Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Controller Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Controller Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:05:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:05:42 --> Session Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Session Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:05:42 --> A session cookie was not found.
DEBUG - 2014-02-19 11:05:42 --> A session cookie was not found.
DEBUG - 2014-02-19 11:05:42 --> Session routines successfully run
DEBUG - 2014-02-19 11:05:42 --> Session routines successfully run
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:05:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:05:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:05:42 --> Final output sent to browser
DEBUG - 2014-02-19 11:05:42 --> Final output sent to browser
DEBUG - 2014-02-19 11:05:42 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:05:42 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:05:47 --> Config Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:05:47 --> URI Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Router Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Output Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Security Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Input Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:05:47 --> Language Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Loader Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Controller Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:05:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:05:47 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:05:47 --> Session Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:05:47 --> A session cookie was not found.
DEBUG - 2014-02-19 11:05:47 --> Session routines successfully run
DEBUG - 2014-02-19 11:05:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:05:47 --> Model Class Initialized
DEBUG - 2014-02-19 11:05:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:05:47 --> Final output sent to browser
DEBUG - 2014-02-19 11:05:47 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:06:54 --> Config Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Config Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:06:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:06:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:06:54 --> URI Class Initialized
DEBUG - 2014-02-19 11:06:54 --> URI Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Router Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Router Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Output Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Output Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Security Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Security Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Input Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Input Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:06:54 --> Language Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Language Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Loader Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Loader Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Controller Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Controller Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Config Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:06:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> URI Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:06:54 --> Router Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Session Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Session Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:06:54 --> Output Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:06:54 --> A session cookie was not found.
DEBUG - 2014-02-19 11:06:54 --> A session cookie was not found.
DEBUG - 2014-02-19 11:06:54 --> Session routines successfully run
DEBUG - 2014-02-19 11:06:54 --> Security Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Session routines successfully run
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:06:54 --> Input Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Language Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:06:54 --> Loader Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Controller Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Final output sent to browser
DEBUG - 2014-02-19 11:06:54 --> Final output sent to browser
DEBUG - 2014-02-19 11:06:54 --> Total execution time: 0.0240
DEBUG - 2014-02-19 11:06:54 --> Total execution time: 0.0240
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:06:54 --> Session Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:06:54 --> A session cookie was not found.
DEBUG - 2014-02-19 11:06:54 --> Session routines successfully run
DEBUG - 2014-02-19 11:06:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:06:54 --> Model Class Initialized
DEBUG - 2014-02-19 11:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:06:54 --> Final output sent to browser
DEBUG - 2014-02-19 11:06:54 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:07:09 --> Config Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Config Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:07:09 --> URI Class Initialized
DEBUG - 2014-02-19 11:07:09 --> URI Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Router Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Router Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Output Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Output Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Security Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Security Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Input Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Input Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:07:09 --> Language Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Language Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Loader Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Loader Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Controller Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Controller Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:07:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:07:09 --> Session Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Session Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:07:09 --> A session cookie was not found.
DEBUG - 2014-02-19 11:07:09 --> A session cookie was not found.
DEBUG - 2014-02-19 11:07:09 --> Session routines successfully run
DEBUG - 2014-02-19 11:07:09 --> Session routines successfully run
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:07:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:07:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:07:09 --> Final output sent to browser
DEBUG - 2014-02-19 11:07:09 --> Final output sent to browser
DEBUG - 2014-02-19 11:07:09 --> Total execution time: 0.0180
DEBUG - 2014-02-19 11:07:09 --> Total execution time: 0.0180
DEBUG - 2014-02-19 11:07:14 --> Config Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:07:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:07:14 --> URI Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Router Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Output Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Security Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Input Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:07:14 --> Language Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Loader Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Controller Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:07:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:07:14 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:07:14 --> Session Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:07:14 --> A session cookie was not found.
DEBUG - 2014-02-19 11:07:14 --> Session routines successfully run
DEBUG - 2014-02-19 11:07:14 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:07:14 --> Model Class Initialized
DEBUG - 2014-02-19 11:07:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:07:14 --> Final output sent to browser
DEBUG - 2014-02-19 11:07:14 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:36:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:36:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:36:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:36:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:36:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:36:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:36:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:36:32 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:36:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:36:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:36:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:36:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:36:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:36:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:36:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:36:32 --> Total execution time: 0.0180
DEBUG - 2014-02-19 11:36:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:36:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:36:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:36:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:36:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:36:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:36:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:36:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:36:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:36:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:36:32 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:37:06 --> Config Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:37:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:37:06 --> URI Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Router Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Output Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Security Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Input Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:37:06 --> Language Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Loader Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Controller Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:37:06 --> Session Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:37:06 --> A session cookie was not found.
DEBUG - 2014-02-19 11:37:06 --> Session routines successfully run
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:37:06 --> Final output sent to browser
DEBUG - 2014-02-19 11:37:06 --> Total execution time: 0.0170
DEBUG - 2014-02-19 11:37:06 --> Config Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:37:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:37:06 --> URI Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Router Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Output Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Security Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Input Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:37:06 --> Language Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Loader Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Controller Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:37:06 --> Session Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:37:06 --> A session cookie was not found.
DEBUG - 2014-02-19 11:37:06 --> Session routines successfully run
DEBUG - 2014-02-19 11:37:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:37:06 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:37:06 --> Final output sent to browser
DEBUG - 2014-02-19 11:37:06 --> Total execution time: 0.0130
DEBUG - 2014-02-19 11:37:16 --> Config Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:37:16 --> URI Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Router Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Output Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Security Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Input Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:37:16 --> Language Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Loader Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Controller Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:37:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:37:16 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:37:16 --> Session Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:37:16 --> A session cookie was not found.
DEBUG - 2014-02-19 11:37:16 --> Session routines successfully run
DEBUG - 2014-02-19 11:37:16 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:37:16 --> Model Class Initialized
DEBUG - 2014-02-19 11:37:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:37:16 --> Final output sent to browser
DEBUG - 2014-02-19 11:37:16 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:38:28 --> Config Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Config Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:38:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:38:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:38:28 --> URI Class Initialized
DEBUG - 2014-02-19 11:38:28 --> URI Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Router Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Router Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Output Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Output Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Security Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Security Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Input Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Input Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:38:28 --> Language Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Language Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Loader Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Loader Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Controller Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Controller Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:38:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:38:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:38:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:38:28 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:38:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:38:28 --> Session Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Session Class Initialized
DEBUG - 2014-02-19 11:38:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:38:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:38:29 --> A session cookie was not found.
DEBUG - 2014-02-19 11:38:29 --> A session cookie was not found.
DEBUG - 2014-02-19 11:38:29 --> Session routines successfully run
DEBUG - 2014-02-19 11:38:29 --> Session routines successfully run
DEBUG - 2014-02-19 11:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:38:29 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:29 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:38:29 --> Final output sent to browser
DEBUG - 2014-02-19 11:38:29 --> Final output sent to browser
DEBUG - 2014-02-19 11:38:29 --> Total execution time: 0.0170
DEBUG - 2014-02-19 11:38:29 --> Total execution time: 0.0170
DEBUG - 2014-02-19 11:38:33 --> Config Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:38:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:38:33 --> URI Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Router Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Output Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Security Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Input Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:38:33 --> Language Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Loader Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Controller Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:38:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:38:33 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:38:34 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:38:34 --> Session Class Initialized
DEBUG - 2014-02-19 11:38:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:38:34 --> A session cookie was not found.
DEBUG - 2014-02-19 11:38:34 --> Session routines successfully run
DEBUG - 2014-02-19 11:38:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:38:34 --> Model Class Initialized
DEBUG - 2014-02-19 11:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:38:34 --> Final output sent to browser
DEBUG - 2014-02-19 11:38:34 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:40:07 --> Config Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Config Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:40:07 --> URI Class Initialized
DEBUG - 2014-02-19 11:40:07 --> URI Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Router Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Router Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Output Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Output Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Security Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Security Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Input Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Input Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:40:07 --> Language Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Language Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Loader Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Loader Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Controller Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Controller Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:40:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:40:07 --> Session Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Session Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:40:07 --> A session cookie was not found.
DEBUG - 2014-02-19 11:40:07 --> A session cookie was not found.
DEBUG - 2014-02-19 11:40:07 --> Session routines successfully run
DEBUG - 2014-02-19 11:40:07 --> Session routines successfully run
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:40:07 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:40:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:40:07 --> Final output sent to browser
DEBUG - 2014-02-19 11:40:07 --> Final output sent to browser
DEBUG - 2014-02-19 11:40:07 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:40:07 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:40:12 --> Config Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:40:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:40:12 --> URI Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Router Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Output Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Security Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Input Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:40:12 --> Language Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Loader Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Controller Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:40:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:40:12 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:40:12 --> Session Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:40:12 --> A session cookie was not found.
DEBUG - 2014-02-19 11:40:12 --> Session routines successfully run
DEBUG - 2014-02-19 11:40:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:40:12 --> Model Class Initialized
DEBUG - 2014-02-19 11:40:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:40:12 --> Final output sent to browser
DEBUG - 2014-02-19 11:40:12 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:41:19 --> Config Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Config Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:41:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:41:19 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:41:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:41:19 --> URI Class Initialized
DEBUG - 2014-02-19 11:41:19 --> URI Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Router Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Router Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Output Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Output Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Security Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Security Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Input Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Input Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:41:19 --> Language Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Language Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Loader Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Loader Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Controller Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Controller Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:19 --> Session Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Session Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:41:19 --> A session cookie was not found.
DEBUG - 2014-02-19 11:41:19 --> A session cookie was not found.
DEBUG - 2014-02-19 11:41:19 --> Session routines successfully run
DEBUG - 2014-02-19 11:41:19 --> Session routines successfully run
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:41:19 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:19 --> Final output sent to browser
DEBUG - 2014-02-19 11:41:19 --> Final output sent to browser
DEBUG - 2014-02-19 11:41:19 --> Total execution time: 0.0180
DEBUG - 2014-02-19 11:41:19 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:41:20 --> Config Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:41:20 --> URI Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Router Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Output Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Security Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Input Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Config Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:41:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Language Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:41:20 --> Loader Class Initialized
DEBUG - 2014-02-19 11:41:20 --> URI Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Controller Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Router Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:41:20 --> Output Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Security Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Input Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:41:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Language Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Loader Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Controller Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:41:20 --> Session Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> A session cookie was not found.
DEBUG - 2014-02-19 11:41:20 --> Session routines successfully run
DEBUG - 2014-02-19 11:41:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:20 --> Final output sent to browser
DEBUG - 2014-02-19 11:41:20 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:41:20 --> Session Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:41:20 --> A session cookie was not found.
DEBUG - 2014-02-19 11:41:20 --> Session routines successfully run
DEBUG - 2014-02-19 11:41:20 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:41:20 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:20 --> Final output sent to browser
DEBUG - 2014-02-19 11:41:20 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:41:24 --> Config Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:41:24 --> URI Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Router Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Output Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Security Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Input Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:41:24 --> Language Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Loader Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Controller Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:41:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:41:24 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:24 --> Session Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:41:24 --> A session cookie was not found.
DEBUG - 2014-02-19 11:41:24 --> Session routines successfully run
DEBUG - 2014-02-19 11:41:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:41:24 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:24 --> Final output sent to browser
DEBUG - 2014-02-19 11:41:24 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:41:25 --> Config Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:41:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:41:25 --> URI Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Router Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Output Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Security Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Input Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:41:25 --> Language Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Loader Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Controller Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:41:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:25 --> Session Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:41:25 --> A session cookie was not found.
DEBUG - 2014-02-19 11:41:25 --> Session routines successfully run
DEBUG - 2014-02-19 11:41:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 11:41:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:41:25 --> Final output sent to browser
DEBUG - 2014-02-19 11:41:25 --> Total execution time: 0.0170
DEBUG - 2014-02-19 11:42:38 --> Config Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:42:38 --> Config Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:42:38 --> URI Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:42:38 --> Router Class Initialized
DEBUG - 2014-02-19 11:42:38 --> URI Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Router Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Output Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Output Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Security Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Security Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Input Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Input Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:42:38 --> Language Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Language Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Loader Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Loader Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Controller Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Controller Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:42:38 --> Session Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Session Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:42:38 --> A session cookie was not found.
DEBUG - 2014-02-19 11:42:38 --> A session cookie was not found.
DEBUG - 2014-02-19 11:42:38 --> Session routines successfully run
DEBUG - 2014-02-19 11:42:38 --> Session routines successfully run
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:42:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:42:38 --> Final output sent to browser
DEBUG - 2014-02-19 11:42:38 --> Final output sent to browser
DEBUG - 2014-02-19 11:42:38 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:42:38 --> Total execution time: 0.0250
DEBUG - 2014-02-19 11:42:48 --> Config Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:42:48 --> URI Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Router Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Output Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Security Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Input Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:42:48 --> Language Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Loader Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Controller Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:42:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:42:48 --> Session Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:42:48 --> A session cookie was not found.
DEBUG - 2014-02-19 11:42:48 --> Session routines successfully run
DEBUG - 2014-02-19 11:42:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 11:42:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:42:48 --> Final output sent to browser
DEBUG - 2014-02-19 11:42:48 --> Total execution time: 0.0200
DEBUG - 2014-02-19 11:43:27 --> Config Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Config Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:43:27 --> URI Class Initialized
DEBUG - 2014-02-19 11:43:27 --> URI Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Router Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Router Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Output Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Output Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Security Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Security Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Input Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Input Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:43:27 --> Language Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Language Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Loader Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Loader Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Controller Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Controller Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:43:27 --> Session Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Session Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:43:27 --> A session cookie was not found.
DEBUG - 2014-02-19 11:43:27 --> A session cookie was not found.
DEBUG - 2014-02-19 11:43:27 --> Session routines successfully run
DEBUG - 2014-02-19 11:43:27 --> Session routines successfully run
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:43:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:43:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:43:27 --> Final output sent to browser
DEBUG - 2014-02-19 11:43:27 --> Final output sent to browser
DEBUG - 2014-02-19 11:43:27 --> Total execution time: 0.0150
DEBUG - 2014-02-19 11:43:27 --> Total execution time: 0.0150
DEBUG - 2014-02-19 11:43:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:43:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:43:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:43:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:43:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:43:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:43:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:43:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:43:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:43:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:43:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:43:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:43:32 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:44:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:44:32 --> Config Class Initialized
DEBUG - 2014-02-19 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:44:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:44:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:44:32 --> URI Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Router Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Output Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:44:32 --> Security Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Input Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:44:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Language Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Loader Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:44:32 --> Controller Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:44:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Session Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:44:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:44:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:44:32 --> A session cookie was not found.
DEBUG - 2014-02-19 11:44:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:44:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:44:32 --> Session routines successfully run
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:44:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Model Class Initialized
DEBUG - 2014-02-19 11:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:44:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:44:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:44:32 --> Final output sent to browser
DEBUG - 2014-02-19 11:44:32 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:44:32 --> Total execution time: 0.0190
DEBUG - 2014-02-19 11:44:32 --> Total execution time: 0.0170
DEBUG - 2014-02-19 11:58:53 --> Config Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Config Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:58:53 --> URI Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Config Class Initialized
DEBUG - 2014-02-19 11:58:53 --> URI Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Router Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Router Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 11:58:53 --> Output Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Output Class Initialized
DEBUG - 2014-02-19 11:58:53 --> URI Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Security Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Router Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Security Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Input Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Input Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:58:53 --> Output Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Language Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Language Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Security Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Loader Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Input Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Loader Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Controller Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 11:58:53 --> Controller Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Language Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:58:53 --> Loader Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Controller Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:58:53 --> Session Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Session Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:58:53 --> Session Class Initialized
DEBUG - 2014-02-19 11:58:53 --> A session cookie was not found.
DEBUG - 2014-02-19 11:58:53 --> A session cookie was not found.
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 11:58:53 --> Session routines successfully run
DEBUG - 2014-02-19 11:58:53 --> Session routines successfully run
DEBUG - 2014-02-19 11:58:53 --> A session cookie was not found.
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:58:53 --> Session routines successfully run
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 11:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:58:53 --> Model Class Initialized
DEBUG - 2014-02-19 11:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 11:58:53 --> Final output sent to browser
DEBUG - 2014-02-19 11:58:53 --> Final output sent to browser
DEBUG - 2014-02-19 11:58:53 --> Total execution time: 0.0240
DEBUG - 2014-02-19 11:58:53 --> Total execution time: 0.0230
DEBUG - 2014-02-19 11:58:53 --> Final output sent to browser
DEBUG - 2014-02-19 11:58:53 --> Total execution time: 0.0220
DEBUG - 2014-02-19 12:03:32 --> Config Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:03:32 --> URI Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Router Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Output Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Security Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Input Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:03:32 --> Language Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Loader Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Controller Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:03:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:03:32 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:03:32 --> Session Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:03:32 --> A session cookie was not found.
DEBUG - 2014-02-19 12:03:32 --> Session routines successfully run
DEBUG - 2014-02-19 12:03:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:03:32 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:03:32 --> Final output sent to browser
DEBUG - 2014-02-19 12:03:32 --> Total execution time: 0.0210
DEBUG - 2014-02-19 12:03:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:03:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:03:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:03:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:03:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:03:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:03:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:03:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:03:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:03:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:03:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:03:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:03:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:03:37 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:03:37 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:05:33 --> Config Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Config Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:05:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:05:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:05:33 --> URI Class Initialized
DEBUG - 2014-02-19 12:05:33 --> URI Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Router Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Router Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Output Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Output Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Security Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Security Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Input Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Input Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:05:33 --> Language Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Language Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Loader Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Loader Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Controller Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Controller Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:05:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:05:33 --> Session Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Session Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:05:33 --> A session cookie was not found.
DEBUG - 2014-02-19 12:05:33 --> A session cookie was not found.
DEBUG - 2014-02-19 12:05:33 --> Session routines successfully run
DEBUG - 2014-02-19 12:05:33 --> Session routines successfully run
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:05:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:05:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:05:33 --> Final output sent to browser
DEBUG - 2014-02-19 12:05:33 --> Final output sent to browser
DEBUG - 2014-02-19 12:05:33 --> Total execution time: 0.0240
DEBUG - 2014-02-19 12:05:33 --> Total execution time: 0.0240
DEBUG - 2014-02-19 12:05:38 --> Config Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:05:38 --> URI Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Router Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Output Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Security Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Input Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:05:38 --> Language Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Loader Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Controller Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:05:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:05:38 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:05:38 --> Session Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:05:38 --> A session cookie was not found.
DEBUG - 2014-02-19 12:05:38 --> Session routines successfully run
DEBUG - 2014-02-19 12:05:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:05:38 --> Model Class Initialized
DEBUG - 2014-02-19 12:05:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:05:38 --> Final output sent to browser
DEBUG - 2014-02-19 12:05:38 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:06:12 --> Config Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:06:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:06:12 --> URI Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Router Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Output Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Security Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Input Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:06:12 --> Language Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Loader Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Controller Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:06:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:06:12 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:06:12 --> Session Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:06:12 --> A session cookie was not found.
DEBUG - 2014-02-19 12:06:12 --> Session routines successfully run
DEBUG - 2014-02-19 12:06:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:06:12 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:06:12 --> Final output sent to browser
DEBUG - 2014-02-19 12:06:12 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:06:17 --> Config Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Config Class Initialized
DEBUG - 2014-02-19 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:06:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:06:17 --> URI Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:06:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:06:17 --> Router Class Initialized
DEBUG - 2014-02-19 12:06:17 --> URI Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Router Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Output Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Output Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Security Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Security Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Input Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Input Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:06:17 --> Language Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Language Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Loader Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Loader Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Controller Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Controller Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:06:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:06:17 --> Session Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Session Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:06:17 --> A session cookie was not found.
DEBUG - 2014-02-19 12:06:17 --> A session cookie was not found.
DEBUG - 2014-02-19 12:06:17 --> Session routines successfully run
DEBUG - 2014-02-19 12:06:17 --> Session routines successfully run
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:06:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Model Class Initialized
DEBUG - 2014-02-19 12:06:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:06:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:06:17 --> Final output sent to browser
DEBUG - 2014-02-19 12:06:17 --> Final output sent to browser
DEBUG - 2014-02-19 12:06:17 --> Total execution time: 0.0240
DEBUG - 2014-02-19 12:06:17 --> Total execution time: 0.0220
DEBUG - 2014-02-19 12:07:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:07:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:07:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:07:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:07:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:07:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:07:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:07:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:07:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:07:37 --> Total execution time: 0.0240
DEBUG - 2014-02-19 12:07:37 --> Total execution time: 0.0230
DEBUG - 2014-02-19 12:07:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:07:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:07:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:07:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:07:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:07:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:07:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:07:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:07:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:07:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:07:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:37 --> Total execution time: 0.0210
DEBUG - 2014-02-19 12:07:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:07:37 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:07:42 --> Config Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:07:42 --> URI Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Router Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Output Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Security Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Input Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:07:42 --> Language Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Loader Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Controller Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:42 --> Session Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:07:42 --> A session cookie was not found.
DEBUG - 2014-02-19 12:07:42 --> Session routines successfully run
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:42 --> Final output sent to browser
DEBUG - 2014-02-19 12:07:42 --> Total execution time: 0.0170
DEBUG - 2014-02-19 12:07:42 --> Config Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:07:42 --> URI Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Router Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Output Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Security Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Input Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:07:42 --> Language Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Loader Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Controller Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:42 --> Session Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:07:42 --> A session cookie was not found.
DEBUG - 2014-02-19 12:07:42 --> Session routines successfully run
DEBUG - 2014-02-19 12:07:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:07:42 --> Model Class Initialized
DEBUG - 2014-02-19 12:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:07:42 --> Final output sent to browser
DEBUG - 2014-02-19 12:07:42 --> Total execution time: 0.0180
DEBUG - 2014-02-19 12:19:04 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:04 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:04 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:04 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:04 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:04 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Session Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Session Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:19:04 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:04 --> A session cookie was not found.
DEBUG - 2014-02-19 12:19:04 --> A session cookie was not found.
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:04 --> Session routines successfully run
DEBUG - 2014-02-19 12:19:04 --> Session routines successfully run
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:04 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:04 --> Total execution time: 0.0240
DEBUG - 2014-02-19 12:19:04 --> Total execution time: 0.0230
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:04 --> Session Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:19:04 --> A session cookie was not found.
DEBUG - 2014-02-19 12:19:04 --> Session routines successfully run
DEBUG - 2014-02-19 12:19:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:19:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:04 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:04 --> Total execution time: 0.0160
DEBUG - 2014-02-19 12:19:23 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:23 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:23 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:23 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:23 --> Session Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Session Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:19:23 --> A session cookie was not found.
DEBUG - 2014-02-19 12:19:23 --> A session cookie was not found.
DEBUG - 2014-02-19 12:19:23 --> Session routines successfully run
DEBUG - 2014-02-19 12:19:23 --> Session routines successfully run
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:19:23 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:23 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:23 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:23 --> Total execution time: 0.0220
DEBUG - 2014-02-19 12:19:23 --> Total execution time: 0.0220
DEBUG - 2014-02-19 12:19:28 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:28 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:28 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:28 --> Session Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:19:28 --> A session cookie was not found.
DEBUG - 2014-02-19 12:19:28 --> Session routines successfully run
DEBUG - 2014-02-19 12:19:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:19:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:28 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:28 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:19:50 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:50 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:50 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:19:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:19:50 --> Final output sent to browser
DEBUG - 2014-02-19 12:19:50 --> Total execution time: 0.0180
DEBUG - 2014-02-19 12:19:55 --> Config Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:19:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:19:55 --> URI Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Router Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Output Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Security Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Input Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:19:55 --> Language Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Loader Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Controller Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:19:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:19:55 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:19:55 --> Model Class Initialized
DEBUG - 2014-02-19 12:19:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:20:01 --> Final output sent to browser
DEBUG - 2014-02-19 12:20:01 --> Total execution time: 5.9143
DEBUG - 2014-02-19 12:20:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:20:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:20:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:20:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:20:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:20:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:20:37 --> Upload Class Initialized
DEBUG - 2014-02-19 12:20:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:20:37 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:20:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:20:37 --> Total execution time: 0.0600
DEBUG - 2014-02-19 12:21:02 --> Config Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:21:02 --> URI Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Router Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Output Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Security Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Input Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:21:02 --> Language Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Loader Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Controller Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:21:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:21:02 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:21:02 --> Final output sent to browser
DEBUG - 2014-02-19 12:21:02 --> Total execution time: 0.0150
DEBUG - 2014-02-19 12:21:13 --> Config Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:21:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:21:13 --> URI Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Router Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Output Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Security Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Input Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:21:13 --> Language Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Loader Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Controller Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:21:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:21:13 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:21:13 --> Final output sent to browser
DEBUG - 2014-02-19 12:21:13 --> Total execution time: 0.0140
DEBUG - 2014-02-19 12:21:15 --> Config Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:21:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:21:15 --> URI Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Router Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Output Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Security Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Input Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:21:15 --> Language Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Loader Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Controller Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:21:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:21:15 --> Upload Class Initialized
DEBUG - 2014-02-19 12:21:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:21:15 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:21:15 --> Final output sent to browser
DEBUG - 2014-02-19 12:21:15 --> Total execution time: 0.0100
DEBUG - 2014-02-19 12:21:27 --> Config Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:21:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:21:27 --> URI Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Router Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Output Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Security Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Input Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:21:27 --> Language Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Loader Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Controller Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:21:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:21:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:21:27 --> Upload Class Initialized
DEBUG - 2014-02-19 12:21:27 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:21:27 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:21:27 --> Final output sent to browser
DEBUG - 2014-02-19 12:21:27 --> Total execution time: 0.0180
DEBUG - 2014-02-19 12:24:24 --> Config Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:24:24 --> URI Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Router Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Output Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Security Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Input Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:24:24 --> Language Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Loader Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Controller Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:24:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:24:24 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:24 --> Session Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:24:24 --> A session cookie was not found.
DEBUG - 2014-02-19 12:24:24 --> Session routines successfully run
DEBUG - 2014-02-19 12:24:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:24:24 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:24 --> Final output sent to browser
DEBUG - 2014-02-19 12:24:24 --> Total execution time: 0.3670
DEBUG - 2014-02-19 12:24:28 --> Config Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:24:28 --> URI Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Router Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Output Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Security Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Input Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:24:28 --> Language Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Loader Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Controller Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:24:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:28 --> Session Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:24:28 --> A session cookie was not found.
DEBUG - 2014-02-19 12:24:28 --> Session routines successfully run
DEBUG - 2014-02-19 12:24:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:24:28 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:28 --> Final output sent to browser
DEBUG - 2014-02-19 12:24:28 --> Total execution time: 0.1630
DEBUG - 2014-02-19 12:24:45 --> Config Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Config Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:24:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:24:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:24:45 --> URI Class Initialized
DEBUG - 2014-02-19 12:24:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:24:45 --> Router Class Initialized
DEBUG - 2014-02-19 12:24:45 --> URI Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Router Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Output Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Output Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Security Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Security Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Input Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:24:45 --> Language Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Loader Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Controller Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:45 --> Session Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:24:45 --> Session routines successfully run
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:45 --> Final output sent to browser
DEBUG - 2014-02-19 12:24:45 --> Total execution time: 0.0130
DEBUG - 2014-02-19 12:24:45 --> Input Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:24:45 --> Language Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Loader Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Controller Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:45 --> Session Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:24:45 --> Session routines successfully run
DEBUG - 2014-02-19 12:24:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:24:45 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:45 --> Final output sent to browser
DEBUG - 2014-02-19 12:24:45 --> Total execution time: 0.0220
DEBUG - 2014-02-19 12:24:50 --> Config Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:24:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:24:50 --> URI Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Router Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Output Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Security Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Input Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:24:50 --> Language Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Loader Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Controller Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:24:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:24:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:50 --> Session Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:24:50 --> Session routines successfully run
DEBUG - 2014-02-19 12:24:50 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:24:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:24:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:24:50 --> Final output sent to browser
DEBUG - 2014-02-19 12:24:50 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:25:09 --> Config Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:25:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:25:09 --> URI Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Router Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Output Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Security Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Input Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:25:09 --> Language Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Loader Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Controller Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:25:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:25:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:25:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:25:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:25:14 --> Final output sent to browser
DEBUG - 2014-02-19 12:25:14 --> Total execution time: 4.4643
DEBUG - 2014-02-19 12:25:36 --> Config Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:25:36 --> URI Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Router Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Output Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Security Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Input Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:25:36 --> Language Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Loader Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Controller Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:25:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:25:36 --> Model Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Model Class Initialized
DEBUG - 2014-02-19 12:25:36 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:25:49 --> Model Class Initialized
DEBUG - 2014-02-19 12:25:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:25:52 --> Upload Class Initialized
DEBUG - 2014-02-19 12:25:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:25:52 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:25:52 --> Final output sent to browser
DEBUG - 2014-02-19 12:25:52 --> Total execution time: 16.0859
DEBUG - 2014-02-19 12:26:35 --> Config Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:26:35 --> URI Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Router Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Output Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Security Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Input Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:26:35 --> Language Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Loader Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Controller Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:26:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:26:35 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:26:35 --> Session Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:26:35 --> Session routines successfully run
DEBUG - 2014-02-19 12:26:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:26:35 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:26:35 --> Final output sent to browser
DEBUG - 2014-02-19 12:26:35 --> Total execution time: 0.1490
DEBUG - 2014-02-19 12:26:41 --> Config Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:26:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:26:41 --> URI Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Router Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Output Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Security Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Input Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:26:41 --> Language Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Loader Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Controller Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:26:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:26:41 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:26:41 --> Session Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:26:41 --> Session routines successfully run
DEBUG - 2014-02-19 12:26:41 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:26:41 --> Model Class Initialized
DEBUG - 2014-02-19 12:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:26:41 --> Final output sent to browser
DEBUG - 2014-02-19 12:26:41 --> Total execution time: 0.1490
DEBUG - 2014-02-19 12:27:04 --> Config Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:27:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:27:04 --> URI Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Router Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Output Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Security Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Input Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:27:04 --> Language Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Loader Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Controller Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:27:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:27:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:04 --> Session Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:27:04 --> Session routines successfully run
DEBUG - 2014-02-19 12:27:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:27:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:04 --> Final output sent to browser
DEBUG - 2014-02-19 12:27:04 --> Total execution time: 0.1490
DEBUG - 2014-02-19 12:27:10 --> Config Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:27:10 --> URI Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Router Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Output Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Security Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Input Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:27:10 --> Language Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Loader Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Controller Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:27:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:27:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:10 --> Session Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:27:10 --> Session routines successfully run
DEBUG - 2014-02-19 12:27:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:27:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:10 --> Final output sent to browser
DEBUG - 2014-02-19 12:27:10 --> Total execution time: 0.0110
DEBUG - 2014-02-19 12:27:15 --> Config Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:27:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:27:15 --> URI Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Router Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Output Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Security Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Input Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:27:15 --> Language Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Loader Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Controller Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:27:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:27:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:15 --> Session Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:27:15 --> Session routines successfully run
DEBUG - 2014-02-19 12:27:15 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:27:15 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:15 --> Final output sent to browser
DEBUG - 2014-02-19 12:27:15 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:27:20 --> Config Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:27:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:27:20 --> URI Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Router Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Output Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Security Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Input Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:27:20 --> Language Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Loader Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Controller Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:27:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:27:20 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:20 --> Session Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:27:20 --> Session routines successfully run
DEBUG - 2014-02-19 12:27:20 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:27:20 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:20 --> Final output sent to browser
DEBUG - 2014-02-19 12:27:20 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:27:33 --> Config Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:27:33 --> URI Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Router Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Output Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Security Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Input Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:27:33 --> Language Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Loader Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Controller Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:27:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:27:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:27:33 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:27:38 --> Final output sent to browser
DEBUG - 2014-02-19 12:27:38 --> Total execution time: 5.8293
DEBUG - 2014-02-19 12:27:50 --> Config Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:27:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:27:50 --> URI Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Router Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Output Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Security Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Input Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:27:50 --> Language Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Loader Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Controller Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:27:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:27:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Model Class Initialized
DEBUG - 2014-02-19 12:27:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:28:00 --> Final output sent to browser
DEBUG - 2014-02-19 12:28:00 --> Total execution time: 9.9106
DEBUG - 2014-02-19 12:44:48 --> Config Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Config Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:44:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:44:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:44:48 --> URI Class Initialized
DEBUG - 2014-02-19 12:44:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:44:48 --> Router Class Initialized
DEBUG - 2014-02-19 12:44:48 --> URI Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Router Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Output Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Output Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Security Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Security Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Input Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Input Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:44:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:44:48 --> Language Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Language Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Loader Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Loader Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Controller Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Controller Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:44:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:44:48 --> Session Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Session Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:44:48 --> A session cookie was not found.
DEBUG - 2014-02-19 12:44:48 --> A session cookie was not found.
DEBUG - 2014-02-19 12:44:48 --> Session routines successfully run
DEBUG - 2014-02-19 12:44:48 --> Session routines successfully run
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:44:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:44:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:44:48 --> Final output sent to browser
DEBUG - 2014-02-19 12:44:48 --> Total execution time: 0.0230
DEBUG - 2014-02-19 12:44:48 --> Final output sent to browser
DEBUG - 2014-02-19 12:44:48 --> Total execution time: 0.0420
DEBUG - 2014-02-19 12:44:53 --> Config Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:44:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:44:53 --> URI Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Router Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Output Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Security Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Input Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:44:53 --> Language Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Loader Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Controller Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:44:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:44:53 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:44:53 --> Session Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:44:53 --> A session cookie was not found.
DEBUG - 2014-02-19 12:44:53 --> Session routines successfully run
DEBUG - 2014-02-19 12:44:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:44:53 --> Model Class Initialized
DEBUG - 2014-02-19 12:44:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:44:53 --> Final output sent to browser
DEBUG - 2014-02-19 12:44:53 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:46:22 --> Config Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:46:22 --> URI Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Router Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Output Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Security Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Input Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:46:22 --> Language Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Loader Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Controller Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:46:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:46:22 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:22 --> Session Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:46:22 --> A session cookie was not found.
DEBUG - 2014-02-19 12:46:22 --> Session routines successfully run
DEBUG - 2014-02-19 12:46:22 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:46:22 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:22 --> Final output sent to browser
DEBUG - 2014-02-19 12:46:22 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:46:27 --> Config Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:46:27 --> URI Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Router Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Output Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Security Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Input Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:46:27 --> Language Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Loader Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Controller Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:46:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:27 --> Session Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:46:27 --> A session cookie was not found.
DEBUG - 2014-02-19 12:46:27 --> Session routines successfully run
DEBUG - 2014-02-19 12:46:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:27 --> Final output sent to browser
DEBUG - 2014-02-19 12:46:27 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:46:37 --> Config Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:46:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:46:37 --> URI Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Router Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Output Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Security Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Input Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:46:37 --> Language Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Loader Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Controller Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:46:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:37 --> Session Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:46:37 --> A session cookie was not found.
DEBUG - 2014-02-19 12:46:37 --> Session routines successfully run
DEBUG - 2014-02-19 12:46:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:46:37 --> Total execution time: 0.0130
DEBUG - 2014-02-19 12:46:49 --> Config Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:46:49 --> URI Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Router Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Output Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Security Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Input Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:46:49 --> Language Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Loader Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Controller Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:46:49 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:46:49 --> Model Class Initialized
DEBUG - 2014-02-19 12:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:46:54 --> Final output sent to browser
DEBUG - 2014-02-19 12:46:54 --> Total execution time: 4.8563
DEBUG - 2014-02-19 12:47:09 --> Config Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:47:09 --> URI Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Router Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Output Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Security Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Input Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:47:09 --> Language Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Loader Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Controller Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:47:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:47:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:47:09 --> Final output sent to browser
DEBUG - 2014-02-19 12:47:09 --> Total execution time: 0.0140
DEBUG - 2014-02-19 12:47:10 --> Config Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:47:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:47:10 --> URI Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Router Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Output Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Security Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Input Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:47:10 --> Language Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Loader Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Controller Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:47:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:47:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:47:10 --> Upload Class Initialized
DEBUG - 2014-02-19 12:47:10 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:47:10 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:47:10 --> Final output sent to browser
DEBUG - 2014-02-19 12:47:10 --> Total execution time: 0.0170
DEBUG - 2014-02-19 12:48:00 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:00 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:00 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:00 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:00 --> Session Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:48:00 --> A session cookie was not found.
DEBUG - 2014-02-19 12:48:00 --> Session routines successfully run
DEBUG - 2014-02-19 12:48:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:48:00 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:00 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:00 --> Total execution time: 0.0135
DEBUG - 2014-02-19 12:48:05 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:05 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:05 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:05 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:05 --> Session Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:48:05 --> A session cookie was not found.
DEBUG - 2014-02-19 12:48:05 --> Session routines successfully run
DEBUG - 2014-02-19 12:48:05 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:48:05 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:05 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:05 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:48:10 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:10 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:10 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:10 --> Session Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:48:10 --> A session cookie was not found.
DEBUG - 2014-02-19 12:48:10 --> Session routines successfully run
DEBUG - 2014-02-19 12:48:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:48:10 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:10 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:10 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:48:20 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:20 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:20 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:20 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:20 --> Total execution time: 0.0150
DEBUG - 2014-02-19 12:48:31 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:31 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:31 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:31 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:48:31 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:37 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:37 --> Total execution time: 6.1203
DEBUG - 2014-02-19 12:48:51 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:51 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:51 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:51 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:51 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:51 --> Total execution time: 0.0130
DEBUG - 2014-02-19 12:48:56 --> Config Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:48:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:48:56 --> URI Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Router Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Output Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Security Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Input Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:48:56 --> Language Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Loader Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Controller Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:48:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:48:56 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Model Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:48:56 --> Upload Class Initialized
DEBUG - 2014-02-19 12:48:56 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:48:56 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:48:56 --> Final output sent to browser
DEBUG - 2014-02-19 12:48:56 --> Total execution time: 0.0110
DEBUG - 2014-02-19 12:49:03 --> Config Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:49:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:49:03 --> URI Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Router Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Output Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Security Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Input Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:49:03 --> Language Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Loader Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Controller Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:49:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:49:03 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:49:03 --> Final output sent to browser
DEBUG - 2014-02-19 12:49:03 --> Total execution time: 0.0110
DEBUG - 2014-02-19 12:49:08 --> Config Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:49:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:49:08 --> URI Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Router Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Output Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Security Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Input Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:49:08 --> Language Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Loader Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Controller Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:49:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:49:08 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:49:08 --> Upload Class Initialized
DEBUG - 2014-02-19 12:49:08 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:49:08 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:49:08 --> Final output sent to browser
DEBUG - 2014-02-19 12:49:08 --> Total execution time: 0.0190
DEBUG - 2014-02-19 12:49:54 --> Config Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:49:54 --> URI Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Router Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Output Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Security Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Input Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:49:54 --> Language Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Loader Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Controller Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:49:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:49:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:49:54 --> Session Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:49:54 --> Session routines successfully run
DEBUG - 2014-02-19 12:49:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:49:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:49:54 --> Final output sent to browser
DEBUG - 2014-02-19 12:49:54 --> Total execution time: 0.1630
DEBUG - 2014-02-19 12:49:59 --> Config Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:49:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:49:59 --> URI Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Router Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Output Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Security Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Input Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:49:59 --> Language Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Loader Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Controller Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:49:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:49:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:49:59 --> Session Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:49:59 --> Session routines successfully run
DEBUG - 2014-02-19 12:49:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:49:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:49:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:49:59 --> Final output sent to browser
DEBUG - 2014-02-19 12:49:59 --> Total execution time: 0.1640
DEBUG - 2014-02-19 12:50:09 --> Config Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:50:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:50:09 --> URI Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Router Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Output Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Security Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Input Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:50:09 --> Language Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Loader Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Controller Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:50:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:50:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:50:09 --> Session Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:50:09 --> Session routines successfully run
DEBUG - 2014-02-19 12:50:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:50:09 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:50:09 --> Final output sent to browser
DEBUG - 2014-02-19 12:50:09 --> Total execution time: 0.1560
DEBUG - 2014-02-19 12:50:23 --> Config Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:50:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:50:23 --> URI Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Router Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Output Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Security Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Input Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:50:23 --> Language Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Loader Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Controller Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:50:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:50:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:50:24 --> Helper loaded: email_helper
DEBUG - 2014-02-19 12:50:24 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:50:33 --> Final output sent to browser
DEBUG - 2014-02-19 12:50:33 --> Total execution time: 9.6936
DEBUG - 2014-02-19 12:50:56 --> Config Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:50:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:50:56 --> URI Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Router Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Output Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Security Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Input Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:50:56 --> Language Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Loader Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Controller Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:50:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:50:56 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Model Class Initialized
DEBUG - 2014-02-19 12:50:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:51:04 --> Model Class Initialized
DEBUG - 2014-02-19 12:51:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:51:04 --> Upload Class Initialized
DEBUG - 2014-02-19 12:51:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-02-19 12:51:04 --> You did not select a file to upload.
DEBUG - 2014-02-19 12:51:04 --> Final output sent to browser
DEBUG - 2014-02-19 12:51:04 --> Total execution time: 7.4294
DEBUG - 2014-02-19 12:51:14 --> Config Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:51:14 --> URI Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Router Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Output Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Security Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Input Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:51:14 --> Language Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Loader Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Controller Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:51:14 --> Model Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Model Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Model Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:51:14 --> Upload Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Image Lib Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Model Class Initialized
DEBUG - 2014-02-19 12:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:51:16 --> Final output sent to browser
DEBUG - 2014-02-19 12:51:16 --> Total execution time: 2.3941
DEBUG - 2014-02-19 12:57:25 --> Config Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:57:25 --> URI Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Router Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Output Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Security Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Input Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:57:25 --> Language Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Loader Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Controller Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:57:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-19 12:57:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:57:28 --> Final output sent to browser
DEBUG - 2014-02-19 12:57:28 --> Total execution time: 2.4621
DEBUG - 2014-02-19 12:58:54 --> Config Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:58:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:58:54 --> URI Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Router Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Output Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Security Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Input Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:58:54 --> Language Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Config Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Loader Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Controller Class Initialized
DEBUG - 2014-02-19 12:58:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:58:54 --> URI Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:58:54 --> Router Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Output Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Security Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Input Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:58:54 --> Language Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:58:54 --> Loader Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Controller Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:58:54 --> Session Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:58:54 --> Session routines successfully run
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:58:54 --> Final output sent to browser
DEBUG - 2014-02-19 12:58:54 --> Total execution time: 0.0160
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:58:54 --> Session Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:58:54 --> Session routines successfully run
DEBUG - 2014-02-19 12:58:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:58:54 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:58:54 --> Final output sent to browser
DEBUG - 2014-02-19 12:58:54 --> Total execution time: 0.0170
DEBUG - 2014-02-19 12:58:59 --> Config Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:58:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:58:59 --> URI Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Router Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Output Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Security Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Input Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:58:59 --> Language Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Loader Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Controller Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:58:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:58:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:58:59 --> Session Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 12:58:59 --> Session routines successfully run
DEBUG - 2014-02-19 12:58:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 12:58:59 --> Model Class Initialized
DEBUG - 2014-02-19 12:58:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:58:59 --> Final output sent to browser
DEBUG - 2014-02-19 12:58:59 --> Total execution time: 0.0200
DEBUG - 2014-02-19 12:59:21 --> Config Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:59:21 --> URI Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Router Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Output Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Security Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Input Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:59:21 --> Language Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Loader Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Controller Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:59:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:59:21 --> Model Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Model Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:59:21 --> Final output sent to browser
DEBUG - 2014-02-19 12:59:21 --> Total execution time: 0.0160
DEBUG - 2014-02-19 12:59:27 --> Config Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 12:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 12:59:27 --> URI Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Router Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Output Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Security Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Input Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 12:59:27 --> Language Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Loader Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Controller Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 12:59:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 12:59:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:59:27 --> Upload Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Image Lib Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Model Class Initialized
DEBUG - 2014-02-19 12:59:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 12:59:29 --> Final output sent to browser
DEBUG - 2014-02-19 12:59:29 --> Total execution time: 2.2721
DEBUG - 2014-02-19 13:01:23 --> Config Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:01:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:01:23 --> URI Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Router Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Output Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Security Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Input Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:01:23 --> Language Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Loader Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Controller Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:01:23 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:01:23 --> Model Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Model Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Model Class Initialized
DEBUG - 2014-02-19 13:01:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:01:25 --> Final output sent to browser
DEBUG - 2014-02-19 13:01:25 --> Total execution time: 2.2351
DEBUG - 2014-02-19 13:11:58 --> Config Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:11:58 --> URI Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Router Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Output Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Security Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Input Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:11:58 --> Language Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Loader Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Controller Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Config Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> URI Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:11:58 --> Router Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Session Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Output Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:11:58 --> A session cookie was not found.
DEBUG - 2014-02-19 13:11:58 --> Security Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Session routines successfully run
DEBUG - 2014-02-19 13:11:58 --> Input Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:11:58 --> Language Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:11:58 --> Loader Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Controller Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:11:58 --> Final output sent to browser
DEBUG - 2014-02-19 13:11:58 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:11:58 --> Session Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:11:58 --> A session cookie was not found.
DEBUG - 2014-02-19 13:11:58 --> Session routines successfully run
DEBUG - 2014-02-19 13:11:58 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:11:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:11:58 --> Final output sent to browser
DEBUG - 2014-02-19 13:11:58 --> Total execution time: 0.0180
DEBUG - 2014-02-19 13:12:01 --> Config Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Config Class Initialized
DEBUG - 2014-02-19 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:12:01 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:12:01 --> URI Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:12:01 --> Router Class Initialized
DEBUG - 2014-02-19 13:12:01 --> URI Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Router Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Output Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Output Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Security Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Security Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Input Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Input Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:12:01 --> Language Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Language Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Loader Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Loader Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Controller Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Controller Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:01 --> Session Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Session Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:12:01 --> A session cookie was not found.
DEBUG - 2014-02-19 13:12:01 --> A session cookie was not found.
DEBUG - 2014-02-19 13:12:01 --> Session routines successfully run
DEBUG - 2014-02-19 13:12:01 --> Session routines successfully run
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:12:01 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:01 --> Final output sent to browser
DEBUG - 2014-02-19 13:12:01 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:12:01 --> Final output sent to browser
DEBUG - 2014-02-19 13:12:01 --> Total execution time: 0.0230
DEBUG - 2014-02-19 13:12:06 --> Config Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:12:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:12:06 --> URI Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Router Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Output Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Security Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Input Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:12:06 --> Language Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Loader Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Controller Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:12:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:12:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:06 --> Session Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:12:06 --> A session cookie was not found.
DEBUG - 2014-02-19 13:12:06 --> Session routines successfully run
DEBUG - 2014-02-19 13:12:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:12:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:06 --> Final output sent to browser
DEBUG - 2014-02-19 13:12:06 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:12:08 --> Config Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:12:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:12:08 --> URI Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Router Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Output Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Security Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Input Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:12:08 --> Language Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Loader Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Controller Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:12:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:12:08 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:08 --> Session Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:12:08 --> A session cookie was not found.
DEBUG - 2014-02-19 13:12:08 --> Session routines successfully run
DEBUG - 2014-02-19 13:12:08 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:12:08 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:12:08 --> Final output sent to browser
DEBUG - 2014-02-19 13:12:08 --> Total execution time: 0.0180
DEBUG - 2014-02-19 13:12:55 --> Config Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:12:55 --> URI Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Router Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Output Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Security Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Input Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:12:55 --> Language Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Loader Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Controller Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:12:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:12:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:12:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:12:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:13:01 --> Final output sent to browser
DEBUG - 2014-02-19 13:13:01 --> Total execution time: 6.0003
DEBUG - 2014-02-19 13:13:12 --> Config Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:13:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:13:12 --> URI Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Router Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Output Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Security Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Input Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:13:12 --> Language Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Loader Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Controller Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:13:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:13:12 --> Model Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Model Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:13:12 --> Final output sent to browser
DEBUG - 2014-02-19 13:13:12 --> Total execution time: 0.0150
DEBUG - 2014-02-19 13:13:13 --> Config Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:13:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:13:13 --> URI Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Router Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Output Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Security Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Input Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:13:13 --> Language Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Loader Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Controller Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:13:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:13:13 --> Model Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Model Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Model Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:13:13 --> Upload Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Model Class Initialized
DEBUG - 2014-02-19 13:13:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:13:15 --> Final output sent to browser
DEBUG - 2014-02-19 13:13:15 --> Total execution time: 2.3331
DEBUG - 2014-02-19 13:14:17 --> Config Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:14:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:14:17 --> URI Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Router Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Output Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Security Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Input Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:14:17 --> Language Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Loader Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Controller Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:14:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:14:17 --> Model Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Model Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Model Class Initialized
DEBUG - 2014-02-19 13:14:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:14:19 --> Final output sent to browser
DEBUG - 2014-02-19 13:14:19 --> Total execution time: 2.2121
DEBUG - 2014-02-19 13:18:32 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:32 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:32 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:32 --> Session Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:18:32 --> A session cookie was not found.
DEBUG - 2014-02-19 13:18:32 --> Session routines successfully run
DEBUG - 2014-02-19 13:18:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:18:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:32 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:32 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:18:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Session Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:18:33 --> A session cookie was not found.
DEBUG - 2014-02-19 13:18:33 --> Session Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Session routines successfully run
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:18:33 --> A session cookie was not found.
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Session routines successfully run
DEBUG - 2014-02-19 13:18:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:18:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:33 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:33 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:18:33 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:33 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:18:37 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:37 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:37 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:37 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:37 --> Session Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Session Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:18:37 --> A session cookie was not found.
DEBUG - 2014-02-19 13:18:37 --> A session cookie was not found.
DEBUG - 2014-02-19 13:18:37 --> Session routines successfully run
DEBUG - 2014-02-19 13:18:37 --> Session routines successfully run
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:18:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:37 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:37 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:37 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:18:37 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:18:38 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:38 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:38 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:38 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:38 --> Session Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:18:38 --> A session cookie was not found.
DEBUG - 2014-02-19 13:18:38 --> Session routines successfully run
DEBUG - 2014-02-19 13:18:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:18:38 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:38 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:38 --> Total execution time: 0.0170
DEBUG - 2014-02-19 13:18:54 --> Config Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:18:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:18:54 --> URI Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Router Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Output Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Security Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Input Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:18:54 --> Language Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Loader Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Controller Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:18:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:18:54 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:18:54 --> Model Class Initialized
DEBUG - 2014-02-19 13:18:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:18:58 --> Final output sent to browser
DEBUG - 2014-02-19 13:18:58 --> Total execution time: 4.4323
DEBUG - 2014-02-19 13:19:32 --> Config Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:19:32 --> URI Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Router Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Output Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Security Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Input Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:19:32 --> Language Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Loader Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Controller Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:19:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:19:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:19:32 --> Final output sent to browser
DEBUG - 2014-02-19 13:19:32 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:19:42 --> Config Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:19:42 --> URI Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Router Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Output Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Security Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Input Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:19:42 --> Language Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Loader Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Controller Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:19:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:19:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:19:42 --> Upload Class Initialized
DEBUG - 2014-02-19 13:19:42 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:19:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:19:45 --> Final output sent to browser
DEBUG - 2014-02-19 13:19:45 --> Total execution time: 2.4261
DEBUG - 2014-02-19 13:19:53 --> Config Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:19:53 --> URI Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Router Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Output Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Security Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Input Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:19:53 --> Language Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Loader Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Controller Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:19:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:19:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:19:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:19:57 --> Final output sent to browser
DEBUG - 2014-02-19 13:19:57 --> Total execution time: 3.8002
DEBUG - 2014-02-19 13:21:04 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:04 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:04 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:04 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:04 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:04 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:04 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:04 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:21:09 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:09 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:09 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:09 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:09 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:09 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:09 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:09 --> Total execution time: 0.0170
DEBUG - 2014-02-19 13:21:10 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:10 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:10 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:10 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:10 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:10 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:10 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:10 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:10 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:10 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:10 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:21:10 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:10 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:10 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:21:14 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:14 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:14 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:14 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:14 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:14 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:14 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:14 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:14 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:21:15 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:15 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:15 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:15 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:15 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:15 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:15 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:15 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:15 --> Total execution time: 0.0180
DEBUG - 2014-02-19 13:21:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:36 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:36 --> Total execution time: 3.3672
DEBUG - 2014-02-19 13:21:55 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Config Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:21:55 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:55 --> URI Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Router Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Output Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Security Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Input Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:21:55 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Language Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Loader Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Controller Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:55 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Session Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:21:55 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:55 --> A session cookie was not found.
DEBUG - 2014-02-19 13:21:55 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:55 --> Session routines successfully run
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:55 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Model Class Initialized
DEBUG - 2014-02-19 13:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:21:55 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:55 --> Final output sent to browser
DEBUG - 2014-02-19 13:21:55 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:21:55 --> Total execution time: 0.0230
DEBUG - 2014-02-19 13:22:00 --> Config Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:22:00 --> URI Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Router Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Output Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Security Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Input Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:22:00 --> Language Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Loader Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Controller Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:22:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:22:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:22:00 --> Session Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:22:00 --> A session cookie was not found.
DEBUG - 2014-02-19 13:22:00 --> Session routines successfully run
DEBUG - 2014-02-19 13:22:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:22:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:22:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:22:00 --> Final output sent to browser
DEBUG - 2014-02-19 13:22:00 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:31:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:31:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:31:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:31:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:31:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:31:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:21 --> Session Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Session Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:31:21 --> A session cookie was not found.
DEBUG - 2014-02-19 13:31:21 --> A session cookie was not found.
DEBUG - 2014-02-19 13:31:21 --> Session routines successfully run
DEBUG - 2014-02-19 13:31:21 --> Session routines successfully run
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:31:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:31:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:31:21 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:31:21 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:31:26 --> Config Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:31:26 --> URI Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Router Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Output Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Security Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Input Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:31:26 --> Language Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Loader Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Controller Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:31:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:31:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:26 --> Session Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:31:26 --> A session cookie was not found.
DEBUG - 2014-02-19 13:31:26 --> Session routines successfully run
DEBUG - 2014-02-19 13:31:26 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:31:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:26 --> Final output sent to browser
DEBUG - 2014-02-19 13:31:26 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:31:44 --> Config Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:31:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:31:44 --> URI Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Router Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Output Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Security Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Input Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:31:44 --> Language Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Loader Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Controller Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:31:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:31:44 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:31:44 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:44 --> Final output sent to browser
DEBUG - 2014-02-19 13:31:44 --> Total execution time: 0.0170
DEBUG - 2014-02-19 13:31:53 --> Config Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:31:53 --> URI Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Router Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Output Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Security Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Input Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:31:53 --> Language Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Loader Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Controller Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:31:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:31:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:31:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:31:53 --> Final output sent to browser
DEBUG - 2014-02-19 13:31:53 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:32:18 --> Config Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:32:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:32:18 --> URI Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Router Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Output Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Security Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Input Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:32:18 --> Language Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Loader Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Controller Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:32:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:32:18 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:32:18 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:32:23 --> Final output sent to browser
DEBUG - 2014-02-19 13:32:23 --> Total execution time: 4.5493
DEBUG - 2014-02-19 13:32:29 --> Config Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:32:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:32:29 --> URI Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Router Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Output Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Security Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Input Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:32:29 --> Language Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Loader Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Controller Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:32:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:32:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:32:29 --> Final output sent to browser
DEBUG - 2014-02-19 13:32:29 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:32:39 --> Config Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:32:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:32:39 --> URI Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Router Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Output Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Security Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Input Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:32:39 --> Language Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Loader Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Controller Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:32:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:32:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:32:39 --> Upload Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:32:41 --> Final output sent to browser
DEBUG - 2014-02-19 13:32:41 --> Total execution time: 2.3311
DEBUG - 2014-02-19 13:32:41 --> Config Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:32:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:32:41 --> URI Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Router Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Output Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Security Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Input Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:32:41 --> Language Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Loader Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Controller Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:32:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:32:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:32:43 --> Final output sent to browser
DEBUG - 2014-02-19 13:32:43 --> Total execution time: 2.3041
DEBUG - 2014-02-19 13:32:57 --> Config Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:32:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:32:57 --> URI Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Router Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Output Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Security Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Input Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:32:57 --> Language Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Loader Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Controller Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:32:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:32:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:32:57 --> Session Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:32:57 --> A session cookie was not found.
DEBUG - 2014-02-19 13:32:57 --> Session routines successfully run
DEBUG - 2014-02-19 13:32:57 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:32:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:32:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:32:57 --> Final output sent to browser
DEBUG - 2014-02-19 13:32:57 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:33:02 --> Config Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:33:02 --> Config Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:33:02 --> URI Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:33:02 --> Router Class Initialized
DEBUG - 2014-02-19 13:33:02 --> URI Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Router Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Output Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Security Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Output Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Input Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Security Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:33:02 --> Input Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:33:02 --> Language Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Language Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Loader Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Loader Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Controller Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Controller Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:02 --> Session Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Session Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:33:02 --> A session cookie was not found.
DEBUG - 2014-02-19 13:33:02 --> A session cookie was not found.
DEBUG - 2014-02-19 13:33:02 --> Session routines successfully run
DEBUG - 2014-02-19 13:33:02 --> Session routines successfully run
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:33:02 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:02 --> Final output sent to browser
DEBUG - 2014-02-19 13:33:02 --> Final output sent to browser
DEBUG - 2014-02-19 13:33:02 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:33:02 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:33:12 --> Config Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:33:12 --> URI Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Router Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Output Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Security Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Input Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:33:12 --> Language Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Loader Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Controller Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:33:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:33:12 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:33:12 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:16 --> Final output sent to browser
DEBUG - 2014-02-19 13:33:16 --> Total execution time: 4.5353
DEBUG - 2014-02-19 13:33:29 --> Config Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:33:29 --> URI Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Router Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Output Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Security Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Input Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:33:29 --> Language Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Loader Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Controller Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:33:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:33:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:33:29 --> Final output sent to browser
DEBUG - 2014-02-19 13:33:29 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:33:39 --> Config Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:33:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:33:39 --> URI Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Router Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Output Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Security Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Input Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:33:39 --> Language Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Loader Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Controller Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:33:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:33:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:39 --> Upload Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:42 --> Final output sent to browser
DEBUG - 2014-02-19 13:33:42 --> Total execution time: 2.3081
DEBUG - 2014-02-19 13:33:42 --> Config Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:33:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:33:42 --> URI Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Router Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Output Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Security Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Input Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:33:42 --> Language Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Loader Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Controller Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:33:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:33:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:33:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:33:44 --> Final output sent to browser
DEBUG - 2014-02-19 13:33:44 --> Total execution time: 2.2381
DEBUG - 2014-02-19 13:34:46 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:46 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:46 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:46 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:46 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:46 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:46 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:46 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:46 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:46 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:46 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:34:47 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:47 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:47 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:47 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:47 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:47 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:47 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:47 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:47 --> Total execution time: 0.0170
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:47 --> Total execution time: 0.0170
DEBUG - 2014-02-19 13:34:47 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:47 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:47 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:47 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:47 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:47 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:47 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:47 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:47 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:47 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:47 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:47 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:47 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:47 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:47 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:47 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:47 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:34:47 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:34:47 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:47 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:47 --> Total execution time: 0.0180
DEBUG - 2014-02-19 13:34:51 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:51 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:51 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:51 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:51 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Session Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:34:51 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:51 --> A session cookie was not found.
DEBUG - 2014-02-19 13:34:51 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:51 --> Session routines successfully run
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:34:51 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:51 --> Final output sent to browser
DEBUG - 2014-02-19 13:34:51 --> Total execution time: 0.0150
DEBUG - 2014-02-19 13:34:51 --> Total execution time: 0.0160
DEBUG - 2014-02-19 13:34:57 --> Config Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:34:57 --> URI Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Router Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Output Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Security Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Input Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:34:57 --> Language Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Loader Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Controller Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:34:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:34:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:34:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:34:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:35:02 --> Config Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:35:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:35:02 --> URI Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Router Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Output Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Security Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Input Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:35:02 --> Language Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Loader Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Controller Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:35:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:35:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:35:02 --> Session Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:35:02 --> A session cookie was not found.
DEBUG - 2014-02-19 13:35:02 --> Session routines successfully run
DEBUG - 2014-02-19 13:35:02 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:35:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:35:02 --> Final output sent to browser
DEBUG - 2014-02-19 13:35:02 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:35:02 --> Final output sent to browser
DEBUG - 2014-02-19 13:35:02 --> Total execution time: 4.4693
DEBUG - 2014-02-19 13:35:07 --> Config Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:35:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:35:07 --> URI Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Router Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Output Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Security Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Input Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:35:07 --> Language Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Loader Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Controller Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:35:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:35:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:35:07 --> Final output sent to browser
DEBUG - 2014-02-19 13:35:07 --> Total execution time: 0.0130
DEBUG - 2014-02-19 13:35:22 --> Config Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:35:22 --> URI Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Router Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Output Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Security Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Input Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:35:22 --> Language Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Loader Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Controller Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:35:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:35:22 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:35:22 --> Upload Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:35:24 --> Final output sent to browser
DEBUG - 2014-02-19 13:35:24 --> Total execution time: 2.2911
DEBUG - 2014-02-19 13:35:34 --> Config Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:35:34 --> URI Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Router Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Output Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Security Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Input Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:35:34 --> Language Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Loader Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Controller Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:35:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:35:34 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Model Class Initialized
DEBUG - 2014-02-19 13:35:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:35:37 --> Final output sent to browser
DEBUG - 2014-02-19 13:35:37 --> Total execution time: 2.2461
DEBUG - 2014-02-19 13:37:57 --> Config Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:37:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:37:57 --> URI Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Router Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Output Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Security Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Input Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:37:57 --> Language Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Loader Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Controller Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:37:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:37:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:37:57 --> Session Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:37:57 --> A session cookie was not found.
DEBUG - 2014-02-19 13:37:57 --> Session routines successfully run
DEBUG - 2014-02-19 13:37:57 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:37:57 --> Model Class Initialized
DEBUG - 2014-02-19 13:37:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:37:57 --> Final output sent to browser
DEBUG - 2014-02-19 13:37:57 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:38:02 --> Config Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:38:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:38:02 --> URI Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Router Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Output Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Security Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Input Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:38:02 --> Language Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Loader Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Controller Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:38:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:38:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:02 --> Session Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:38:02 --> A session cookie was not found.
DEBUG - 2014-02-19 13:38:02 --> Session routines successfully run
DEBUG - 2014-02-19 13:38:02 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:38:02 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:02 --> Final output sent to browser
DEBUG - 2014-02-19 13:38:02 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:38:07 --> Config Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:38:07 --> URI Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Router Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Output Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Security Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Input Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:38:07 --> Language Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Loader Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Controller Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:38:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:38:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:07 --> Session Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:38:07 --> A session cookie was not found.
DEBUG - 2014-02-19 13:38:07 --> Session routines successfully run
DEBUG - 2014-02-19 13:38:07 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:38:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:07 --> Final output sent to browser
DEBUG - 2014-02-19 13:38:07 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:38:29 --> Config Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:38:29 --> URI Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Router Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Output Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Security Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Input Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:38:29 --> Language Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Loader Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Controller Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:38:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:31 --> Final output sent to browser
DEBUG - 2014-02-19 13:38:31 --> Total execution time: 2.2341
DEBUG - 2014-02-19 13:38:53 --> Config Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Config Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:38:53 --> URI Class Initialized
DEBUG - 2014-02-19 13:38:53 --> URI Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Router Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Router Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Output Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Output Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Security Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Security Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Input Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Input Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:38:53 --> Language Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Language Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Loader Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Loader Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Controller Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Controller Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:53 --> Session Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Session Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:38:53 --> A session cookie was not found.
DEBUG - 2014-02-19 13:38:53 --> A session cookie was not found.
DEBUG - 2014-02-19 13:38:53 --> Session routines successfully run
DEBUG - 2014-02-19 13:38:53 --> Session routines successfully run
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:38:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:53 --> Final output sent to browser
DEBUG - 2014-02-19 13:38:53 --> Final output sent to browser
DEBUG - 2014-02-19 13:38:53 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:38:53 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:38:58 --> Config Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:38:58 --> URI Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Router Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Output Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Security Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Input Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:38:58 --> Language Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Loader Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Controller Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:38:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:38:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:58 --> Session Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:38:58 --> A session cookie was not found.
DEBUG - 2014-02-19 13:38:58 --> Session routines successfully run
DEBUG - 2014-02-19 13:38:58 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:38:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:38:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:38:58 --> Final output sent to browser
DEBUG - 2014-02-19 13:38:58 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:39:14 --> Config Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:39:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:39:14 --> URI Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Router Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Output Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Security Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Input Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:39:14 --> Language Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Loader Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Controller Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:39:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:39:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:39:14 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:39:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:39:21 --> Total execution time: 7.5334
DEBUG - 2014-02-19 13:39:30 --> Config Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:39:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:39:30 --> URI Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Router Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Output Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Security Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Input Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:39:30 --> Language Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Loader Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Controller Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:39:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:39:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:39:30 --> Final output sent to browser
DEBUG - 2014-02-19 13:39:30 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:39:35 --> Config Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:39:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:39:35 --> URI Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Router Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Output Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Security Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Input Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:39:35 --> Language Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Loader Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Controller Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:39:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:39:35 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:39:35 --> Upload Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:39:37 --> Final output sent to browser
DEBUG - 2014-02-19 13:39:37 --> Total execution time: 2.3231
DEBUG - 2014-02-19 13:39:42 --> Config Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:39:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:39:42 --> URI Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Router Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Output Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Security Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Input Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:39:42 --> Language Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Loader Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Controller Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:39:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:39:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Model Class Initialized
DEBUG - 2014-02-19 13:39:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:39:45 --> Final output sent to browser
DEBUG - 2014-02-19 13:39:45 --> Total execution time: 2.2001
DEBUG - 2014-02-19 13:40:45 --> Config Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Config Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:40:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:40:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:40:45 --> URI Class Initialized
DEBUG - 2014-02-19 13:40:45 --> URI Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Router Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Router Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Output Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Output Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Security Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Security Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Input Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Input Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:40:45 --> Language Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Language Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Loader Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Loader Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Controller Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Controller Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:40:45 --> Session Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Session Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:40:45 --> A session cookie was not found.
DEBUG - 2014-02-19 13:40:45 --> A session cookie was not found.
DEBUG - 2014-02-19 13:40:45 --> Session routines successfully run
DEBUG - 2014-02-19 13:40:45 --> Session routines successfully run
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:40:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:40:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:40:45 --> Final output sent to browser
DEBUG - 2014-02-19 13:40:45 --> Final output sent to browser
DEBUG - 2014-02-19 13:40:45 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:40:45 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:40:50 --> Config Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:40:50 --> URI Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Router Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Output Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Security Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Input Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:40:50 --> Language Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Loader Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Controller Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:40:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:40:50 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:40:50 --> Session Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:40:50 --> A session cookie was not found.
DEBUG - 2014-02-19 13:40:50 --> Session routines successfully run
DEBUG - 2014-02-19 13:40:50 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:40:50 --> Model Class Initialized
DEBUG - 2014-02-19 13:40:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:40:50 --> Final output sent to browser
DEBUG - 2014-02-19 13:40:50 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:41:00 --> Config Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:41:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:41:00 --> URI Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Router Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Output Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Security Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Input Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:41:00 --> Language Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Loader Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Controller Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:41:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:41:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:41:00 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:41:04 --> Final output sent to browser
DEBUG - 2014-02-19 13:41:04 --> Total execution time: 4.5703
DEBUG - 2014-02-19 13:41:15 --> Config Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:41:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:41:15 --> URI Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Router Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Output Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Security Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Input Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:41:15 --> Language Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Loader Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Controller Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:41:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:41:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:41:15 --> Final output sent to browser
DEBUG - 2014-02-19 13:41:15 --> Total execution time: 0.0110
DEBUG - 2014-02-19 13:41:25 --> Config Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:41:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:41:25 --> URI Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Router Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Output Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Security Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Input Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:41:25 --> Language Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Loader Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Controller Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:41:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:41:25 --> Upload Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:41:28 --> Final output sent to browser
DEBUG - 2014-02-19 13:41:28 --> Total execution time: 2.4201
DEBUG - 2014-02-19 13:41:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:41:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:41:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:41:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:41:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:41:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:41:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:41:35 --> Final output sent to browser
DEBUG - 2014-02-19 13:41:35 --> Total execution time: 2.1931
DEBUG - 2014-02-19 13:42:48 --> Config Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:42:48 --> URI Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Router Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Output Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Security Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Input Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:42:48 --> Language Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Loader Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Controller Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:42:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:42:48 --> Session Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:42:48 --> A session cookie was not found.
DEBUG - 2014-02-19 13:42:48 --> Session routines successfully run
DEBUG - 2014-02-19 13:42:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:42:48 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:42:48 --> Final output sent to browser
DEBUG - 2014-02-19 13:42:48 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:42:53 --> Config Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:42:53 --> URI Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Router Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Output Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Security Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Input Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:42:53 --> Language Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Loader Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Controller Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:42:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:42:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:42:53 --> Session Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:42:53 --> A session cookie was not found.
DEBUG - 2014-02-19 13:42:53 --> Session routines successfully run
DEBUG - 2014-02-19 13:42:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:42:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:42:53 --> Final output sent to browser
DEBUG - 2014-02-19 13:42:53 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:42:58 --> Config Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:42:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:42:58 --> URI Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Router Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Output Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Security Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Input Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:42:58 --> Language Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Loader Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Controller Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:42:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:42:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:42:58 --> Session Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:42:58 --> A session cookie was not found.
DEBUG - 2014-02-19 13:42:58 --> Session routines successfully run
DEBUG - 2014-02-19 13:42:58 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:42:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:42:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:42:58 --> Final output sent to browser
DEBUG - 2014-02-19 13:42:58 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:43:07 --> Config Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:43:07 --> URI Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Router Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Output Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Security Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Input Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:43:07 --> Language Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Loader Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Controller Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:43:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:43:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:43:07 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:43:11 --> Final output sent to browser
DEBUG - 2014-02-19 13:43:11 --> Total execution time: 4.4243
DEBUG - 2014-02-19 13:43:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:43:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:43:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:43:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:43:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:43:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:43:21 --> Total execution time: 0.0150
DEBUG - 2014-02-19 13:43:26 --> Config Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:43:26 --> URI Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Router Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Output Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Security Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Input Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:43:26 --> Language Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Loader Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Controller Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:43:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:43:26 --> Upload Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:43:28 --> Final output sent to browser
DEBUG - 2014-02-19 13:43:28 --> Total execution time: 2.2971
DEBUG - 2014-02-19 13:43:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:43:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:43:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:43:36 --> Final output sent to browser
DEBUG - 2014-02-19 13:43:36 --> Total execution time: 2.2131
DEBUG - 2014-02-19 13:44:10 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:10 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:10 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:10 --> Session Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:44:10 --> A session cookie was not found.
DEBUG - 2014-02-19 13:44:10 --> Session routines successfully run
DEBUG - 2014-02-19 13:44:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:44:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:10 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:10 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:44:15 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:15 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:15 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:15 --> Session Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:44:15 --> A session cookie was not found.
DEBUG - 2014-02-19 13:44:15 --> Session routines successfully run
DEBUG - 2014-02-19 13:44:15 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:44:15 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:15 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:15 --> Total execution time: 0.0200
DEBUG - 2014-02-19 13:44:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:21 --> Session Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Session Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Session Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:44:21 --> A session cookie was not found.
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:44:21 --> A session cookie was not found.
DEBUG - 2014-02-19 13:44:21 --> A session cookie was not found.
DEBUG - 2014-02-19 13:44:21 --> Session routines successfully run
DEBUG - 2014-02-19 13:44:21 --> Session routines successfully run
DEBUG - 2014-02-19 13:44:21 --> Session routines successfully run
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:44:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:21 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:21 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:44:21 --> Total execution time: 0.0210
DEBUG - 2014-02-19 13:44:21 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:44:25 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:25 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:25 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:25 --> Session Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:44:25 --> A session cookie was not found.
DEBUG - 2014-02-19 13:44:25 --> Session routines successfully run
DEBUG - 2014-02-19 13:44:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:44:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:25 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:25 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:44:31 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:31 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:31 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:31 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:44:31 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:36 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:36 --> Total execution time: 4.4353
DEBUG - 2014-02-19 13:44:53 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:53 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:53 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:53 --> Final output sent to browser
DEBUG - 2014-02-19 13:44:53 --> Total execution time: 0.0130
DEBUG - 2014-02-19 13:44:58 --> Config Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:44:58 --> URI Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Router Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Output Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Security Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Input Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:44:58 --> Language Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Loader Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Controller Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:44:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:44:58 --> Upload Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:44:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:00 --> Final output sent to browser
DEBUG - 2014-02-19 13:45:00 --> Total execution time: 2.3381
DEBUG - 2014-02-19 13:45:10 --> Config Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:45:10 --> URI Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Router Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Output Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Security Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Input Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:45:10 --> Language Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Loader Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Controller Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:45:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:45:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:12 --> Final output sent to browser
DEBUG - 2014-02-19 13:45:12 --> Total execution time: 2.2041
DEBUG - 2014-02-19 13:45:58 --> Config Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:45:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:45:58 --> URI Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Router Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Output Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Security Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Input Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:45:58 --> Language Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Loader Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Controller Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:45:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:45:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:58 --> Session Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:45:58 --> A session cookie was not found.
DEBUG - 2014-02-19 13:45:58 --> Session routines successfully run
DEBUG - 2014-02-19 13:45:58 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:45:58 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:58 --> Final output sent to browser
DEBUG - 2014-02-19 13:45:58 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:45:59 --> Config Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:45:59 --> URI Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Router Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Output Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Security Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Config Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Input Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:45:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:45:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:45:59 --> Language Class Initialized
DEBUG - 2014-02-19 13:45:59 --> URI Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Loader Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Router Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Controller Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:45:59 --> Output Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:45:59 --> Security Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Input Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:45:59 --> Language Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Loader Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Controller Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Session Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:45:59 --> A session cookie was not found.
DEBUG - 2014-02-19 13:45:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Session routines successfully run
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:59 --> Session Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Final output sent to browser
DEBUG - 2014-02-19 13:45:59 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:45:59 --> A session cookie was not found.
DEBUG - 2014-02-19 13:45:59 --> Session routines successfully run
DEBUG - 2014-02-19 13:45:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:45:59 --> Model Class Initialized
DEBUG - 2014-02-19 13:45:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:45:59 --> Final output sent to browser
DEBUG - 2014-02-19 13:45:59 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:46:01 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:01 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:01 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:01 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:01 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:01 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:01 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:01 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:01 --> Session Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Session Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Session Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:46:01 --> A session cookie was not found.
DEBUG - 2014-02-19 13:46:01 --> A session cookie was not found.
DEBUG - 2014-02-19 13:46:01 --> A session cookie was not found.
DEBUG - 2014-02-19 13:46:01 --> Session routines successfully run
DEBUG - 2014-02-19 13:46:01 --> Session routines successfully run
DEBUG - 2014-02-19 13:46:01 --> Session routines successfully run
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:46:01 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:01 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:01 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:01 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:01 --> Total execution time: 0.0160
DEBUG - 2014-02-19 13:46:01 --> Total execution time: 0.0180
DEBUG - 2014-02-19 13:46:01 --> Total execution time: 0.0180
DEBUG - 2014-02-19 13:46:03 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:03 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:03 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:03 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:03 --> Session Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Session Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:46:03 --> A session cookie was not found.
DEBUG - 2014-02-19 13:46:03 --> A session cookie was not found.
DEBUG - 2014-02-19 13:46:03 --> Session routines successfully run
DEBUG - 2014-02-19 13:46:03 --> Session routines successfully run
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:46:03 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:03 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:03 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:03 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:46:03 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:46:04 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:04 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:04 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:04 --> Session Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:46:04 --> A session cookie was not found.
DEBUG - 2014-02-19 13:46:04 --> Session routines successfully run
DEBUG - 2014-02-19 13:46:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:46:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:04 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:04 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:46:21 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:21 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:21 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:46:21 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:25 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:25 --> Total execution time: 4.4383
DEBUG - 2014-02-19 13:46:32 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:32 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:32 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:32 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:32 --> Total execution time: 0.0130
DEBUG - 2014-02-19 13:46:37 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:37 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:37 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:37 --> Upload Class Initialized
DEBUG - 2014-02-19 13:46:37 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:46:38 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:40 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:40 --> Total execution time: 2.3961
DEBUG - 2014-02-19 13:46:40 --> Config Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:46:40 --> URI Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Router Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Output Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Security Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Input Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:46:40 --> Language Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Loader Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Controller Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:46:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 13:46:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:46:45 --> Final output sent to browser
DEBUG - 2014-02-19 13:46:45 --> Total execution time: 5.2143
DEBUG - 2014-02-19 13:47:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Config Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:47:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:47:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:47:33 --> URI Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Router Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Output Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Security Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Input Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:47:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Language Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Loader Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Controller Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:47:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:47:33 --> Session Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Session Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:47:33 --> A session cookie was not found.
DEBUG - 2014-02-19 13:47:33 --> A session cookie was not found.
DEBUG - 2014-02-19 13:47:33 --> Session routines successfully run
DEBUG - 2014-02-19 13:47:33 --> Session routines successfully run
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:47:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:47:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:47:33 --> Final output sent to browser
DEBUG - 2014-02-19 13:47:33 --> Final output sent to browser
DEBUG - 2014-02-19 13:47:33 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:47:33 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:47:43 --> Config Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:47:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:47:43 --> URI Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Router Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Output Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Security Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Input Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:47:43 --> Language Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Loader Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Controller Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:47:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:47:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:47:43 --> Session Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:47:43 --> A session cookie was not found.
DEBUG - 2014-02-19 13:47:43 --> Session routines successfully run
DEBUG - 2014-02-19 13:47:43 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:47:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:47:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:47:43 --> Final output sent to browser
DEBUG - 2014-02-19 13:47:43 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:48:04 --> Config Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:48:04 --> URI Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Router Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Output Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Security Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Input Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:48:04 --> Language Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Loader Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Controller Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:48:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Helper loaded: email_helper
DEBUG - 2014-02-19 13:48:04 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:48:09 --> Final output sent to browser
DEBUG - 2014-02-19 13:48:09 --> Total execution time: 4.4373
DEBUG - 2014-02-19 13:48:20 --> Config Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:48:20 --> URI Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Router Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Output Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Security Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Input Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:48:20 --> Language Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Loader Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Controller Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:48:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Final output sent to browser
DEBUG - 2014-02-19 13:48:20 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:48:20 --> Config Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:48:20 --> URI Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Router Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Output Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Security Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Input Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:48:20 --> Language Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Loader Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Controller Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:48:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:48:20 --> Upload Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Image Lib Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:48:22 --> Final output sent to browser
DEBUG - 2014-02-19 13:48:22 --> Total execution time: 2.3151
DEBUG - 2014-02-19 13:48:32 --> Config Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:48:32 --> URI Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Router Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Output Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Security Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Input Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:48:32 --> Language Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Loader Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Controller Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:48:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:48:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Model Class Initialized
DEBUG - 2014-02-19 13:48:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:48:37 --> Final output sent to browser
DEBUG - 2014-02-19 13:48:37 --> Total execution time: 4.8623
DEBUG - 2014-02-19 13:49:01 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:01 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:01 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:01 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:01 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:01 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:01 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:06 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:06 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:06 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:06 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:06 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:06 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-19 13:49:06 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:06 --> Total execution time: 0.0190
DEBUG - 2014-02-19 13:49:09 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:09 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:09 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:09 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:09 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:09 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:09 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:19 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:19 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:19 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:19 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:19 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:19 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:19 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:19 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:24 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:25 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:25 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:25 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:25 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:25 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-19 13:49:25 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:25 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:49:25 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:25 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:25 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:25 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:25 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:25 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:25 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:25 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:25 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:25 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:25 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:25 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:25 --> Total execution time: 0.0140
DEBUG - 2014-02-19 13:49:25 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:25 --> Total execution time: 0.0270
DEBUG - 2014-02-19 13:49:27 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:27 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:27 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:27 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:27 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:27 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:27 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-19 13:49:27 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:27 --> Total execution time: 0.0220
DEBUG - 2014-02-19 13:49:30 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:30 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:30 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:30 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:30 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:30 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:30 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:30 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:30 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:30 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:30 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:30 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:30 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:30 --> Total execution time: 0.0280
DEBUG - 2014-02-19 13:49:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:30 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:30 --> Total execution time: 0.0290
DEBUG - 2014-02-19 13:49:30 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:30 --> Total execution time: 0.0350
DEBUG - 2014-02-19 13:49:56 --> Config Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:49:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:49:56 --> URI Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Router Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Output Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Security Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Input Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:49:56 --> Language Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Loader Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Controller Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:49:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:49:56 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Model Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:49:56 --> Session Class Initialized
DEBUG - 2014-02-19 13:49:56 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:49:56 --> Session routines successfully run
DEBUG - 2014-02-19 13:49:56 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:49:56 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-19 13:49:56 --> Final output sent to browser
DEBUG - 2014-02-19 13:49:56 --> Total execution time: 0.0240
DEBUG - 2014-02-19 13:50:19 --> Config Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:50:19 --> URI Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Router Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Output Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Security Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Input Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:50:19 --> Language Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Loader Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Controller Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:50:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:50:19 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:50:19 --> Session Class Initialized
DEBUG - 2014-02-19 13:50:19 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:50:19 --> Session routines successfully run
DEBUG - 2014-02-19 13:50:19 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:50:43 --> Config Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:50:43 --> URI Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Router Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Output Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Security Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Input Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:50:43 --> Language Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Loader Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Controller Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:50:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:50:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:50:43 --> Session Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:50:43 --> Session routines successfully run
DEBUG - 2014-02-19 13:50:43 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:50:43 --> Model Class Initialized
DEBUG - 2014-02-19 13:50:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:50:43 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-19 13:50:43 --> Final output sent to browser
DEBUG - 2014-02-19 13:50:43 --> Total execution time: 0.0670
DEBUG - 2014-02-19 13:51:41 --> Config Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:51:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:51:41 --> URI Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Router Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Output Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Security Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Input Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:51:41 --> Language Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Loader Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Controller Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:51:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:51:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:51:41 --> Session Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:51:41 --> Session routines successfully run
DEBUG - 2014-02-19 13:51:41 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:51:41 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:51:41 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-19 13:51:41 --> Final output sent to browser
DEBUG - 2014-02-19 13:51:41 --> Total execution time: 0.0410
DEBUG - 2014-02-19 13:51:49 --> Config Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 13:51:49 --> URI Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Router Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Output Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Security Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Input Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 13:51:49 --> Language Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Loader Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Controller Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 13:51:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 13:51:49 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Model Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 13:51:49 --> Session Class Initialized
DEBUG - 2014-02-19 13:51:49 --> Helper loaded: string_helper
DEBUG - 2014-02-19 13:51:49 --> Session routines successfully run
DEBUG - 2014-02-19 13:51:49 --> Helper loaded: url_helper
DEBUG - 2014-02-19 13:51:49 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-19 13:51:49 --> Final output sent to browser
DEBUG - 2014-02-19 13:51:49 --> Total execution time: 0.0240
DEBUG - 2014-02-19 14:42:12 --> Config Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:42:12 --> URI Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Router Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Output Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Security Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Input Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:42:12 --> Language Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Loader Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Controller Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:42:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:42:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:42:12 --> Session Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:42:12 --> A session cookie was not found.
DEBUG - 2014-02-19 14:42:12 --> Session routines successfully run
DEBUG - 2014-02-19 14:42:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:42:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:42:12 --> Final output sent to browser
DEBUG - 2014-02-19 14:42:12 --> Total execution time: 0.0130
DEBUG - 2014-02-19 14:42:17 --> Config Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:42:17 --> URI Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Router Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Output Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Security Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Input Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:42:17 --> Language Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Loader Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Controller Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:42:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:42:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:42:17 --> Session Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:42:17 --> A session cookie was not found.
DEBUG - 2014-02-19 14:42:17 --> Session routines successfully run
DEBUG - 2014-02-19 14:42:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:42:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:42:17 --> Final output sent to browser
DEBUG - 2014-02-19 14:42:17 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:42:22 --> Config Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:42:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:42:22 --> URI Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Router Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Output Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Security Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Input Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:42:22 --> Language Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Loader Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Controller Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:42:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:42:22 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:42:22 --> Session Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:42:22 --> A session cookie was not found.
DEBUG - 2014-02-19 14:42:22 --> Session routines successfully run
DEBUG - 2014-02-19 14:42:22 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:42:22 --> Model Class Initialized
DEBUG - 2014-02-19 14:42:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:42:22 --> Final output sent to browser
DEBUG - 2014-02-19 14:42:22 --> Total execution time: 0.0180
DEBUG - 2014-02-19 14:43:06 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:06 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:06 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:06 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:06 --> Session Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:43:06 --> A session cookie was not found.
DEBUG - 2014-02-19 14:43:06 --> Session routines successfully run
DEBUG - 2014-02-19 14:43:06 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:43:06 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:06 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:06 --> Total execution time: 0.0190
DEBUG - 2014-02-19 14:43:10 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:10 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:10 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:10 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:10 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:10 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:10 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:10 --> Session Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Session Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:43:10 --> A session cookie was not found.
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:43:10 --> Session routines successfully run
DEBUG - 2014-02-19 14:43:10 --> A session cookie was not found.
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:43:10 --> Session routines successfully run
DEBUG - 2014-02-19 14:43:10 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:10 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:10 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:10 --> Total execution time: 0.0210
DEBUG - 2014-02-19 14:43:10 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:10 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:43:11 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:11 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:11 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:11 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:11 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:11 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:11 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:11 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:11 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:11 --> Session Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:43:11 --> Session Class Initialized
DEBUG - 2014-02-19 14:43:11 --> A session cookie was not found.
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:43:11 --> Session routines successfully run
DEBUG - 2014-02-19 14:43:11 --> A session cookie was not found.
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:43:11 --> Session routines successfully run
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:43:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:11 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:11 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:11 --> Total execution time: 0.0210
DEBUG - 2014-02-19 14:43:11 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:11 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:43:15 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:15 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:15 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:15 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:15 --> Session Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:43:15 --> A session cookie was not found.
DEBUG - 2014-02-19 14:43:15 --> Session routines successfully run
DEBUG - 2014-02-19 14:43:15 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:43:15 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:15 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:15 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:43:43 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:43 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:43 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:43 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Helper loaded: email_helper
DEBUG - 2014-02-19 14:43:43 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:43 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:43 --> Total execution time: 0.0160
DEBUG - 2014-02-19 14:43:52 --> Config Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:43:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:43:52 --> URI Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Router Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Output Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Security Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Input Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:43:52 --> Language Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Loader Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Controller Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:43:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:43:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Helper loaded: email_helper
DEBUG - 2014-02-19 14:43:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:43:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:43:57 --> Final output sent to browser
DEBUG - 2014-02-19 14:43:57 --> Total execution time: 4.9773
DEBUG - 2014-02-19 14:44:18 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:18 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:18 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:18 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Final output sent to browser
DEBUG - 2014-02-19 14:44:18 --> Total execution time: 0.0140
DEBUG - 2014-02-19 14:44:18 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:18 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:18 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:18 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:18 --> Upload Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Image Lib Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:20 --> Final output sent to browser
DEBUG - 2014-02-19 14:44:20 --> Total execution time: 2.3201
DEBUG - 2014-02-19 14:44:27 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:27 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:27 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:27 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:30 --> Final output sent to browser
DEBUG - 2014-02-19 14:44:30 --> Total execution time: 2.2081
DEBUG - 2014-02-19 14:44:34 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:34 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:34 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:34 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:34 --> Session Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:44:34 --> A session cookie was not found.
DEBUG - 2014-02-19 14:44:34 --> Session routines successfully run
DEBUG - 2014-02-19 14:44:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:44:34 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:34 --> Final output sent to browser
DEBUG - 2014-02-19 14:44:34 --> Total execution time: 0.0210
DEBUG - 2014-02-19 14:44:39 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:39 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:39 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:39 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:39 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:39 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:39 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:39 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:39 --> Session Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Session Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:44:39 --> A session cookie was not found.
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:44:39 --> A session cookie was not found.
DEBUG - 2014-02-19 14:44:39 --> Session routines successfully run
DEBUG - 2014-02-19 14:44:39 --> Session routines successfully run
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:44:39 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:39 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:44:39 --> Final output sent to browser
DEBUG - 2014-02-19 14:44:39 --> Final output sent to browser
DEBUG - 2014-02-19 14:44:39 --> Total execution time: 0.0230
DEBUG - 2014-02-19 14:44:39 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:44:58 --> Config Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:44:58 --> URI Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Router Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Output Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Security Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Input Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:44:58 --> Language Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Loader Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Controller Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:44:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Helper loaded: email_helper
DEBUG - 2014-02-19 14:44:58 --> Model Class Initialized
DEBUG - 2014-02-19 14:44:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:45:03 --> Final output sent to browser
DEBUG - 2014-02-19 14:45:03 --> Total execution time: 4.4293
DEBUG - 2014-02-19 14:45:08 --> Config Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:45:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:45:08 --> URI Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Router Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Output Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Security Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Input Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:45:08 --> Language Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Loader Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Controller Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:45:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:45:08 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:45:08 --> Final output sent to browser
DEBUG - 2014-02-19 14:45:08 --> Total execution time: 0.0140
DEBUG - 2014-02-19 14:45:13 --> Config Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:45:13 --> URI Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Router Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Output Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Security Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Input Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:45:13 --> Language Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Loader Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Controller Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:45:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:45:13 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:45:13 --> Upload Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Image Lib Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:45:15 --> Final output sent to browser
DEBUG - 2014-02-19 14:45:15 --> Total execution time: 2.3101
DEBUG - 2014-02-19 14:45:25 --> Config Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:45:25 --> URI Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Router Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Output Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Security Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Input Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:45:25 --> Language Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Loader Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Controller Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:45:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:45:25 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Model Class Initialized
DEBUG - 2014-02-19 14:45:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:45:27 --> Final output sent to browser
DEBUG - 2014-02-19 14:45:27 --> Total execution time: 2.2101
DEBUG - 2014-02-19 14:46:12 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:12 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:12 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:12 --> Session Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:46:12 --> A session cookie was not found.
DEBUG - 2014-02-19 14:46:12 --> Session routines successfully run
DEBUG - 2014-02-19 14:46:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:46:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:12 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:12 --> Total execution time: 0.0110
DEBUG - 2014-02-19 14:46:14 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:14 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:14 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:14 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:14 --> Session Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Session Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:46:14 --> A session cookie was not found.
DEBUG - 2014-02-19 14:46:14 --> A session cookie was not found.
DEBUG - 2014-02-19 14:46:14 --> Session routines successfully run
DEBUG - 2014-02-19 14:46:14 --> Session routines successfully run
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:46:14 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:14 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:14 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:14 --> Total execution time: 0.0190
DEBUG - 2014-02-19 14:46:14 --> Total execution time: 0.0190
DEBUG - 2014-02-19 14:46:17 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:17 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:17 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:17 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:17 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:17 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:17 --> Session Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Session Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:46:17 --> A session cookie was not found.
DEBUG - 2014-02-19 14:46:17 --> A session cookie was not found.
DEBUG - 2014-02-19 14:46:17 --> Session routines successfully run
DEBUG - 2014-02-19 14:46:17 --> Session routines successfully run
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:46:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:17 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:17 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:17 --> Total execution time: 0.0220
DEBUG - 2014-02-19 14:46:17 --> Total execution time: 0.0240
DEBUG - 2014-02-19 14:46:19 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:19 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:19 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:19 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:19 --> Session Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:46:19 --> A session cookie was not found.
DEBUG - 2014-02-19 14:46:19 --> Session routines successfully run
DEBUG - 2014-02-19 14:46:19 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:46:19 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:19 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:19 --> Total execution time: 0.0180
DEBUG - 2014-02-19 14:46:27 --> Config Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:46:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:46:27 --> URI Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Router Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Output Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Security Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Input Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:46:27 --> Language Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Loader Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Controller Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:46:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Model Class Initialized
DEBUG - 2014-02-19 14:46:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:46:30 --> Final output sent to browser
DEBUG - 2014-02-19 14:46:30 --> Total execution time: 2.2851
DEBUG - 2014-02-19 14:48:12 --> Config Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Config Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:48:12 --> URI Class Initialized
DEBUG - 2014-02-19 14:48:12 --> URI Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Router Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Router Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Output Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Output Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Security Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Security Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Input Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Input Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:48:12 --> Language Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Language Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Loader Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Loader Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Controller Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Controller Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:12 --> Session Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Session Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:48:12 --> A session cookie was not found.
DEBUG - 2014-02-19 14:48:12 --> A session cookie was not found.
DEBUG - 2014-02-19 14:48:12 --> Session routines successfully run
DEBUG - 2014-02-19 14:48:12 --> Session routines successfully run
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:48:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:12 --> Final output sent to browser
DEBUG - 2014-02-19 14:48:12 --> Final output sent to browser
DEBUG - 2014-02-19 14:48:12 --> Total execution time: 0.0240
DEBUG - 2014-02-19 14:48:12 --> Total execution time: 0.0240
DEBUG - 2014-02-19 14:48:17 --> Config Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:48:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:48:17 --> URI Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Router Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Output Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Security Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Input Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:48:17 --> Language Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Loader Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Controller Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:48:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:17 --> Session Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:48:17 --> A session cookie was not found.
DEBUG - 2014-02-19 14:48:17 --> Session routines successfully run
DEBUG - 2014-02-19 14:48:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:17 --> Final output sent to browser
DEBUG - 2014-02-19 14:48:17 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:48:31 --> Config Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:48:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:48:31 --> URI Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Router Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Output Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Security Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Input Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:48:31 --> Language Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Loader Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Controller Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:48:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:48:31 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Model Class Initialized
DEBUG - 2014-02-19 14:48:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:48:34 --> Final output sent to browser
DEBUG - 2014-02-19 14:48:34 --> Total execution time: 2.2911
DEBUG - 2014-02-19 14:55:47 --> Config Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:55:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:55:47 --> URI Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Router Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Output Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Security Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Input Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:55:47 --> Language Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Loader Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Controller Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:55:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:55:47 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:47 --> Session Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:55:47 --> A session cookie was not found.
DEBUG - 2014-02-19 14:55:47 --> Session routines successfully run
DEBUG - 2014-02-19 14:55:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:55:47 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:47 --> Final output sent to browser
DEBUG - 2014-02-19 14:55:47 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:55:48 --> Config Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:55:48 --> URI Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Router Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Output Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Security Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Input Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:55:48 --> Language Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Loader Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Controller Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:55:48 --> Config Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:55:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:55:48 --> URI Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Router Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Output Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Security Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:48 --> Input Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Session Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:55:48 --> Language Class Initialized
DEBUG - 2014-02-19 14:55:48 --> A session cookie was not found.
DEBUG - 2014-02-19 14:55:48 --> Session routines successfully run
DEBUG - 2014-02-19 14:55:48 --> Loader Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:55:48 --> Controller Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:55:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Final output sent to browser
DEBUG - 2014-02-19 14:55:48 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:48 --> Session Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:55:48 --> A session cookie was not found.
DEBUG - 2014-02-19 14:55:48 --> Session routines successfully run
DEBUG - 2014-02-19 14:55:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:55:48 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:48 --> Final output sent to browser
DEBUG - 2014-02-19 14:55:48 --> Total execution time: 0.0200
DEBUG - 2014-02-19 14:55:52 --> Config Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:55:52 --> URI Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Config Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Router Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:55:52 --> Output Class Initialized
DEBUG - 2014-02-19 14:55:52 --> URI Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Security Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Router Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Input Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:55:52 --> Output Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Language Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Security Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Input Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Loader Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:55:52 --> Controller Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Language Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:55:52 --> Loader Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:55:52 --> Controller Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Session Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:55:52 --> A session cookie was not found.
DEBUG - 2014-02-19 14:55:52 --> Session Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Session routines successfully run
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:55:52 --> A session cookie was not found.
DEBUG - 2014-02-19 14:55:52 --> Session routines successfully run
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:52 --> Final output sent to browser
DEBUG - 2014-02-19 14:55:52 --> Total execution time: 0.0130
DEBUG - 2014-02-19 14:55:52 --> Final output sent to browser
DEBUG - 2014-02-19 14:55:52 --> Total execution time: 0.0110
DEBUG - 2014-02-19 14:55:53 --> Config Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:55:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:55:53 --> URI Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Router Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Output Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Security Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Input Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:55:53 --> Language Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Loader Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Controller Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:55:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:55:53 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:53 --> Session Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 14:55:53 --> A session cookie was not found.
DEBUG - 2014-02-19 14:55:53 --> Session routines successfully run
DEBUG - 2014-02-19 14:55:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 14:55:53 --> Model Class Initialized
DEBUG - 2014-02-19 14:55:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:55:53 --> Final output sent to browser
DEBUG - 2014-02-19 14:55:53 --> Total execution time: 0.0180
DEBUG - 2014-02-19 14:56:12 --> Config Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 14:56:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 14:56:12 --> URI Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Router Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Output Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Security Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Input Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 14:56:12 --> Language Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Loader Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Controller Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 14:56:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 14:56:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Model Class Initialized
DEBUG - 2014-02-19 14:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 14:56:14 --> Final output sent to browser
DEBUG - 2014-02-19 14:56:14 --> Total execution time: 2.2401
DEBUG - 2014-02-19 15:13:33 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:33 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:33 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:33 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:33 --> Session Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Session Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:13:33 --> A session cookie was not found.
DEBUG - 2014-02-19 15:13:33 --> A session cookie was not found.
DEBUG - 2014-02-19 15:13:33 --> Session routines successfully run
DEBUG - 2014-02-19 15:13:33 --> Session routines successfully run
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:13:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:33 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:33 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:33 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:13:33 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:13:34 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:34 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:34 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:34 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:34 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:34 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:34 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:34 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Session Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Session Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:13:34 --> A session cookie was not found.
DEBUG - 2014-02-19 15:13:34 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:34 --> A session cookie was not found.
DEBUG - 2014-02-19 15:13:34 --> Session routines successfully run
DEBUG - 2014-02-19 15:13:34 --> Session routines successfully run
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:34 --> Session Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:34 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:34 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:13:34 --> Total execution time: 0.0240
DEBUG - 2014-02-19 15:13:34 --> A session cookie was not found.
DEBUG - 2014-02-19 15:13:34 --> Session routines successfully run
DEBUG - 2014-02-19 15:13:34 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:13:34 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:34 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:34 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:13:43 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:43 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:43 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:43 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:43 --> Session Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:13:43 --> A session cookie was not found.
DEBUG - 2014-02-19 15:13:43 --> Session routines successfully run
DEBUG - 2014-02-19 15:13:43 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:13:43 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:43 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:43 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:13:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:13:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:13:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:13:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:13:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:13:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:13:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:13:53 --> Final output sent to browser
DEBUG - 2014-02-19 15:13:53 --> Total execution time: 2.2631
DEBUG - 2014-02-19 15:14:37 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:37 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:37 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:37 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:37 --> Session Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:14:37 --> A session cookie was not found.
DEBUG - 2014-02-19 15:14:37 --> Session routines successfully run
DEBUG - 2014-02-19 15:14:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:14:37 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:37 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:37 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:14:38 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:38 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:38 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:38 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:38 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:38 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:38 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:38 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:38 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:38 --> Session Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Session Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:14:38 --> A session cookie was not found.
DEBUG - 2014-02-19 15:14:38 --> A session cookie was not found.
DEBUG - 2014-02-19 15:14:38 --> Session Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Session routines successfully run
DEBUG - 2014-02-19 15:14:38 --> Session routines successfully run
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:14:38 --> A session cookie was not found.
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Session routines successfully run
DEBUG - 2014-02-19 15:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:14:38 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:38 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:38 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:38 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:14:38 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:14:38 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:38 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:14:42 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:42 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:42 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:42 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:42 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:42 --> Session Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:14:42 --> A session cookie was not found.
DEBUG - 2014-02-19 15:14:42 --> Session routines successfully run
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:14:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Session Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:14:42 --> A session cookie was not found.
DEBUG - 2014-02-19 15:14:42 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:42 --> Session routines successfully run
DEBUG - 2014-02-19 15:14:42 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:14:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:14:42 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:42 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:42 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:14:56 --> Config Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:14:56 --> URI Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Router Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Output Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Security Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Input Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:14:56 --> Language Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Loader Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Controller Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:14:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:14:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:14:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:14:58 --> Final output sent to browser
DEBUG - 2014-02-19 15:14:58 --> Total execution time: 2.2711
DEBUG - 2014-02-19 15:15:25 --> Config Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:15:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:15:25 --> URI Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Router Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Output Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Security Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Input Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:15:25 --> Language Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Loader Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Controller Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:15:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:15:25 --> Model Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Model Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Model Class Initialized
DEBUG - 2014-02-19 15:15:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:15:31 --> Final output sent to browser
DEBUG - 2014-02-19 15:15:31 --> Total execution time: 5.2233
DEBUG - 2014-02-19 15:16:46 --> Config Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Config Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:16:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:16:46 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:16:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:16:46 --> URI Class Initialized
DEBUG - 2014-02-19 15:16:46 --> URI Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Router Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Router Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Output Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Output Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Security Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Security Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Input Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Input Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:16:46 --> Language Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Language Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Loader Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Loader Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Controller Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Controller Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:46 --> Session Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Session Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:16:46 --> A session cookie was not found.
DEBUG - 2014-02-19 15:16:46 --> A session cookie was not found.
DEBUG - 2014-02-19 15:16:46 --> Session routines successfully run
DEBUG - 2014-02-19 15:16:46 --> Session routines successfully run
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:16:46 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:46 --> Final output sent to browser
DEBUG - 2014-02-19 15:16:46 --> Final output sent to browser
DEBUG - 2014-02-19 15:16:46 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:16:46 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:16:47 --> Config Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:16:47 --> URI Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Router Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Output Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Security Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Input Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:16:47 --> Language Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Loader Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Controller Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:16:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:16:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:47 --> Session Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:16:47 --> A session cookie was not found.
DEBUG - 2014-02-19 15:16:47 --> Session routines successfully run
DEBUG - 2014-02-19 15:16:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:16:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:47 --> Final output sent to browser
DEBUG - 2014-02-19 15:16:47 --> Total execution time: 0.0160
DEBUG - 2014-02-19 15:16:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:16:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:16:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:16:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:16:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:51 --> Session Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:16:51 --> A session cookie was not found.
DEBUG - 2014-02-19 15:16:51 --> Session routines successfully run
DEBUG - 2014-02-19 15:16:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:16:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:51 --> Final output sent to browser
DEBUG - 2014-02-19 15:16:51 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:16:52 --> Config Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:16:52 --> URI Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Router Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Output Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Security Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Input Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:16:52 --> Language Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Loader Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Controller Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:16:52 --> Config Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:16:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:16:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> URI Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Router Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Output Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Security Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Input Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:16:52 --> Language Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Session Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:16:52 --> Loader Class Initialized
DEBUG - 2014-02-19 15:16:52 --> A session cookie was not found.
DEBUG - 2014-02-19 15:16:52 --> Controller Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Session routines successfully run
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Final output sent to browser
DEBUG - 2014-02-19 15:16:52 --> Total execution time: 0.0180
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:52 --> Session Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:16:52 --> A session cookie was not found.
DEBUG - 2014-02-19 15:16:52 --> Session routines successfully run
DEBUG - 2014-02-19 15:16:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:16:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:16:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:16:52 --> Final output sent to browser
DEBUG - 2014-02-19 15:16:52 --> Total execution time: 0.0150
DEBUG - 2014-02-19 15:17:00 --> Config Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:17:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:17:00 --> URI Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Router Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Output Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Security Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Input Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:17:00 --> Language Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Loader Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Controller Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:17:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:17:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:02 --> Final output sent to browser
DEBUG - 2014-02-19 15:17:02 --> Total execution time: 2.2841
DEBUG - 2014-02-19 15:17:21 --> Config Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:17:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:17:21 --> URI Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Router Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Output Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Security Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Input Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:17:21 --> Language Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Loader Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Controller Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:17:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:17:21 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:21 --> Session Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:17:21 --> A session cookie was not found.
DEBUG - 2014-02-19 15:17:21 --> Session routines successfully run
DEBUG - 2014-02-19 15:17:21 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:17:21 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:21 --> Final output sent to browser
DEBUG - 2014-02-19 15:17:21 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:17:26 --> Config Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:17:26 --> URI Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Router Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Output Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Security Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Input Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:17:26 --> Language Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Loader Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Controller Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:17:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:17:26 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:26 --> Session Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:17:26 --> A session cookie was not found.
DEBUG - 2014-02-19 15:17:26 --> Session routines successfully run
DEBUG - 2014-02-19 15:17:26 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:17:26 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:26 --> Final output sent to browser
DEBUG - 2014-02-19 15:17:26 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:17:31 --> Config Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:17:31 --> URI Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Router Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Output Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Security Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Input Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:17:31 --> Language Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Loader Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Controller Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:17:31 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:31 --> Session Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:17:31 --> A session cookie was not found.
DEBUG - 2014-02-19 15:17:31 --> Session routines successfully run
DEBUG - 2014-02-19 15:17:31 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:17:31 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:17:31 --> Final output sent to browser
DEBUG - 2014-02-19 15:17:31 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:17:58 --> Config Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:17:58 --> URI Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Router Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Output Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Security Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Input Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:17:58 --> Language Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Loader Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Controller Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:17:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:17:58 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Model Class Initialized
DEBUG - 2014-02-19 15:17:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:18:01 --> Final output sent to browser
DEBUG - 2014-02-19 15:18:01 --> Total execution time: 2.2411
DEBUG - 2014-02-19 15:18:41 --> Config Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:18:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:18:41 --> URI Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Router Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Output Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Security Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Input Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:18:41 --> Language Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Loader Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Controller Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:18:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:18:41 --> Model Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Model Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Model Class Initialized
DEBUG - 2014-02-19 15:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:18:43 --> Final output sent to browser
DEBUG - 2014-02-19 15:18:43 --> Total execution time: 2.1901
DEBUG - 2014-02-19 15:18:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:18:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:18:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:18:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:18:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:18:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:18:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:18:53 --> Final output sent to browser
DEBUG - 2014-02-19 15:18:53 --> Total execution time: 2.4901
DEBUG - 2014-02-19 15:20:20 --> Config Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:20:20 --> Config Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:20:20 --> URI Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Router Class Initialized
DEBUG - 2014-02-19 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:20:20 --> URI Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Router Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Output Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Security Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Output Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Input Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:20:20 --> Security Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Input Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Language Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:20:20 --> Language Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Loader Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Controller Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Loader Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Controller Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:20 --> Session Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Session Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:20:20 --> A session cookie was not found.
DEBUG - 2014-02-19 15:20:20 --> A session cookie was not found.
DEBUG - 2014-02-19 15:20:20 --> Session routines successfully run
DEBUG - 2014-02-19 15:20:20 --> Session routines successfully run
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:20:20 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:20 --> Final output sent to browser
DEBUG - 2014-02-19 15:20:20 --> Final output sent to browser
DEBUG - 2014-02-19 15:20:20 --> Total execution time: 0.0240
DEBUG - 2014-02-19 15:20:20 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:20:35 --> Config Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:20:35 --> URI Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Router Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Output Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Security Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Input Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:20:35 --> Language Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Loader Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Controller Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:35 --> Session Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:20:35 --> A session cookie was not found.
DEBUG - 2014-02-19 15:20:35 --> Session routines successfully run
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:35 --> Final output sent to browser
DEBUG - 2014-02-19 15:20:35 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:20:35 --> Config Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:20:35 --> URI Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Router Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Config Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Output Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:20:35 --> Security Class Initialized
DEBUG - 2014-02-19 15:20:35 --> URI Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Input Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Router Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:20:35 --> Language Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Output Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Loader Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Security Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Controller Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Input Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:20:35 --> Language Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Loader Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Controller Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:20:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:35 --> Session Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> A session cookie was not found.
DEBUG - 2014-02-19 15:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:35 --> Session routines successfully run
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:20:35 --> Session Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:20:35 --> A session cookie was not found.
DEBUG - 2014-02-19 15:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:35 --> Session routines successfully run
DEBUG - 2014-02-19 15:20:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:20:35 --> Final output sent to browser
DEBUG - 2014-02-19 15:20:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:35 --> Total execution time: 0.0170
DEBUG - 2014-02-19 15:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:35 --> Final output sent to browser
DEBUG - 2014-02-19 15:20:35 --> Total execution time: 0.0160
DEBUG - 2014-02-19 15:20:45 --> Config Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:20:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:20:45 --> URI Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Router Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Output Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Security Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Input Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:20:45 --> Language Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Loader Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Controller Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:20:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:20:45 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:45 --> Session Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:20:45 --> A session cookie was not found.
DEBUG - 2014-02-19 15:20:45 --> Session routines successfully run
DEBUG - 2014-02-19 15:20:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:20:45 --> Model Class Initialized
DEBUG - 2014-02-19 15:20:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:20:45 --> Final output sent to browser
DEBUG - 2014-02-19 15:20:45 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:21:04 --> Config Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:21:04 --> URI Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Router Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Output Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Security Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Input Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:21:04 --> Language Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Loader Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Controller Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:21:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:21:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:21:13 --> Final output sent to browser
DEBUG - 2014-02-19 15:21:13 --> Total execution time: 8.2345
DEBUG - 2014-02-19 15:23:49 --> Config Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:23:49 --> URI Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Router Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Output Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Security Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Input Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:23:49 --> Language Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Loader Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Controller Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:23:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:23:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:49 --> Session Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:23:49 --> A session cookie was not found.
DEBUG - 2014-02-19 15:23:49 --> Session routines successfully run
DEBUG - 2014-02-19 15:23:49 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:23:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:49 --> Final output sent to browser
DEBUG - 2014-02-19 15:23:49 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:23:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:23:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:23:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:23:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:23:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:23:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:23:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:23:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:51 --> Session Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:23:51 --> Session Class Initialized
DEBUG - 2014-02-19 15:23:51 --> A session cookie was not found.
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:23:51 --> Session routines successfully run
DEBUG - 2014-02-19 15:23:51 --> A session cookie was not found.
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:23:51 --> Session routines successfully run
DEBUG - 2014-02-19 15:23:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:51 --> Final output sent to browser
DEBUG - 2014-02-19 15:23:51 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:23:51 --> Final output sent to browser
DEBUG - 2014-02-19 15:23:51 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:23:54 --> Config Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Config Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:23:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:23:54 --> URI Class Initialized
DEBUG - 2014-02-19 15:23:54 --> URI Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Router Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Router Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Output Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Output Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Security Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Security Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Input Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Input Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:23:54 --> Language Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Language Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Loader Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Loader Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Controller Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Controller Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:54 --> Session Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Session Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:23:54 --> A session cookie was not found.
DEBUG - 2014-02-19 15:23:54 --> A session cookie was not found.
DEBUG - 2014-02-19 15:23:54 --> Session routines successfully run
DEBUG - 2014-02-19 15:23:54 --> Session routines successfully run
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:23:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:54 --> Final output sent to browser
DEBUG - 2014-02-19 15:23:54 --> Final output sent to browser
DEBUG - 2014-02-19 15:23:54 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:23:54 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:23:56 --> Config Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:23:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:23:56 --> URI Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Router Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Output Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Security Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Input Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:23:56 --> Language Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Loader Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Controller Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:23:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:23:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:56 --> Session Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:23:56 --> A session cookie was not found.
DEBUG - 2014-02-19 15:23:56 --> Session routines successfully run
DEBUG - 2014-02-19 15:23:56 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:23:56 --> Model Class Initialized
DEBUG - 2014-02-19 15:23:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:23:56 --> Final output sent to browser
DEBUG - 2014-02-19 15:23:56 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:24:09 --> Config Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:24:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:24:09 --> URI Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Router Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Output Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Security Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Input Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:24:09 --> Language Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Loader Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Controller Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:24:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:24:09 --> Model Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Model Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Model Class Initialized
DEBUG - 2014-02-19 15:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:24:11 --> Final output sent to browser
DEBUG - 2014-02-19 15:24:11 --> Total execution time: 2.2261
DEBUG - 2014-02-19 15:27:59 --> Config Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:27:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:27:59 --> URI Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Router Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Output Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Security Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Input Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:27:59 --> Language Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Loader Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Controller Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:27:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:27:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:27:59 --> Session Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:27:59 --> A session cookie was not found.
DEBUG - 2014-02-19 15:27:59 --> Session routines successfully run
DEBUG - 2014-02-19 15:27:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:27:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:27:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:27:59 --> Final output sent to browser
DEBUG - 2014-02-19 15:27:59 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:28:00 --> Config Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Config Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:28:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:28:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:28:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:28:00 --> URI Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Router Class Initialized
DEBUG - 2014-02-19 15:28:00 --> URI Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Router Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Output Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Output Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Security Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Input Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Security Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:28:00 --> Input Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Language Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:28:00 --> Language Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Loader Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Controller Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Loader Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:28:00 --> Controller Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:00 --> Session Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Session Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:28:00 --> A session cookie was not found.
DEBUG - 2014-02-19 15:28:00 --> A session cookie was not found.
DEBUG - 2014-02-19 15:28:00 --> Session routines successfully run
DEBUG - 2014-02-19 15:28:00 --> Session routines successfully run
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:28:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:00 --> Final output sent to browser
DEBUG - 2014-02-19 15:28:00 --> Final output sent to browser
DEBUG - 2014-02-19 15:28:00 --> Total execution time: 0.0120
DEBUG - 2014-02-19 15:28:00 --> Total execution time: 0.0120
DEBUG - 2014-02-19 15:28:04 --> Config Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Config Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:28:04 --> URI Class Initialized
DEBUG - 2014-02-19 15:28:04 --> URI Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Router Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Router Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Output Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Output Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Security Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Security Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Input Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Input Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:28:04 --> Language Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Language Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Loader Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Loader Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Controller Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Controller Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:04 --> Session Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Session Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:28:04 --> A session cookie was not found.
DEBUG - 2014-02-19 15:28:04 --> A session cookie was not found.
DEBUG - 2014-02-19 15:28:04 --> Session routines successfully run
DEBUG - 2014-02-19 15:28:04 --> Session routines successfully run
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:28:04 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:04 --> Final output sent to browser
DEBUG - 2014-02-19 15:28:04 --> Final output sent to browser
DEBUG - 2014-02-19 15:28:04 --> Total execution time: 0.0240
DEBUG - 2014-02-19 15:28:04 --> Total execution time: 0.0240
DEBUG - 2014-02-19 15:28:05 --> Config Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:28:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:28:05 --> URI Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Router Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Output Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Security Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Input Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:28:05 --> Language Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Loader Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Controller Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:28:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:28:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:05 --> Session Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:28:05 --> A session cookie was not found.
DEBUG - 2014-02-19 15:28:05 --> Session routines successfully run
DEBUG - 2014-02-19 15:28:05 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:28:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:05 --> Final output sent to browser
DEBUG - 2014-02-19 15:28:05 --> Total execution time: 0.0170
DEBUG - 2014-02-19 15:28:14 --> Config Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:28:14 --> URI Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Router Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Output Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Security Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Input Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:28:14 --> Language Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Loader Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Controller Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:28:14 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Model Class Initialized
DEBUG - 2014-02-19 15:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:28:16 --> Final output sent to browser
DEBUG - 2014-02-19 15:28:16 --> Total execution time: 2.2381
DEBUG - 2014-02-19 15:30:59 --> Config Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Config Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Config Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:30:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:30:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:30:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:30:59 --> URI Class Initialized
DEBUG - 2014-02-19 15:30:59 --> URI Class Initialized
DEBUG - 2014-02-19 15:30:59 --> URI Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Router Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Router Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Router Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Output Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Output Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Output Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Security Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Security Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Security Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Input Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Input Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Input Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:30:59 --> Language Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Language Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Language Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Loader Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Loader Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Loader Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Controller Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Controller Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Controller Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:30:59 --> Session Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Session Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Session Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:30:59 --> A session cookie was not found.
DEBUG - 2014-02-19 15:30:59 --> A session cookie was not found.
DEBUG - 2014-02-19 15:30:59 --> A session cookie was not found.
DEBUG - 2014-02-19 15:30:59 --> Session routines successfully run
DEBUG - 2014-02-19 15:30:59 --> Session routines successfully run
DEBUG - 2014-02-19 15:30:59 --> Session routines successfully run
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:30:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 15:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:30:59 --> Final output sent to browser
DEBUG - 2014-02-19 15:30:59 --> Final output sent to browser
DEBUG - 2014-02-19 15:30:59 --> Final output sent to browser
DEBUG - 2014-02-19 15:30:59 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:30:59 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:30:59 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:31:00 --> Config Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:31:00 --> URI Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Router Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Output Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Security Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Input Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:31:00 --> Language Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Loader Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Controller Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:31:00 --> Config Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:31:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:31:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> URI Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Router Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Output Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Security Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:00 --> Input Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:31:00 --> Session Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Language Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:31:00 --> A session cookie was not found.
DEBUG - 2014-02-19 15:31:00 --> Loader Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Session routines successfully run
DEBUG - 2014-02-19 15:31:00 --> Controller Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:31:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Final output sent to browser
DEBUG - 2014-02-19 15:31:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Total execution time: 0.0110
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:00 --> Session Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:31:00 --> A session cookie was not found.
DEBUG - 2014-02-19 15:31:00 --> Session routines successfully run
DEBUG - 2014-02-19 15:31:00 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:31:00 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:00 --> Final output sent to browser
DEBUG - 2014-02-19 15:31:00 --> Total execution time: 0.0120
DEBUG - 2014-02-19 15:31:05 --> Config Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:31:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:31:05 --> URI Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Router Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Output Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Security Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Input Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:31:05 --> Language Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Loader Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Controller Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:31:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:31:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:05 --> Session Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:31:05 --> A session cookie was not found.
DEBUG - 2014-02-19 15:31:05 --> Session routines successfully run
DEBUG - 2014-02-19 15:31:05 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:31:05 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:05 --> Final output sent to browser
DEBUG - 2014-02-19 15:31:05 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:31:17 --> Config Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:31:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:31:17 --> URI Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Router Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Output Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Security Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Input Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:31:17 --> Language Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Loader Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Controller Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:31:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:31:17 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Model Class Initialized
DEBUG - 2014-02-19 15:31:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:31:20 --> Final output sent to browser
DEBUG - 2014-02-19 15:31:20 --> Total execution time: 2.2251
DEBUG - 2014-02-19 15:35:30 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:30 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:30 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:30 --> Session Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:35:30 --> A session cookie was not found.
DEBUG - 2014-02-19 15:35:30 --> Session routines successfully run
DEBUG - 2014-02-19 15:35:30 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:30 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:30 --> Total execution time: 0.0130
DEBUG - 2014-02-19 15:35:32 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:32 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:32 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:32 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:32 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:32 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:32 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:32 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:32 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Session Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:32 --> A session cookie was not found.
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Session routines successfully run
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:32 --> Session Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:35:32 --> A session cookie was not found.
DEBUG - 2014-02-19 15:35:32 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:35:32 --> Session routines successfully run
DEBUG - 2014-02-19 15:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:35:32 --> Session Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:32 --> A session cookie was not found.
DEBUG - 2014-02-19 15:35:32 --> Session routines successfully run
DEBUG - 2014-02-19 15:35:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:35:32 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:32 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:35:32 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:32 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:32 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:35:35 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:35 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:35 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:35 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:35 --> Session Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Session Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:35:35 --> A session cookie was not found.
DEBUG - 2014-02-19 15:35:35 --> A session cookie was not found.
DEBUG - 2014-02-19 15:35:35 --> Session routines successfully run
DEBUG - 2014-02-19 15:35:35 --> Session routines successfully run
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:35:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:35 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:35 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:35 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:35:35 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:35:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:35:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:35:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:35:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:35:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:35:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:35:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:35:53 --> Final output sent to browser
DEBUG - 2014-02-19 15:35:53 --> Total execution time: 2.2401
DEBUG - 2014-02-19 15:36:46 --> Config Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Config Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:36:46 --> URI Class Initialized
DEBUG - 2014-02-19 15:36:46 --> URI Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Router Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Router Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Output Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Output Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Security Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Security Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Input Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Input Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:36:46 --> Language Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Language Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Loader Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Loader Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Controller Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Controller Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:46 --> Session Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Session Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:36:46 --> A session cookie was not found.
DEBUG - 2014-02-19 15:36:46 --> A session cookie was not found.
DEBUG - 2014-02-19 15:36:46 --> Session routines successfully run
DEBUG - 2014-02-19 15:36:46 --> Session routines successfully run
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:36:46 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:46 --> Final output sent to browser
DEBUG - 2014-02-19 15:36:46 --> Final output sent to browser
DEBUG - 2014-02-19 15:36:46 --> Total execution time: 0.0230
DEBUG - 2014-02-19 15:36:46 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:36:49 --> Config Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Config Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:36:49 --> URI Class Initialized
DEBUG - 2014-02-19 15:36:49 --> URI Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Router Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Router Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Output Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Output Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Security Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Security Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Input Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Input Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:36:49 --> Language Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Language Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Loader Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Loader Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Controller Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Controller Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:49 --> Session Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Session Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:36:49 --> A session cookie was not found.
DEBUG - 2014-02-19 15:36:49 --> A session cookie was not found.
DEBUG - 2014-02-19 15:36:49 --> Session routines successfully run
DEBUG - 2014-02-19 15:36:49 --> Session routines successfully run
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:36:49 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:49 --> Final output sent to browser
DEBUG - 2014-02-19 15:36:49 --> Final output sent to browser
DEBUG - 2014-02-19 15:36:49 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:36:49 --> Total execution time: 0.0220
DEBUG - 2014-02-19 15:36:51 --> Config Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:36:51 --> URI Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Router Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Output Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Security Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Input Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:36:51 --> Language Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Loader Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Controller Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:36:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:51 --> Session Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:36:51 --> A session cookie was not found.
DEBUG - 2014-02-19 15:36:51 --> Session routines successfully run
DEBUG - 2014-02-19 15:36:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:36:51 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:51 --> Final output sent to browser
DEBUG - 2014-02-19 15:36:51 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:36:54 --> Config Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:36:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:36:54 --> URI Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Router Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Output Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Security Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Input Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:36:54 --> Language Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Loader Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Controller Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:36:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:36:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:54 --> Session Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:36:54 --> A session cookie was not found.
DEBUG - 2014-02-19 15:36:54 --> Session routines successfully run
DEBUG - 2014-02-19 15:36:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:36:54 --> Model Class Initialized
DEBUG - 2014-02-19 15:36:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:36:54 --> Final output sent to browser
DEBUG - 2014-02-19 15:36:54 --> Total execution time: 0.0210
DEBUG - 2014-02-19 15:37:07 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:07 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:07 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:07 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:09 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:09 --> Total execution time: 2.2281
DEBUG - 2014-02-19 15:37:47 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:47 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:47 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:47 --> Session Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:37:47 --> A session cookie was not found.
DEBUG - 2014-02-19 15:37:47 --> Session routines successfully run
DEBUG - 2014-02-19 15:37:47 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:37:47 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:47 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:47 --> Total execution time: 0.0190
DEBUG - 2014-02-19 15:37:48 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:48 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:48 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:48 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:48 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:48 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:48 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:48 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Session Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:37:48 --> A session cookie was not found.
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Session routines successfully run
DEBUG - 2014-02-19 15:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:37:48 --> Session Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:37:48 --> A session cookie was not found.
DEBUG - 2014-02-19 15:37:48 --> Session routines successfully run
DEBUG - 2014-02-19 15:37:48 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:48 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:37:48 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:37:48 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:48 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:48 --> Total execution time: 0.0200
DEBUG - 2014-02-19 15:37:52 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:52 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:52 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:52 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:52 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:52 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:52 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:52 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Session Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:37:52 --> A session cookie was not found.
DEBUG - 2014-02-19 15:37:52 --> Session Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Session routines successfully run
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:37:52 --> A session cookie was not found.
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:37:52 --> Session routines successfully run
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:37:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:52 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:52 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:52 --> Total execution time: 0.0130
DEBUG - 2014-02-19 15:37:52 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:52 --> Total execution time: 0.0110
DEBUG - 2014-02-19 15:37:53 --> Config Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:37:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:37:53 --> URI Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Router Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Output Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Security Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Input Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:37:53 --> Language Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Loader Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Controller Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:37:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:37:53 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:53 --> Session Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 15:37:53 --> A session cookie was not found.
DEBUG - 2014-02-19 15:37:53 --> Session routines successfully run
DEBUG - 2014-02-19 15:37:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 15:37:53 --> Model Class Initialized
DEBUG - 2014-02-19 15:37:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:37:53 --> Final output sent to browser
DEBUG - 2014-02-19 15:37:53 --> Total execution time: 0.0180
DEBUG - 2014-02-19 15:38:03 --> Config Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 15:38:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 15:38:03 --> URI Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Router Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Output Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Security Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Input Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 15:38:03 --> Language Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Loader Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Controller Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 15:38:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 15:38:03 --> Model Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Model Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Model Class Initialized
DEBUG - 2014-02-19 15:38:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 15:38:05 --> Final output sent to browser
DEBUG - 2014-02-19 15:38:05 --> Total execution time: 2.2301
DEBUG - 2014-02-19 21:01:03 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:03 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:03 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:03 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:03 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:03 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:03 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:03 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:03 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:03 --> Session Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Session Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Session Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:01:03 --> A session cookie was not found.
DEBUG - 2014-02-19 21:01:03 --> A session cookie was not found.
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:01:03 --> Session routines successfully run
DEBUG - 2014-02-19 21:01:03 --> A session cookie was not found.
DEBUG - 2014-02-19 21:01:03 --> Session routines successfully run
DEBUG - 2014-02-19 21:01:03 --> Session routines successfully run
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:01:03 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:03 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:03 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:03 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:03 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:03 --> Total execution time: 0.0240
DEBUG - 2014-02-19 21:01:03 --> Total execution time: 0.0230
DEBUG - 2014-02-19 21:01:03 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:01:05 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:05 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:05 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:05 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:05 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:05 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:05 --> Session Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Session Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Session Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:01:05 --> A session cookie was not found.
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:01:05 --> A session cookie was not found.
DEBUG - 2014-02-19 21:01:05 --> A session cookie was not found.
DEBUG - 2014-02-19 21:01:05 --> Session routines successfully run
DEBUG - 2014-02-19 21:01:05 --> Session routines successfully run
DEBUG - 2014-02-19 21:01:05 --> Session routines successfully run
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:01:05 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:05 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:05 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:05 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:05 --> Total execution time: 0.0230
DEBUG - 2014-02-19 21:01:05 --> Total execution time: 0.0220
DEBUG - 2014-02-19 21:01:05 --> Total execution time: 0.0220
DEBUG - 2014-02-19 21:01:28 --> Config Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:01:28 --> URI Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Router Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Output Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Security Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Input Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:01:28 --> Language Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Loader Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Controller Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:01:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-19 21:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:01:30 --> Final output sent to browser
DEBUG - 2014-02-19 21:01:30 --> Total execution time: 2.9712
DEBUG - 2014-02-19 21:05:27 --> Config Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:05:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:05:27 --> URI Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Router Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Output Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Security Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Input Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:05:27 --> Language Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Loader Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Controller Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:05:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:05:27 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:05:27 --> Session Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:05:27 --> A session cookie was not found.
DEBUG - 2014-02-19 21:05:27 --> Session routines successfully run
DEBUG - 2014-02-19 21:05:27 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:05:27 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:05:27 --> Final output sent to browser
DEBUG - 2014-02-19 21:05:27 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:05:32 --> Config Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:05:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:05:32 --> URI Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Router Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Output Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Security Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Input Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:05:32 --> Language Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Loader Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Controller Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:05:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:05:32 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:05:32 --> Session Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:05:32 --> A session cookie was not found.
DEBUG - 2014-02-19 21:05:32 --> Session routines successfully run
DEBUG - 2014-02-19 21:05:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:05:32 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:05:32 --> Final output sent to browser
DEBUG - 2014-02-19 21:05:32 --> Total execution time: 0.0150
DEBUG - 2014-02-19 21:05:37 --> Config Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:05:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:05:37 --> URI Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Router Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Output Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Security Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Input Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:05:37 --> Language Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Loader Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Controller Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:05:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:05:37 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:05:37 --> Session Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:05:37 --> A session cookie was not found.
DEBUG - 2014-02-19 21:05:37 --> Session routines successfully run
DEBUG - 2014-02-19 21:05:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:05:37 --> Model Class Initialized
DEBUG - 2014-02-19 21:05:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:05:37 --> Final output sent to browser
DEBUG - 2014-02-19 21:05:37 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:07:16 --> Config Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Config Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Config Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:07:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:07:16 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:07:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:07:16 --> URI Class Initialized
DEBUG - 2014-02-19 21:07:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:07:16 --> URI Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Router Class Initialized
DEBUG - 2014-02-19 21:07:16 --> URI Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Router Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Router Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Output Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Output Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Output Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Security Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Security Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Security Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Input Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Input Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Input Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:07:16 --> Language Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Language Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Language Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Loader Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Loader Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Loader Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Controller Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Controller Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Controller Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:07:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:07:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:07:16 --> Session Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Session Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Session Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:07:16 --> A session cookie was not found.
DEBUG - 2014-02-19 21:07:16 --> A session cookie was not found.
DEBUG - 2014-02-19 21:07:16 --> A session cookie was not found.
DEBUG - 2014-02-19 21:07:16 --> Session routines successfully run
DEBUG - 2014-02-19 21:07:16 --> Session routines successfully run
DEBUG - 2014-02-19 21:07:16 --> Session routines successfully run
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:07:16 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:07:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:07:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:07:16 --> Final output sent to browser
DEBUG - 2014-02-19 21:07:16 --> Final output sent to browser
DEBUG - 2014-02-19 21:07:16 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:07:16 --> Final output sent to browser
DEBUG - 2014-02-19 21:07:16 --> Total execution time: 0.0210
DEBUG - 2014-02-19 21:07:16 --> Total execution time: 0.0220
DEBUG - 2014-02-19 21:30:59 --> Config Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:30:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:30:59 --> URI Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Router Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Output Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Security Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Input Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:30:59 --> Language Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Loader Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Controller Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:30:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Model Class Initialized
DEBUG - 2014-02-19 21:30:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:31:01 --> Final output sent to browser
DEBUG - 2014-02-19 21:31:01 --> Total execution time: 2.5951
DEBUG - 2014-02-19 21:31:35 --> Config Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:31:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:31:35 --> URI Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Router Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Output Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Security Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Input Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:31:35 --> Language Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Loader Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Controller Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:31:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:31:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:31:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:31:37 --> Final output sent to browser
DEBUG - 2014-02-19 21:31:37 --> Total execution time: 2.3781
DEBUG - 2014-02-19 21:35:24 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:24 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:24 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:24 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:24 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:24 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:24 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:24 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:24 --> Session Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Session Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Session Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:35:24 --> A session cookie was not found.
DEBUG - 2014-02-19 21:35:24 --> A session cookie was not found.
DEBUG - 2014-02-19 21:35:24 --> A session cookie was not found.
DEBUG - 2014-02-19 21:35:24 --> Session routines successfully run
DEBUG - 2014-02-19 21:35:24 --> Session routines successfully run
DEBUG - 2014-02-19 21:35:24 --> Session routines successfully run
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:35:24 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:24 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:24 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:24 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:24 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:35:24 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:35:24 --> Total execution time: 0.0180
DEBUG - 2014-02-19 21:35:25 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:25 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:25 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:25 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:25 --> Session Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Session Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:35:25 --> A session cookie was not found.
DEBUG - 2014-02-19 21:35:25 --> A session cookie was not found.
DEBUG - 2014-02-19 21:35:25 --> Session routines successfully run
DEBUG - 2014-02-19 21:35:25 --> Session routines successfully run
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:35:25 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:25 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:25 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:25 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:35:25 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:35:30 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:30 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:30 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:30 --> Session Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:35:30 --> A session cookie was not found.
DEBUG - 2014-02-19 21:35:30 --> Session routines successfully run
DEBUG - 2014-02-19 21:35:30 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:35:30 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:30 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:30 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:35:44 --> Config Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:35:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:35:44 --> URI Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Router Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Output Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Security Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Input Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:35:44 --> Language Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Loader Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Controller Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:35:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:35:44 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Model Class Initialized
DEBUG - 2014-02-19 21:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:35:48 --> Final output sent to browser
DEBUG - 2014-02-19 21:35:48 --> Total execution time: 3.3942
DEBUG - 2014-02-19 21:37:14 --> Config Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:37:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:37:14 --> URI Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Router Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Output Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Security Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Input Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:37:14 --> Language Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Loader Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Controller Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:37:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:37:14 --> Model Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Model Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Model Class Initialized
DEBUG - 2014-02-19 21:37:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:37:16 --> Final output sent to browser
DEBUG - 2014-02-19 21:37:16 --> Total execution time: 2.4341
DEBUG - 2014-02-19 21:40:53 --> Config Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:40:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:40:53 --> URI Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Router Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Output Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Security Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Input Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:40:53 --> Language Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Loader Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Controller Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:40:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:40:53 --> Model Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Model Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Model Class Initialized
DEBUG - 2014-02-19 21:40:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:40:56 --> Final output sent to browser
DEBUG - 2014-02-19 21:40:56 --> Total execution time: 2.3981
DEBUG - 2014-02-19 21:42:33 --> Config Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:42:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:42:33 --> URI Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Router Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Output Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Security Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Input Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:42:33 --> Language Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Loader Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Controller Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:42:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:42:33 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:33 --> Session Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:42:33 --> A session cookie was not found.
DEBUG - 2014-02-19 21:42:33 --> Session routines successfully run
DEBUG - 2014-02-19 21:42:33 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:42:33 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:33 --> Final output sent to browser
DEBUG - 2014-02-19 21:42:33 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:42:35 --> Config Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:42:35 --> URI Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Config Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Router Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:42:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:42:35 --> Output Class Initialized
DEBUG - 2014-02-19 21:42:35 --> URI Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Security Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Router Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Input Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:42:35 --> Language Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Output Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Security Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Loader Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Input Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Controller Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:42:35 --> Language Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:42:35 --> Loader Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Controller Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:42:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:35 --> Session Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:42:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:35 --> A session cookie was not found.
DEBUG - 2014-02-19 21:42:35 --> Session routines successfully run
DEBUG - 2014-02-19 21:42:35 --> Session Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:42:35 --> A session cookie was not found.
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Session routines successfully run
DEBUG - 2014-02-19 21:42:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:35 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:42:35 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:35 --> Final output sent to browser
DEBUG - 2014-02-19 21:42:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:35 --> Total execution time: 0.0220
DEBUG - 2014-02-19 21:42:35 --> Final output sent to browser
DEBUG - 2014-02-19 21:42:35 --> Total execution time: 0.0220
DEBUG - 2014-02-19 21:42:38 --> Config Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:42:38 --> URI Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Router Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Output Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Security Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Input Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:42:38 --> Config Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Language Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Loader Class Initialized
DEBUG - 2014-02-19 21:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:42:38 --> Controller Class Initialized
DEBUG - 2014-02-19 21:42:38 --> URI Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:42:38 --> Router Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:42:38 --> Output Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Security Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Input Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:42:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Language Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Loader Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Controller Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Session Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:42:38 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:42:38 --> A session cookie was not found.
DEBUG - 2014-02-19 21:42:38 --> Session routines successfully run
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:38 --> Session Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:42:38 --> Final output sent to browser
DEBUG - 2014-02-19 21:42:38 --> A session cookie was not found.
DEBUG - 2014-02-19 21:42:38 --> Total execution time: 0.0130
DEBUG - 2014-02-19 21:42:38 --> Session routines successfully run
DEBUG - 2014-02-19 21:42:38 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:42:38 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:38 --> Final output sent to browser
DEBUG - 2014-02-19 21:42:38 --> Total execution time: 0.0110
DEBUG - 2014-02-19 21:42:39 --> Config Class Initialized
DEBUG - 2014-02-19 21:42:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:42:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:42:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:42:39 --> URI Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Router Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Output Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Security Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Input Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:42:40 --> Language Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Loader Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Controller Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:42:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:42:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:40 --> Session Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:42:40 --> A session cookie was not found.
DEBUG - 2014-02-19 21:42:40 --> Session routines successfully run
DEBUG - 2014-02-19 21:42:40 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:42:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:42:40 --> Final output sent to browser
DEBUG - 2014-02-19 21:42:40 --> Total execution time: 0.0180
DEBUG - 2014-02-19 21:43:00 --> Config Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:43:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:43:00 --> URI Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Router Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Output Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Security Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Input Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:43:00 --> Language Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Loader Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Controller Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:43:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:43:00 --> Model Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Model Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Model Class Initialized
DEBUG - 2014-02-19 21:43:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:43:02 --> Final output sent to browser
DEBUG - 2014-02-19 21:43:02 --> Total execution time: 2.4871
DEBUG - 2014-02-19 21:46:40 --> Config Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:46:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:46:40 --> URI Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Router Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Output Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Security Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Input Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:46:40 --> Language Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Loader Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Controller Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:46:40 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:40 --> Session Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:46:40 --> A session cookie was not found.
DEBUG - 2014-02-19 21:46:40 --> Session routines successfully run
DEBUG - 2014-02-19 21:46:40 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:46:40 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:40 --> Final output sent to browser
DEBUG - 2014-02-19 21:46:40 --> Total execution time: 0.0210
DEBUG - 2014-02-19 21:46:42 --> Config Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:46:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:46:42 --> URI Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Router Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Output Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Security Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Config Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Input Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:46:42 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:46:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:46:42 --> Language Class Initialized
DEBUG - 2014-02-19 21:46:42 --> URI Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Loader Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Router Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Controller Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:46:42 --> Output Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:46:42 --> Security Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Input Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:46:42 --> Language Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Loader Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Controller Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:46:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Session Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:46:42 --> A session cookie was not found.
DEBUG - 2014-02-19 21:46:42 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Session routines successfully run
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:42 --> Session Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Final output sent to browser
DEBUG - 2014-02-19 21:46:42 --> Total execution time: 0.0140
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:46:42 --> A session cookie was not found.
DEBUG - 2014-02-19 21:46:42 --> Session routines successfully run
DEBUG - 2014-02-19 21:46:42 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:46:42 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:42 --> Final output sent to browser
DEBUG - 2014-02-19 21:46:42 --> Total execution time: 0.0140
DEBUG - 2014-02-19 21:46:45 --> Config Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Config Class Initialized
DEBUG - 2014-02-19 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:46:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:46:45 --> URI Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:46:45 --> Router Class Initialized
DEBUG - 2014-02-19 21:46:45 --> URI Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Router Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Output Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Output Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Security Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Input Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Security Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:46:45 --> Input Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Language Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:46:45 --> Language Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Loader Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Loader Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Controller Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Controller Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:45 --> Session Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Session Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:46:45 --> A session cookie was not found.
DEBUG - 2014-02-19 21:46:45 --> A session cookie was not found.
DEBUG - 2014-02-19 21:46:45 --> Session routines successfully run
DEBUG - 2014-02-19 21:46:45 --> Session routines successfully run
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:46:45 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:45 --> Final output sent to browser
DEBUG - 2014-02-19 21:46:45 --> Final output sent to browser
DEBUG - 2014-02-19 21:46:45 --> Total execution time: 0.0190
DEBUG - 2014-02-19 21:46:45 --> Total execution time: 0.0210
DEBUG - 2014-02-19 21:46:52 --> Config Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:46:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:46:52 --> URI Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Router Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Output Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Security Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Input Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:46:52 --> Language Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Loader Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Controller Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:46:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:46:52 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:52 --> Session Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:46:52 --> A session cookie was not found.
DEBUG - 2014-02-19 21:46:52 --> Session routines successfully run
DEBUG - 2014-02-19 21:46:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:46:52 --> Model Class Initialized
DEBUG - 2014-02-19 21:46:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:46:52 --> Final output sent to browser
DEBUG - 2014-02-19 21:46:52 --> Total execution time: 0.0150
DEBUG - 2014-02-19 21:47:09 --> Config Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:47:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:47:09 --> URI Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Router Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Output Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Security Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Input Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:47:09 --> Language Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Loader Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Controller Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:47:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:47:09 --> Model Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Model Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Model Class Initialized
DEBUG - 2014-02-19 21:47:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:47:13 --> Final output sent to browser
DEBUG - 2014-02-19 21:47:13 --> Total execution time: 4.1492
DEBUG - 2014-02-19 21:48:11 --> Config Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:48:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:48:11 --> URI Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Router Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Output Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Security Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Input Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:48:11 --> Language Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Loader Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Controller Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:48:11 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:48:11 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:11 --> Session Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:48:11 --> A session cookie was not found.
DEBUG - 2014-02-19 21:48:11 --> Session routines successfully run
DEBUG - 2014-02-19 21:48:11 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:48:11 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:11 --> Final output sent to browser
DEBUG - 2014-02-19 21:48:11 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:48:12 --> Config Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:48:12 --> URI Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Router Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Config Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Output Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:48:12 --> Security Class Initialized
DEBUG - 2014-02-19 21:48:12 --> URI Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Input Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Router Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:48:12 --> Language Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Output Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Loader Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Controller Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Security Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Input Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:48:12 --> Language Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Loader Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Controller Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:12 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Session Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:48:12 --> A session cookie was not found.
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Session routines successfully run
DEBUG - 2014-02-19 21:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:48:12 --> Session Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:48:12 --> A session cookie was not found.
DEBUG - 2014-02-19 21:48:12 --> Session routines successfully run
DEBUG - 2014-02-19 21:48:12 --> Final output sent to browser
DEBUG - 2014-02-19 21:48:12 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:48:12 --> Total execution time: 0.0210
DEBUG - 2014-02-19 21:48:12 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:12 --> Final output sent to browser
DEBUG - 2014-02-19 21:48:12 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:48:16 --> Config Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:48:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:48:16 --> URI Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Router Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Config Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Output Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:48:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:48:16 --> Security Class Initialized
DEBUG - 2014-02-19 21:48:16 --> URI Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Router Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Input Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:48:16 --> Output Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Language Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Security Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Input Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Loader Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:48:16 --> Controller Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Language Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:48:16 --> Loader Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:48:16 --> Controller Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:16 --> Session Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Session Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:48:16 --> A session cookie was not found.
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:48:16 --> Session routines successfully run
DEBUG - 2014-02-19 21:48:16 --> A session cookie was not found.
DEBUG - 2014-02-19 21:48:16 --> Session routines successfully run
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:48:16 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:16 --> Final output sent to browser
DEBUG - 2014-02-19 21:48:16 --> Final output sent to browser
DEBUG - 2014-02-19 21:48:16 --> Total execution time: 0.0240
DEBUG - 2014-02-19 21:48:16 --> Total execution time: 0.0200
DEBUG - 2014-02-19 21:48:17 --> Config Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:48:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:48:17 --> URI Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Router Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Output Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Security Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Input Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:48:17 --> Language Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Loader Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Controller Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:48:17 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:17 --> Session Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Helper loaded: string_helper
DEBUG - 2014-02-19 21:48:17 --> A session cookie was not found.
DEBUG - 2014-02-19 21:48:17 --> Session routines successfully run
DEBUG - 2014-02-19 21:48:17 --> Helper loaded: url_helper
DEBUG - 2014-02-19 21:48:17 --> Model Class Initialized
DEBUG - 2014-02-19 21:48:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:48:17 --> Final output sent to browser
DEBUG - 2014-02-19 21:48:17 --> Total execution time: 0.0180
DEBUG - 2014-02-19 21:49:45 --> Config Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Hooks Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Utf8 Class Initialized
DEBUG - 2014-02-19 21:49:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 21:49:45 --> URI Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Router Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Output Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Security Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Input Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 21:49:45 --> Language Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Loader Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Controller Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 21:49:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 21:49:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Database Driver Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Model Class Initialized
DEBUG - 2014-02-19 21:49:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 21:49:48 --> Final output sent to browser
DEBUG - 2014-02-19 21:49:48 --> Total execution time: 3.4152
DEBUG - 2014-02-19 23:52:53 --> Config Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Config Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:52:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:52:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:52:53 --> URI Class Initialized
DEBUG - 2014-02-19 23:52:53 --> URI Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Router Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Router Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Output Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Output Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Security Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Security Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Input Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Input Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:52:53 --> Language Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Language Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Loader Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Loader Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Controller Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Controller Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:53 --> Session Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Session Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:52:53 --> A session cookie was not found.
DEBUG - 2014-02-19 23:52:53 --> A session cookie was not found.
DEBUG - 2014-02-19 23:52:53 --> Session routines successfully run
DEBUG - 2014-02-19 23:52:53 --> Session routines successfully run
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:52:53 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:53 --> Final output sent to browser
DEBUG - 2014-02-19 23:52:53 --> Final output sent to browser
DEBUG - 2014-02-19 23:52:53 --> Total execution time: 0.0180
DEBUG - 2014-02-19 23:52:53 --> Total execution time: 0.0180
DEBUG - 2014-02-19 23:52:54 --> Config Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:52:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:52:54 --> URI Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Router Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Output Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Security Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Input Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:52:54 --> Language Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Loader Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Controller Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:52:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:52:54 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:54 --> Session Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:52:54 --> A session cookie was not found.
DEBUG - 2014-02-19 23:52:54 --> Session routines successfully run
DEBUG - 2014-02-19 23:52:54 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:52:54 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:54 --> Final output sent to browser
DEBUG - 2014-02-19 23:52:54 --> Total execution time: 0.0130
DEBUG - 2014-02-19 23:52:58 --> Config Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:52:58 --> URI Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Router Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Output Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Security Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Input Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:52:58 --> Language Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Loader Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Controller Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:52:58 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:58 --> Session Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:52:58 --> A session cookie was not found.
DEBUG - 2014-02-19 23:52:58 --> Session routines successfully run
DEBUG - 2014-02-19 23:52:58 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:52:58 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:58 --> Final output sent to browser
DEBUG - 2014-02-19 23:52:58 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:52:59 --> Config Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:52:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:52:59 --> URI Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Router Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Output Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Security Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Input Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:52:59 --> Language Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Config Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Loader Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Controller Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:52:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:52:59 --> URI Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:52:59 --> Router Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Output Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Security Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Input Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:52:59 --> Language Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Loader Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Controller Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:52:59 --> Session Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:52:59 --> A session cookie was not found.
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Session routines successfully run
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:52:59 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Final output sent to browser
DEBUG - 2014-02-19 23:52:59 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:52:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:59 --> Session Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:52:59 --> A session cookie was not found.
DEBUG - 2014-02-19 23:52:59 --> Session routines successfully run
DEBUG - 2014-02-19 23:52:59 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:52:59 --> Model Class Initialized
DEBUG - 2014-02-19 23:52:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:52:59 --> Final output sent to browser
DEBUG - 2014-02-19 23:52:59 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:53:14 --> Config Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:53:14 --> URI Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Router Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Output Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Security Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Input Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:53:14 --> Language Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Loader Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Controller Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:53:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:53:14 --> Model Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Model Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Model Class Initialized
DEBUG - 2014-02-19 23:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:53:17 --> Final output sent to browser
DEBUG - 2014-02-19 23:53:17 --> Total execution time: 2.9092
DEBUG - 2014-02-19 23:54:26 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:26 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:26 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:26 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:26 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:26 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Session Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:54:26 --> A session cookie was not found.
DEBUG - 2014-02-19 23:54:26 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Session routines successfully run
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:26 --> Session Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:54:26 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:54:26 --> A session cookie was not found.
DEBUG - 2014-02-19 23:54:26 --> Session routines successfully run
DEBUG - 2014-02-19 23:54:26 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:54:26 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:26 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:26 --> Total execution time: 0.0170
DEBUG - 2014-02-19 23:54:28 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:28 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:28 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:28 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:28 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:28 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:28 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:28 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:28 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:28 --> Session Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> A session cookie was not found.
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Session routines successfully run
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:54:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:28 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:28 --> Total execution time: 0.0210
DEBUG - 2014-02-19 23:54:28 --> Session Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Session Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:54:28 --> A session cookie was not found.
DEBUG - 2014-02-19 23:54:28 --> A session cookie was not found.
DEBUG - 2014-02-19 23:54:28 --> Session routines successfully run
DEBUG - 2014-02-19 23:54:28 --> Session routines successfully run
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:54:28 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:28 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:28 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:28 --> Total execution time: 0.0210
DEBUG - 2014-02-19 23:54:28 --> Total execution time: 0.0220
DEBUG - 2014-02-19 23:54:36 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:36 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:36 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:36 --> Session Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:54:36 --> A session cookie was not found.
DEBUG - 2014-02-19 23:54:36 --> Session routines successfully run
DEBUG - 2014-02-19 23:54:36 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:54:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:54:36 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:36 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:54:46 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:46 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:46 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:46 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:46 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Helper loaded: email_helper
DEBUG - 2014-02-19 23:54:46 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:46 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-02-19 23:54:48 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 104
DEBUG - 2014-02-19 23:54:48 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:48 --> Total execution time: 2.3901
DEBUG - 2014-02-19 23:54:57 --> Config Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:54:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:54:57 --> URI Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Router Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Output Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Security Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Input Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:54:57 --> Language Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Loader Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Controller Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:54:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:54:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Helper loaded: email_helper
DEBUG - 2014-02-19 23:54:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:54:57 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-02-19 23:54:59 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: &quot;sendmail_from&quot; not set in php.ini or custom &quot;From:&quot; header missing F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\member.php 104
DEBUG - 2014-02-19 23:54:59 --> Final output sent to browser
DEBUG - 2014-02-19 23:54:59 --> Total execution time: 2.6292
DEBUG - 2014-02-19 23:55:27 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:27 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:27 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:27 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:30 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:30 --> Total execution time: 2.4131
DEBUG - 2014-02-19 23:55:51 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:51 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:51 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:51 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:51 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:51 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:51 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:51 --> Session Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Session Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:55:51 --> A session cookie was not found.
DEBUG - 2014-02-19 23:55:51 --> A session cookie was not found.
DEBUG - 2014-02-19 23:55:51 --> Session routines successfully run
DEBUG - 2014-02-19 23:55:51 --> Session routines successfully run
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:55:51 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:51 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:51 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:51 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:55:51 --> Total execution time: 0.0230
DEBUG - 2014-02-19 23:55:52 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:52 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:52 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:52 --> Session Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:55:52 --> A session cookie was not found.
DEBUG - 2014-02-19 23:55:52 --> Session routines successfully run
DEBUG - 2014-02-19 23:55:52 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:55:52 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:52 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:52 --> Total execution time: 0.0180
DEBUG - 2014-02-19 23:55:56 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:56 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:56 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:56 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:56 --> Session Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:55:56 --> A session cookie was not found.
DEBUG - 2014-02-19 23:55:56 --> Session routines successfully run
DEBUG - 2014-02-19 23:55:56 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:55:56 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:56 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:56 --> Total execution time: 0.0190
DEBUG - 2014-02-19 23:55:57 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:57 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:57 --> Config Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:55:57 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:57 --> URI Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:57 --> Router Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:57 --> Output Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Security Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Input Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:55:57 --> Language Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Loader Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Controller Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:55:57 --> Session Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> A session cookie was not found.
DEBUG - 2014-02-19 23:55:57 --> Session routines successfully run
DEBUG - 2014-02-19 23:55:57 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:57 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:57 --> Session Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:55:57 --> A session cookie was not found.
DEBUG - 2014-02-19 23:55:57 --> Session routines successfully run
DEBUG - 2014-02-19 23:55:57 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:55:57 --> Model Class Initialized
DEBUG - 2014-02-19 23:55:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:55:57 --> Final output sent to browser
DEBUG - 2014-02-19 23:55:57 --> Total execution time: 0.0190
DEBUG - 2014-02-19 23:56:09 --> Config Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:56:09 --> URI Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Router Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Output Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Security Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Input Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:56:09 --> Language Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Loader Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Controller Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:56:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:56:09 --> Model Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Model Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Model Class Initialized
DEBUG - 2014-02-19 23:56:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:56:14 --> Final output sent to browser
DEBUG - 2014-02-19 23:56:14 --> Total execution time: 5.3993
DEBUG - 2014-02-19 23:56:39 --> Config Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:56:39 --> URI Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Router Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Output Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Security Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Input Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:56:39 --> Language Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Loader Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Controller Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:56:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:56:39 --> Model Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Model Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Model Class Initialized
DEBUG - 2014-02-19 23:56:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:56:43 --> Final output sent to browser
DEBUG - 2014-02-19 23:56:43 --> Total execution time: 4.1252
DEBUG - 2014-02-19 23:57:31 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:31 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:31 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:31 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:31 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:31 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:31 --> Session Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Session Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:57:31 --> A session cookie was not found.
DEBUG - 2014-02-19 23:57:31 --> A session cookie was not found.
DEBUG - 2014-02-19 23:57:31 --> Session routines successfully run
DEBUG - 2014-02-19 23:57:31 --> Session routines successfully run
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:57:31 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:31 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:31 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:31 --> Total execution time: 0.0250
DEBUG - 2014-02-19 23:57:31 --> Total execution time: 0.0240
DEBUG - 2014-02-19 23:57:32 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:32 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:32 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:32 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:32 --> Session Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:57:32 --> A session cookie was not found.
DEBUG - 2014-02-19 23:57:32 --> Session routines successfully run
DEBUG - 2014-02-19 23:57:32 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:57:32 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:32 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:32 --> Total execution time: 0.0180
DEBUG - 2014-02-19 23:57:36 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:36 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:36 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:36 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:36 --> Session Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:57:36 --> A session cookie was not found.
DEBUG - 2014-02-19 23:57:36 --> Session routines successfully run
DEBUG - 2014-02-19 23:57:36 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:57:36 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:36 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:36 --> Total execution time: 0.0200
DEBUG - 2014-02-19 23:57:37 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:37 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:37 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:37 --> Session Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:57:37 --> A session cookie was not found.
DEBUG - 2014-02-19 23:57:37 --> Session routines successfully run
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:37 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:37 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Total execution time: 0.0180
DEBUG - 2014-02-19 23:57:37 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:37 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:37 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:37 --> Session Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: string_helper
DEBUG - 2014-02-19 23:57:37 --> A session cookie was not found.
DEBUG - 2014-02-19 23:57:37 --> Session routines successfully run
DEBUG - 2014-02-19 23:57:37 --> Helper loaded: url_helper
DEBUG - 2014-02-19 23:57:37 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:37 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:37 --> Total execution time: 0.0190
DEBUG - 2014-02-19 23:57:50 --> Config Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:57:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:57:50 --> URI Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Router Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Output Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Security Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Input Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:57:50 --> Language Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Loader Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Controller Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:57:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:57:50 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Model Class Initialized
DEBUG - 2014-02-19 23:57:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:57:53 --> Final output sent to browser
DEBUG - 2014-02-19 23:57:53 --> Total execution time: 2.4351
DEBUG - 2014-02-19 23:58:15 --> Config Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Hooks Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Utf8 Class Initialized
DEBUG - 2014-02-19 23:58:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-19 23:58:15 --> URI Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Router Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Output Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Security Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Input Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-19 23:58:15 --> Language Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Loader Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Controller Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-19 23:58:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-19 23:58:15 --> Model Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Model Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Database Driver Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Model Class Initialized
DEBUG - 2014-02-19 23:58:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-19 23:58:18 --> Final output sent to browser
DEBUG - 2014-02-19 23:58:18 --> Total execution time: 3.3782
