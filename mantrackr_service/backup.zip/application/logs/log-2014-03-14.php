<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-14 15:06:11 --> Config Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Hooks Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Utf8 Class Initialized
DEBUG - 2014-03-14 15:06:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-14 15:06:11 --> URI Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Router Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Output Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Security Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Input Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-14 15:06:11 --> Language Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Loader Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Controller Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-14 15:06:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-14 15:06:11 --> Model Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Model Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Database Driver Class Initialized
ERROR - 2014-03-14 15:06:11 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-14 15:06:11 --> Model Class Initialized
DEBUG - 2014-03-14 15:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 15:06:11 --> Final output sent to browser
DEBUG - 2014-03-14 15:06:11 --> Total execution time: 0.0820
DEBUG - 2014-03-14 15:06:15 --> Config Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Hooks Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Utf8 Class Initialized
DEBUG - 2014-03-14 15:06:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-14 15:06:15 --> URI Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Router Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Output Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Security Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Input Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-14 15:06:15 --> Language Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Loader Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Controller Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-14 15:06:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-14 15:06:15 --> Model Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Model Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Database Driver Class Initialized
ERROR - 2014-03-14 15:06:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-14 15:06:15 --> Model Class Initialized
DEBUG - 2014-03-14 15:06:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 15:06:15 --> Final output sent to browser
DEBUG - 2014-03-14 15:06:15 --> Total execution time: 0.0150
DEBUG - 2014-03-14 22:11:12 --> Config Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Config Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Hooks Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Hooks Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Utf8 Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Utf8 Class Initialized
DEBUG - 2014-03-14 22:11:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-14 22:11:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-14 22:11:12 --> URI Class Initialized
DEBUG - 2014-03-14 22:11:12 --> URI Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Router Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Router Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Output Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Output Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Security Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Security Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Input Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Input Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-14 22:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-14 22:11:12 --> Language Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Language Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Loader Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Loader Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Controller Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Controller Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Database Driver Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Database Driver Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Config Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Hooks Class Initialized
ERROR - 2014-03-14 22:11:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-14 22:11:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-14 22:11:12 --> Utf8 Class Initialized
DEBUG - 2014-03-14 22:11:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-14 22:11:12 --> URI Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Router Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Output Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Security Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Input Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 22:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-14 22:11:12 --> Language Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Loader Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Controller Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Database Driver Class Initialized
ERROR - 2014-03-14 22:11:12 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 22:11:12 --> Session Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Session Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Session Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: string_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: string_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: string_helper
DEBUG - 2014-03-14 22:11:12 --> A session cookie was not found.
DEBUG - 2014-03-14 22:11:12 --> A session cookie was not found.
DEBUG - 2014-03-14 22:11:12 --> A session cookie was not found.
DEBUG - 2014-03-14 22:11:12 --> Session routines successfully run
DEBUG - 2014-03-14 22:11:12 --> Session routines successfully run
DEBUG - 2014-03-14 22:11:12 --> Session routines successfully run
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: url_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: url_helper
DEBUG - 2014-03-14 22:11:12 --> Helper loaded: url_helper
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Model Class Initialized
DEBUG - 2014-03-14 22:11:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 22:11:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 22:11:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-14 22:11:12 --> Final output sent to browser
DEBUG - 2014-03-14 22:11:12 --> Final output sent to browser
DEBUG - 2014-03-14 22:11:12 --> Final output sent to browser
DEBUG - 2014-03-14 22:11:12 --> Total execution time: 0.0710
DEBUG - 2014-03-14 22:11:12 --> Total execution time: 0.0790
DEBUG - 2014-03-14 22:11:12 --> Total execution time: 0.0790
