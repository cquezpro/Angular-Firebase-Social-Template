<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-04 00:04:33 --> Config Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:04:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:04:33 --> URI Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Router Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Output Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Security Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Input Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:04:33 --> Language Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Loader Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Controller Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:04:33 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:04:33 --> Model Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Model Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Model Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:04:33 --> Session Class Initialized
DEBUG - 2014-02-04 00:04:33 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:04:33 --> Session routines successfully run
DEBUG - 2014-02-04 00:04:33 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:04:33 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:04:33 --> Final output sent to browser
DEBUG - 2014-02-04 00:04:33 --> Total execution time: 0.0230
DEBUG - 2014-02-04 00:04:38 --> Config Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:04:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:04:38 --> URI Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Router Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Output Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Security Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Input Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:04:38 --> Language Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Loader Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Controller Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:04:38 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:04:38 --> Model Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Model Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Model Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:04:38 --> Session Class Initialized
DEBUG - 2014-02-04 00:04:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:04:38 --> Session routines successfully run
DEBUG - 2014-02-04 00:04:38 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:04:38 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:05:08 --> Config Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:05:08 --> URI Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Router Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Output Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Security Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Input Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:05:08 --> Language Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Loader Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Controller Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:05:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:05:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:05:08 --> Session Class Initialized
DEBUG - 2014-02-04 00:05:08 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:05:08 --> Session routines successfully run
DEBUG - 2014-02-04 00:05:08 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:05:08 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:05:08 --> Final output sent to browser
DEBUG - 2014-02-04 00:05:08 --> Total execution time: 0.0230
DEBUG - 2014-02-04 00:05:13 --> Config Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:05:13 --> URI Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Router Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Output Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Security Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Input Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:05:13 --> Language Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Loader Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Controller Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:05:13 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:05:13 --> Model Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Model Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Model Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:05:13 --> Session Class Initialized
DEBUG - 2014-02-04 00:05:13 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:05:13 --> Session routines successfully run
DEBUG - 2014-02-04 00:05:13 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:05:13 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:13:15 --> Config Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:13:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:13:15 --> URI Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Router Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Output Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Security Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Input Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:13:15 --> Language Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Loader Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Controller Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:13:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:13:15 --> Model Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Model Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Model Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:13:15 --> Session Class Initialized
DEBUG - 2014-02-04 00:13:15 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:13:15 --> Session routines successfully run
DEBUG - 2014-02-04 00:13:15 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:13:15 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:13:15 --> Final output sent to browser
DEBUG - 2014-02-04 00:13:15 --> Total execution time: 0.0210
DEBUG - 2014-02-04 00:13:20 --> Config Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:13:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:13:20 --> URI Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Router Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Output Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Security Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Input Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:13:20 --> Language Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Loader Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Controller Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:13:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:13:20 --> Model Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Model Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Model Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:13:20 --> Session Class Initialized
DEBUG - 2014-02-04 00:13:20 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:13:20 --> Session routines successfully run
DEBUG - 2014-02-04 00:13:20 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:13:20 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:15:05 --> Config Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:15:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:15:05 --> URI Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Router Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Output Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Security Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Input Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:15:05 --> Language Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Loader Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Controller Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:15:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:15:05 --> Model Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Model Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Model Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:15:05 --> Session Class Initialized
DEBUG - 2014-02-04 00:15:05 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:15:05 --> Session routines successfully run
DEBUG - 2014-02-04 00:15:05 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:15:05 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:15:05 --> Final output sent to browser
DEBUG - 2014-02-04 00:15:05 --> Total execution time: 0.0220
DEBUG - 2014-02-04 00:15:10 --> Config Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:15:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:15:10 --> URI Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Router Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Output Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Security Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Input Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:15:10 --> Language Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Loader Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Controller Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:15:10 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:15:10 --> Model Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Model Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Model Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:15:10 --> Session Class Initialized
DEBUG - 2014-02-04 00:15:10 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:15:10 --> Session routines successfully run
DEBUG - 2014-02-04 00:15:10 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:15:10 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:16:59 --> Config Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:16:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:16:59 --> URI Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Router Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Output Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Security Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Input Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:16:59 --> Language Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Loader Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Controller Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:16:59 --> Session Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:16:59 --> Session routines successfully run
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:16:59 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:16:59 --> Final output sent to browser
DEBUG - 2014-02-04 00:16:59 --> Total execution time: 0.0240
DEBUG - 2014-02-04 00:16:59 --> Config Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:16:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:16:59 --> URI Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Router Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Output Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Security Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Input Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:16:59 --> Language Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Loader Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Controller Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:16:59 --> Session Class Initialized
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:16:59 --> Session routines successfully run
DEBUG - 2014-02-04 00:16:59 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:16:59 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:17:08 --> Config Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:17:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:17:08 --> URI Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Router Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Output Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Security Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Input Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:17:08 --> Language Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Loader Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Controller Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:17:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:17:08 --> Session Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:17:08 --> Session routines successfully run
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:17:08 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:17:08 --> Final output sent to browser
DEBUG - 2014-02-04 00:17:08 --> Total execution time: 0.0220
DEBUG - 2014-02-04 00:17:08 --> Config Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:17:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:17:08 --> URI Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Router Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Output Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Security Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Input Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:17:08 --> Language Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Loader Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Controller Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:17:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Model Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:17:08 --> Session Class Initialized
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:17:08 --> Session routines successfully run
DEBUG - 2014-02-04 00:17:08 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:17:08 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:18:28 --> Config Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:18:28 --> URI Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Router Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Output Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Security Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Input Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:18:28 --> Language Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Loader Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Controller Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:18:28 --> Model Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Model Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Model Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:18:28 --> Session Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:18:28 --> Session routines successfully run
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:18:28 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:18:28 --> Final output sent to browser
DEBUG - 2014-02-04 00:18:28 --> Total execution time: 0.0260
DEBUG - 2014-02-04 00:18:28 --> Config Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:18:28 --> URI Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Router Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Output Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Security Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Input Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:18:28 --> Language Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Loader Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Controller Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:18:28 --> Model Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Model Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Model Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:18:28 --> Session Class Initialized
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:18:28 --> Session routines successfully run
DEBUG - 2014-02-04 00:18:28 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:18:28 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:20:14 --> Config Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:20:14 --> URI Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Router Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Output Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Security Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Input Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:20:14 --> Language Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Loader Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Controller Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:20:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:20:14 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:20:14 --> Session Class Initialized
DEBUG - 2014-02-04 00:20:14 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:20:14 --> Session routines successfully run
DEBUG - 2014-02-04 00:20:14 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:20:14 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:20:14 --> Final output sent to browser
DEBUG - 2014-02-04 00:20:14 --> Total execution time: 0.0140
DEBUG - 2014-02-04 00:20:19 --> Config Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:20:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:20:19 --> URI Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Router Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Output Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Security Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Input Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:20:19 --> Language Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Loader Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Controller Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:20:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:20:19 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:20:19 --> Session Class Initialized
DEBUG - 2014-02-04 00:20:19 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:20:19 --> Session routines successfully run
DEBUG - 2014-02-04 00:20:19 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:20:19 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:20:47 --> Config Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:20:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:20:47 --> URI Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Router Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Output Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Security Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Input Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:20:47 --> Language Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Loader Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Controller Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:20:47 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:20:47 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:20:47 --> Session Class Initialized
DEBUG - 2014-02-04 00:20:47 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:20:47 --> Session routines successfully run
DEBUG - 2014-02-04 00:20:47 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:20:47 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:20:47 --> Final output sent to browser
DEBUG - 2014-02-04 00:20:47 --> Total execution time: 0.0240
DEBUG - 2014-02-04 00:20:52 --> Config Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:20:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:20:52 --> URI Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Router Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Output Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Security Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Input Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:20:52 --> Language Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Loader Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Controller Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:20:52 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:20:52 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Model Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:20:52 --> Session Class Initialized
DEBUG - 2014-02-04 00:20:52 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:20:52 --> Session routines successfully run
DEBUG - 2014-02-04 00:20:52 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:20:52 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:21:27 --> Config Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:21:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:21:27 --> URI Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Router Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Output Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Security Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Input Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:21:27 --> Language Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Loader Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Controller Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:21:27 --> Model Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Model Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Model Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:21:27 --> Session Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:21:27 --> Session routines successfully run
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:21:27 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:21:27 --> Final output sent to browser
DEBUG - 2014-02-04 00:21:27 --> Total execution time: 0.0180
DEBUG - 2014-02-04 00:21:27 --> Config Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:21:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:21:27 --> URI Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Router Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Output Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Security Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Input Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:21:27 --> Language Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Loader Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Controller Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:21:27 --> Model Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Model Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Model Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:21:27 --> Session Class Initialized
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:21:27 --> Session routines successfully run
DEBUG - 2014-02-04 00:21:27 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:21:27 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:25:42 --> Config Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:25:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:25:42 --> URI Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Router Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Output Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Security Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Input Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:25:42 --> Language Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Loader Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Controller Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:25:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:25:42 --> Session Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:25:42 --> Session routines successfully run
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:25:42 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:25:42 --> Final output sent to browser
DEBUG - 2014-02-04 00:25:42 --> Total execution time: 0.0240
DEBUG - 2014-02-04 00:25:42 --> Config Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:25:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:25:42 --> URI Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Router Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Output Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Security Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Input Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:25:42 --> Language Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Loader Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Controller Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:25:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:25:42 --> Session Class Initialized
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:25:42 --> Session routines successfully run
DEBUG - 2014-02-04 00:25:42 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:25:42 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:26:14 --> Config Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:26:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:26:14 --> URI Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Router Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Output Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Security Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Input Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:26:14 --> Language Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Loader Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Controller Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:26:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:26:14 --> Model Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Model Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Model Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:26:14 --> Session Class Initialized
DEBUG - 2014-02-04 00:26:14 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:26:14 --> Session routines successfully run
DEBUG - 2014-02-04 00:26:14 --> Helper loaded: url_helper
ERROR - 2014-02-04 00:26:14 --> 404 Page Not Found --> admin/img
DEBUG - 2014-02-04 00:27:16 --> Config Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:27:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:27:16 --> URI Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Router Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Output Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Security Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Input Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:27:16 --> Language Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Loader Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Controller Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:27:16 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:27:16 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:27:16 --> Session Class Initialized
DEBUG - 2014-02-04 00:27:16 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:27:16 --> Session routines successfully run
DEBUG - 2014-02-04 00:27:16 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:27:16 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:27:16 --> Final output sent to browser
DEBUG - 2014-02-04 00:27:16 --> Total execution time: 0.0200
DEBUG - 2014-02-04 00:27:31 --> Config Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:27:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:27:31 --> URI Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Router Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Output Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Security Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Input Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:27:31 --> Language Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Loader Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Controller Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:27:31 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:27:31 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:27:31 --> Session Class Initialized
DEBUG - 2014-02-04 00:27:31 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:27:31 --> Session routines successfully run
DEBUG - 2014-02-04 00:27:31 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:27:31 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:27:31 --> Final output sent to browser
DEBUG - 2014-02-04 00:27:31 --> Total execution time: 0.0210
DEBUG - 2014-02-04 00:27:37 --> Config Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:27:37 --> URI Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Router Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Output Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Security Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Input Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:27:37 --> Language Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Loader Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Controller Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:27:37 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:27:37 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:27:37 --> Session Class Initialized
DEBUG - 2014-02-04 00:27:37 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:27:37 --> Session routines successfully run
DEBUG - 2014-02-04 00:27:37 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:27:37 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:27:37 --> Final output sent to browser
DEBUG - 2014-02-04 00:27:37 --> Total execution time: 0.0590
DEBUG - 2014-02-04 00:27:42 --> Config Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:27:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:27:42 --> URI Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Router Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Output Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Security Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Input Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:27:42 --> Language Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Loader Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Controller Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:27:42 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:27:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:27:42 --> Session Class Initialized
DEBUG - 2014-02-04 00:27:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:27:42 --> Session routines successfully run
DEBUG - 2014-02-04 00:27:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:27:42 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:27:42 --> Final output sent to browser
DEBUG - 2014-02-04 00:27:42 --> Total execution time: 0.0210
DEBUG - 2014-02-04 00:27:45 --> Config Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:27:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:27:45 --> URI Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Router Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Output Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Security Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Input Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:27:45 --> Language Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Loader Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Controller Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:27:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:27:45 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:27:45 --> Session Class Initialized
DEBUG - 2014-02-04 00:27:45 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:27:45 --> Session routines successfully run
DEBUG - 2014-02-04 00:27:45 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:27:45 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:27:45 --> Final output sent to browser
DEBUG - 2014-02-04 00:27:45 --> Total execution time: 0.0230
DEBUG - 2014-02-04 00:27:50 --> Config Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:27:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:27:50 --> URI Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Router Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Output Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Security Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Input Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:27:50 --> Language Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Loader Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Controller Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:27:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:27:50 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Model Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:27:50 --> Session Class Initialized
DEBUG - 2014-02-04 00:27:50 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:27:50 --> Session routines successfully run
DEBUG - 2014-02-04 00:27:50 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:27:50 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:27:50 --> Final output sent to browser
DEBUG - 2014-02-04 00:27:50 --> Total execution time: 0.0130
DEBUG - 2014-02-04 00:29:09 --> Config Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:29:09 --> URI Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Router Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Output Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Security Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Input Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:29:09 --> Language Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Loader Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Controller Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:29:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:29:09 --> Model Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Model Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Model Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:29:09 --> Session Class Initialized
DEBUG - 2014-02-04 00:29:09 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:29:09 --> Session routines successfully run
DEBUG - 2014-02-04 00:29:09 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:29:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:29:09 --> Final output sent to browser
DEBUG - 2014-02-04 00:29:09 --> Total execution time: 0.0240
DEBUG - 2014-02-04 00:29:15 --> Config Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Hooks Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Utf8 Class Initialized
DEBUG - 2014-02-04 00:29:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 00:29:15 --> URI Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Router Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Output Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Security Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Input Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 00:29:15 --> Language Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Loader Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Controller Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-04 00:29:15 --> Helper loaded: utilities_helper
DEBUG - 2014-02-04 00:29:15 --> Model Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Model Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Database Driver Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Model Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-04 00:29:15 --> Session Class Initialized
DEBUG - 2014-02-04 00:29:15 --> Helper loaded: string_helper
DEBUG - 2014-02-04 00:29:15 --> Session routines successfully run
DEBUG - 2014-02-04 00:29:15 --> Helper loaded: url_helper
DEBUG - 2014-02-04 00:29:15 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-04 00:29:15 --> Final output sent to browser
DEBUG - 2014-02-04 00:29:15 --> Total execution time: 0.0210
