<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-07 12:41:51 --> Config Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:41:51 --> Config Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:41:51 --> Config Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:41:51 --> URI Class Initialized
DEBUG - 2014-03-07 12:41:51 --> URI Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Router Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Router Class Initialized
DEBUG - 2014-03-07 12:41:51 --> URI Class Initialized
DEBUG - 2014-03-07 12:41:51 --> Router Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Output Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Output Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Output Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Security Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Security Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Security Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Input Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:41:52 --> Input Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:41:52 --> Input Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:41:52 --> Language Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Language Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Language Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Loader Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Loader Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Loader Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Controller Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Controller Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Controller Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:41:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:41:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:41:52 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:41:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:41:54 --> Session Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Session Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Session Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:41:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:41:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:41:54 --> A session cookie was not found.
DEBUG - 2014-03-07 12:41:54 --> A session cookie was not found.
DEBUG - 2014-03-07 12:41:54 --> A session cookie was not found.
DEBUG - 2014-03-07 12:41:54 --> Session routines successfully run
DEBUG - 2014-03-07 12:41:54 --> Session routines successfully run
DEBUG - 2014-03-07 12:41:54 --> Session routines successfully run
DEBUG - 2014-03-07 12:41:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:41:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:41:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:41:54 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Model Class Initialized
DEBUG - 2014-03-07 12:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:41:55 --> Final output sent to browser
DEBUG - 2014-03-07 12:41:55 --> Total execution time: 3.7942
DEBUG - 2014-03-07 12:41:55 --> Final output sent to browser
DEBUG - 2014-03-07 12:41:55 --> Total execution time: 3.9012
DEBUG - 2014-03-07 12:41:55 --> Final output sent to browser
DEBUG - 2014-03-07 12:41:55 --> Total execution time: 3.3902
DEBUG - 2014-03-07 12:42:05 --> Config Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:42:05 --> URI Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Router Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Output Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Security Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Input Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:42:05 --> Language Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Loader Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Controller Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:42:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:42:05 --> Model Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Model Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Helper loaded: email_helper
DEBUG - 2014-03-07 12:42:05 --> Model Class Initialized
DEBUG - 2014-03-07 12:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:42:11 --> Final output sent to browser
DEBUG - 2014-03-07 12:42:11 --> Total execution time: 6.0883
DEBUG - 2014-03-07 12:47:28 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:28 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:28 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:28 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:28 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:29 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:29 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:29 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:29 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:29 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:29 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:29 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:29 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:29 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:29 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:29 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:29 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:29 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:29 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:29 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:29 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:29 --> Total execution time: 0.0240
DEBUG - 2014-03-07 12:47:29 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:29 --> Total execution time: 0.0280
DEBUG - 2014-03-07 12:47:29 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:29 --> Total execution time: 0.0470
DEBUG - 2014-03-07 12:47:30 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:30 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:30 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:30 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:30 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:30 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:30 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:30 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:30 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:30 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:30 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:30 --> Total execution time: 0.0120
DEBUG - 2014-03-07 12:47:30 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:30 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:30 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:30 --> Total execution time: 0.0110
DEBUG - 2014-03-07 12:47:30 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:30 --> Total execution time: 0.0210
DEBUG - 2014-03-07 12:47:37 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:37 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:37 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:37 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:37 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:37 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:37 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:37 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:37 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:37 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:37 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:37 --> Total execution time: 0.0200
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:37 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:37 --> Total execution time: 0.0170
DEBUG - 2014-03-07 12:47:37 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:37 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:37 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:37 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:37 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:37 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:37 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:37 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:37 --> Total execution time: 0.0100
DEBUG - 2014-03-07 12:47:39 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:39 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:39 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Config Class Initialized
DEBUG - 2014-03-07 12:47:39 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:47:39 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:39 --> URI Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Router Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:39 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:39 --> Output Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Security Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Input Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:47:39 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Language Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:39 --> Loader Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:39 --> Controller Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:47:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:39 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:39 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:39 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:39 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:39 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:39 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:39 --> Session Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Total execution time: 0.0220
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> A session cookie was not found.
DEBUG - 2014-03-07 12:47:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:39 --> Session routines successfully run
DEBUG - 2014-03-07 12:47:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:47:39 --> Model Class Initialized
DEBUG - 2014-03-07 12:47:39 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:47:39 --> Total execution time: 0.0210
DEBUG - 2014-03-07 12:47:39 --> Final output sent to browser
DEBUG - 2014-03-07 12:47:39 --> Total execution time: 0.0200
DEBUG - 2014-03-07 12:54:32 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:32 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:32 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:32 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:32 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:32 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:32 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:32 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:32 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:32 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:32 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:32 --> Total execution time: 0.0360
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:32 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:32 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:32 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:32 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:32 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:32 --> Total execution time: 0.0740
DEBUG - 2014-03-07 12:54:32 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:32 --> Total execution time: 0.0750
DEBUG - 2014-03-07 12:54:34 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:34 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:34 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:34 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:34 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:34 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:34 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:34 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:34 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:34 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:34 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:34 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:34 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:34 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:34 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:34 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:34 --> Total execution time: 0.0130
DEBUG - 2014-03-07 12:54:34 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Total execution time: 0.0120
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:34 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:34 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:34 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:34 --> Total execution time: 0.0130
DEBUG - 2014-03-07 12:54:40 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:40 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:40 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:40 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:40 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:40 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:40 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:40 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:40 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:40 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:40 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:40 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:40 --> Total execution time: 0.0120
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:40 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:40 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:40 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:40 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:40 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:40 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:40 --> Total execution time: 0.0120
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:40 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:40 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:40 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:40 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:40 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:40 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:40 --> Total execution time: 0.0110
DEBUG - 2014-03-07 12:54:42 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:42 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:42 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:42 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Config Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:54:42 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:42 --> URI Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Router Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:42 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Output Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Security Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Input Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:54:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:42 --> Language Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Loader Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Controller Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:54:42 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:42 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:42 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:42 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:42 --> Session Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:42 --> Total execution time: 0.0120
DEBUG - 2014-03-07 12:54:42 --> A session cookie was not found.
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Session routines successfully run
DEBUG - 2014-03-07 12:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:54:42 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:42 --> Model Class Initialized
DEBUG - 2014-03-07 12:54:42 --> Total execution time: 0.0130
DEBUG - 2014-03-07 12:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:54:42 --> Final output sent to browser
DEBUG - 2014-03-07 12:54:42 --> Total execution time: 0.0120
DEBUG - 2014-03-07 12:58:53 --> Config Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:58:53 --> URI Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Router Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Output Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Security Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Input Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:58:53 --> Language Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Loader Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Controller Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:58:53 --> Session Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:58:53 --> A session cookie was not found.
DEBUG - 2014-03-07 12:58:53 --> Session routines successfully run
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:58:53 --> Final output sent to browser
DEBUG - 2014-03-07 12:58:53 --> Total execution time: 0.0200
DEBUG - 2014-03-07 12:58:53 --> Config Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:58:53 --> URI Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Router Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Output Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Security Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Input Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:58:53 --> Language Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Loader Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Controller Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:58:53 --> Session Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:58:53 --> A session cookie was not found.
DEBUG - 2014-03-07 12:58:53 --> Session routines successfully run
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:58:53 --> Final output sent to browser
DEBUG - 2014-03-07 12:58:53 --> Total execution time: 0.0100
DEBUG - 2014-03-07 12:58:53 --> Config Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 12:58:53 --> URI Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Router Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Output Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Security Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Input Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 12:58:53 --> Language Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Loader Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Controller Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:58:53 --> Session Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 12:58:53 --> A session cookie was not found.
DEBUG - 2014-03-07 12:58:53 --> Session routines successfully run
DEBUG - 2014-03-07 12:58:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 12:58:53 --> Model Class Initialized
DEBUG - 2014-03-07 12:58:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 12:58:53 --> Final output sent to browser
DEBUG - 2014-03-07 12:58:53 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:00:09 --> Config Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:00:09 --> URI Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Router Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Output Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Security Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Input Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:00:09 --> Language Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Loader Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Controller Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Config Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:00:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:00:09 --> URI Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Router Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Output Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Security Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Input Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:00:09 --> Language Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:00:09 --> Loader Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Controller Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Session Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:00:09 --> A session cookie was not found.
DEBUG - 2014-03-07 13:00:09 --> Session routines successfully run
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Config Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:00:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:00:09 --> URI Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Router Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Final output sent to browser
DEBUG - 2014-03-07 13:00:09 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Output Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:00:09 --> Security Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Session Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Input Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:00:09 --> A session cookie was not found.
DEBUG - 2014-03-07 13:00:09 --> Language Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Session routines successfully run
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:00:09 --> Loader Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Controller Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:00:09 --> Final output sent to browser
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:00:09 --> Session Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:00:09 --> A session cookie was not found.
DEBUG - 2014-03-07 13:00:09 --> Session routines successfully run
DEBUG - 2014-03-07 13:00:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:00:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:00:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:00:09 --> Final output sent to browser
DEBUG - 2014-03-07 13:00:09 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:06:52 --> Config Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Config Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Config Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:06:52 --> URI Class Initialized
DEBUG - 2014-03-07 13:06:52 --> URI Class Initialized
DEBUG - 2014-03-07 13:06:52 --> URI Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Router Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Router Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Router Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Output Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Output Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Output Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Security Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Security Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Security Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Input Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Input Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Input Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:06:52 --> Language Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Language Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Language Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Loader Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Loader Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Loader Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Controller Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Controller Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Controller Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:06:52 --> Session Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Session Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:06:52 --> A session cookie was not found.
DEBUG - 2014-03-07 13:06:52 --> A session cookie was not found.
DEBUG - 2014-03-07 13:06:52 --> Session routines successfully run
DEBUG - 2014-03-07 13:06:52 --> Session routines successfully run
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:06:52 --> Final output sent to browser
DEBUG - 2014-03-07 13:06:52 --> Final output sent to browser
DEBUG - 2014-03-07 13:06:52 --> Total execution time: 0.0180
DEBUG - 2014-03-07 13:06:52 --> Total execution time: 0.0180
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:06:52 --> Session Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:06:52 --> A session cookie was not found.
DEBUG - 2014-03-07 13:06:52 --> Session routines successfully run
DEBUG - 2014-03-07 13:06:52 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:06:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:06:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:06:52 --> Final output sent to browser
DEBUG - 2014-03-07 13:06:52 --> Total execution time: 0.0270
DEBUG - 2014-03-07 13:07:21 --> Config Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:07:21 --> URI Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Router Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Output Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Security Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Input Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:07:21 --> Language Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Loader Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Controller Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:07:21 --> Session Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Config Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Config Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:07:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:07:21 --> A session cookie was not found.
DEBUG - 2014-03-07 13:07:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Session routines successfully run
DEBUG - 2014-03-07 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:07:21 --> URI Class Initialized
DEBUG - 2014-03-07 13:07:21 --> URI Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Router Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Router Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:07:21 --> Output Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Output Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Security Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Final output sent to browser
DEBUG - 2014-03-07 13:07:21 --> Security Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Total execution time: 0.1950
DEBUG - 2014-03-07 13:07:21 --> Input Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Input Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:07:21 --> Language Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Language Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Loader Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Loader Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Controller Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Controller Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:07:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:07:21 --> Session Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Session Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:07:21 --> A session cookie was not found.
DEBUG - 2014-03-07 13:07:21 --> A session cookie was not found.
DEBUG - 2014-03-07 13:07:21 --> Session routines successfully run
DEBUG - 2014-03-07 13:07:21 --> Session routines successfully run
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:07:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:07:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:07:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:07:21 --> Final output sent to browser
DEBUG - 2014-03-07 13:07:21 --> Total execution time: 0.1960
DEBUG - 2014-03-07 13:07:21 --> Final output sent to browser
DEBUG - 2014-03-07 13:07:21 --> Total execution time: 0.1300
DEBUG - 2014-03-07 13:08:57 --> Config Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:08:57 --> URI Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Router Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Output Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Security Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Input Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:08:57 --> Language Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Loader Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Controller Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:08:57 --> Session Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:08:57 --> A session cookie was not found.
DEBUG - 2014-03-07 13:08:57 --> Session routines successfully run
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:08:57 --> Final output sent to browser
DEBUG - 2014-03-07 13:08:57 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:08:57 --> Config Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:08:57 --> URI Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Router Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Output Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Security Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Input Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:08:57 --> Language Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Loader Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Controller Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:08:57 --> Session Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:08:57 --> A session cookie was not found.
DEBUG - 2014-03-07 13:08:57 --> Session routines successfully run
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:08:57 --> Final output sent to browser
DEBUG - 2014-03-07 13:08:57 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:08:57 --> Config Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:08:57 --> URI Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Router Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Output Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Security Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Input Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:08:57 --> Language Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Loader Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Controller Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:08:57 --> Session Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:08:57 --> A session cookie was not found.
DEBUG - 2014-03-07 13:08:57 --> Session routines successfully run
DEBUG - 2014-03-07 13:08:57 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:08:57 --> Model Class Initialized
DEBUG - 2014-03-07 13:08:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:08:57 --> Final output sent to browser
DEBUG - 2014-03-07 13:08:57 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:11:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:25 --> Total execution time: 0.0160
DEBUG - 2014-03-07 13:11:25 --> Total execution time: 0.0170
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:25 --> Total execution time: 0.0260
DEBUG - 2014-03-07 13:11:31 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:31 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:31 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:31 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:31 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:31 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:31 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:31 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:31 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:31 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:31 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:31 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:11:31 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:31 --> Total execution time: 0.0260
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:31 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:31 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:31 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:31 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:31 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:31 --> Total execution time: 0.0300
DEBUG - 2014-03-07 13:11:53 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:53 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:53 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:53 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:53 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:53 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:53 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:53 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:53 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:53 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:53 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:53 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:53 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:53 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:53 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:11:53 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:11:53 --> Config Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:11:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:11:53 --> URI Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Router Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Output Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Security Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Input Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:11:53 --> Language Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Loader Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Controller Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:53 --> Session Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:11:53 --> A session cookie was not found.
DEBUG - 2014-03-07 13:11:53 --> Session routines successfully run
DEBUG - 2014-03-07 13:11:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:11:53 --> Model Class Initialized
DEBUG - 2014-03-07 13:11:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:11:53 --> Final output sent to browser
DEBUG - 2014-03-07 13:11:53 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:12:01 --> Config Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Config Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Config Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:12:01 --> URI Class Initialized
DEBUG - 2014-03-07 13:12:01 --> URI Class Initialized
DEBUG - 2014-03-07 13:12:01 --> URI Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Router Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Router Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Router Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Output Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Output Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Output Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Security Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Security Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Security Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Input Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Input Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Input Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:12:01 --> Language Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Language Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Language Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Loader Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Loader Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Loader Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Controller Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Controller Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Controller Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:12:01 --> Session Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Session Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:12:01 --> A session cookie was not found.
DEBUG - 2014-03-07 13:12:01 --> A session cookie was not found.
DEBUG - 2014-03-07 13:12:01 --> Session routines successfully run
DEBUG - 2014-03-07 13:12:01 --> Session routines successfully run
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:12:01 --> Final output sent to browser
DEBUG - 2014-03-07 13:12:01 --> Final output sent to browser
DEBUG - 2014-03-07 13:12:01 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:12:01 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:12:01 --> Session Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:12:01 --> A session cookie was not found.
DEBUG - 2014-03-07 13:12:01 --> Session routines successfully run
DEBUG - 2014-03-07 13:12:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:12:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:12:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:12:01 --> Final output sent to browser
DEBUG - 2014-03-07 13:12:01 --> Total execution time: 0.0280
DEBUG - 2014-03-07 13:13:52 --> Config Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Config Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Config Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:13:52 --> URI Class Initialized
DEBUG - 2014-03-07 13:13:52 --> URI Class Initialized
DEBUG - 2014-03-07 13:13:52 --> URI Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Router Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Router Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Router Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Output Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Output Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Output Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Security Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Security Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Security Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Input Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Input Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Input Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:13:52 --> Language Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Language Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Language Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Loader Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Loader Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Loader Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Controller Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Controller Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Controller Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:52 --> Session Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Session Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:13:52 --> A session cookie was not found.
DEBUG - 2014-03-07 13:13:52 --> A session cookie was not found.
DEBUG - 2014-03-07 13:13:52 --> Session routines successfully run
DEBUG - 2014-03-07 13:13:52 --> Session routines successfully run
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:52 --> Final output sent to browser
DEBUG - 2014-03-07 13:13:52 --> Final output sent to browser
DEBUG - 2014-03-07 13:13:52 --> Total execution time: 0.0190
DEBUG - 2014-03-07 13:13:52 --> Total execution time: 0.0180
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:52 --> Session Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:13:52 --> A session cookie was not found.
DEBUG - 2014-03-07 13:13:52 --> Session routines successfully run
DEBUG - 2014-03-07 13:13:52 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:13:52 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:52 --> Final output sent to browser
DEBUG - 2014-03-07 13:13:52 --> Total execution time: 0.0280
DEBUG - 2014-03-07 13:13:54 --> Config Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Config Class Initialized
DEBUG - 2014-03-07 13:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:13:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:13:54 --> URI Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Router Class Initialized
DEBUG - 2014-03-07 13:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:13:54 --> URI Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Output Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Router Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Security Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Input Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Output Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:13:54 --> Language Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Security Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Config Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Loader Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Input Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Controller Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:13:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:13:54 --> Language Class Initialized
DEBUG - 2014-03-07 13:13:54 --> URI Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:13:54 --> Router Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Loader Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Controller Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Output Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:13:54 --> Security Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:13:54 --> Input Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Language Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Loader Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:54 --> Controller Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:13:54 --> Session Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> A session cookie was not found.
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:54 --> Session routines successfully run
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Session Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:13:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> A session cookie was not found.
DEBUG - 2014-03-07 13:13:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:54 --> Session routines successfully run
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:13:54 --> Final output sent to browser
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:13:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:54 --> Session Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Final output sent to browser
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:13:54 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:13:54 --> A session cookie was not found.
DEBUG - 2014-03-07 13:13:54 --> Session routines successfully run
DEBUG - 2014-03-07 13:13:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:13:54 --> Model Class Initialized
DEBUG - 2014-03-07 13:13:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:13:54 --> Final output sent to browser
DEBUG - 2014-03-07 13:13:54 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:15:36 --> Config Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:15:36 --> URI Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Router Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Output Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Config Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Security Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:15:36 --> Input Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:15:36 --> URI Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Config Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Language Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Router Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:15:36 --> Loader Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Output Class Initialized
DEBUG - 2014-03-07 13:15:36 --> URI Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Controller Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Security Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Router Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:15:36 --> Input Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:15:36 --> Output Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Language Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Security Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Loader Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Input Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Controller Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:15:36 --> Language Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:15:36 --> Loader Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Controller Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Session Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:15:36 --> A session cookie was not found.
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Session routines successfully run
DEBUG - 2014-03-07 13:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:15:36 --> Session Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:36 --> A session cookie was not found.
DEBUG - 2014-03-07 13:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:36 --> Session routines successfully run
DEBUG - 2014-03-07 13:15:36 --> Session Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:15:36 --> Final output sent to browser
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Total execution time: 0.0230
DEBUG - 2014-03-07 13:15:36 --> A session cookie was not found.
DEBUG - 2014-03-07 13:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:36 --> Session routines successfully run
DEBUG - 2014-03-07 13:15:36 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:15:36 --> Final output sent to browser
DEBUG - 2014-03-07 13:15:36 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:36 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:36 --> Final output sent to browser
DEBUG - 2014-03-07 13:15:36 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:15:38 --> Config Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:15:38 --> URI Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Router Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Output Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Security Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Input Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:15:38 --> Language Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Config Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Loader Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Controller Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Config Class Initialized
DEBUG - 2014-03-07 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:15:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:15:38 --> URI Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:15:38 --> Router Class Initialized
DEBUG - 2014-03-07 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> URI Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Output Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Router Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Security Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Output Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Input Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:15:38 --> Security Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Input Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Language Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:15:38 --> Language Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Loader Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Controller Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Loader Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:15:38 --> Controller Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:15:38 --> Session Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> A session cookie was not found.
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Session routines successfully run
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:38 --> Session Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Final output sent to browser
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:38 --> A session cookie was not found.
DEBUG - 2014-03-07 13:15:38 --> Session Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Session routines successfully run
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:15:38 --> A session cookie was not found.
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Session routines successfully run
DEBUG - 2014-03-07 13:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:15:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:15:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:15:38 --> Final output sent to browser
DEBUG - 2014-03-07 13:15:38 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:15:38 --> Final output sent to browser
DEBUG - 2014-03-07 13:15:38 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:19:38 --> Config Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:19:38 --> URI Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Router Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Output Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Config Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Security Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:19:38 --> Input Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:19:38 --> URI Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Language Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Router Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Loader Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Output Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Controller Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Security Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:19:38 --> Input Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Language Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Loader Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Controller Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:19:38 --> Config Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:19:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:38 --> URI Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Router Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Session Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:19:38 --> Output Class Initialized
DEBUG - 2014-03-07 13:19:38 --> A session cookie was not found.
DEBUG - 2014-03-07 13:19:38 --> Security Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Session routines successfully run
DEBUG - 2014-03-07 13:19:38 --> Input Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:38 --> Language Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:38 --> Session Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Loader Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:19:38 --> Controller Class Initialized
DEBUG - 2014-03-07 13:19:38 --> A session cookie was not found.
DEBUG - 2014-03-07 13:19:38 --> Final output sent to browser
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:19:38 --> Session routines successfully run
DEBUG - 2014-03-07 13:19:38 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Final output sent to browser
DEBUG - 2014-03-07 13:19:38 --> Total execution time: 0.0190
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:38 --> Session Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:19:38 --> A session cookie was not found.
DEBUG - 2014-03-07 13:19:38 --> Session routines successfully run
DEBUG - 2014-03-07 13:19:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:19:38 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:38 --> Final output sent to browser
DEBUG - 2014-03-07 13:19:38 --> Total execution time: 0.0150
DEBUG - 2014-03-07 13:19:39 --> Config Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Config Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:19:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:19:39 --> URI Class Initialized
DEBUG - 2014-03-07 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:19:39 --> Router Class Initialized
DEBUG - 2014-03-07 13:19:39 --> URI Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Router Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Output Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Output Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Security Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Config Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Input Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Security Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:19:39 --> Input Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:19:39 --> Language Class Initialized
DEBUG - 2014-03-07 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:19:39 --> Language Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Loader Class Initialized
DEBUG - 2014-03-07 13:19:39 --> URI Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Loader Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Controller Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Router Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Controller Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:19:39 --> Output Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Security Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Input Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:19:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Language Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Loader Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Controller Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:19:39 --> Session Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Session Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:19:39 --> A session cookie was not found.
DEBUG - 2014-03-07 13:19:39 --> A session cookie was not found.
DEBUG - 2014-03-07 13:19:39 --> Session routines successfully run
DEBUG - 2014-03-07 13:19:39 --> Session routines successfully run
DEBUG - 2014-03-07 13:19:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:39 --> Final output sent to browser
DEBUG - 2014-03-07 13:19:39 --> Final output sent to browser
DEBUG - 2014-03-07 13:19:39 --> Total execution time: 0.0190
DEBUG - 2014-03-07 13:19:39 --> Session Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:19:39 --> A session cookie was not found.
DEBUG - 2014-03-07 13:19:39 --> Session routines successfully run
DEBUG - 2014-03-07 13:19:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:19:39 --> Model Class Initialized
DEBUG - 2014-03-07 13:19:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:19:39 --> Final output sent to browser
DEBUG - 2014-03-07 13:19:39 --> Total execution time: 0.0170
DEBUG - 2014-03-07 13:22:02 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:02 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:02 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:02 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:02 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:02 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:02 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:02 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:22:02 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:02 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:02 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:02 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:02 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:02 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:02 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:02 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:22:02 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:02 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:02 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:02 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:02 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:02 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:02 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:02 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:02 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:02 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:22:20 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:20 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:20 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:20 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:20 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:20 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:20 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:20 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:20 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:20 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:20 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:20 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:20 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:20 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:20 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:20 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:20 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:20 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:20 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:20 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:20 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:22:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:20 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:20 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:20 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:22:44 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:44 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:44 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:44 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:44 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:44 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:44 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:44 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:44 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:44 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:44 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:44 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:44 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:44 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:44 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:44 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:22:44 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:22:44 --> Config Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:22:44 --> URI Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Router Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Output Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Security Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Input Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:22:44 --> Language Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Loader Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Controller Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:44 --> Session Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:22:44 --> A session cookie was not found.
DEBUG - 2014-03-07 13:22:44 --> Session routines successfully run
DEBUG - 2014-03-07 13:22:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:22:44 --> Model Class Initialized
DEBUG - 2014-03-07 13:22:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:22:44 --> Final output sent to browser
DEBUG - 2014-03-07 13:22:44 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:23:16 --> Config Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Config Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Config Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:23:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:23:16 --> URI Class Initialized
DEBUG - 2014-03-07 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:23:16 --> URI Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Router Class Initialized
DEBUG - 2014-03-07 13:23:16 --> URI Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Router Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Router Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Output Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Output Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Output Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Security Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Security Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Security Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Input Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Input Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Input Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:23:16 --> Language Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Language Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Language Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Loader Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Loader Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Loader Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Controller Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Controller Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Controller Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:16 --> Session Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Session Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Session Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:23:16 --> A session cookie was not found.
DEBUG - 2014-03-07 13:23:16 --> A session cookie was not found.
DEBUG - 2014-03-07 13:23:16 --> A session cookie was not found.
DEBUG - 2014-03-07 13:23:16 --> Session routines successfully run
DEBUG - 2014-03-07 13:23:16 --> Session routines successfully run
DEBUG - 2014-03-07 13:23:16 --> Session routines successfully run
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:23:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:16 --> Final output sent to browser
DEBUG - 2014-03-07 13:23:16 --> Final output sent to browser
DEBUG - 2014-03-07 13:23:16 --> Final output sent to browser
DEBUG - 2014-03-07 13:23:16 --> Total execution time: 0.0130
DEBUG - 2014-03-07 13:23:16 --> Total execution time: 0.0130
DEBUG - 2014-03-07 13:23:16 --> Total execution time: 0.0140
DEBUG - 2014-03-07 13:23:30 --> Config Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Config Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Config Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:23:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:23:30 --> URI Class Initialized
DEBUG - 2014-03-07 13:23:30 --> URI Class Initialized
DEBUG - 2014-03-07 13:23:30 --> URI Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Router Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Router Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Router Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Output Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Output Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Output Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Security Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Security Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Security Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Input Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Input Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Input Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:23:30 --> Language Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Language Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Language Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Loader Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Loader Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Loader Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Controller Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Controller Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Controller Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:30 --> Session Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:23:30 --> A session cookie was not found.
DEBUG - 2014-03-07 13:23:30 --> Session routines successfully run
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Final output sent to browser
DEBUG - 2014-03-07 13:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:30 --> Total execution time: 0.0250
DEBUG - 2014-03-07 13:23:30 --> Session Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:23:30 --> Session Class Initialized
DEBUG - 2014-03-07 13:23:30 --> A session cookie was not found.
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:23:30 --> Session routines successfully run
DEBUG - 2014-03-07 13:23:30 --> A session cookie was not found.
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:23:30 --> Session routines successfully run
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:30 --> Model Class Initialized
DEBUG - 2014-03-07 13:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:23:30 --> Final output sent to browser
DEBUG - 2014-03-07 13:23:30 --> Total execution time: 0.0300
DEBUG - 2014-03-07 13:23:30 --> Final output sent to browser
DEBUG - 2014-03-07 13:23:30 --> Total execution time: 0.0310
DEBUG - 2014-03-07 13:28:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:28:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:28:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:28:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:28:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:28:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:28:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:28:12 --> Total execution time: 0.0270
DEBUG - 2014-03-07 13:28:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:28:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:28:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:28:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:28:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:28:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:28:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:28:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:28:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:28:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:28:12 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:28:13 --> Config Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:28:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:28:13 --> URI Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Router Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Output Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Security Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Input Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:28:13 --> Language Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Loader Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Controller Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:28:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:28:13 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:28:13 --> Session Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:28:13 --> A session cookie was not found.
DEBUG - 2014-03-07 13:28:13 --> Session routines successfully run
DEBUG - 2014-03-07 13:28:13 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:28:13 --> Model Class Initialized
DEBUG - 2014-03-07 13:28:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:28:13 --> Final output sent to browser
DEBUG - 2014-03-07 13:28:13 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:30:22 --> Config Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:30:22 --> URI Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Router Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Output Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Security Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Input Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:30:22 --> Language Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Loader Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Controller Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:30:22 --> Session Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:30:22 --> A session cookie was not found.
DEBUG - 2014-03-07 13:30:22 --> Session routines successfully run
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:30:22 --> Final output sent to browser
DEBUG - 2014-03-07 13:30:22 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:30:22 --> Config Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:30:22 --> URI Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Router Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Output Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Security Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Input Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:30:22 --> Language Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Loader Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Controller Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:30:22 --> Session Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:30:22 --> A session cookie was not found.
DEBUG - 2014-03-07 13:30:22 --> Session routines successfully run
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:30:22 --> Final output sent to browser
DEBUG - 2014-03-07 13:30:22 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:30:22 --> Config Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:30:22 --> URI Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Router Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Output Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Security Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Input Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:30:22 --> Language Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Loader Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Controller Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:30:22 --> Session Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:30:22 --> A session cookie was not found.
DEBUG - 2014-03-07 13:30:22 --> Session routines successfully run
DEBUG - 2014-03-07 13:30:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:30:22 --> Model Class Initialized
DEBUG - 2014-03-07 13:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:30:22 --> Final output sent to browser
DEBUG - 2014-03-07 13:30:22 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:37:48 --> Config Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Config Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:37:48 --> URI Class Initialized
DEBUG - 2014-03-07 13:37:48 --> URI Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Router Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Router Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Output Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Output Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Security Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Security Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Input Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Input Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:37:48 --> Language Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Language Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Loader Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Loader Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Controller Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Controller Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Config Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:37:48 --> URI Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Session Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Router Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Session Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:37:48 --> A session cookie was not found.
DEBUG - 2014-03-07 13:37:48 --> A session cookie was not found.
DEBUG - 2014-03-07 13:37:48 --> Output Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Session routines successfully run
DEBUG - 2014-03-07 13:37:48 --> Session routines successfully run
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:37:48 --> Security Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:37:48 --> Input Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Language Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:37:48 --> Loader Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Final output sent to browser
DEBUG - 2014-03-07 13:37:48 --> Controller Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Final output sent to browser
DEBUG - 2014-03-07 13:37:48 --> Total execution time: 0.0130
DEBUG - 2014-03-07 13:37:48 --> Total execution time: 0.0130
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:37:48 --> Session Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:37:48 --> A session cookie was not found.
DEBUG - 2014-03-07 13:37:48 --> Session routines successfully run
DEBUG - 2014-03-07 13:37:48 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:37:48 --> Model Class Initialized
DEBUG - 2014-03-07 13:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:37:48 --> Final output sent to browser
DEBUG - 2014-03-07 13:37:48 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:38:05 --> Config Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Config Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Config Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:38:05 --> URI Class Initialized
DEBUG - 2014-03-07 13:38:05 --> URI Class Initialized
DEBUG - 2014-03-07 13:38:05 --> URI Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Router Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Router Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Router Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Output Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Output Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Output Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Security Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Security Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Security Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Input Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Input Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Input Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:38:05 --> Language Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Language Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Language Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Loader Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Loader Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Loader Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Controller Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Controller Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Controller Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:38:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:38:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:38:05 --> Session Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Session Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Session Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:38:05 --> A session cookie was not found.
DEBUG - 2014-03-07 13:38:05 --> A session cookie was not found.
DEBUG - 2014-03-07 13:38:05 --> A session cookie was not found.
DEBUG - 2014-03-07 13:38:05 --> Session routines successfully run
DEBUG - 2014-03-07 13:38:05 --> Session routines successfully run
DEBUG - 2014-03-07 13:38:05 --> Session routines successfully run
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:38:05 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:38:05 --> Model Class Initialized
DEBUG - 2014-03-07 13:38:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:38:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:38:05 --> Final output sent to browser
DEBUG - 2014-03-07 13:38:05 --> Final output sent to browser
DEBUG - 2014-03-07 13:38:05 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:38:05 --> Final output sent to browser
DEBUG - 2014-03-07 13:38:05 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:38:05 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:42:21 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:21 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:21 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:21 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:21 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:21 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:21 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:21 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:21 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:21 --> Total execution time: 0.0150
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:21 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:21 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:21 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:21 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:21 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:21 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:21 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:21 --> Total execution time: 0.0260
DEBUG - 2014-03-07 13:42:21 --> Total execution time: 0.0260
DEBUG - 2014-03-07 13:42:47 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:47 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:47 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:47 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:47 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:47 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:47 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:47 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:47 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:47 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:47 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:47 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:42:47 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:42:47 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:47 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:47 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:47 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:47 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:47 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:47 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:47 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:42:49 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:49 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Config Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:42:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:42:49 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:49 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:49 --> URI Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:49 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Router Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Output Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:49 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Security Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Input Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:49 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Language Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:49 --> Loader Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Controller Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:42:49 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:49 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:49 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:49 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:49 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:49 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:49 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:49 --> Session Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:42:49 --> A session cookie was not found.
DEBUG - 2014-03-07 13:42:49 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:49 --> Session routines successfully run
DEBUG - 2014-03-07 13:42:49 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:49 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:42:49 --> Total execution time: 0.0140
DEBUG - 2014-03-07 13:42:49 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:42:49 --> Model Class Initialized
DEBUG - 2014-03-07 13:42:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:42:49 --> Final output sent to browser
DEBUG - 2014-03-07 13:42:49 --> Total execution time: 0.0130
DEBUG - 2014-03-07 13:43:59 --> Config Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Config Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Config Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:43:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:43:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:43:59 --> URI Class Initialized
DEBUG - 2014-03-07 13:43:59 --> URI Class Initialized
DEBUG - 2014-03-07 13:43:59 --> URI Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Router Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Router Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Router Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Output Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Output Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Output Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Security Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Security Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Security Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Input Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Input Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Input Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:43:59 --> Language Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Language Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Language Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Loader Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Loader Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Loader Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Controller Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Controller Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Controller Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:43:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:43:59 --> Session Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Session Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Session Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:43:59 --> A session cookie was not found.
DEBUG - 2014-03-07 13:43:59 --> A session cookie was not found.
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:43:59 --> Session routines successfully run
DEBUG - 2014-03-07 13:43:59 --> A session cookie was not found.
DEBUG - 2014-03-07 13:43:59 --> Session routines successfully run
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:43:59 --> Session routines successfully run
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:43:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:43:59 --> Model Class Initialized
DEBUG - 2014-03-07 13:43:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:43:59 --> Final output sent to browser
DEBUG - 2014-03-07 13:43:59 --> Final output sent to browser
DEBUG - 2014-03-07 13:43:59 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:43:59 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:43:59 --> Final output sent to browser
DEBUG - 2014-03-07 13:43:59 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:45:09 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:09 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:09 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:09 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:09 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:09 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:09 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:09 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:09 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:09 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:09 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:09 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:09 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:45:09 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:09 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:45:09 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:09 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:09 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:09 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:09 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:09 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:09 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:09 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:09 --> Total execution time: 0.0100
DEBUG - 2014-03-07 13:45:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:12 --> Total execution time: 0.0130
DEBUG - 2014-03-07 13:45:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:12 --> Total execution time: 0.0110
DEBUG - 2014-03-07 13:45:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:12 --> Total execution time: 0.0120
DEBUG - 2014-03-07 13:45:45 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:45 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:45 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:45 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:45 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:45 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:45 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:45 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:45 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:45 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:45 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:45 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:45 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:45 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:45 --> Total execution time: 0.0260
DEBUG - 2014-03-07 13:45:45 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:45 --> Total execution time: 0.0260
DEBUG - 2014-03-07 13:45:45 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:45 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:45 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:45 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:45:47 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:47 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:47 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Config Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:45:47 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:47 --> URI Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Router Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:47 --> Output Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:47 --> Security Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Input Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Language Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Loader Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Controller Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:47 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:47 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:47 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:47 --> Session Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:45:47 --> A session cookie was not found.
DEBUG - 2014-03-07 13:45:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:47 --> Session routines successfully run
DEBUG - 2014-03-07 13:45:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:45:47 --> Model Class Initialized
DEBUG - 2014-03-07 13:45:47 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:47 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:45:47 --> Total execution time: 0.0240
DEBUG - 2014-03-07 13:45:47 --> Total execution time: 0.0240
DEBUG - 2014-03-07 13:45:47 --> Final output sent to browser
DEBUG - 2014-03-07 13:45:47 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:46:01 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:01 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:01 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:01 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:01 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:01 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:01 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:01 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:01 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:01 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:01 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:01 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:01 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:01 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:01 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:01 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:01 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:01 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:01 --> Total execution time: 0.0200
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:01 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:01 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:01 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:01 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:01 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:01 --> Total execution time: 0.0310
DEBUG - 2014-03-07 13:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:25 --> Total execution time: 0.0220
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:25 --> Total execution time: 0.0290
DEBUG - 2014-03-07 13:46:25 --> Total execution time: 0.0290
DEBUG - 2014-03-07 13:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Config Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:46:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:25 --> URI Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Router Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:25 --> Output Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Security Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Input Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:46:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Language Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Loader Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Controller Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:46:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:25 --> Total execution time: 0.0160
DEBUG - 2014-03-07 13:46:25 --> Total execution time: 0.0160
DEBUG - 2014-03-07 13:46:25 --> Session Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:46:25 --> A session cookie was not found.
DEBUG - 2014-03-07 13:46:25 --> Session routines successfully run
DEBUG - 2014-03-07 13:46:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:46:25 --> Model Class Initialized
DEBUG - 2014-03-07 13:46:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:46:25 --> Final output sent to browser
DEBUG - 2014-03-07 13:46:25 --> Total execution time: 0.0160
DEBUG - 2014-03-07 13:47:04 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:04 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:04 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:04 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:04 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:04 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:04 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:04 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:04 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:04 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:04 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:04 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:04 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:04 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:04 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:04 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:04 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:04 --> Total execution time: 0.0190
DEBUG - 2014-03-07 13:47:04 --> Total execution time: 0.0190
DEBUG - 2014-03-07 13:47:04 --> Total execution time: 0.0190
DEBUG - 2014-03-07 13:47:11 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:11 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:11 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:11 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:11 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:11 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:11 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:11 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:11 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:11 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:11 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:11 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:11 --> Total execution time: 0.0230
DEBUG - 2014-03-07 13:47:11 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:11 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:11 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:11 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:11 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:11 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:47:11 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:47:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Config Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 13:47:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:12 --> URI Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Router Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:12 --> Output Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:12 --> Security Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Input Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 13:47:12 --> Language Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Loader Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Controller Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 13:47:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:12 --> Session Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 13:47:12 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:47:12 --> Total execution time: 0.0210
DEBUG - 2014-03-07 13:47:12 --> A session cookie was not found.
DEBUG - 2014-03-07 13:47:12 --> Session routines successfully run
DEBUG - 2014-03-07 13:47:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 13:47:12 --> Model Class Initialized
DEBUG - 2014-03-07 13:47:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 13:47:12 --> Final output sent to browser
DEBUG - 2014-03-07 13:47:12 --> Total execution time: 0.0190
DEBUG - 2014-03-07 14:02:28 --> Config Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Config Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Config Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:02:28 --> URI Class Initialized
DEBUG - 2014-03-07 14:02:28 --> URI Class Initialized
DEBUG - 2014-03-07 14:02:28 --> URI Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Router Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Router Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Router Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Output Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Output Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Output Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Security Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Security Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Security Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Input Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Input Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Input Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:02:28 --> Language Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Language Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Language Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Loader Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Loader Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Loader Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Controller Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Controller Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Controller Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:02:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:02:28 --> Session Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Session Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:02:28 --> A session cookie was not found.
DEBUG - 2014-03-07 14:02:28 --> A session cookie was not found.
DEBUG - 2014-03-07 14:02:28 --> Session routines successfully run
DEBUG - 2014-03-07 14:02:28 --> Session routines successfully run
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:02:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:02:28 --> Final output sent to browser
DEBUG - 2014-03-07 14:02:28 --> Total execution time: 0.0170
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:02:28 --> Session Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:02:28 --> A session cookie was not found.
DEBUG - 2014-03-07 14:02:28 --> Session routines successfully run
DEBUG - 2014-03-07 14:02:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:02:28 --> Model Class Initialized
DEBUG - 2014-03-07 14:02:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:02:28 --> Final output sent to browser
DEBUG - 2014-03-07 14:02:28 --> Total execution time: 0.0260
DEBUG - 2014-03-07 14:02:28 --> Final output sent to browser
DEBUG - 2014-03-07 14:02:28 --> Total execution time: 0.0430
DEBUG - 2014-03-07 14:04:14 --> Config Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:04:14 --> URI Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Router Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Output Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Security Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Config Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Input Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Config Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:04:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Language Class Initialized
DEBUG - 2014-03-07 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:04:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:04:14 --> URI Class Initialized
DEBUG - 2014-03-07 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:04:14 --> Loader Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Router Class Initialized
DEBUG - 2014-03-07 14:04:14 --> URI Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Controller Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Router Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:04:14 --> Output Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:04:14 --> Output Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Security Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Security Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Input Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:04:14 --> Input Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:04:14 --> Language Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Language Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Loader Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Controller Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Loader Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Controller Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Session Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:04:14 --> A session cookie was not found.
DEBUG - 2014-03-07 14:04:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Session routines successfully run
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:14 --> Session Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:04:14 --> Session Class Initialized
DEBUG - 2014-03-07 14:04:14 --> A session cookie was not found.
DEBUG - 2014-03-07 14:04:14 --> Final output sent to browser
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:04:14 --> Session routines successfully run
DEBUG - 2014-03-07 14:04:14 --> Total execution time: 0.0190
DEBUG - 2014-03-07 14:04:14 --> A session cookie was not found.
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:04:14 --> Session routines successfully run
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:14 --> Final output sent to browser
DEBUG - 2014-03-07 14:04:14 --> Total execution time: 0.0150
DEBUG - 2014-03-07 14:04:14 --> Final output sent to browser
DEBUG - 2014-03-07 14:04:14 --> Total execution time: 0.0150
DEBUG - 2014-03-07 14:04:32 --> Config Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Config Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:04:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:04:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:04:32 --> URI Class Initialized
DEBUG - 2014-03-07 14:04:32 --> URI Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Router Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Router Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Config Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Output Class Initialized
DEBUG - 2014-03-07 14:04:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:04:32 --> Output Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Security Class Initialized
DEBUG - 2014-03-07 14:04:32 --> URI Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Security Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Input Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Router Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Input Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:04:32 --> Language Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Language Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Output Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Loader Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Loader Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Controller Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Controller Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:04:32 --> Security Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:04:32 --> Input Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Language Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Loader Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Controller Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:32 --> Session Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Session Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:04:32 --> A session cookie was not found.
DEBUG - 2014-03-07 14:04:32 --> A session cookie was not found.
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Session routines successfully run
DEBUG - 2014-03-07 14:04:32 --> Session routines successfully run
DEBUG - 2014-03-07 14:04:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:04:32 --> Session Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:04:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:32 --> A session cookie was not found.
DEBUG - 2014-03-07 14:04:32 --> Session routines successfully run
DEBUG - 2014-03-07 14:04:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:04:32 --> Final output sent to browser
DEBUG - 2014-03-07 14:04:32 --> Final output sent to browser
DEBUG - 2014-03-07 14:04:32 --> Total execution time: 0.0140
DEBUG - 2014-03-07 14:04:32 --> Total execution time: 0.0140
DEBUG - 2014-03-07 14:04:32 --> Model Class Initialized
DEBUG - 2014-03-07 14:04:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:04:32 --> Final output sent to browser
DEBUG - 2014-03-07 14:04:32 --> Total execution time: 0.0130
DEBUG - 2014-03-07 14:11:48 --> Config Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Config Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:11:48 --> URI Class Initialized
DEBUG - 2014-03-07 14:11:48 --> URI Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Router Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Router Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Output Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Output Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Security Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Security Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Input Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Input Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:11:48 --> Language Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Language Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Loader Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Loader Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Controller Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Controller Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Config Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:11:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:11:48 --> URI Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Router Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:48 --> Output Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Session Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Session Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Security Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:11:48 --> Input Class Initialized
DEBUG - 2014-03-07 14:11:48 --> A session cookie was not found.
DEBUG - 2014-03-07 14:11:48 --> A session cookie was not found.
DEBUG - 2014-03-07 14:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:11:48 --> Session routines successfully run
DEBUG - 2014-03-07 14:11:48 --> Session routines successfully run
DEBUG - 2014-03-07 14:11:48 --> Language Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Loader Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:48 --> Controller Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:11:48 --> Final output sent to browser
DEBUG - 2014-03-07 14:11:48 --> Final output sent to browser
DEBUG - 2014-03-07 14:11:48 --> Total execution time: 0.0180
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Total execution time: 0.0180
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:48 --> Session Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:11:48 --> A session cookie was not found.
DEBUG - 2014-03-07 14:11:48 --> Session routines successfully run
DEBUG - 2014-03-07 14:11:48 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:11:48 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:48 --> Final output sent to browser
DEBUG - 2014-03-07 14:11:48 --> Total execution time: 0.0110
DEBUG - 2014-03-07 14:11:50 --> Config Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Config Class Initialized
DEBUG - 2014-03-07 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:11:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:11:50 --> URI Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:11:50 --> Router Class Initialized
DEBUG - 2014-03-07 14:11:50 --> URI Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Output Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Router Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Security Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Input Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Output Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:11:50 --> Security Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Config Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Language Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Input Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:11:50 --> Loader Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Controller Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Language Class Initialized
DEBUG - 2014-03-07 14:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:11:50 --> URI Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Loader Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:11:50 --> Controller Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Router Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Output Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:11:50 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Security Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Input Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:11:50 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Language Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Loader Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:50 --> Controller Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Session Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:11:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:50 --> A session cookie was not found.
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Session routines successfully run
DEBUG - 2014-03-07 14:11:50 --> Session Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:11:50 --> A session cookie was not found.
DEBUG - 2014-03-07 14:11:50 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Session routines successfully run
DEBUG - 2014-03-07 14:11:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Final output sent to browser
DEBUG - 2014-03-07 14:11:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Total execution time: 0.0220
DEBUG - 2014-03-07 14:11:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:50 --> Session Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Final output sent to browser
DEBUG - 2014-03-07 14:11:50 --> Total execution time: 0.0220
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:11:50 --> A session cookie was not found.
DEBUG - 2014-03-07 14:11:50 --> Session routines successfully run
DEBUG - 2014-03-07 14:11:50 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:11:50 --> Model Class Initialized
DEBUG - 2014-03-07 14:11:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:11:50 --> Final output sent to browser
DEBUG - 2014-03-07 14:11:50 --> Total execution time: 0.0220
DEBUG - 2014-03-07 14:12:57 --> Config Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Config Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:12:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:12:57 --> URI Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Router Class Initialized
DEBUG - 2014-03-07 14:12:57 --> URI Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Output Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Security Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Router Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Input Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:12:57 --> Output Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Language Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Security Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Loader Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Input Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:12:57 --> Controller Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Language Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:12:57 --> Loader Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Controller Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:12:57 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Session Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:12:57 --> A session cookie was not found.
DEBUG - 2014-03-07 14:12:57 --> Session Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Session routines successfully run
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:12:57 --> Config Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:12:57 --> A session cookie was not found.
DEBUG - 2014-03-07 14:12:57 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Session routines successfully run
DEBUG - 2014-03-07 14:12:57 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:12:57 --> URI Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Router Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:12:57 --> Final output sent to browser
DEBUG - 2014-03-07 14:12:57 --> Total execution time: 0.0130
DEBUG - 2014-03-07 14:12:57 --> Output Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Final output sent to browser
DEBUG - 2014-03-07 14:12:57 --> Total execution time: 0.0130
DEBUG - 2014-03-07 14:12:57 --> Security Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Input Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:12:57 --> Language Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Loader Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Controller Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:12:57 --> Session Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:12:57 --> A session cookie was not found.
DEBUG - 2014-03-07 14:12:57 --> Session routines successfully run
DEBUG - 2014-03-07 14:12:57 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:12:57 --> Model Class Initialized
DEBUG - 2014-03-07 14:12:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:12:57 --> Final output sent to browser
DEBUG - 2014-03-07 14:12:57 --> Total execution time: 0.0110
DEBUG - 2014-03-07 14:13:24 --> Config Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Config Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Config Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:13:24 --> URI Class Initialized
DEBUG - 2014-03-07 14:13:24 --> URI Class Initialized
DEBUG - 2014-03-07 14:13:24 --> URI Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Router Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Router Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Router Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Output Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Output Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Output Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Security Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Security Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Security Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Input Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Input Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Input Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:13:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:13:24 --> Language Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Language Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Language Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Loader Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Loader Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Loader Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Controller Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Controller Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Controller Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:13:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:13:24 --> Session Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Session Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:13:24 --> A session cookie was not found.
DEBUG - 2014-03-07 14:13:24 --> A session cookie was not found.
DEBUG - 2014-03-07 14:13:24 --> Session routines successfully run
DEBUG - 2014-03-07 14:13:24 --> Session routines successfully run
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:13:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:13:24 --> Final output sent to browser
DEBUG - 2014-03-07 14:13:24 --> Final output sent to browser
DEBUG - 2014-03-07 14:13:24 --> Total execution time: 0.0210
DEBUG - 2014-03-07 14:13:24 --> Total execution time: 0.0210
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:13:24 --> Session Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:13:24 --> A session cookie was not found.
DEBUG - 2014-03-07 14:13:24 --> Session routines successfully run
DEBUG - 2014-03-07 14:13:24 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:13:24 --> Model Class Initialized
DEBUG - 2014-03-07 14:13:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:13:24 --> Final output sent to browser
DEBUG - 2014-03-07 14:13:24 --> Total execution time: 0.0290
DEBUG - 2014-03-07 14:14:09 --> Config Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Config Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:14:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:14:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:14:09 --> URI Class Initialized
DEBUG - 2014-03-07 14:14:09 --> URI Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Router Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Router Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Output Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Output Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Security Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Security Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Input Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Input Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:14:09 --> Language Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Language Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Loader Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Loader Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Controller Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Controller Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:14:09 --> Session Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Session Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:14:09 --> A session cookie was not found.
DEBUG - 2014-03-07 14:14:09 --> A session cookie was not found.
DEBUG - 2014-03-07 14:14:09 --> Session routines successfully run
DEBUG - 2014-03-07 14:14:09 --> Session routines successfully run
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:14:09 --> Final output sent to browser
DEBUG - 2014-03-07 14:14:09 --> Final output sent to browser
DEBUG - 2014-03-07 14:14:09 --> Total execution time: 0.0250
DEBUG - 2014-03-07 14:14:09 --> Total execution time: 0.0250
DEBUG - 2014-03-07 14:14:09 --> Config Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:14:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:14:09 --> URI Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Router Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Output Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Security Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Input Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:14:09 --> Language Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Loader Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Controller Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:14:09 --> Session Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:14:09 --> A session cookie was not found.
DEBUG - 2014-03-07 14:14:09 --> Session routines successfully run
DEBUG - 2014-03-07 14:14:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:14:09 --> Model Class Initialized
DEBUG - 2014-03-07 14:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:14:09 --> Final output sent to browser
DEBUG - 2014-03-07 14:14:09 --> Total execution time: 0.0180
DEBUG - 2014-03-07 14:15:40 --> Config Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:15:40 --> URI Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Config Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Router Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:15:40 --> URI Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Output Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Router Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Security Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Output Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Input Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:15:40 --> Security Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Input Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Language Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:15:40 --> Language Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Loader Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Loader Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Controller Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Controller Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:40 --> Session Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Session Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:15:40 --> A session cookie was not found.
DEBUG - 2014-03-07 14:15:40 --> A session cookie was not found.
DEBUG - 2014-03-07 14:15:40 --> Session routines successfully run
DEBUG - 2014-03-07 14:15:40 --> Session routines successfully run
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Config Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:40 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:40 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:15:40 --> Final output sent to browser
DEBUG - 2014-03-07 14:15:40 --> Final output sent to browser
DEBUG - 2014-03-07 14:15:40 --> URI Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Total execution time: 0.0210
DEBUG - 2014-03-07 14:15:40 --> Total execution time: 0.0240
DEBUG - 2014-03-07 14:15:40 --> Router Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Output Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Security Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Input Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:15:40 --> Language Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Loader Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Controller Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:40 --> Session Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:15:40 --> A session cookie was not found.
DEBUG - 2014-03-07 14:15:40 --> Session routines successfully run
DEBUG - 2014-03-07 14:15:40 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:15:40 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:40 --> Final output sent to browser
DEBUG - 2014-03-07 14:15:40 --> Total execution time: 0.0150
DEBUG - 2014-03-07 14:15:45 --> Config Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Config Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:15:45 --> URI Class Initialized
DEBUG - 2014-03-07 14:15:45 --> URI Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Router Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Router Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Output Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Output Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Security Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Security Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Input Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Input Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:15:45 --> Language Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Language Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Loader Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Loader Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Controller Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Controller Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Config Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:15:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:15:45 --> URI Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Router Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Output Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Security Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:45 --> Input Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:15:45 --> Session Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Session Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Language Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:15:45 --> A session cookie was not found.
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:15:45 --> Loader Class Initialized
DEBUG - 2014-03-07 14:15:45 --> A session cookie was not found.
DEBUG - 2014-03-07 14:15:45 --> Session routines successfully run
DEBUG - 2014-03-07 14:15:45 --> Controller Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Session routines successfully run
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Final output sent to browser
DEBUG - 2014-03-07 14:15:45 --> Total execution time: 0.0130
DEBUG - 2014-03-07 14:15:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Final output sent to browser
DEBUG - 2014-03-07 14:15:45 --> Total execution time: 0.0130
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:45 --> Session Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:15:45 --> A session cookie was not found.
DEBUG - 2014-03-07 14:15:45 --> Session routines successfully run
DEBUG - 2014-03-07 14:15:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:15:45 --> Model Class Initialized
DEBUG - 2014-03-07 14:15:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:15:45 --> Final output sent to browser
DEBUG - 2014-03-07 14:15:45 --> Total execution time: 0.0120
DEBUG - 2014-03-07 14:16:27 --> Config Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Config Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Config Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:16:27 --> URI Class Initialized
DEBUG - 2014-03-07 14:16:27 --> URI Class Initialized
DEBUG - 2014-03-07 14:16:27 --> URI Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Router Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Router Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Router Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Output Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Output Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Output Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Security Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Security Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Security Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Input Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Input Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Input Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:16:27 --> Language Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Language Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Language Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Loader Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Loader Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Loader Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Controller Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Controller Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Controller Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:16:27 --> Session Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Session Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Session Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:16:27 --> A session cookie was not found.
DEBUG - 2014-03-07 14:16:27 --> A session cookie was not found.
DEBUG - 2014-03-07 14:16:27 --> A session cookie was not found.
DEBUG - 2014-03-07 14:16:27 --> Session routines successfully run
DEBUG - 2014-03-07 14:16:27 --> Session routines successfully run
DEBUG - 2014-03-07 14:16:27 --> Session routines successfully run
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:16:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Model Class Initialized
DEBUG - 2014-03-07 14:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:16:27 --> Final output sent to browser
DEBUG - 2014-03-07 14:16:27 --> Final output sent to browser
DEBUG - 2014-03-07 14:16:27 --> Final output sent to browser
DEBUG - 2014-03-07 14:16:27 --> Total execution time: 0.0170
DEBUG - 2014-03-07 14:16:27 --> Total execution time: 0.0170
DEBUG - 2014-03-07 14:16:27 --> Total execution time: 0.0170
DEBUG - 2014-03-07 14:19:22 --> Config Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:19:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:19:22 --> URI Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Router Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Output Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Security Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Input Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:19:22 --> Language Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Loader Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Controller Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:22 --> Session Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:19:22 --> A session cookie was not found.
DEBUG - 2014-03-07 14:19:22 --> Session routines successfully run
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:22 --> Final output sent to browser
DEBUG - 2014-03-07 14:19:22 --> Total execution time: 0.0120
DEBUG - 2014-03-07 14:19:22 --> Config Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:19:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:19:22 --> URI Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Router Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Output Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Security Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Input Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:19:22 --> Language Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Loader Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Controller Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:22 --> Session Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:19:22 --> A session cookie was not found.
DEBUG - 2014-03-07 14:19:22 --> Session routines successfully run
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:22 --> Final output sent to browser
DEBUG - 2014-03-07 14:19:22 --> Total execution time: 0.0110
DEBUG - 2014-03-07 14:19:22 --> Config Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:19:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:19:22 --> URI Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Router Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Output Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Security Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Input Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:19:22 --> Language Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Loader Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Controller Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:22 --> Session Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:19:22 --> A session cookie was not found.
DEBUG - 2014-03-07 14:19:22 --> Session routines successfully run
DEBUG - 2014-03-07 14:19:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:19:22 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:22 --> Final output sent to browser
DEBUG - 2014-03-07 14:19:22 --> Total execution time: 0.0110
DEBUG - 2014-03-07 14:19:36 --> Config Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:19:36 --> Config Class Initialized
DEBUG - 2014-03-07 14:19:36 --> URI Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Router Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:19:36 --> URI Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Output Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Router Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Security Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Output Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Input Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:19:36 --> Security Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Language Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Input Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:19:36 --> Language Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Loader Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Controller Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Loader Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:19:36 --> Controller Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Session Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:19:36 --> Session Class Initialized
DEBUG - 2014-03-07 14:19:36 --> A session cookie was not found.
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:19:36 --> Session routines successfully run
DEBUG - 2014-03-07 14:19:36 --> A session cookie was not found.
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:19:36 --> Session routines successfully run
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:36 --> Final output sent to browser
DEBUG - 2014-03-07 14:19:36 --> Config Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Total execution time: 0.0220
DEBUG - 2014-03-07 14:19:36 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Final output sent to browser
DEBUG - 2014-03-07 14:19:36 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Total execution time: 0.0210
DEBUG - 2014-03-07 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:19:36 --> URI Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Router Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Output Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Security Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Input Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:19:36 --> Language Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Loader Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Controller Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:36 --> Session Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:19:36 --> A session cookie was not found.
DEBUG - 2014-03-07 14:19:36 --> Session routines successfully run
DEBUG - 2014-03-07 14:19:36 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:19:36 --> Model Class Initialized
DEBUG - 2014-03-07 14:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:19:36 --> Final output sent to browser
DEBUG - 2014-03-07 14:19:36 --> Total execution time: 0.0140
DEBUG - 2014-03-07 14:20:01 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:01 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:01 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:01 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:01 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:01 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:01 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:01 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:01 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:01 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:01 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:01 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:01 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:01 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:01 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:01 --> Total execution time: 0.0190
DEBUG - 2014-03-07 14:20:01 --> Total execution time: 0.0190
DEBUG - 2014-03-07 14:20:01 --> Total execution time: 0.0180
DEBUG - 2014-03-07 14:20:14 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:14 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:14 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:14 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:14 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:14 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:14 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:14 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:14 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:14 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:14 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:14 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:14 --> Total execution time: 0.0190
DEBUG - 2014-03-07 14:20:14 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:14 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:14 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:14 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:14 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:14 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:14 --> Total execution time: 0.0160
DEBUG - 2014-03-07 14:20:14 --> Total execution time: 0.0240
DEBUG - 2014-03-07 14:20:23 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:23 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:23 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:23 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:23 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:23 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:23 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:23 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:23 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:23 --> Total execution time: 0.0230
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:23 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:23 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:23 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:23 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:23 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:23 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:23 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:23 --> Total execution time: 0.0300
DEBUG - 2014-03-07 14:20:23 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:23 --> Total execution time: 0.0310
DEBUG - 2014-03-07 14:20:25 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:25 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:25 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:25 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Config Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 14:20:25 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:25 --> URI Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Router Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:25 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:25 --> Output Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Security Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Input Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 14:20:25 --> Language Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Loader Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Controller Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 14:20:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:25 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:25 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:25 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:25 --> Session Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:25 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 14:20:25 --> Total execution time: 0.0230
DEBUG - 2014-03-07 14:20:25 --> Total execution time: 0.0230
DEBUG - 2014-03-07 14:20:25 --> A session cookie was not found.
DEBUG - 2014-03-07 14:20:25 --> Session routines successfully run
DEBUG - 2014-03-07 14:20:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 14:20:25 --> Model Class Initialized
DEBUG - 2014-03-07 14:20:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 14:20:25 --> Final output sent to browser
DEBUG - 2014-03-07 14:20:25 --> Total execution time: 0.0210
DEBUG - 2014-03-07 17:01:11 --> Config Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:01:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:01:11 --> URI Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Router Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Config Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Output Class Initialized
DEBUG - 2014-03-07 17:01:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:01:11 --> URI Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Security Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Router Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Input Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:01:11 --> Output Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Language Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Security Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Input Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Loader Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:01:11 --> Language Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Controller Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:01:11 --> Loader Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Controller Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:01:11 --> Session Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:01:11 --> A session cookie was not found.
DEBUG - 2014-03-07 17:01:11 --> Session routines successfully run
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Final output sent to browser
DEBUG - 2014-03-07 17:01:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:01:11 --> Total execution time: 0.0160
DEBUG - 2014-03-07 17:01:11 --> Config Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Session Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:01:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:01:11 --> A session cookie was not found.
DEBUG - 2014-03-07 17:01:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:01:11 --> Session routines successfully run
DEBUG - 2014-03-07 17:01:11 --> URI Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:01:11 --> Router Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:01:11 --> Output Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Security Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Input Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Final output sent to browser
DEBUG - 2014-03-07 17:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:01:11 --> Total execution time: 0.0170
DEBUG - 2014-03-07 17:01:11 --> Language Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Loader Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Controller Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:01:11 --> Session Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:01:11 --> A session cookie was not found.
DEBUG - 2014-03-07 17:01:11 --> Session routines successfully run
DEBUG - 2014-03-07 17:01:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:01:11 --> Model Class Initialized
DEBUG - 2014-03-07 17:01:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:01:11 --> Final output sent to browser
DEBUG - 2014-03-07 17:01:11 --> Total execution time: 0.0180
DEBUG - 2014-03-07 17:24:14 --> Config Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Config Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:24:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:24:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:24:14 --> URI Class Initialized
DEBUG - 2014-03-07 17:24:14 --> URI Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Router Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Router Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Output Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Output Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Security Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Security Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Input Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Input Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:24:14 --> Config Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Language Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Language Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Loader Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Loader Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Controller Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Controller Class Initialized
DEBUG - 2014-03-07 17:24:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:24:14 --> URI Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:24:14 --> Router Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Output Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Security Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Input Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:24:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Language Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:14 --> Session Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:24:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:14 --> Loader Class Initialized
DEBUG - 2014-03-07 17:24:14 --> A session cookie was not found.
DEBUG - 2014-03-07 17:24:14 --> Session routines successfully run
DEBUG - 2014-03-07 17:24:14 --> Session Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> A session cookie was not found.
DEBUG - 2014-03-07 17:24:14 --> Controller Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:24:14 --> Final output sent to browser
DEBUG - 2014-03-07 17:24:14 --> Session routines successfully run
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Total execution time: 0.0140
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:14 --> Final output sent to browser
DEBUG - 2014-03-07 17:24:14 --> Total execution time: 0.0170
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:14 --> Session Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:24:14 --> A session cookie was not found.
DEBUG - 2014-03-07 17:24:14 --> Session routines successfully run
DEBUG - 2014-03-07 17:24:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:24:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:14 --> Final output sent to browser
DEBUG - 2014-03-07 17:24:14 --> Total execution time: 0.0160
DEBUG - 2014-03-07 17:24:23 --> Config Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Config Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Config Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:24:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:24:23 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:24:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:24:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:24:23 --> URI Class Initialized
DEBUG - 2014-03-07 17:24:23 --> URI Class Initialized
DEBUG - 2014-03-07 17:24:23 --> URI Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Router Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Router Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Router Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Output Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Output Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Output Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Security Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Security Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Security Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Input Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Input Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Input Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:24:23 --> Language Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Language Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Language Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Loader Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Loader Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Loader Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Controller Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Controller Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Controller Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:23 --> Session Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Session Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Session Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:24:23 --> A session cookie was not found.
DEBUG - 2014-03-07 17:24:23 --> A session cookie was not found.
DEBUG - 2014-03-07 17:24:23 --> A session cookie was not found.
DEBUG - 2014-03-07 17:24:23 --> Session routines successfully run
DEBUG - 2014-03-07 17:24:23 --> Session routines successfully run
DEBUG - 2014-03-07 17:24:23 --> Session routines successfully run
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:24:23 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Model Class Initialized
DEBUG - 2014-03-07 17:24:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:24:23 --> Final output sent to browser
DEBUG - 2014-03-07 17:24:23 --> Final output sent to browser
DEBUG - 2014-03-07 17:24:23 --> Final output sent to browser
DEBUG - 2014-03-07 17:24:23 --> Total execution time: 0.0240
DEBUG - 2014-03-07 17:24:23 --> Total execution time: 0.0240
DEBUG - 2014-03-07 17:24:23 --> Total execution time: 0.0240
DEBUG - 2014-03-07 17:27:43 --> Config Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:27:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:27:43 --> URI Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Router Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Output Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Security Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Input Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:27:43 --> Config Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Language Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:27:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:27:43 --> Loader Class Initialized
DEBUG - 2014-03-07 17:27:43 --> URI Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Controller Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Router Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:27:43 --> Output Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Security Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Input Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:27:43 --> Language Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Loader Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Controller Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Session Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:27:43 --> A session cookie was not found.
DEBUG - 2014-03-07 17:27:43 --> Session routines successfully run
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:27:43 --> Session Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Final output sent to browser
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:27:43 --> Total execution time: 0.0140
DEBUG - 2014-03-07 17:27:43 --> A session cookie was not found.
DEBUG - 2014-03-07 17:27:43 --> Session routines successfully run
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:27:43 --> Final output sent to browser
DEBUG - 2014-03-07 17:27:43 --> Total execution time: 0.0130
DEBUG - 2014-03-07 17:27:43 --> Config Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:27:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:27:43 --> URI Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Router Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Output Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Security Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Input Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:27:43 --> Language Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Loader Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Controller Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:27:43 --> Session Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:27:43 --> A session cookie was not found.
DEBUG - 2014-03-07 17:27:43 --> Session routines successfully run
DEBUG - 2014-03-07 17:27:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:27:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:27:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:27:43 --> Final output sent to browser
DEBUG - 2014-03-07 17:27:43 --> Total execution time: 0.0120
DEBUG - 2014-03-07 17:28:14 --> Config Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Config Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Config Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:28:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:28:14 --> URI Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:28:14 --> URI Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Router Class Initialized
DEBUG - 2014-03-07 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:28:14 --> Router Class Initialized
DEBUG - 2014-03-07 17:28:14 --> URI Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Output Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Router Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Output Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Security Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Security Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Output Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Input Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Input Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Security Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:28:14 --> Input Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:28:14 --> Language Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Language Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Language Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Loader Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Loader Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Loader Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Controller Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Controller Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Controller Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Session Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:28:14 --> A session cookie was not found.
DEBUG - 2014-03-07 17:28:14 --> Session Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Session routines successfully run
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:28:14 --> A session cookie was not found.
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:28:14 --> Session routines successfully run
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:28:14 --> Final output sent to browser
DEBUG - 2014-03-07 17:28:14 --> Total execution time: 0.0150
DEBUG - 2014-03-07 17:28:14 --> Final output sent to browser
DEBUG - 2014-03-07 17:28:14 --> Total execution time: 0.0150
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:28:14 --> Session Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:28:14 --> A session cookie was not found.
DEBUG - 2014-03-07 17:28:14 --> Session routines successfully run
DEBUG - 2014-03-07 17:28:14 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:28:14 --> Model Class Initialized
DEBUG - 2014-03-07 17:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:28:14 --> Final output sent to browser
DEBUG - 2014-03-07 17:28:14 --> Total execution time: 0.0240
DEBUG - 2014-03-07 17:30:43 --> Config Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Config Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:30:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:30:43 --> URI Class Initialized
DEBUG - 2014-03-07 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:30:43 --> Router Class Initialized
DEBUG - 2014-03-07 17:30:43 --> URI Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Router Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Config Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Output Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Output Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Security Class Initialized
DEBUG - 2014-03-07 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:30:43 --> Security Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Input Class Initialized
DEBUG - 2014-03-07 17:30:43 --> URI Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Input Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:30:43 --> Router Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Language Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Language Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Output Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Loader Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Loader Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Security Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Controller Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Controller Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Input Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:30:43 --> Language Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Loader Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Controller Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:30:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:30:43 --> Session Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:30:43 --> Session Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:30:43 --> Session Class Initialized
DEBUG - 2014-03-07 17:30:43 --> A session cookie was not found.
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:30:43 --> Session routines successfully run
DEBUG - 2014-03-07 17:30:43 --> A session cookie was not found.
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:30:43 --> A session cookie was not found.
DEBUG - 2014-03-07 17:30:43 --> Session routines successfully run
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:30:43 --> Session routines successfully run
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-03-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:30:43 --> Final output sent to browser
DEBUG - 2014-03-07 17:30:43 --> Final output sent to browser
DEBUG - 2014-03-07 17:30:43 --> Final output sent to browser
DEBUG - 2014-03-07 17:30:43 --> Total execution time: 0.0240
DEBUG - 2014-03-07 17:30:43 --> Total execution time: 0.0230
DEBUG - 2014-03-07 17:30:43 --> Total execution time: 0.0200
DEBUG - 2014-03-07 17:34:32 --> Config Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Config Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:34:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:34:32 --> URI Class Initialized
DEBUG - 2014-03-07 17:34:32 --> URI Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Router Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Router Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Config Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Output Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Output Class Initialized
DEBUG - 2014-03-07 17:34:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:34:32 --> Security Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Security Class Initialized
DEBUG - 2014-03-07 17:34:32 --> URI Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Input Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Input Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Router Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:34:32 --> Language Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Language Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Output Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Loader Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Loader Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Controller Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Security Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Controller Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:34:32 --> Input Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:34:32 --> Language Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Loader Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Controller Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:34:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:32 --> Session Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> A session cookie was not found.
DEBUG - 2014-03-07 17:34:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:32 --> Session routines successfully run
DEBUG - 2014-03-07 17:34:32 --> Session Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> A session cookie was not found.
DEBUG - 2014-03-07 17:34:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:32 --> Session routines successfully run
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Final output sent to browser
DEBUG - 2014-03-07 17:34:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:32 --> Total execution time: 0.0180
DEBUG - 2014-03-07 17:34:32 --> Final output sent to browser
DEBUG - 2014-03-07 17:34:32 --> Total execution time: 0.0150
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:32 --> Session Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:34:32 --> A session cookie was not found.
DEBUG - 2014-03-07 17:34:32 --> Session routines successfully run
DEBUG - 2014-03-07 17:34:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:34:32 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:32 --> Final output sent to browser
DEBUG - 2014-03-07 17:34:32 --> Total execution time: 0.0260
DEBUG - 2014-03-07 17:34:34 --> Config Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:34:34 --> URI Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Router Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Output Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Security Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Input Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:34:34 --> Config Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Language Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Config Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:34:34 --> Loader Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Controller Class Initialized
DEBUG - 2014-03-07 17:34:34 --> URI Class Initialized
DEBUG - 2014-03-07 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:34:34 --> Router Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:34:34 --> URI Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:34:34 --> Router Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Output Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Security Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Output Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Input Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:34:34 --> Security Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Language Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Input Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:34:34 --> Loader Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Language Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Controller Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:34:34 --> Loader Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:34:34 --> Controller Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:34:34 --> Session Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:34:34 --> A session cookie was not found.
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Session routines successfully run
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:34 --> Final output sent to browser
DEBUG - 2014-03-07 17:34:34 --> Session Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Total execution time: 0.0220
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:34:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:34 --> A session cookie was not found.
DEBUG - 2014-03-07 17:34:34 --> Session routines successfully run
DEBUG - 2014-03-07 17:34:34 --> Session Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> A session cookie was not found.
DEBUG - 2014-03-07 17:34:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:34 --> Session routines successfully run
DEBUG - 2014-03-07 17:34:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:34:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:34:34 --> Final output sent to browser
DEBUG - 2014-03-07 17:34:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:34:34 --> Total execution time: 0.0210
DEBUG - 2014-03-07 17:34:34 --> Final output sent to browser
DEBUG - 2014-03-07 17:34:34 --> Total execution time: 0.0230
DEBUG - 2014-03-07 17:35:53 --> Config Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:35:53 --> Config Class Initialized
DEBUG - 2014-03-07 17:35:53 --> URI Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Router Class Initialized
DEBUG - 2014-03-07 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:35:53 --> URI Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Router Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Output Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Security Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Output Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Input Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:35:53 --> Security Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Input Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Language Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:35:53 --> Language Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Loader Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Controller Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Loader Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Controller Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:35:53 --> Session Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:35:53 --> A session cookie was not found.
DEBUG - 2014-03-07 17:35:53 --> Session routines successfully run
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:35:53 --> Config Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Final output sent to browser
DEBUG - 2014-03-07 17:35:53 --> Total execution time: 0.0190
DEBUG - 2014-03-07 17:35:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:35:53 --> URI Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Router Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Output Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Security Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Input Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:35:53 --> Language Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Loader Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Controller Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:35:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Session Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:35:53 --> A session cookie was not found.
DEBUG - 2014-03-07 17:35:53 --> Session routines successfully run
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:35:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Session Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:35:53 --> A session cookie was not found.
DEBUG - 2014-03-07 17:35:53 --> Session routines successfully run
DEBUG - 2014-03-07 17:35:53 --> Final output sent to browser
DEBUG - 2014-03-07 17:35:53 --> Total execution time: 0.0310
DEBUG - 2014-03-07 17:35:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:35:53 --> Model Class Initialized
DEBUG - 2014-03-07 17:35:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:35:53 --> Final output sent to browser
DEBUG - 2014-03-07 17:35:53 --> Total execution time: 0.0130
DEBUG - 2014-03-07 17:36:00 --> Config Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Config Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:36:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:36:00 --> URI Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Router Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Output Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:36:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:36:00 --> URI Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Security Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Config Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Input Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Router Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Output Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:36:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:36:00 --> Security Class Initialized
DEBUG - 2014-03-07 17:36:00 --> URI Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Input Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Router Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:36:00 --> Language Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Output Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Loader Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Language Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Security Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Controller Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Input Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Loader Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:36:00 --> Language Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:36:00 --> Loader Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Controller Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:36:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Controller Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:36:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Session Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:36:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:36:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:36:00 --> A session cookie was not found.
DEBUG - 2014-03-07 17:36:00 --> Session routines successfully run
DEBUG - 2014-03-07 17:36:00 --> Session Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:36:00 --> A session cookie was not found.
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Session routines successfully run
DEBUG - 2014-03-07 17:36:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:36:00 --> Final output sent to browser
DEBUG - 2014-03-07 17:36:00 --> Total execution time: 0.0170
DEBUG - 2014-03-07 17:36:00 --> Final output sent to browser
DEBUG - 2014-03-07 17:36:00 --> Total execution time: 0.0130
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:36:00 --> Session Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:36:00 --> A session cookie was not found.
DEBUG - 2014-03-07 17:36:00 --> Session routines successfully run
DEBUG - 2014-03-07 17:36:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:36:00 --> Model Class Initialized
DEBUG - 2014-03-07 17:36:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:36:00 --> Final output sent to browser
DEBUG - 2014-03-07 17:36:00 --> Total execution time: 0.0210
DEBUG - 2014-03-07 17:54:12 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:12 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:12 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:12 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:12 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:12 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:12 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:12 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:12 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:12 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:12 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:12 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:12 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:12 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:12 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:12 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:12 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:12 --> Total execution time: 0.0140
DEBUG - 2014-03-07 17:54:12 --> Total execution time: 0.0140
DEBUG - 2014-03-07 17:54:12 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:12 --> Total execution time: 0.0120
DEBUG - 2014-03-07 17:54:25 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:25 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:25 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:25 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:25 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:25 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:25 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:25 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:25 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:25 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:25 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:25 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:25 --> Total execution time: 0.0140
DEBUG - 2014-03-07 17:54:25 --> Total execution time: 0.0140
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:25 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:25 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:25 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:25 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:25 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:25 --> Total execution time: 0.0120
DEBUG - 2014-03-07 17:54:34 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:34 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:34 --> Config Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:54:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:54:34 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:34 --> URI Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Router Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:34 --> Output Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:34 --> Security Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Input Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:54:34 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Language Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Loader Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Controller Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:34 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:34 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:34 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:34 --> Session Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:54:34 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:34 --> A session cookie was not found.
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:34 --> Session routines successfully run
DEBUG - 2014-03-07 17:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Model Class Initialized
DEBUG - 2014-03-07 17:54:34 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:54:34 --> Total execution time: 0.0260
DEBUG - 2014-03-07 17:54:34 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:34 --> Final output sent to browser
DEBUG - 2014-03-07 17:54:34 --> Total execution time: 0.0210
DEBUG - 2014-03-07 17:54:34 --> Total execution time: 0.0220
DEBUG - 2014-03-07 17:57:54 --> Config Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:57:54 --> URI Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Router Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Output Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Security Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Input Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:57:54 --> Language Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Loader Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Controller Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Session Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:57:54 --> A session cookie was not found.
DEBUG - 2014-03-07 17:57:54 --> Session routines successfully run
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Final output sent to browser
DEBUG - 2014-03-07 17:57:54 --> Total execution time: 0.0200
DEBUG - 2014-03-07 17:57:54 --> Config Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Config Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:57:54 --> Config Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:57:54 --> URI Class Initialized
DEBUG - 2014-03-07 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:57:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Router Class Initialized
DEBUG - 2014-03-07 17:57:54 --> URI Class Initialized
DEBUG - 2014-03-07 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 17:57:54 --> Router Class Initialized
DEBUG - 2014-03-07 17:57:54 --> URI Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Output Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Router Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Security Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Output Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Input Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Output Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Security Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:57:54 --> Input Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Security Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Language Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:57:54 --> Input Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Language Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 17:57:54 --> Loader Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Language Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Loader Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Controller Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Controller Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Loader Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:57:54 --> Controller Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Session Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Session Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Session Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:57:54 --> A session cookie was not found.
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 17:57:54 --> A session cookie was not found.
DEBUG - 2014-03-07 17:57:54 --> Session routines successfully run
DEBUG - 2014-03-07 17:57:54 --> A session cookie was not found.
DEBUG - 2014-03-07 17:57:54 --> Session routines successfully run
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:57:54 --> Session routines successfully run
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Model Class Initialized
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 17:57:54 --> Final output sent to browser
DEBUG - 2014-03-07 17:57:54 --> Total execution time: 0.0200
DEBUG - 2014-03-07 17:57:54 --> Final output sent to browser
DEBUG - 2014-03-07 17:57:54 --> Final output sent to browser
DEBUG - 2014-03-07 17:57:54 --> Total execution time: 0.0220
DEBUG - 2014-03-07 17:57:54 --> Total execution time: 0.0200
DEBUG - 2014-03-07 18:23:10 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:10 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:10 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:10 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:10 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:10 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:10 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:10 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:10 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:10 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:10 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:10 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:10 --> Total execution time: 0.0240
DEBUG - 2014-03-07 18:23:10 --> Total execution time: 0.0240
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:10 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:10 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:10 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:10 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:10 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:10 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:10 --> Total execution time: 0.0320
DEBUG - 2014-03-07 18:23:12 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:12 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:12 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:12 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:12 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:12 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:12 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:12 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:12 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:12 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:12 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:12 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:12 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:12 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:12 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:12 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:23:12 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:12 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:12 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:12 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:12 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:12 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:12 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:23:41 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:41 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:41 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:41 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:41 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:41 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:41 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:41 --> Total execution time: 0.0110
DEBUG - 2014-03-07 18:23:41 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:41 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:41 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:41 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:41 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:41 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:41 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:41 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:41 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:41 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:41 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:41 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:41 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:41 --> Total execution time: 0.0120
DEBUG - 2014-03-07 18:23:41 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:41 --> Total execution time: 0.0110
DEBUG - 2014-03-07 18:23:43 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:43 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:43 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:43 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:43 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:43 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:43 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:43 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:43 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:43 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:43 --> Config Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Total execution time: 0.0110
DEBUG - 2014-03-07 18:23:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:43 --> URI Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Router Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Output Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Security Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Input Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:23:43 --> Language Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Loader Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Controller Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:43 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:43 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:43 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:23:43 --> Session Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:23:43 --> A session cookie was not found.
DEBUG - 2014-03-07 18:23:43 --> Session routines successfully run
DEBUG - 2014-03-07 18:23:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:23:43 --> Model Class Initialized
DEBUG - 2014-03-07 18:23:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:23:43 --> Final output sent to browser
DEBUG - 2014-03-07 18:23:43 --> Total execution time: 0.0110
DEBUG - 2014-03-07 18:25:00 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:00 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:00 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:00 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:00 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:00 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:00 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:00 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:00 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:00 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:00 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:00 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:00 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:00 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:00 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:00 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:00 --> Total execution time: 0.0150
DEBUG - 2014-03-07 18:25:00 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:00 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:00 --> Total execution time: 0.0160
DEBUG - 2014-03-07 18:25:05 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:05 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:05 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:05 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:05 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:05 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:05 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:05 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:05 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:05 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:05 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:05 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:05 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:05 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:05 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:05 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:05 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:05 --> Total execution time: 0.0240
DEBUG - 2014-03-07 18:25:05 --> Total execution time: 0.0240
DEBUG - 2014-03-07 18:25:05 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:05 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:05 --> Total execution time: 0.0210
DEBUG - 2014-03-07 18:25:11 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:11 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:11 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:11 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:11 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:11 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:11 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:11 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:11 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:11 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:11 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:11 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Total execution time: 0.0240
DEBUG - 2014-03-07 18:25:11 --> Total execution time: 0.0240
DEBUG - 2014-03-07 18:25:11 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:11 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:11 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:11 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:11 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:11 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:11 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:11 --> Total execution time: 0.0140
DEBUG - 2014-03-07 18:25:26 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:26 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:26 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:26 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:26 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:26 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:26 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:26 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:26 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:26 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:26 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:26 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:26 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:26 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:26 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:26 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:26 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:26 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:26 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:26 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:26 --> Total execution time: 0.0180
DEBUG - 2014-03-07 18:25:26 --> Total execution time: 0.0150
DEBUG - 2014-03-07 18:25:26 --> Total execution time: 0.0160
DEBUG - 2014-03-07 18:25:33 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:33 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:33 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:33 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:33 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:33 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:33 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:33 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:33 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:33 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:33 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:33 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:33 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:33 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:33 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:33 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:33 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:33 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:33 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:33 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:33 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:33 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:33 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:33 --> Total execution time: 0.0150
DEBUG - 2014-03-07 18:25:33 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:33 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:33 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:25:33 --> Total execution time: 0.0120
DEBUG - 2014-03-07 18:25:47 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:47 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:47 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Config Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:25:47 --> URI Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Router Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:47 --> Output Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:47 --> Security Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Input Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:25:47 --> Language Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Loader Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Controller Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:47 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:47 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:47 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:47 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:47 --> Session Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:25:47 --> A session cookie was not found.
DEBUG - 2014-03-07 18:25:47 --> Session routines successfully run
DEBUG - 2014-03-07 18:25:47 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:47 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:25:47 --> Total execution time: 0.0140
DEBUG - 2014-03-07 18:25:47 --> Total execution time: 0.0140
DEBUG - 2014-03-07 18:25:47 --> Model Class Initialized
DEBUG - 2014-03-07 18:25:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:25:47 --> Final output sent to browser
DEBUG - 2014-03-07 18:25:47 --> Total execution time: 0.0110
DEBUG - 2014-03-07 18:28:39 --> Config Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Config Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:28:39 --> URI Class Initialized
DEBUG - 2014-03-07 18:28:39 --> URI Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Router Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Router Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Config Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Output Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Output Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:28:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:28:39 --> Security Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Security Class Initialized
DEBUG - 2014-03-07 18:28:39 --> URI Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Input Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Input Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Router Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:28:39 --> Language Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Language Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Output Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Security Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Loader Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Loader Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Input Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Controller Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Controller Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:28:39 --> Language Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:28:39 --> Loader Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Controller Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:28:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:39 --> Session Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Session Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:28:39 --> A session cookie was not found.
DEBUG - 2014-03-07 18:28:39 --> A session cookie was not found.
DEBUG - 2014-03-07 18:28:39 --> Session routines successfully run
DEBUG - 2014-03-07 18:28:39 --> Session routines successfully run
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:39 --> Final output sent to browser
DEBUG - 2014-03-07 18:28:39 --> Final output sent to browser
DEBUG - 2014-03-07 18:28:39 --> Total execution time: 0.0350
DEBUG - 2014-03-07 18:28:39 --> Total execution time: 0.0350
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:39 --> Session Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:28:39 --> A session cookie was not found.
DEBUG - 2014-03-07 18:28:39 --> Session routines successfully run
DEBUG - 2014-03-07 18:28:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:28:39 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:39 --> Final output sent to browser
DEBUG - 2014-03-07 18:28:39 --> Total execution time: 0.0370
DEBUG - 2014-03-07 18:28:41 --> Config Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:28:41 --> URI Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Router Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Config Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Output Class Initialized
DEBUG - 2014-03-07 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:28:41 --> Security Class Initialized
DEBUG - 2014-03-07 18:28:41 --> URI Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Input Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Router Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:28:41 --> Language Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Config Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Output Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Loader Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Security Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Controller Class Initialized
DEBUG - 2014-03-07 18:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:28:41 --> Input Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:28:41 --> URI Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:28:41 --> Language Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Router Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Loader Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Output Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Controller Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Security Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:28:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Input Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Language Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Loader Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Controller Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:28:41 --> Session Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:28:41 --> A session cookie was not found.
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Session routines successfully run
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:28:41 --> Session Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:41 --> A session cookie was not found.
DEBUG - 2014-03-07 18:28:41 --> Session routines successfully run
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:28:41 --> Final output sent to browser
DEBUG - 2014-03-07 18:28:41 --> Total execution time: 0.0110
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:41 --> Session Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Final output sent to browser
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:28:41 --> Total execution time: 0.0120
DEBUG - 2014-03-07 18:28:41 --> A session cookie was not found.
DEBUG - 2014-03-07 18:28:41 --> Session routines successfully run
DEBUG - 2014-03-07 18:28:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:28:41 --> Model Class Initialized
DEBUG - 2014-03-07 18:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:28:41 --> Final output sent to browser
DEBUG - 2014-03-07 18:28:41 --> Total execution time: 0.0130
DEBUG - 2014-03-07 18:31:53 --> Config Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Config Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:31:53 --> URI Class Initialized
DEBUG - 2014-03-07 18:31:53 --> URI Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Router Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Router Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Output Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Output Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Security Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Security Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Input Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Input Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:31:53 --> Language Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Language Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Loader Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Loader Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Controller Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Controller Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:31:53 --> Session Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Session Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:31:53 --> A session cookie was not found.
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:31:53 --> A session cookie was not found.
DEBUG - 2014-03-07 18:31:53 --> Session routines successfully run
DEBUG - 2014-03-07 18:31:53 --> Session routines successfully run
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:31:53 --> Final output sent to browser
DEBUG - 2014-03-07 18:31:53 --> Final output sent to browser
DEBUG - 2014-03-07 18:31:53 --> Total execution time: 0.0190
DEBUG - 2014-03-07 18:31:53 --> Total execution time: 0.0190
DEBUG - 2014-03-07 18:31:53 --> Config Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 18:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 18:31:53 --> URI Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Router Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Output Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Security Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Input Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 18:31:53 --> Language Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Loader Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Controller Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:31:53 --> Session Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 18:31:53 --> A session cookie was not found.
DEBUG - 2014-03-07 18:31:53 --> Session routines successfully run
DEBUG - 2014-03-07 18:31:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 18:31:53 --> Model Class Initialized
DEBUG - 2014-03-07 18:31:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 18:31:53 --> Final output sent to browser
DEBUG - 2014-03-07 18:31:53 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:14:18 --> Config Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Config Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:14:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:14:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:14:18 --> URI Class Initialized
DEBUG - 2014-03-07 19:14:18 --> URI Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Router Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Router Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Output Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Output Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Security Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Security Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Input Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Input Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:14:18 --> Language Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Language Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Loader Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Loader Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Controller Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Controller Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Config Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:14:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:14:18 --> URI Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Router Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Output Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:18 --> Security Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Session Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Session Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Input Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:14:18 --> A session cookie was not found.
DEBUG - 2014-03-07 19:14:18 --> A session cookie was not found.
DEBUG - 2014-03-07 19:14:18 --> Language Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Session routines successfully run
DEBUG - 2014-03-07 19:14:18 --> Session routines successfully run
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:14:18 --> Loader Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:14:18 --> Controller Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:14:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Final output sent to browser
DEBUG - 2014-03-07 19:14:18 --> Final output sent to browser
DEBUG - 2014-03-07 19:14:18 --> Total execution time: 0.0140
DEBUG - 2014-03-07 19:14:18 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:14:18 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:18 --> Session Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:14:18 --> A session cookie was not found.
DEBUG - 2014-03-07 19:14:18 --> Session routines successfully run
DEBUG - 2014-03-07 19:14:18 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:14:18 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:18 --> Final output sent to browser
DEBUG - 2014-03-07 19:14:18 --> Total execution time: 0.0200
DEBUG - 2014-03-07 19:14:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:14:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:14:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:14:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:14:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Session Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:14:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:14:20 --> A session cookie was not found.
DEBUG - 2014-03-07 19:14:20 --> Session Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Session routines successfully run
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:14:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:14:20 --> A session cookie was not found.
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:14:20 --> Session routines successfully run
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Final output sent to browser
DEBUG - 2014-03-07 19:14:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:14:20 --> Final output sent to browser
DEBUG - 2014-03-07 19:14:20 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:20 --> Session Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:14:20 --> A session cookie was not found.
DEBUG - 2014-03-07 19:14:20 --> Session routines successfully run
DEBUG - 2014-03-07 19:14:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:14:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:14:20 --> Final output sent to browser
DEBUG - 2014-03-07 19:14:20 --> Total execution time: 0.0180
DEBUG - 2014-03-07 19:18:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:20 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:20 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:20 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:20 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:20 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:20 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:20 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:20 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:20 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:20 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:18:20 --> Total execution time: 0.0140
DEBUG - 2014-03-07 19:18:20 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:20 --> Total execution time: 0.0140
DEBUG - 2014-03-07 19:18:21 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:21 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:21 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:21 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:21 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:21 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:21 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:21 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:21 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:21 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:21 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:21 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:21 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:21 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:21 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:21 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:18:21 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:21 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:18:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:21 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:21 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:21 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:18:42 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Config Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:42 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:18:42 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:18:42 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:42 --> URI Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Router Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Output Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Security Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Input Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:18:42 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Language Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Loader Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Controller Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:42 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Session Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:18:42 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:42 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:42 --> A session cookie was not found.
DEBUG - 2014-03-07 19:18:42 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:42 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:42 --> Session routines successfully run
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:18:42 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:42 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:42 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:18:42 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:18:42 --> Final output sent to browser
DEBUG - 2014-03-07 19:18:42 --> Total execution time: 0.0190
DEBUG - 2014-03-07 19:26:25 --> Config Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:26:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:26:25 --> URI Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Router Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Output Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Security Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Input Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:26:25 --> Language Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Loader Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Controller Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:25 --> Session Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:26:25 --> A session cookie was not found.
DEBUG - 2014-03-07 19:26:25 --> Session routines successfully run
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:25 --> Final output sent to browser
DEBUG - 2014-03-07 19:26:25 --> Total execution time: 0.0110
DEBUG - 2014-03-07 19:26:25 --> Config Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:26:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:26:25 --> URI Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Router Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Output Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Security Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Input Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:26:25 --> Language Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Loader Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Controller Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:25 --> Session Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:26:25 --> A session cookie was not found.
DEBUG - 2014-03-07 19:26:25 --> Session routines successfully run
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:25 --> Final output sent to browser
DEBUG - 2014-03-07 19:26:25 --> Total execution time: 0.0110
DEBUG - 2014-03-07 19:26:25 --> Config Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:26:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:26:25 --> URI Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Router Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Output Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Security Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Input Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:26:25 --> Language Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Loader Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Controller Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:25 --> Session Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:26:25 --> A session cookie was not found.
DEBUG - 2014-03-07 19:26:25 --> Session routines successfully run
DEBUG - 2014-03-07 19:26:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:26:25 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:25 --> Final output sent to browser
DEBUG - 2014-03-07 19:26:25 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:26:59 --> Config Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:26:59 --> URI Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Router Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Output Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Security Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Input Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:26:59 --> Language Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Loader Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Controller Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:59 --> Config Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Session Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:26:59 --> A session cookie was not found.
DEBUG - 2014-03-07 19:26:59 --> URI Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Session routines successfully run
DEBUG - 2014-03-07 19:26:59 --> Router Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Output Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:59 --> Security Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Input Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:26:59 --> Final output sent to browser
DEBUG - 2014-03-07 19:26:59 --> Language Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:26:59 --> Loader Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Controller Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:59 --> Session Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:26:59 --> A session cookie was not found.
DEBUG - 2014-03-07 19:26:59 --> Session routines successfully run
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:59 --> Final output sent to browser
DEBUG - 2014-03-07 19:26:59 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:26:59 --> Config Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:26:59 --> URI Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Router Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Output Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Security Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Input Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:26:59 --> Language Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Loader Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Controller Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:59 --> Session Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:26:59 --> A session cookie was not found.
DEBUG - 2014-03-07 19:26:59 --> Session routines successfully run
DEBUG - 2014-03-07 19:26:59 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:26:59 --> Model Class Initialized
DEBUG - 2014-03-07 19:26:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:26:59 --> Final output sent to browser
DEBUG - 2014-03-07 19:26:59 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:30:42 --> Config Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:30:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:30:42 --> URI Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Router Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Output Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Security Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Input Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:30:42 --> Language Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Loader Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Controller Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:30:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:30:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Model Class Initialized
DEBUG - 2014-03-07 19:30:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:30:42 --> Final output sent to browser
DEBUG - 2014-03-07 19:30:42 --> Total execution time: 0.0750
DEBUG - 2014-03-07 19:42:11 --> Config Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Config Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Config Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:42:11 --> URI Class Initialized
DEBUG - 2014-03-07 19:42:11 --> URI Class Initialized
DEBUG - 2014-03-07 19:42:11 --> URI Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Router Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Router Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Router Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Output Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Output Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Output Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Security Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Security Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Security Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Input Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Input Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Input Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:42:11 --> Language Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Language Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Language Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Loader Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Loader Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Loader Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Controller Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Controller Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Controller Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:42:11 --> Session Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Session Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:42:11 --> A session cookie was not found.
DEBUG - 2014-03-07 19:42:11 --> A session cookie was not found.
DEBUG - 2014-03-07 19:42:11 --> Session routines successfully run
DEBUG - 2014-03-07 19:42:11 --> Session routines successfully run
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:42:11 --> Final output sent to browser
DEBUG - 2014-03-07 19:42:11 --> Final output sent to browser
DEBUG - 2014-03-07 19:42:11 --> Total execution time: 0.0200
DEBUG - 2014-03-07 19:42:11 --> Total execution time: 0.0210
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:42:11 --> Session Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:42:11 --> A session cookie was not found.
DEBUG - 2014-03-07 19:42:11 --> Session routines successfully run
DEBUG - 2014-03-07 19:42:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:42:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:42:11 --> Final output sent to browser
DEBUG - 2014-03-07 19:42:11 --> Total execution time: 0.0300
DEBUG - 2014-03-07 19:42:17 --> Config Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:42:17 --> URI Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Router Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Output Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Security Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Input Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:42:17 --> Language Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Loader Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Controller Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:42:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:42:17 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Model Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Upload Class Initialized
DEBUG - 2014-03-07 19:42:17 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:42:17 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:42:17 --> Final output sent to browser
DEBUG - 2014-03-07 19:42:17 --> Total execution time: 0.0760
DEBUG - 2014-03-07 19:43:30 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:30 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:30 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:30 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:30 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:30 --> Session Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:43:30 --> A session cookie was not found.
DEBUG - 2014-03-07 19:43:30 --> Session routines successfully run
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:30 --> Session Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Session Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:43:30 --> A session cookie was not found.
DEBUG - 2014-03-07 19:43:30 --> A session cookie was not found.
DEBUG - 2014-03-07 19:43:30 --> Session routines successfully run
DEBUG - 2014-03-07 19:43:30 --> Session routines successfully run
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:43:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:30 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:30 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:30 --> Total execution time: 0.0320
DEBUG - 2014-03-07 19:43:30 --> Total execution time: 0.0300
DEBUG - 2014-03-07 19:43:30 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:30 --> Total execution time: 0.0350
DEBUG - 2014-03-07 19:43:33 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:33 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:33 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:33 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:33 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:33 --> Session Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Session Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Session Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:43:33 --> A session cookie was not found.
DEBUG - 2014-03-07 19:43:33 --> A session cookie was not found.
DEBUG - 2014-03-07 19:43:33 --> A session cookie was not found.
DEBUG - 2014-03-07 19:43:33 --> Session routines successfully run
DEBUG - 2014-03-07 19:43:33 --> Session routines successfully run
DEBUG - 2014-03-07 19:43:33 --> Session routines successfully run
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:43:33 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:43:33 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:33 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:33 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:33 --> Total execution time: 0.0230
DEBUG - 2014-03-07 19:43:33 --> Total execution time: 0.0230
DEBUG - 2014-03-07 19:43:33 --> Total execution time: 0.0220
DEBUG - 2014-03-07 19:43:39 --> Config Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:43:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:43:39 --> URI Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Router Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Output Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Security Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Input Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:43:39 --> Language Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Loader Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Controller Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:43:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:43:39 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Model Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Upload Class Initialized
DEBUG - 2014-03-07 19:43:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:43:39 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:43:39 --> Final output sent to browser
DEBUG - 2014-03-07 19:43:39 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:46:58 --> Language Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Loader Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Controller Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:46:58 --> Language Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Loader Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Controller Class Initialized
DEBUG - 2014-03-07 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:46:58 --> Session Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:46:58 --> A session cookie was not found.
DEBUG - 2014-03-07 19:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Session routines successfully run
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:46:58 --> Language Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Final output sent to browser
DEBUG - 2014-03-07 19:46:58 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:46:58 --> Loader Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Controller Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:46:58 --> Session Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> A session cookie was not found.
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Session routines successfully run
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:46:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Final output sent to browser
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:46:58 --> Session Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:46:58 --> A session cookie was not found.
DEBUG - 2014-03-07 19:46:58 --> Session routines successfully run
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Final output sent to browser
DEBUG - 2014-03-07 19:46:58 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Config Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:46:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Language Class Initialized
DEBUG - 2014-03-07 19:46:58 --> URI Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Router Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Loader Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Controller Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Output Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Security Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:46:58 --> Input Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Language Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Language Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Loader Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Controller Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Loader Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Controller Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:46:58 --> Session Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Session routines successfully run
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:46:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Session Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Session routines successfully run
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:46:58 --> Final output sent to browser
DEBUG - 2014-03-07 19:46:58 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:46:58 --> Session Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:46:58 --> Session routines successfully run
DEBUG - 2014-03-07 19:46:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:46:58 --> Final output sent to browser
DEBUG - 2014-03-07 19:46:58 --> Model Class Initialized
DEBUG - 2014-03-07 19:46:58 --> Total execution time: 0.0110
DEBUG - 2014-03-07 19:46:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:46:58 --> Final output sent to browser
DEBUG - 2014-03-07 19:46:58 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:47:14 --> Config Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:47:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:47:14 --> URI Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Router Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Output Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Security Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Input Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:47:14 --> Language Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Loader Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Controller Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:47:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:47:14 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:47:24 --> Upload Class Initialized
DEBUG - 2014-03-07 19:47:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:47:26 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:47:38 --> Final output sent to browser
DEBUG - 2014-03-07 19:47:38 --> Total execution time: 23.3713
DEBUG - 2014-03-07 19:47:45 --> Config Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:47:45 --> URI Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Router Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Output Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Config Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Security Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Input Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:47:45 --> URI Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Language Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Router Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Loader Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Controller Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Output Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:47:45 --> Security Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:47:45 --> Input Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Language Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Loader Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Controller Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Session Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:47:45 --> Session routines successfully run
DEBUG - 2014-03-07 19:47:45 --> Session Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Session routines successfully run
DEBUG - 2014-03-07 19:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:47:45 --> Final output sent to browser
DEBUG - 2014-03-07 19:47:45 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:47:45 --> Final output sent to browser
DEBUG - 2014-03-07 19:47:45 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:47:45 --> Config Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:47:45 --> URI Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Router Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Output Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Security Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Input Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:47:45 --> Language Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Loader Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Controller Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:47:45 --> Session Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:47:45 --> Session routines successfully run
DEBUG - 2014-03-07 19:47:45 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:47:45 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:47:45 --> Final output sent to browser
DEBUG - 2014-03-07 19:47:45 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:47:51 --> Config Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:47:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:47:51 --> URI Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Router Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Output Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Security Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Input Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:47:51 --> Language Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Loader Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Controller Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:47:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:47:51 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Model Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Upload Class Initialized
DEBUG - 2014-03-07 19:47:51 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:47:51 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:47:51 --> Final output sent to browser
DEBUG - 2014-03-07 19:47:51 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:49:37 --> Config Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:49:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:49:37 --> URI Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Router Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Config Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:49:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:49:37 --> Output Class Initialized
DEBUG - 2014-03-07 19:49:37 --> URI Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Security Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Router Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Input Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:49:37 --> Output Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Language Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Security Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Input Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Loader Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:49:37 --> Controller Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Language Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:49:37 --> Loader Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Controller Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Config Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:49:37 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:49:37 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:49:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> URI Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Router Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:49:37 --> Output Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Security Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Session Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:49:37 --> Input Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:49:37 --> Session routines successfully run
DEBUG - 2014-03-07 19:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:49:37 --> Session Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:49:37 --> Language Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Session routines successfully run
DEBUG - 2014-03-07 19:49:37 --> Loader Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:49:37 --> Controller Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:49:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Final output sent to browser
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:49:37 --> Final output sent to browser
DEBUG - 2014-03-07 19:49:37 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:49:37 --> Session Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:49:37 --> Session routines successfully run
DEBUG - 2014-03-07 19:49:37 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:49:37 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:49:37 --> Final output sent to browser
DEBUG - 2014-03-07 19:49:37 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:49:44 --> Config Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:49:44 --> URI Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Router Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Output Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Security Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Input Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:49:44 --> Language Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Loader Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Controller Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:49:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:49:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Upload Class Initialized
DEBUG - 2014-03-07 19:49:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:49:44 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:49:44 --> Final output sent to browser
DEBUG - 2014-03-07 19:49:44 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:50:08 --> Config Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Config Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:50:08 --> URI Class Initialized
DEBUG - 2014-03-07 19:50:08 --> URI Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Router Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Router Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Config Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Output Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Output Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Security Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Security Class Initialized
DEBUG - 2014-03-07 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:50:08 --> Input Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Input Class Initialized
DEBUG - 2014-03-07 19:50:08 --> URI Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:50:08 --> Router Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Language Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Language Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Output Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Loader Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Loader Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Security Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Controller Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Controller Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Input Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:50:08 --> Language Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Loader Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Controller Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:50:08 --> Session Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Session Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:50:08 --> Session routines successfully run
DEBUG - 2014-03-07 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:50:08 --> Session routines successfully run
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:50:08 --> Session Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:50:08 --> Session routines successfully run
DEBUG - 2014-03-07 19:50:08 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:50:08 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:08 --> Final output sent to browser
DEBUG - 2014-03-07 19:50:08 --> Final output sent to browser
DEBUG - 2014-03-07 19:50:08 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:50:08 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:50:08 --> Final output sent to browser
DEBUG - 2014-03-07 19:50:08 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:50:20 --> Config Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:50:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:50:20 --> URI Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Router Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Output Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Security Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Input Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:50:20 --> Language Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Loader Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Controller Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:50:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:50:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Model Class Initialized
DEBUG - 2014-03-07 19:50:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:50:24 --> Upload Class Initialized
DEBUG - 2014-03-07 19:50:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:50:25 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:50:57 --> Final output sent to browser
DEBUG - 2014-03-07 19:50:57 --> Total execution time: 36.2781
DEBUG - 2014-03-07 19:51:13 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:13 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:13 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:13 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:13 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:13 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:13 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:51:14 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:14 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:14 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:14 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:14 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:14 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:14 --> Total execution time: 0.0090
DEBUG - 2014-03-07 19:51:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:15 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:15 --> Total execution time: 0.0090
DEBUG - 2014-03-07 19:51:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:15 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:15 --> Total execution time: 0.0080
DEBUG - 2014-03-07 19:51:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:15 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:15 --> Total execution time: 0.0080
DEBUG - 2014-03-07 19:51:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:15 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:15 --> Total execution time: 0.0080
DEBUG - 2014-03-07 19:51:16 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:16 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:16 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:16 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:16 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:16 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:16 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:51:16 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:16 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:16 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:16 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:51:16 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:51:16 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:16 --> Total execution time: 0.0080
DEBUG - 2014-03-07 19:51:28 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:28 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:28 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:28 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:28 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:28 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Session Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:51:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Session routines successfully run
DEBUG - 2014-03-07 19:51:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:51:28 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:28 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:28 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:28 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Session Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:51:28 --> Session routines successfully run
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:51:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:28 --> Session Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:51:28 --> Session routines successfully run
DEBUG - 2014-03-07 19:51:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:51:28 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:28 --> Total execution time: 0.0180
DEBUG - 2014-03-07 19:51:28 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:28 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:28 --> Total execution time: 0.0110
DEBUG - 2014-03-07 19:51:29 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:29 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:29 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:29 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:29 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:29 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:29 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:29 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:29 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:29 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:29 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Session Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:51:29 --> Session Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Session routines successfully run
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:51:29 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Session routines successfully run
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:29 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:29 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:51:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:29 --> Session Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:51:29 --> Session routines successfully run
DEBUG - 2014-03-07 19:51:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:51:29 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:51:29 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:29 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:51:34 --> Config Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:51:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:51:34 --> URI Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Router Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Output Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Security Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Input Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:51:34 --> Language Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Loader Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Controller Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:51:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:51:34 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Model Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Upload Class Initialized
DEBUG - 2014-03-07 19:51:34 --> Final output sent to browser
DEBUG - 2014-03-07 19:51:34 --> Total execution time: 0.0830
DEBUG - 2014-03-07 19:53:30 --> Config Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:53:30 --> Config Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:53:30 --> URI Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Router Class Initialized
DEBUG - 2014-03-07 19:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:53:30 --> URI Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Router Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Output Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Security Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Output Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Input Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Security Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Input Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:53:30 --> Language Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:53:30 --> Loader Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Language Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Controller Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Loader Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:53:30 --> Controller Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:53:30 --> Config Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Session Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:53:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:53:30 --> Session routines successfully run
DEBUG - 2014-03-07 19:53:30 --> URI Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Session Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Router Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Session routines successfully run
DEBUG - 2014-03-07 19:53:30 --> Output Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:53:30 --> Security Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Input Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:53:30 --> Final output sent to browser
DEBUG - 2014-03-07 19:53:30 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:53:30 --> Language Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Final output sent to browser
DEBUG - 2014-03-07 19:53:30 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:53:30 --> Loader Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Controller Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:53:30 --> Session Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:53:30 --> Session routines successfully run
DEBUG - 2014-03-07 19:53:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:53:30 --> Model Class Initialized
DEBUG - 2014-03-07 19:53:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:53:30 --> Final output sent to browser
DEBUG - 2014-03-07 19:53:30 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:54:09 --> Config Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:54:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:54:09 --> URI Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Router Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Output Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Security Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Input Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:54:09 --> Language Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Loader Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Controller Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:54:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:54:09 --> Model Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Model Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Upload Class Initialized
DEBUG - 2014-03-07 19:54:09 --> Final output sent to browser
DEBUG - 2014-03-07 19:54:09 --> Total execution time: 0.0120
DEBUG - 2014-03-07 19:54:47 --> Config Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:54:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:54:47 --> URI Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Router Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Output Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Security Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Input Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:54:47 --> Language Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Loader Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Controller Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:54:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:54:47 --> Model Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Model Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Upload Class Initialized
DEBUG - 2014-03-07 19:54:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-07 19:54:47 --> You did not select a file to upload.
DEBUG - 2014-03-07 19:54:47 --> Final output sent to browser
DEBUG - 2014-03-07 19:54:47 --> Total execution time: 0.0090
DEBUG - 2014-03-07 19:56:38 --> Config Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Config Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:56:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:56:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:56:38 --> URI Class Initialized
DEBUG - 2014-03-07 19:56:38 --> URI Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Router Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Router Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Config Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Output Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Output Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:56:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:56:38 --> Security Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Security Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Input Class Initialized
DEBUG - 2014-03-07 19:56:38 --> URI Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Input Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:56:38 --> Router Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:56:38 --> Language Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Language Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Output Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Loader Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Loader Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Security Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Controller Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Controller Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Input Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:56:38 --> Language Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Loader Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Controller Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:56:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Session Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:56:38 --> Session Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Session routines successfully run
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:56:38 --> Session routines successfully run
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:56:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:56:38 --> Final output sent to browser
DEBUG - 2014-03-07 19:56:38 --> Final output sent to browser
DEBUG - 2014-03-07 19:56:38 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:56:38 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:56:38 --> Session Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:56:38 --> Session routines successfully run
DEBUG - 2014-03-07 19:56:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:56:38 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:56:38 --> Final output sent to browser
DEBUG - 2014-03-07 19:56:38 --> Total execution time: 0.0180
DEBUG - 2014-03-07 19:56:46 --> Config Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:56:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:56:46 --> URI Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Router Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Output Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Security Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Input Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:56:46 --> Language Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Loader Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Controller Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:56:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:56:46 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Model Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Upload Class Initialized
DEBUG - 2014-03-07 19:56:46 --> Final output sent to browser
DEBUG - 2014-03-07 19:56:46 --> Total execution time: 0.0320
DEBUG - 2014-03-07 19:58:04 --> Config Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Config Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:58:04 --> URI Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Config Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Router Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:58:04 --> Output Class Initialized
DEBUG - 2014-03-07 19:58:04 --> URI Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Router Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Security Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Input Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Output Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:58:04 --> Security Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Language Class Initialized
DEBUG - 2014-03-07 19:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:58:04 --> Input Class Initialized
DEBUG - 2014-03-07 19:58:04 --> URI Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:58:04 --> Router Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Language Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Loader Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Loader Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Controller Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Output Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Controller Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:58:04 --> Security Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:58:04 --> Input Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Language Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Loader Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Controller Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:58:04 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Session Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:58:04 --> Session routines successfully run
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:58:04 --> Session Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:58:04 --> Session routines successfully run
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:58:04 --> Final output sent to browser
DEBUG - 2014-03-07 19:58:04 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Final output sent to browser
DEBUG - 2014-03-07 19:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:58:04 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:58:04 --> Session Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:58:04 --> Session routines successfully run
DEBUG - 2014-03-07 19:58:04 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:58:04 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:58:04 --> Final output sent to browser
DEBUG - 2014-03-07 19:58:04 --> Total execution time: 0.0160
DEBUG - 2014-03-07 19:58:11 --> Config Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:58:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:58:11 --> URI Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Router Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Output Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Security Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Input Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:58:11 --> Language Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Loader Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Controller Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:58:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:58:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Model Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Upload Class Initialized
DEBUG - 2014-03-07 19:58:11 --> Final output sent to browser
DEBUG - 2014-03-07 19:58:11 --> Total execution time: 0.0600
DEBUG - 2014-03-07 19:59:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:15 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:15 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:15 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:15 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:15 --> A session cookie was not found.
DEBUG - 2014-03-07 19:59:15 --> A session cookie was not found.
DEBUG - 2014-03-07 19:59:15 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:15 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:15 --> A session cookie was not found.
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:15 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:15 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:15 --> Total execution time: 0.0140
DEBUG - 2014-03-07 19:59:15 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:59:15 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:15 --> Total execution time: 0.0140
DEBUG - 2014-03-07 19:59:35 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:35 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:35 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:35 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Upload Class Initialized
DEBUG - 2014-03-07 19:59:35 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:35 --> Total execution time: 0.0110
DEBUG - 2014-03-07 19:59:44 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:44 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:44 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:44 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:44 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:44 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:44 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:44 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:44 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:44 --> Total execution time: 0.0130
DEBUG - 2014-03-07 19:59:44 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:44 --> Total execution time: 0.0100
DEBUG - 2014-03-07 19:59:44 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:44 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:44 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:44 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:44 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:44 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:44 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:44 --> Total execution time: 0.0110
DEBUG - 2014-03-07 19:59:54 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:54 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:54 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:54 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Config Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 19:59:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 19:59:54 --> URI Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Router Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:54 --> Output Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Security Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Input Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 19:59:54 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Language Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Loader Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:54 --> Controller Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 19:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:54 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Total execution time: 0.0150
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:54 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:54 --> Session Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 19:59:54 --> Total execution time: 0.0190
DEBUG - 2014-03-07 19:59:54 --> Session routines successfully run
DEBUG - 2014-03-07 19:59:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 19:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 19:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 19:59:54 --> Final output sent to browser
DEBUG - 2014-03-07 19:59:54 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:00:22 --> Config Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:00:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:00:22 --> URI Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Router Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Output Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Security Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Input Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:00:22 --> Language Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Loader Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Controller Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Config Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:00:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:00:22 --> URI Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Router Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Config Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Output Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Security Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Input Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:00:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:00:22 --> Language Class Initialized
DEBUG - 2014-03-07 20:00:22 --> URI Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Session Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Loader Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Router Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:00:22 --> Controller Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Session routines successfully run
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:00:22 --> Output Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:00:22 --> Security Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Input Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:00:22 --> Language Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Final output sent to browser
DEBUG - 2014-03-07 20:00:22 --> Total execution time: 0.0170
DEBUG - 2014-03-07 20:00:22 --> Loader Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Controller Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Session Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:00:22 --> Session routines successfully run
DEBUG - 2014-03-07 20:00:22 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:00:22 --> Final output sent to browser
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Total execution time: 0.0100
DEBUG - 2014-03-07 20:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:00:22 --> Session Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:00:22 --> Session routines successfully run
DEBUG - 2014-03-07 20:00:22 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:00:22 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:00:22 --> Final output sent to browser
DEBUG - 2014-03-07 20:00:22 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:00:32 --> Config Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:00:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:00:32 --> URI Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Router Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Output Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Security Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Input Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:00:32 --> Language Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Loader Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Controller Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:00:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Upload Class Initialized
DEBUG - 2014-03-07 20:00:32 --> Final output sent to browser
DEBUG - 2014-03-07 20:00:32 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:03:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:03:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:03:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:03:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:03:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:03:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:03:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:03:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:03:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:03:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:03:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:03:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:03:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:03:53 --> Total execution time: 0.0140
DEBUG - 2014-03-07 20:03:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:03:53 --> Total execution time: 0.0180
DEBUG - 2014-03-07 20:03:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:03:53 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:03:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:03:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:03:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:03:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:03:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:03:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:03:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:03:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:03:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:03:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:03:54 --> Total execution time: 0.0150
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:03:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:03:54 --> Total execution time: 0.0230
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:03:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:03:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:03:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:03:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:03:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:03:54 --> Total execution time: 0.0240
DEBUG - 2014-03-07 20:04:01 --> Config Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:04:01 --> URI Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Router Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Config Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Output Class Initialized
DEBUG - 2014-03-07 20:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:04:01 --> URI Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Security Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Router Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Input Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:04:01 --> Output Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Language Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Config Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Security Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Loader Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Input Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Controller Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:04:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Language Class Initialized
DEBUG - 2014-03-07 20:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:04:01 --> Loader Class Initialized
DEBUG - 2014-03-07 20:04:01 --> URI Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Controller Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:04:01 --> Router Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Output Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Security Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Input Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:04:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Language Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Loader Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Controller Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:04:01 --> Session Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Session routines successfully run
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:04:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Final output sent to browser
DEBUG - 2014-03-07 20:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:04:01 --> Total execution time: 0.0140
DEBUG - 2014-03-07 20:04:01 --> Session Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:04:01 --> Session routines successfully run
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:04:01 --> Final output sent to browser
DEBUG - 2014-03-07 20:04:01 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:04:01 --> Session Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:04:01 --> Session routines successfully run
DEBUG - 2014-03-07 20:04:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:04:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:04:01 --> Final output sent to browser
DEBUG - 2014-03-07 20:04:01 --> Total execution time: 0.0190
DEBUG - 2014-03-07 20:04:12 --> Config Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:04:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:04:12 --> URI Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Router Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Output Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Security Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Input Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:04:12 --> Language Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Loader Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Controller Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:04:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:04:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Upload Class Initialized
DEBUG - 2014-03-07 20:04:12 --> Final output sent to browser
DEBUG - 2014-03-07 20:04:12 --> Total execution time: 0.0200
DEBUG - 2014-03-07 20:16:02 --> Config Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Config Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:16:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:16:02 --> URI Class Initialized
DEBUG - 2014-03-07 20:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:16:02 --> Config Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Router Class Initialized
DEBUG - 2014-03-07 20:16:02 --> URI Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Router Class Initialized
DEBUG - 2014-03-07 20:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:16:02 --> Output Class Initialized
DEBUG - 2014-03-07 20:16:02 --> URI Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Security Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Router Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Output Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Input Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Security Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Output Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:16:02 --> Input Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Language Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Security Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:16:02 --> Input Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Language Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Loader Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:16:02 --> Loader Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Controller Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Language Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Controller Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:16:02 --> Loader Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:16:02 --> Controller Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Session Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:16:02 --> Session Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:16:02 --> Session routines successfully run
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:16:02 --> Session routines successfully run
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Final output sent to browser
DEBUG - 2014-03-07 20:16:02 --> Total execution time: 0.0160
DEBUG - 2014-03-07 20:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:16:02 --> Final output sent to browser
DEBUG - 2014-03-07 20:16:02 --> Session Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Total execution time: 0.0160
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:16:02 --> Session routines successfully run
DEBUG - 2014-03-07 20:16:02 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:16:02 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:16:02 --> Final output sent to browser
DEBUG - 2014-03-07 20:16:02 --> Total execution time: 0.0180
DEBUG - 2014-03-07 20:16:09 --> Config Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:16:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:16:09 --> URI Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Router Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Output Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Security Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Input Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:16:09 --> Language Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Loader Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Controller Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:16:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:16:09 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Model Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Upload Class Initialized
DEBUG - 2014-03-07 20:16:09 --> Final output sent to browser
DEBUG - 2014-03-07 20:16:09 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:17:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:17:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:17:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:17:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:17:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:17:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:17:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:17:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:17:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:17:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:17:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:17:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:17:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:17:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:17:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:17:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:17:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:17:53 --> Total execution time: 0.0110
DEBUG - 2014-03-07 20:17:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:17:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:17:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:17:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:17:53 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:17:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:17:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:17:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:17:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:17:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:17:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:17:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:17:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:17:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:17:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:17:54 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:17:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:17:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:17:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:17:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:17:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:17:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:17:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:17:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:17:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:17:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:17:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:17:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:17:54 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:18:01 --> Config Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:18:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:18:01 --> URI Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Router Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Output Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Security Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Input Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:18:01 --> Language Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Loader Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Controller Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:18:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:18:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Upload Class Initialized
DEBUG - 2014-03-07 20:18:01 --> Final output sent to browser
DEBUG - 2014-03-07 20:18:01 --> Total execution time: 0.0170
DEBUG - 2014-03-07 20:18:39 --> Config Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Config Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:18:39 --> URI Class Initialized
DEBUG - 2014-03-07 20:18:39 --> URI Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Router Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Router Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Config Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Output Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Output Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:18:39 --> Security Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Security Class Initialized
DEBUG - 2014-03-07 20:18:39 --> URI Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Input Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Input Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Router Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:18:39 --> Language Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Output Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Language Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Security Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Loader Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Loader Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Input Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Controller Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Controller Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:18:39 --> Language Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:18:39 --> Loader Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Controller Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:18:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:18:39 --> Session Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:18:39 --> Session routines successfully run
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:18:39 --> Final output sent to browser
DEBUG - 2014-03-07 20:18:39 --> Total execution time: 0.0150
DEBUG - 2014-03-07 20:18:39 --> Session Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:18:39 --> Session routines successfully run
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Session Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:18:39 --> Session routines successfully run
DEBUG - 2014-03-07 20:18:39 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:18:39 --> Final output sent to browser
DEBUG - 2014-03-07 20:18:39 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:39 --> Total execution time: 0.0200
DEBUG - 2014-03-07 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:18:39 --> Final output sent to browser
DEBUG - 2014-03-07 20:18:39 --> Total execution time: 0.0210
DEBUG - 2014-03-07 20:18:45 --> Config Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:18:45 --> URI Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Router Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Output Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Security Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Input Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:18:45 --> Language Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Loader Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Controller Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:18:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:18:45 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Model Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Upload Class Initialized
DEBUG - 2014-03-07 20:18:45 --> Final output sent to browser
DEBUG - 2014-03-07 20:18:45 --> Total execution time: 0.0110
DEBUG - 2014-03-07 20:19:42 --> Config Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:19:42 --> Config Class Initialized
DEBUG - 2014-03-07 20:19:42 --> URI Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Router Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Config Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:19:42 --> Output Class Initialized
DEBUG - 2014-03-07 20:19:42 --> URI Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Router Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Security Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Input Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Output Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:19:42 --> Security Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Language Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Input Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:19:42 --> Loader Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Language Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Controller Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Loader Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:19:42 --> Controller Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:19:42 --> URI Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:19:42 --> Router Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:19:42 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Output Class Initialized
DEBUG - 2014-03-07 20:19:42 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Security Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Input Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:19:43 --> Language Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Loader Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:43 --> Session Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:19:43 --> Session Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Session routines successfully run
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:19:43 --> Controller Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Session routines successfully run
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Final output sent to browser
DEBUG - 2014-03-07 20:19:43 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:19:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Final output sent to browser
DEBUG - 2014-03-07 20:19:43 --> Total execution time: 0.0110
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:43 --> Session Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:19:43 --> Session routines successfully run
DEBUG - 2014-03-07 20:19:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:19:43 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:43 --> Final output sent to browser
DEBUG - 2014-03-07 20:19:43 --> Total execution time: 0.0160
DEBUG - 2014-03-07 20:19:44 --> Config Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Config Class Initialized
DEBUG - 2014-03-07 20:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:19:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:19:44 --> URI Class Initialized
DEBUG - 2014-03-07 20:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:19:44 --> Router Class Initialized
DEBUG - 2014-03-07 20:19:44 --> URI Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Router Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Output Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Output Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Security Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Security Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Input Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Input Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Config Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:19:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Language Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Language Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Loader Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Loader Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Controller Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Controller Class Initialized
DEBUG - 2014-03-07 20:19:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:19:44 --> URI Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:19:44 --> Router Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Output Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Security Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Input Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:19:44 --> Language Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:44 --> Loader Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Controller Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Session Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:19:44 --> Session routines successfully run
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:44 --> Final output sent to browser
DEBUG - 2014-03-07 20:19:44 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:44 --> Session Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:19:44 --> Session routines successfully run
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:44 --> Session Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:19:44 --> Session routines successfully run
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:19:44 --> Model Class Initialized
DEBUG - 2014-03-07 20:19:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:19:44 --> Final output sent to browser
DEBUG - 2014-03-07 20:19:44 --> Total execution time: 0.0210
DEBUG - 2014-03-07 20:19:44 --> Final output sent to browser
DEBUG - 2014-03-07 20:19:44 --> Total execution time: 0.0170
DEBUG - 2014-03-07 20:21:03 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:03 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:03 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:03 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:03 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:03 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:03 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:03 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:03 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:03 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:03 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:03 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:03 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:03 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:03 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:03 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:03 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:03 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:03 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:03 --> Total execution time: 0.0270
DEBUG - 2014-03-07 20:21:03 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:03 --> Total execution time: 0.0310
DEBUG - 2014-03-07 20:21:31 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:31 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:31 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:31 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:31 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:31 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:31 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:31 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:31 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:31 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:31 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:31 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:31 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:31 --> Total execution time: 0.0110
DEBUG - 2014-03-07 20:21:31 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:31 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Config Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:31 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:21:31 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:31 --> URI Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:31 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Router Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Output Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Security Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:31 --> Input Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:21:31 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Language Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Loader Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Controller Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:21:31 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:31 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:31 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:31 --> Session Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Session routines successfully run
DEBUG - 2014-03-07 20:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:21:31 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:31 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:21:31 --> Model Class Initialized
DEBUG - 2014-03-07 20:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:21:31 --> Final output sent to browser
DEBUG - 2014-03-07 20:21:31 --> Total execution time: 0.0150
DEBUG - 2014-03-07 20:26:20 --> Config Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Config Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Config Class Initialized
DEBUG - 2014-03-07 20:26:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:26:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:26:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:26:20 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:26:20 --> URI Class Initialized
DEBUG - 2014-03-07 20:26:20 --> URI Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Router Class Initialized
DEBUG - 2014-03-07 20:26:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:26:20 --> Router Class Initialized
DEBUG - 2014-03-07 20:26:20 --> URI Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Router Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Output Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Output Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Security Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Output Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Security Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Input Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Input Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Security Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:26:20 --> Input Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Language Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Language Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:26:20 --> Language Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Loader Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Loader Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Controller Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Controller Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Loader Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:26:20 --> Controller Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:20 --> Session Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Session Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:26:20 --> Session routines successfully run
DEBUG - 2014-03-07 20:26:20 --> Session routines successfully run
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:20 --> Final output sent to browser
DEBUG - 2014-03-07 20:26:20 --> Final output sent to browser
DEBUG - 2014-03-07 20:26:20 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:26:20 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:20 --> Session Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:26:20 --> Session routines successfully run
DEBUG - 2014-03-07 20:26:20 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:26:20 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:20 --> Final output sent to browser
DEBUG - 2014-03-07 20:26:20 --> Total execution time: 0.0220
DEBUG - 2014-03-07 20:26:21 --> Config Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:26:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:26:21 --> URI Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Router Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Output Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Security Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Config Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Input Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Config Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:26:21 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Language Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:26:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:26:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:26:21 --> Loader Class Initialized
DEBUG - 2014-03-07 20:26:21 --> URI Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Controller Class Initialized
DEBUG - 2014-03-07 20:26:21 --> URI Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Router Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Router Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:26:21 --> Output Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Output Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Security Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Security Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Input Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Input Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:26:21 --> Language Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Language Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Loader Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Loader Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Controller Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Controller Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:26:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:26:21 --> Session Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Session routines successfully run
DEBUG - 2014-03-07 20:26:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:26:21 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Final output sent to browser
DEBUG - 2014-03-07 20:26:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:21 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:26:21 --> Session Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:26:21 --> Session routines successfully run
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:21 --> Final output sent to browser
DEBUG - 2014-03-07 20:26:21 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:21 --> Session Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:26:21 --> Session routines successfully run
DEBUG - 2014-03-07 20:26:21 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:26:21 --> Model Class Initialized
DEBUG - 2014-03-07 20:26:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:26:21 --> Final output sent to browser
DEBUG - 2014-03-07 20:26:21 --> Total execution time: 0.0260
DEBUG - 2014-03-07 20:53:12 --> Config Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Config Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:53:12 --> URI Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Config Class Initialized
DEBUG - 2014-03-07 20:53:12 --> URI Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Router Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Router Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:53:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:53:12 --> URI Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Output Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Output Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Router Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Security Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Security Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Input Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Output Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Input Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:53:12 --> Security Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Language Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Input Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Language Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:53:12 --> Loader Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Language Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Loader Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Controller Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Loader Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Controller Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:53:12 --> Controller Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Session Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:53:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:12 --> Session Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Session routines successfully run
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:53:12 --> Session Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:53:12 --> Session routines successfully run
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:53:12 --> Session routines successfully run
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:53:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:12 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:12 --> Final output sent to browser
DEBUG - 2014-03-07 20:53:12 --> Total execution time: 0.0120
DEBUG - 2014-03-07 20:53:12 --> Final output sent to browser
DEBUG - 2014-03-07 20:53:12 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:53:12 --> Final output sent to browser
DEBUG - 2014-03-07 20:53:12 --> Total execution time: 0.0150
DEBUG - 2014-03-07 20:53:13 --> Config Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:53:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:53:13 --> URI Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Router Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Output Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Security Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Input Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:53:13 --> Language Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Loader Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Controller Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Config Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:53:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:13 --> URI Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Router Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Session Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:53:13 --> Session routines successfully run
DEBUG - 2014-03-07 20:53:13 --> Output Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:53:13 --> Security Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Input Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Config Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:13 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:53:13 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Language Class Initialized
DEBUG - 2014-03-07 20:53:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:53:13 --> Final output sent to browser
DEBUG - 2014-03-07 20:53:13 --> URI Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Loader Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Total execution time: 0.0100
DEBUG - 2014-03-07 20:53:13 --> Router Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Controller Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:53:13 --> Output Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:53:13 --> Security Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Input Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:53:13 --> Language Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Loader Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Controller Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:53:13 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:13 --> Session Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:53:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:13 --> Session routines successfully run
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:53:13 --> Session Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:53:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:13 --> Session routines successfully run
DEBUG - 2014-03-07 20:53:13 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:53:13 --> Model Class Initialized
DEBUG - 2014-03-07 20:53:13 --> Final output sent to browser
DEBUG - 2014-03-07 20:53:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:53:13 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:53:13 --> Final output sent to browser
DEBUG - 2014-03-07 20:53:13 --> Total execution time: 0.0110
DEBUG - 2014-03-07 20:57:16 --> Config Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Config Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:57:16 --> URI Class Initialized
DEBUG - 2014-03-07 20:57:16 --> URI Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Router Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Router Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Output Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Output Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Config Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Security Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Security Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Input Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Input Class Initialized
DEBUG - 2014-03-07 20:57:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:57:16 --> URI Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Language Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Language Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Router Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Loader Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Loader Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Output Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Controller Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Controller Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Security Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:57:16 --> Input Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Language Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Loader Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Controller Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:57:16 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Session Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:57:16 --> Session routines successfully run
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:57:16 --> Session Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:57:16 --> Session routines successfully run
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:57:16 --> Final output sent to browser
DEBUG - 2014-03-07 20:57:16 --> Final output sent to browser
DEBUG - 2014-03-07 20:57:16 --> Total execution time: 0.0140
DEBUG - 2014-03-07 20:57:16 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:57:16 --> Session Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:57:16 --> Session routines successfully run
DEBUG - 2014-03-07 20:57:16 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:57:16 --> Model Class Initialized
DEBUG - 2014-03-07 20:57:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:57:16 --> Final output sent to browser
DEBUG - 2014-03-07 20:57:16 --> Total execution time: 0.0180
DEBUG - 2014-03-07 20:59:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:59:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:59:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Config Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:59:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:59:53 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:59:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:59:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:59:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:59:53 --> URI Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Router Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Output Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:59:53 --> Security Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:59:53 --> Input Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:59:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Language Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:59:53 --> Loader Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Controller Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:53 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:59:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:59:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:59:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:53 --> Session Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:59:53 --> Session routines successfully run
DEBUG - 2014-03-07 20:59:53 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:59:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:59:53 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:53 --> Total execution time: 0.0130
DEBUG - 2014-03-07 20:59:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:53 --> Final output sent to browser
DEBUG - 2014-03-07 20:59:53 --> Total execution time: 0.0160
DEBUG - 2014-03-07 20:59:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:59:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:59:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:59:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:59:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:59:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:59:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:59:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:59:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:59:54 --> Config Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:59:54 --> Hooks Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Utf8 Class Initialized
DEBUG - 2014-03-07 20:59:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> URI Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:54 --> Router Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Output Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:59:54 --> Security Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Input Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 20:59:54 --> Language Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:59:54 --> Loader Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:54 --> Total execution time: 0.0110
DEBUG - 2014-03-07 20:59:54 --> Controller Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:59:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Database Driver Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:54 --> Total execution time: 0.0150
DEBUG - 2014-03-07 20:59:54 --> Session Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: string_helper
DEBUG - 2014-03-07 20:59:54 --> Session routines successfully run
DEBUG - 2014-03-07 20:59:54 --> Helper loaded: url_helper
DEBUG - 2014-03-07 20:59:54 --> Model Class Initialized
DEBUG - 2014-03-07 20:59:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 20:59:54 --> Final output sent to browser
DEBUG - 2014-03-07 20:59:54 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:08:00 --> Config Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:08:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:08:00 --> URI Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Router Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Output Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Security Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Input Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:08:00 --> Language Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Loader Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Controller Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:00 --> Session Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:08:00 --> Session routines successfully run
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:00 --> Final output sent to browser
DEBUG - 2014-03-07 21:08:00 --> Total execution time: 0.0110
DEBUG - 2014-03-07 21:08:00 --> Config Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:08:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:08:00 --> URI Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Router Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Output Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Security Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Input Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:08:00 --> Config Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Language Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:08:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:08:00 --> Loader Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Controller Class Initialized
DEBUG - 2014-03-07 21:08:00 --> URI Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Router Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:08:00 --> Output Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Security Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Input Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:08:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Language Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Loader Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Controller Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Session Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:08:00 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Session routines successfully run
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:00 --> Final output sent to browser
DEBUG - 2014-03-07 21:08:00 --> Session Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:08:00 --> Session routines successfully run
DEBUG - 2014-03-07 21:08:00 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:08:00 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:00 --> Final output sent to browser
DEBUG - 2014-03-07 21:08:00 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:08:01 --> Config Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:08:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:08:01 --> URI Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Router Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Config Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Output Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:08:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:08:01 --> Security Class Initialized
DEBUG - 2014-03-07 21:08:01 --> URI Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Input Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Router Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:08:01 --> Config Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Language Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Output Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Loader Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Security Class Initialized
DEBUG - 2014-03-07 21:08:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:08:01 --> Input Class Initialized
DEBUG - 2014-03-07 21:08:01 --> URI Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:08:01 --> Router Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Controller Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Language Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:08:01 --> Output Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:08:01 --> Loader Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Security Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Controller Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:08:01 --> Input Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:08:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Language Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Loader Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Controller Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:08:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Session Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:08:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:01 --> Session routines successfully run
DEBUG - 2014-03-07 21:08:01 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:08:01 --> Session Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:08:01 --> Session routines successfully run
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:08:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:01 --> Final output sent to browser
DEBUG - 2014-03-07 21:08:01 --> Session Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:08:01 --> Final output sent to browser
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:08:01 --> Total execution time: 0.0100
DEBUG - 2014-03-07 21:08:01 --> Session routines successfully run
DEBUG - 2014-03-07 21:08:01 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:08:01 --> Model Class Initialized
DEBUG - 2014-03-07 21:08:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:08:01 --> Final output sent to browser
DEBUG - 2014-03-07 21:08:01 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:13:26 --> Config Class Initialized
DEBUG - 2014-03-07 21:13:26 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:13:26 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:13:27 --> URI Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Router Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Config Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Output Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:13:27 --> Security Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Input Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:13:27 --> URI Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Language Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Router Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Loader Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Output Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Controller Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Security Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:13:27 --> Input Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Language Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Loader Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Controller Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Session Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:13:27 --> Session routines successfully run
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:13:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Config Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Session Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:13:27 --> Final output sent to browser
DEBUG - 2014-03-07 21:13:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:13:27 --> Session routines successfully run
DEBUG - 2014-03-07 21:13:27 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:13:27 --> URI Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:13:27 --> Router Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:27 --> Final output sent to browser
DEBUG - 2014-03-07 21:13:27 --> Output Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:13:27 --> Security Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Input Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:13:27 --> Language Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Loader Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Controller Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:27 --> Session Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:13:27 --> Session routines successfully run
DEBUG - 2014-03-07 21:13:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:13:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:27 --> Final output sent to browser
DEBUG - 2014-03-07 21:13:27 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:13:31 --> Config Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:13:31 --> URI Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Router Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Config Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Output Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:13:31 --> Security Class Initialized
DEBUG - 2014-03-07 21:13:31 --> URI Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Input Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Router Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Config Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:13:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Language Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Output Class Initialized
DEBUG - 2014-03-07 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:13:31 --> Security Class Initialized
DEBUG - 2014-03-07 21:13:31 --> URI Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Loader Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Input Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Router Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Controller Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:13:31 --> Language Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Output Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:13:31 --> Loader Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Security Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Controller Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Input Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:13:31 --> Language Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:13:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Loader Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Controller Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:13:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:13:31 --> Session Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Session routines successfully run
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:13:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Session Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:13:31 --> Session routines successfully run
DEBUG - 2014-03-07 21:13:31 --> Final output sent to browser
DEBUG - 2014-03-07 21:13:31 --> Session Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:13:31 --> Session routines successfully run
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:13:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:13:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:13:31 --> Final output sent to browser
DEBUG - 2014-03-07 21:13:31 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:13:31 --> Final output sent to browser
DEBUG - 2014-03-07 21:13:31 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:15:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:15:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:15:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:15:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:15:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:15:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:15:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:15:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:15:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:15:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:15:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:15:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:15:29 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:15:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:15:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:15:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:15:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:15:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:15:29 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:17:25 --> Config Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Config Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:17:25 --> URI Class Initialized
DEBUG - 2014-03-07 21:17:25 --> URI Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Router Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Router Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Output Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Output Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Security Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Security Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Input Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Input Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:17:25 --> Language Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Language Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Loader Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Loader Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Controller Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Controller Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:17:25 --> Config Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:17:25 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> URI Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Router Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Output Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Security Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Input Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Language Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:25 --> Session Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Loader Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Controller Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:17:25 --> Session routines successfully run
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Final output sent to browser
DEBUG - 2014-03-07 21:17:25 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:25 --> Session Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:17:25 --> Session routines successfully run
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:25 --> Final output sent to browser
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:25 --> Session Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:17:25 --> Session routines successfully run
DEBUG - 2014-03-07 21:17:25 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:17:25 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:25 --> Final output sent to browser
DEBUG - 2014-03-07 21:17:25 --> Total execution time: 0.0240
DEBUG - 2014-03-07 21:17:47 --> Config Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:17:47 --> URI Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Config Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Router Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:17:47 --> URI Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Config Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Output Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Router Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Security Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Output Class Initialized
DEBUG - 2014-03-07 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:17:47 --> Input Class Initialized
DEBUG - 2014-03-07 21:17:47 --> URI Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Security Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:17:47 --> Router Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Input Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Language Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:17:47 --> Output Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Language Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Loader Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Security Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Controller Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Loader Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Input Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:17:47 --> Controller Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:17:47 --> Language Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Loader Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Controller Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:17:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:47 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Session Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:17:47 --> Session routines successfully run
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:17:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:47 --> Session Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:17:47 --> Session routines successfully run
DEBUG - 2014-03-07 21:17:47 --> Final output sent to browser
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:17:47 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:47 --> Final output sent to browser
DEBUG - 2014-03-07 21:17:47 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:47 --> Session Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:17:47 --> Session routines successfully run
DEBUG - 2014-03-07 21:17:47 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:17:47 --> Model Class Initialized
DEBUG - 2014-03-07 21:17:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:17:47 --> Final output sent to browser
DEBUG - 2014-03-07 21:17:47 --> Total execution time: 0.0220
DEBUG - 2014-03-07 21:18:27 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:27 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:27 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:27 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:27 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:27 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:27 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:27 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:27 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:27 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:27 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:27 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:27 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:27 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:27 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:27 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:27 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:27 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:27 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:27 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:18:27 --> Total execution time: 0.0110
DEBUG - 2014-03-07 21:18:28 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:28 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:28 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:28 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:28 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:28 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:28 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:28 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:28 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:28 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:28 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:28 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:28 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:28 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:28 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:28 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:18:28 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:18:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:28 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:28 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:28 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:28 --> Total execution time: 0.0190
DEBUG - 2014-03-07 21:18:44 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:44 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:44 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:44 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Config Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:44 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:18:44 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:44 --> URI Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Router Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:44 --> Output Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:44 --> Security Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Input Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Language Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Loader Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Controller Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:44 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:44 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Session Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:44 --> Session routines successfully run
DEBUG - 2014-03-07 21:18:44 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:18:44 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:44 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:44 --> Model Class Initialized
DEBUG - 2014-03-07 21:18:44 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:18:44 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:18:44 --> Final output sent to browser
DEBUG - 2014-03-07 21:18:44 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:21:28 --> Config Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:21:28 --> URI Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Router Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Output Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Security Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Input Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:21:28 --> Language Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Loader Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Controller Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Config Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:21:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:21:28 --> URI Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Router Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Session Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:21:28 --> Output Class Initialized
DEBUG - 2014-03-07 21:21:28 --> A session cookie was not found.
DEBUG - 2014-03-07 21:21:28 --> Security Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Session routines successfully run
DEBUG - 2014-03-07 21:21:28 --> Input Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Language Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:21:28 --> Loader Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Controller Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:21:28 --> Final output sent to browser
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:21:28 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:21:28 --> Session Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:21:28 --> A session cookie was not found.
DEBUG - 2014-03-07 21:21:28 --> Session routines successfully run
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:21:28 --> Final output sent to browser
DEBUG - 2014-03-07 21:21:28 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:21:28 --> Config Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:21:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:21:28 --> URI Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Router Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Output Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Security Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Input Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:21:28 --> Language Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Loader Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Controller Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:21:28 --> Session Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:21:28 --> A session cookie was not found.
DEBUG - 2014-03-07 21:21:28 --> Session routines successfully run
DEBUG - 2014-03-07 21:21:28 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:21:28 --> Model Class Initialized
DEBUG - 2014-03-07 21:21:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:21:28 --> Final output sent to browser
DEBUG - 2014-03-07 21:21:28 --> Total execution time: 0.0100
DEBUG - 2014-03-07 21:22:19 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:19 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:19 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:19 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:19 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:19 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:19 --> A session cookie was not found.
DEBUG - 2014-03-07 21:22:19 --> A session cookie was not found.
DEBUG - 2014-03-07 21:22:19 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:19 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:19 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:19 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:19 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:22:19 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:19 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:19 --> A session cookie was not found.
DEBUG - 2014-03-07 21:22:19 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:19 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:19 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:19 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:19 --> Total execution time: 0.0230
DEBUG - 2014-03-07 21:22:34 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:34 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:34 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:34 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:34 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:34 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:34 --> A session cookie was not found.
DEBUG - 2014-03-07 21:22:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:34 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:34 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:34 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:34 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Total execution time: 0.0180
DEBUG - 2014-03-07 21:22:34 --> A session cookie was not found.
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:34 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:34 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:34 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:34 --> A session cookie was not found.
DEBUG - 2014-03-07 21:22:34 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:34 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:34 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:22:38 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Config Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:22:38 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:38 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:38 --> URI Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Router Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Output Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Security Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Input Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:22:38 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Language Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Loader Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Controller Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:38 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Session Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:22:38 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:38 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:38 --> Session routines successfully run
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:22:38 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:38 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:38 --> Final output sent to browser
DEBUG - 2014-03-07 21:22:38 --> Total execution time: 0.0210
DEBUG - 2014-03-07 21:22:38 --> Total execution time: 0.0220
DEBUG - 2014-03-07 21:22:38 --> Total execution time: 0.0220
DEBUG - 2014-03-07 21:23:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:23:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:23:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:23:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:23:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:23:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:23:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:23:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:23:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:23:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:23:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:23:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:23:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:23:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:23:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:23:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:23:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:23:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:23:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Total execution time: 0.0230
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:23:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:23:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:23:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:23:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:23:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:23:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:23:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:23:29 --> Total execution time: 0.0200
DEBUG - 2014-03-07 21:23:29 --> Total execution time: 0.0200
DEBUG - 2014-03-07 21:25:30 --> Config Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:25:30 --> URI Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Router Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Config Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Output Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:25:30 --> Security Class Initialized
DEBUG - 2014-03-07 21:25:30 --> URI Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Input Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Router Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:25:30 --> Config Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Language Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Output Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:25:30 --> Loader Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Security Class Initialized
DEBUG - 2014-03-07 21:25:30 --> URI Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Controller Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Input Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Router Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:25:30 --> Language Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:25:30 --> Output Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Loader Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Security Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Controller Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Input Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:25:30 --> Language Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Loader Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Controller Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:25:30 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Session Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:25:30 --> Session routines successfully run
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:25:30 --> Session Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:25:30 --> Session Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Session routines successfully run
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:25:30 --> Final output sent to browser
DEBUG - 2014-03-07 21:25:30 --> Session routines successfully run
DEBUG - 2014-03-07 21:25:30 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:25:30 --> Model Class Initialized
DEBUG - 2014-03-07 21:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:25:30 --> Final output sent to browser
DEBUG - 2014-03-07 21:25:30 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:25:30 --> Final output sent to browser
DEBUG - 2014-03-07 21:25:30 --> Total execution time: 0.0110
DEBUG - 2014-03-07 21:27:11 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:11 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:11 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:11 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:11 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:11 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:11 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:11 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:11 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:11 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:11 --> A session cookie was not found.
DEBUG - 2014-03-07 21:27:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:11 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:11 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:11 --> A session cookie was not found.
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> A session cookie was not found.
DEBUG - 2014-03-07 21:27:11 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:11 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:11 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:11 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:11 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:27:11 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:11 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:11 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:27:11 --> Total execution time: 0.0110
DEBUG - 2014-03-07 21:27:35 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:35 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:35 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:35 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:35 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:35 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:35 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:35 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:35 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:35 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:35 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:35 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:35 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:35 --> Total execution time: 0.0340
DEBUG - 2014-03-07 21:27:35 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:35 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:35 --> Total execution time: 0.0350
DEBUG - 2014-03-07 21:27:35 --> Total execution time: 0.0340
DEBUG - 2014-03-07 21:27:41 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:41 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:41 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Config Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:27:41 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:41 --> URI Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Router Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Output Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:41 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Security Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Input Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:41 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:27:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Language Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Loader Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Controller Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:41 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:41 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:41 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:41 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:41 --> Session Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Total execution time: 0.0160
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:27:41 --> Session routines successfully run
DEBUG - 2014-03-07 21:27:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:27:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:27:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:27:41 --> Final output sent to browser
DEBUG - 2014-03-07 21:27:41 --> Total execution time: 0.0180
DEBUG - 2014-03-07 21:32:38 --> Config Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Config Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:32:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:32:38 --> Config Class Initialized
DEBUG - 2014-03-07 21:32:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:32:38 --> URI Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:32:38 --> URI Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Router Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Router Class Initialized
DEBUG - 2014-03-07 21:32:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:32:38 --> URI Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Router Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Output Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Output Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Security Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Security Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Output Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Input Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Input Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Security Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:32:38 --> Input Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Language Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:32:38 --> Language Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Language Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Loader Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Loader Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Loader Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Controller Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Controller Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Controller Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:38 --> Session Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Session Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:32:38 --> A session cookie was not found.
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:32:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:38 --> Session routines successfully run
DEBUG - 2014-03-07 21:32:38 --> Session Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> A session cookie was not found.
DEBUG - 2014-03-07 21:32:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:38 --> Session routines successfully run
DEBUG - 2014-03-07 21:32:38 --> A session cookie was not found.
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Final output sent to browser
DEBUG - 2014-03-07 21:32:38 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:32:38 --> Session routines successfully run
DEBUG - 2014-03-07 21:32:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:38 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:32:38 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:38 --> Final output sent to browser
DEBUG - 2014-03-07 21:32:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:38 --> Total execution time: 0.0160
DEBUG - 2014-03-07 21:32:38 --> Final output sent to browser
DEBUG - 2014-03-07 21:32:38 --> Total execution time: 0.0160
DEBUG - 2014-03-07 21:32:41 --> Config Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:32:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:32:41 --> URI Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Router Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Output Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Security Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Input Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Config Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:32:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Language Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:32:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:32:41 --> Loader Class Initialized
DEBUG - 2014-03-07 21:32:41 --> URI Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Controller Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Router Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:32:41 --> Output Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Security Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Input Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:32:41 --> Language Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Loader Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Controller Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:32:41 --> Session Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> A session cookie was not found.
DEBUG - 2014-03-07 21:32:41 --> Session routines successfully run
DEBUG - 2014-03-07 21:32:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:41 --> Config Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:32:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:32:41 --> Final output sent to browser
DEBUG - 2014-03-07 21:32:41 --> URI Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:32:41 --> Router Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:41 --> Output Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Security Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Input Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Session Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:32:41 --> Language Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:32:41 --> A session cookie was not found.
DEBUG - 2014-03-07 21:32:41 --> Loader Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Session routines successfully run
DEBUG - 2014-03-07 21:32:41 --> Controller Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Final output sent to browser
DEBUG - 2014-03-07 21:32:41 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:41 --> Session Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:32:41 --> A session cookie was not found.
DEBUG - 2014-03-07 21:32:41 --> Session routines successfully run
DEBUG - 2014-03-07 21:32:41 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:32:41 --> Model Class Initialized
DEBUG - 2014-03-07 21:32:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:32:41 --> Final output sent to browser
DEBUG - 2014-03-07 21:32:41 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:33:06 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:06 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:06 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:06 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:06 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:06 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:06 --> Total execution time: 0.0200
DEBUG - 2014-03-07 21:33:06 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:06 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:06 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:06 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:06 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:06 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:06 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:06 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:06 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:06 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:06 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:06 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:06 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:06 --> Total execution time: 0.0180
DEBUG - 2014-03-07 21:33:06 --> Total execution time: 0.0190
DEBUG - 2014-03-07 21:33:09 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:09 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:09 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:09 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:09 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:09 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:09 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:09 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:09 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:09 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:09 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:09 --> Total execution time: 0.0240
DEBUG - 2014-03-07 21:33:09 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:09 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:09 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:09 --> Total execution time: 0.0210
DEBUG - 2014-03-07 21:33:09 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:09 --> Total execution time: 0.0210
DEBUG - 2014-03-07 21:33:55 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:55 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:55 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:55 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:55 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:55 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:55 --> Total execution time: 0.0200
DEBUG - 2014-03-07 21:33:55 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Config Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:33:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:33:55 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:55 --> URI Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Router Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Output Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Security Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Input Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:33:55 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Language Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Loader Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Controller Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:55 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Session Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:33:55 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:55 --> Session routines successfully run
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:55 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:33:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:33:55 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:55 --> Final output sent to browser
DEBUG - 2014-03-07 21:33:55 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:33:55 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:36:51 --> Config Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Config Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Config Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:36:51 --> URI Class Initialized
DEBUG - 2014-03-07 21:36:51 --> URI Class Initialized
DEBUG - 2014-03-07 21:36:51 --> URI Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Router Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Router Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Router Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Output Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Output Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Output Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Security Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Security Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Security Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Input Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Input Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Input Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:36:51 --> Language Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Language Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Language Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Loader Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Loader Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Loader Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Controller Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Controller Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Controller Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:36:51 --> Session Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Session Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:36:51 --> Session routines successfully run
DEBUG - 2014-03-07 21:36:51 --> Session routines successfully run
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:36:51 --> Final output sent to browser
DEBUG - 2014-03-07 21:36:51 --> Final output sent to browser
DEBUG - 2014-03-07 21:36:51 --> Total execution time: 0.0230
DEBUG - 2014-03-07 21:36:51 --> Total execution time: 0.0240
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:36:51 --> Session Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:36:51 --> Session routines successfully run
DEBUG - 2014-03-07 21:36:51 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:36:51 --> Model Class Initialized
DEBUG - 2014-03-07 21:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:36:51 --> Final output sent to browser
DEBUG - 2014-03-07 21:36:51 --> Total execution time: 0.0330
DEBUG - 2014-03-07 21:37:34 --> Config Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Config Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Config Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:37:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:37:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:37:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:37:34 --> URI Class Initialized
DEBUG - 2014-03-07 21:37:34 --> URI Class Initialized
DEBUG - 2014-03-07 21:37:34 --> URI Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Router Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Router Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Router Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Output Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Output Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Output Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Security Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Security Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Security Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Input Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Input Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Input Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:37:34 --> Language Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Language Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Language Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Loader Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Loader Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Loader Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Controller Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Controller Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Controller Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:37:34 --> Session Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Session Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Session Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:37:34 --> Session routines successfully run
DEBUG - 2014-03-07 21:37:34 --> Session routines successfully run
DEBUG - 2014-03-07 21:37:34 --> Session routines successfully run
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:37:34 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Model Class Initialized
DEBUG - 2014-03-07 21:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:37:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:37:34 --> Final output sent to browser
DEBUG - 2014-03-07 21:37:34 --> Final output sent to browser
DEBUG - 2014-03-07 21:37:34 --> Final output sent to browser
DEBUG - 2014-03-07 21:37:34 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:37:34 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:37:34 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:39:56 --> Config Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Config Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Config Class Initialized
DEBUG - 2014-03-07 21:39:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:39:56 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:39:56 --> URI Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:39:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:39:56 --> Router Class Initialized
DEBUG - 2014-03-07 21:39:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:39:56 --> URI Class Initialized
DEBUG - 2014-03-07 21:39:56 --> URI Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Router Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Router Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Output Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Output Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Security Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Output Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Security Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Input Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Security Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Input Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:39:56 --> Input Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:39:56 --> Language Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:39:56 --> Language Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Language Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Loader Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Loader Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Loader Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Controller Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Controller Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Controller Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:39:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:39:56 --> Session Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Session Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:39:56 --> Session routines successfully run
DEBUG - 2014-03-07 21:39:56 --> Session routines successfully run
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:39:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:39:56 --> Final output sent to browser
DEBUG - 2014-03-07 21:39:56 --> Total execution time: 0.0270
DEBUG - 2014-03-07 21:39:56 --> Final output sent to browser
DEBUG - 2014-03-07 21:39:56 --> Total execution time: 0.0290
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:39:56 --> Session Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:39:56 --> Session routines successfully run
DEBUG - 2014-03-07 21:39:56 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:39:56 --> Model Class Initialized
DEBUG - 2014-03-07 21:39:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:39:56 --> Final output sent to browser
DEBUG - 2014-03-07 21:39:56 --> Total execution time: 0.0390
DEBUG - 2014-03-07 21:40:06 --> Config Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:40:06 --> URI Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Router Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Config Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Config Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Output Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:40:06 --> Security Class Initialized
DEBUG - 2014-03-07 21:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:40:06 --> URI Class Initialized
DEBUG - 2014-03-07 21:40:06 --> URI Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Input Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Router Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Router Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:40:06 --> Language Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Output Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Output Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Security Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Security Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Loader Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Input Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Controller Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Input Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:40:06 --> Language Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Language Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Loader Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Loader Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Controller Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Controller Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:40:06 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:40:06 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Session Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:40:06 --> Session routines successfully run
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Session Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:40:06 --> Session Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:40:06 --> Session routines successfully run
DEBUG - 2014-03-07 21:40:06 --> Session routines successfully run
DEBUG - 2014-03-07 21:40:06 --> Final output sent to browser
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:40:06 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:40:06 --> Total execution time: 0.0210
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Model Class Initialized
DEBUG - 2014-03-07 21:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:40:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:40:06 --> Final output sent to browser
DEBUG - 2014-03-07 21:40:06 --> Final output sent to browser
DEBUG - 2014-03-07 21:40:06 --> Total execution time: 0.0200
DEBUG - 2014-03-07 21:40:06 --> Total execution time: 0.0200
DEBUG - 2014-03-07 21:42:43 --> Config Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Config Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Config Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:42:43 --> URI Class Initialized
DEBUG - 2014-03-07 21:42:43 --> URI Class Initialized
DEBUG - 2014-03-07 21:42:43 --> URI Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Router Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Router Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Router Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Output Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Output Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Output Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Security Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Security Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Security Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Input Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Input Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Input Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:42:43 --> Language Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Language Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Language Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Loader Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Loader Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Loader Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Controller Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Controller Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Controller Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:42:43 --> Session Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Session Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:42:43 --> A session cookie was not found.
DEBUG - 2014-03-07 21:42:43 --> A session cookie was not found.
DEBUG - 2014-03-07 21:42:43 --> Session routines successfully run
DEBUG - 2014-03-07 21:42:43 --> Session routines successfully run
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:42:43 --> Final output sent to browser
DEBUG - 2014-03-07 21:42:43 --> Final output sent to browser
DEBUG - 2014-03-07 21:42:43 --> Total execution time: 0.0150
DEBUG - 2014-03-07 21:42:43 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:42:43 --> Session Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:42:43 --> A session cookie was not found.
DEBUG - 2014-03-07 21:42:43 --> Session routines successfully run
DEBUG - 2014-03-07 21:42:43 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:42:43 --> Model Class Initialized
DEBUG - 2014-03-07 21:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:42:43 --> Final output sent to browser
DEBUG - 2014-03-07 21:42:43 --> Total execution time: 0.0240
DEBUG - 2014-03-07 21:44:42 --> Config Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Config Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:44:42 --> URI Class Initialized
DEBUG - 2014-03-07 21:44:42 --> URI Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Router Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Router Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Config Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Output Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Output Class Initialized
DEBUG - 2014-03-07 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:44:42 --> Security Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Security Class Initialized
DEBUG - 2014-03-07 21:44:42 --> URI Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Input Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Input Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Router Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:44:42 --> Language Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Language Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Output Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Security Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Loader Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Loader Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Input Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Controller Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Controller Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:44:42 --> Language Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:44:42 --> Loader Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Controller Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:44:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:44:42 --> Session Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:44:42 --> Session routines successfully run
DEBUG - 2014-03-07 21:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:44:42 --> Session Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Session Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:44:42 --> Session routines successfully run
DEBUG - 2014-03-07 21:44:42 --> Session routines successfully run
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:44:42 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Model Class Initialized
DEBUG - 2014-03-07 21:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:44:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:44:42 --> Final output sent to browser
DEBUG - 2014-03-07 21:44:42 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:44:42 --> Final output sent to browser
DEBUG - 2014-03-07 21:44:42 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:44:42 --> Final output sent to browser
DEBUG - 2014-03-07 21:44:42 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:57:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:29 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:29 --> Total execution time: 0.0130
DEBUG - 2014-03-07 21:57:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:29 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:29 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:29 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:29 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:29 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:29 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:29 --> Total execution time: 0.0120
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:29 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:29 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:29 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:29 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:29 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:29 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:29 --> Total execution time: 0.0190
DEBUG - 2014-03-07 21:57:31 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:31 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:31 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:31 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:31 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:31 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:31 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:31 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:31 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:31 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:31 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:31 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:31 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:31 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:31 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:31 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:31 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:31 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:57:31 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:31 --> Total execution time: 0.0160
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:31 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:31 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:31 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:31 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:31 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:31 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:31 --> Total execution time: 0.0240
DEBUG - 2014-03-07 21:57:55 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:55 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:55 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:55 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:55 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:55 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:55 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:55 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:55 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:55 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:55 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:55 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:55 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:55 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:55 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:55 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Total execution time: 0.0220
DEBUG - 2014-03-07 21:57:55 --> Total execution time: 0.0220
DEBUG - 2014-03-07 21:57:55 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:55 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:55 --> A session cookie was not found.
DEBUG - 2014-03-07 21:57:55 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:55 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:55 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:55 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:55 --> Total execution time: 0.0140
DEBUG - 2014-03-07 21:57:58 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:58 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:58 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:58 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Config Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Hooks Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:58 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Utf8 Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 21:57:58 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:58 --> URI Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:58 --> Router Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:58 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Output Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:58 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Security Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:58 --> Input Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:58 --> Language Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Loader Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Controller Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:58 --> Database Driver Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:58 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:58 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:58 --> Session Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:58 --> Total execution time: 0.0240
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: string_helper
DEBUG - 2014-03-07 21:57:58 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:58 --> Session routines successfully run
DEBUG - 2014-03-07 21:57:58 --> Total execution time: 0.0220
DEBUG - 2014-03-07 21:57:58 --> Helper loaded: url_helper
DEBUG - 2014-03-07 21:57:58 --> Model Class Initialized
DEBUG - 2014-03-07 21:57:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 21:57:58 --> Final output sent to browser
DEBUG - 2014-03-07 21:57:58 --> Total execution time: 0.0210
DEBUG - 2014-03-07 22:00:32 --> Config Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Config Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 22:00:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 22:00:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 22:00:32 --> URI Class Initialized
DEBUG - 2014-03-07 22:00:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 22:00:32 --> URI Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Router Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Router Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Output Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Output Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Security Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Security Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Input Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Input Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 22:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 22:00:32 --> Language Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Language Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Loader Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Loader Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Controller Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Controller Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 22:00:32 --> Config Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Hooks Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Utf8 Class Initialized
DEBUG - 2014-03-07 22:00:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-07 22:00:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 22:00:32 --> URI Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Router Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Output Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Security Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 22:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 22:00:32 --> Input Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Session Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-07 22:00:32 --> Session Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 22:00:32 --> Language Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Session routines successfully run
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 22:00:32 --> Session routines successfully run
DEBUG - 2014-03-07 22:00:32 --> Loader Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Controller Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-07 22:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Final output sent to browser
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Total execution time: 0.0190
DEBUG - 2014-03-07 22:00:32 --> Final output sent to browser
DEBUG - 2014-03-07 22:00:32 --> Total execution time: 0.0200
DEBUG - 2014-03-07 22:00:32 --> Database Driver Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 22:00:32 --> Session Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: string_helper
DEBUG - 2014-03-07 22:00:32 --> Session routines successfully run
DEBUG - 2014-03-07 22:00:32 --> Helper loaded: url_helper
DEBUG - 2014-03-07 22:00:32 --> Model Class Initialized
DEBUG - 2014-03-07 22:00:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-07 22:00:32 --> Final output sent to browser
DEBUG - 2014-03-07 22:00:32 --> Total execution time: 0.0140
