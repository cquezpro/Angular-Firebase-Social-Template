<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-08 21:44:14 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:14 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:14 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:14 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:14 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Database Driver Class Initialized
ERROR - 2014-02-08 21:44:14 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-08 21:44:14 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:14 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:14 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:14 --> A session cookie was not found.
DEBUG - 2014-02-08 21:44:14 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:14 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:19 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:19 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:19 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:19 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Database Driver Class Initialized
ERROR - 2014-02-08 21:44:19 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-08 21:44:19 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:19 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:19 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:19 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:19 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:20 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-08 21:44:20 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:20 --> Total execution time: 0.0200
DEBUG - 2014-02-08 21:44:21 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:21 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:21 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:21 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Database Driver Class Initialized
ERROR - 2014-02-08 21:44:21 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-08 21:44:21 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:21 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:21 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:21 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:21 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:21 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:21 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Database Driver Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:21 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:21 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:21 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:26 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:26 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:26 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:26 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Database Driver Class Initialized
ERROR - 2014-02-08 21:44:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-08 21:44:26 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:26 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:26 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:26 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:26 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-08 21:44:26 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:26 --> Total execution time: 0.0250
DEBUG - 2014-02-08 21:44:28 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:28 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:28 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:28 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:28 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:28 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:28 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Database Driver Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:28 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:28 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:28 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:28 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:28 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:28 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:29 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:29 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Database Driver Class Initialized
ERROR - 2014-02-08 21:44:29 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-08 21:44:29 --> Database Driver Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:29 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:29 --> Total execution time: 0.0200
DEBUG - 2014-02-08 21:44:29 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:29 --> Total execution time: 0.0195
DEBUG - 2014-02-08 21:44:29 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:29 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:29 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Database Driver Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:29 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:29 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:29 --> Total execution time: 0.0315
DEBUG - 2014-02-08 21:44:29 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:29 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:29 --> Total execution time: 0.0275
DEBUG - 2014-02-08 21:44:38 --> Config Class Initialized
DEBUG - 2014-02-08 21:44:38 --> Hooks Class Initialized
DEBUG - 2014-02-08 21:44:38 --> Utf8 Class Initialized
DEBUG - 2014-02-08 21:44:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-08 21:44:38 --> URI Class Initialized
DEBUG - 2014-02-08 21:44:38 --> Router Class Initialized
DEBUG - 2014-02-08 21:44:38 --> Output Class Initialized
DEBUG - 2014-02-08 21:44:38 --> Security Class Initialized
DEBUG - 2014-02-08 21:44:38 --> Input Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-08 21:44:39 --> Language Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Loader Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Controller Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-08 21:44:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-08 21:44:39 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Database Driver Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:39 --> Session Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Helper loaded: string_helper
DEBUG - 2014-02-08 21:44:39 --> Session routines successfully run
DEBUG - 2014-02-08 21:44:39 --> Helper loaded: url_helper
DEBUG - 2014-02-08 21:44:39 --> Model Class Initialized
DEBUG - 2014-02-08 21:44:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-08 21:44:39 --> Final output sent to browser
DEBUG - 2014-02-08 21:44:39 --> Total execution time: 0.0280
