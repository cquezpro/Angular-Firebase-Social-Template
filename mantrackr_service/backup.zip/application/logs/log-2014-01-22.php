<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-22 16:27:13 --> Config Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Hooks Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Utf8 Class Initialized
DEBUG - 2014-01-22 16:27:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 16:27:13 --> URI Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Router Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Output Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Security Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Input Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 16:27:13 --> Language Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Loader Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Controller Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 16:27:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 16:27:13 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:13 --> Database Driver Class Initialized
ERROR - 2014-01-22 16:27:14 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-22 16:27:14 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 16:27:17 --> Final output sent to browser
DEBUG - 2014-01-22 16:27:17 --> Total execution time: 3.4262
DEBUG - 2014-01-22 16:27:22 --> Config Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Hooks Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Utf8 Class Initialized
DEBUG - 2014-01-22 16:27:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 16:27:22 --> URI Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Router Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Output Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Security Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Input Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 16:27:22 --> Language Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Loader Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Controller Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 16:27:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 16:27:22 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:22 --> Database Driver Class Initialized
ERROR - 2014-01-22 16:27:22 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-22 16:27:22 --> Final output sent to browser
DEBUG - 2014-01-22 16:27:22 --> Total execution time: 0.0100
DEBUG - 2014-01-22 16:27:30 --> Config Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Hooks Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Utf8 Class Initialized
DEBUG - 2014-01-22 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 16:27:30 --> URI Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Router Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Output Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Security Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Input Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 16:27:30 --> Language Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Loader Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Controller Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 16:27:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 16:27:30 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Database Driver Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Model Class Initialized
DEBUG - 2014-01-22 16:27:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 16:27:32 --> Final output sent to browser
DEBUG - 2014-01-22 16:27:32 --> Total execution time: 2.2351
DEBUG - 2014-01-22 16:30:22 --> Config Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Hooks Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Utf8 Class Initialized
DEBUG - 2014-01-22 16:30:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 16:30:22 --> URI Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Router Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Output Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Security Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Input Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 16:30:22 --> Language Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Loader Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Controller Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 16:30:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 16:30:22 --> Model Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Model Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Database Driver Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Model Class Initialized
DEBUG - 2014-01-22 16:30:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 16:32:25 --> Final output sent to browser
DEBUG - 2014-01-22 16:32:25 --> Total execution time: 123.3031
DEBUG - 2014-01-22 18:02:43 --> Config Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Hooks Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Utf8 Class Initialized
DEBUG - 2014-01-22 18:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 18:02:43 --> URI Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Router Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Output Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Security Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Input Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 18:02:43 --> Language Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Loader Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Controller Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 18:02:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 18:02:43 --> Model Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Model Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Database Driver Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Model Class Initialized
DEBUG - 2014-01-22 18:02:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 18:02:43 --> Final output sent to browser
DEBUG - 2014-01-22 18:02:43 --> Total execution time: 0.2180
DEBUG - 2014-01-22 18:02:51 --> Config Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Hooks Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Utf8 Class Initialized
DEBUG - 2014-01-22 18:02:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 18:02:51 --> URI Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Router Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Output Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Security Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Input Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 18:02:51 --> Language Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Loader Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Controller Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 18:02:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 18:02:51 --> Model Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Model Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Database Driver Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Model Class Initialized
DEBUG - 2014-01-22 18:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 18:02:54 --> Final output sent to browser
DEBUG - 2014-01-22 18:02:54 --> Total execution time: 3.2132
DEBUG - 2014-01-22 18:03:35 --> Config Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Hooks Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Utf8 Class Initialized
DEBUG - 2014-01-22 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 18:03:35 --> URI Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Router Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Output Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Security Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Input Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 18:03:35 --> Language Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Loader Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Controller Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 18:03:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 18:03:35 --> Model Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Model Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Database Driver Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Model Class Initialized
DEBUG - 2014-01-22 18:03:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 18:04:49 --> Final output sent to browser
DEBUG - 2014-01-22 18:04:49 --> Total execution time: 74.3443
DEBUG - 2014-01-22 18:05:21 --> Config Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Hooks Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Utf8 Class Initialized
DEBUG - 2014-01-22 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 18:05:21 --> URI Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Router Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Output Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Security Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Input Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 18:05:21 --> Language Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Loader Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Controller Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 18:05:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 18:05:21 --> Model Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Model Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Database Driver Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Model Class Initialized
DEBUG - 2014-01-22 18:05:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 18:05:24 --> Final output sent to browser
DEBUG - 2014-01-22 18:05:24 --> Total execution time: 2.6121
DEBUG - 2014-01-22 18:07:02 --> Config Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Hooks Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Utf8 Class Initialized
DEBUG - 2014-01-22 18:07:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 18:07:02 --> URI Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Router Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Output Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Security Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Input Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 18:07:02 --> Language Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Loader Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Controller Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 18:07:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 18:07:02 --> Model Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Model Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Database Driver Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Model Class Initialized
DEBUG - 2014-01-22 18:07:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 18:07:05 --> Final output sent to browser
DEBUG - 2014-01-22 18:07:05 --> Total execution time: 2.8922
DEBUG - 2014-01-22 18:46:27 --> Config Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Hooks Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Utf8 Class Initialized
DEBUG - 2014-01-22 18:46:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 18:46:27 --> URI Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Router Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Output Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Security Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Input Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 18:46:27 --> Language Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Loader Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Controller Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 18:46:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 18:46:27 --> Model Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Model Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Database Driver Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Model Class Initialized
DEBUG - 2014-01-22 18:46:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 18:46:29 --> Final output sent to browser
DEBUG - 2014-01-22 18:46:29 --> Total execution time: 2.5601
DEBUG - 2014-01-22 22:19:17 --> Config Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Hooks Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Utf8 Class Initialized
DEBUG - 2014-01-22 22:19:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 22:19:17 --> URI Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Router Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Output Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Security Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Input Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 22:19:17 --> Language Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Loader Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Controller Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 22:19:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 22:19:17 --> Model Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Model Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Database Driver Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Model Class Initialized
DEBUG - 2014-01-22 22:19:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 22:19:24 --> Final output sent to browser
DEBUG - 2014-01-22 22:19:24 --> Total execution time: 7.0674
DEBUG - 2014-01-22 22:20:59 --> Config Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Hooks Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Utf8 Class Initialized
DEBUG - 2014-01-22 22:20:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 22:20:59 --> URI Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Router Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Output Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Security Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Input Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 22:20:59 --> Language Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Loader Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Controller Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 22:20:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 22:20:59 --> Model Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Model Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Database Driver Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Helper loaded: email_helper
DEBUG - 2014-01-22 22:20:59 --> Model Class Initialized
DEBUG - 2014-01-22 22:20:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 22:20:59 --> Final output sent to browser
DEBUG - 2014-01-22 22:20:59 --> Total execution time: 0.1060
DEBUG - 2014-01-22 22:22:00 --> Config Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Hooks Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Utf8 Class Initialized
DEBUG - 2014-01-22 22:22:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 22:22:00 --> URI Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Router Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Output Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Security Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Input Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 22:22:00 --> Language Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Loader Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Controller Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 22:22:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 22:22:00 --> Model Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Model Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Database Driver Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Model Class Initialized
DEBUG - 2014-01-22 22:22:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 22:22:02 --> Final output sent to browser
DEBUG - 2014-01-22 22:22:02 --> Total execution time: 2.3871
DEBUG - 2014-01-22 22:23:30 --> Config Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Hooks Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Utf8 Class Initialized
DEBUG - 2014-01-22 22:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-22 22:23:30 --> URI Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Router Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Output Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Security Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Input Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-22 22:23:30 --> Language Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Loader Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Controller Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-22 22:23:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-22 22:23:30 --> Model Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Model Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Database Driver Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Model Class Initialized
DEBUG - 2014-01-22 22:23:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-22 22:23:34 --> Final output sent to browser
DEBUG - 2014-01-22 22:23:34 --> Total execution time: 3.9342
