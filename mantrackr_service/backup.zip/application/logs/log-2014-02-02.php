<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-02 15:49:01 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:01 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:01 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:01 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Database Driver Class Initialized
ERROR - 2014-02-02 15:49:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-02 15:49:01 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:01 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:01 --> A session cookie was not found.
DEBUG - 2014-02-02 15:49:01 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:01 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:01 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:01 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:01 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Database Driver Class Initialized
ERROR - 2014-02-02 15:49:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-02 15:49:01 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:01 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:01 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:01 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:01 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-02 15:49:01 --> Final output sent to browser
DEBUG - 2014-02-02 15:49:01 --> Total execution time: 0.0120
DEBUG - 2014-02-02 15:49:05 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:05 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:05 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:05 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:05 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Database Driver Class Initialized
ERROR - 2014-02-02 15:49:05 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-02 15:49:05 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:05 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:05 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:05 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:05 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:06 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:06 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:06 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:06 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:06 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:06 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:06 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:06 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-02 15:49:06 --> Final output sent to browser
DEBUG - 2014-02-02 15:49:06 --> Total execution time: 0.0110
DEBUG - 2014-02-02 15:49:06 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Config Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-02 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-02 15:49:06 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:06 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-02 15:49:06 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:06 --> URI Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Router Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Output Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Security Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:06 --> Input Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:06 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-02 15:49:06 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Language Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Loader Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Controller Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Session Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-02 15:49:06 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:06 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:06 --> Session routines successfully run
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Model Class Initialized
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-02 15:49:06 --> Final output sent to browser
DEBUG - 2014-02-02 15:49:06 --> Total execution time: 0.0140
DEBUG - 2014-02-02 15:49:06 --> Final output sent to browser
DEBUG - 2014-02-02 15:49:06 --> Total execution time: 0.0200
DEBUG - 2014-02-02 15:49:06 --> Final output sent to browser
DEBUG - 2014-02-02 15:49:06 --> Total execution time: 0.0280
