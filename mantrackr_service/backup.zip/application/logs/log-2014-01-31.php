<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-31 00:04:07 --> Config Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:04:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:04:07 --> URI Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Router Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Output Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Security Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Input Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:04:07 --> Language Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Loader Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Controller Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:04:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:04:07 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:07 --> Session Class Initialized
DEBUG - 2014-01-31 00:04:07 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:04:07 --> Session routines successfully run
DEBUG - 2014-01-31 00:04:07 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:04:07 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:04:07 --> Final output sent to browser
DEBUG - 2014-01-31 00:04:07 --> Total execution time: 0.0190
DEBUG - 2014-01-31 00:04:09 --> Config Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:04:09 --> URI Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Router Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Output Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Config Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Security Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Input Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:04:09 --> URI Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Language Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Router Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Loader Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Controller Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Output Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:04:09 --> Security Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:04:09 --> Input Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:04:09 --> Language Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Loader Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Controller Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Session Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:04:09 --> Session routines successfully run
DEBUG - 2014-01-31 00:04:09 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:09 --> Session Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:04:09 --> Session routines successfully run
DEBUG - 2014-01-31 00:04:09 --> Final output sent to browser
DEBUG - 2014-01-31 00:04:09 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:04:09 --> Total execution time: 0.0120
DEBUG - 2014-01-31 00:04:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:09 --> Final output sent to browser
DEBUG - 2014-01-31 00:04:09 --> Total execution time: 0.0250
DEBUG - 2014-01-31 00:04:11 --> Config Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:04:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:04:11 --> URI Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Router Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Output Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Security Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Input Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:04:11 --> Language Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Loader Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Controller Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:04:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:04:11 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:11 --> Session Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:04:11 --> Session routines successfully run
DEBUG - 2014-01-31 00:04:11 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:04:11 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:11 --> Final output sent to browser
DEBUG - 2014-01-31 00:04:11 --> Total execution time: 0.0440
DEBUG - 2014-01-31 00:04:12 --> Config Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:04:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:04:12 --> URI Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Router Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Output Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Security Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Input Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:04:12 --> Language Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Loader Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Controller Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:04:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:04:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:12 --> Session Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:04:12 --> Session routines successfully run
DEBUG - 2014-01-31 00:04:12 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:04:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:04:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:04:12 --> Final output sent to browser
DEBUG - 2014-01-31 00:04:12 --> Total execution time: 0.0250
DEBUG - 2014-01-31 00:11:44 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:44 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:44 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:44 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:44 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:44 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:44 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:44 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:44 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:11:44 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:44 --> Total execution time: 0.0190
DEBUG - 2014-01-31 00:11:45 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:45 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:45 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:45 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:45 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:45 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:45 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:45 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:45 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:45 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:45 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:45 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:45 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:45 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:45 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:45 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:45 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:45 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:45 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:45 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:45 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:45 --> Total execution time: 0.0190
DEBUG - 2014-01-31 00:11:45 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:45 --> Total execution time: 0.0170
DEBUG - 2014-01-31 00:11:45 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:45 --> Total execution time: 0.0290
DEBUG - 2014-01-31 00:11:46 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:46 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:46 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:46 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:46 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:46 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:46 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:46 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:11:46 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:46 --> Total execution time: 0.0190
DEBUG - 2014-01-31 00:11:47 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:47 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:47 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:47 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:47 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:47 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:47 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:47 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:47 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:47 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:47 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:47 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:47 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:47 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:47 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:47 --> Total execution time: 0.0180
DEBUG - 2014-01-31 00:11:47 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:47 --> Total execution time: 0.0210
DEBUG - 2014-01-31 00:11:47 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:47 --> Total execution time: 0.0310
DEBUG - 2014-01-31 00:11:57 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:57 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:57 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:57 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:57 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:57 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:57 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:57 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:11:57 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:57 --> Total execution time: 0.0220
DEBUG - 2014-01-31 00:11:58 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:58 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Config Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:58 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:11:58 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:58 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:58 --> URI Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Router Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Output Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Security Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Input Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:58 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:11:58 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:58 --> Language Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:58 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:58 --> Loader Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:58 --> Controller Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:11:58 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:58 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Session Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:11:58 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:58 --> Session routines successfully run
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:58 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:58 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:58 --> Total execution time: 0.0180
DEBUG - 2014-01-31 00:11:58 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:58 --> Total execution time: 0.0170
DEBUG - 2014-01-31 00:11:58 --> Model Class Initialized
DEBUG - 2014-01-31 00:11:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:11:58 --> Final output sent to browser
DEBUG - 2014-01-31 00:11:58 --> Total execution time: 0.0320
DEBUG - 2014-01-31 00:12:12 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:12 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:12 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:12 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:12 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:12 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:12 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:12 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:12 --> Total execution time: 0.0410
DEBUG - 2014-01-31 00:12:45 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:45 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:45 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:45 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:45 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:45 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:45 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:12:45 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:45 --> Total execution time: 0.0190
DEBUG - 2014-01-31 00:12:46 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:46 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:46 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:46 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:46 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:46 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:46 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:46 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:46 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:46 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:46 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:46 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:46 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:46 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:46 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:46 --> Total execution time: 0.0130
DEBUG - 2014-01-31 00:12:46 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:46 --> Total execution time: 0.0200
DEBUG - 2014-01-31 00:12:46 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:46 --> Total execution time: 0.0260
DEBUG - 2014-01-31 00:12:49 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:49 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:49 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:49 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:49 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:49 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:49 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:49 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:49 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:49 --> Total execution time: 0.0310
DEBUG - 2014-01-31 00:12:56 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:56 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:56 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:56 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:56 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:12:56 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:56 --> Total execution time: 0.0150
DEBUG - 2014-01-31 00:12:56 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:56 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Config Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:56 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:56 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:56 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:56 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> URI Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Router Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Output Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Security Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Input Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:12:56 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:56 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:56 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:56 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Language Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:56 --> Loader Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Controller Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:56 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:56 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:56 --> Total execution time: 0.0190
DEBUG - 2014-01-31 00:12:56 --> Total execution time: 0.0170
DEBUG - 2014-01-31 00:12:56 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Session Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:12:56 --> Session routines successfully run
DEBUG - 2014-01-31 00:12:56 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:12:56 --> Model Class Initialized
DEBUG - 2014-01-31 00:12:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:12:56 --> Final output sent to browser
DEBUG - 2014-01-31 00:12:56 --> Total execution time: 0.0350
DEBUG - 2014-01-31 00:13:52 --> Config Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:13:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:13:52 --> URI Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Router Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Output Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Security Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Input Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:13:52 --> Language Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Loader Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Controller Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:13:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:13:52 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:52 --> Session Class Initialized
DEBUG - 2014-01-31 00:13:52 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:13:52 --> Session routines successfully run
DEBUG - 2014-01-31 00:13:52 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:13:52 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-31 00:13:52 --> Final output sent to browser
DEBUG - 2014-01-31 00:13:52 --> Total execution time: 0.0220
DEBUG - 2014-01-31 00:13:53 --> Config Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:13:53 --> URI Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Router Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Output Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Config Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Config Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Security Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Input Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:13:53 --> Language Class Initialized
DEBUG - 2014-01-31 00:13:53 --> URI Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Router Class Initialized
DEBUG - 2014-01-31 00:13:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:13:53 --> Loader Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Controller Class Initialized
DEBUG - 2014-01-31 00:13:53 --> URI Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Output Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:13:53 --> Security Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:13:53 --> Input Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:13:53 --> Language Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Loader Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Controller Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Router Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:13:53 --> Output Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:13:53 --> Security Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Session Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Input Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:13:53 --> Session routines successfully run
DEBUG - 2014-01-31 00:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:13:53 --> Language Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:53 --> Loader Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Controller Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Session Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:13:53 --> Session routines successfully run
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:53 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Final output sent to browser
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Total execution time: 0.0140
DEBUG - 2014-01-31 00:13:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:53 --> Session Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:13:53 --> Session routines successfully run
DEBUG - 2014-01-31 00:13:53 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:13:53 --> Model Class Initialized
DEBUG - 2014-01-31 00:13:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:13:53 --> Final output sent to browser
DEBUG - 2014-01-31 00:13:53 --> Total execution time: 0.0210
DEBUG - 2014-01-31 00:13:53 --> Final output sent to browser
DEBUG - 2014-01-31 00:13:53 --> Total execution time: 0.0310
DEBUG - 2014-01-31 00:14:08 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:08 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:08 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:08 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:08 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:08 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:08 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:08 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:08 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:08 --> Total execution time: 0.0220
DEBUG - 2014-01-31 00:14:09 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:09 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:09 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:09 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:09 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:09 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:09 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:09 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:09 --> Total execution time: 0.0170
DEBUG - 2014-01-31 00:14:13 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:13 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:13 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:13 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:13 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:13 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:13 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:13 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:13 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:13 --> Total execution time: 0.0330
DEBUG - 2014-01-31 00:14:14 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:14 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:14 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:14 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:14 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:14 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:14 --> Total execution time: 0.0340
DEBUG - 2014-01-31 00:14:14 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:14 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:14 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:14 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:14 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:14 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:14 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:14 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:14 --> Total execution time: 0.0400
DEBUG - 2014-01-31 00:14:16 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:16 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:16 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:16 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:16 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:16 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:16 --> Total execution time: 0.0320
DEBUG - 2014-01-31 00:14:16 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:16 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:16 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:16 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:16 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:16 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:16 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:17 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:17 --> Total execution time: 0.0310
DEBUG - 2014-01-31 00:14:17 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:17 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:17 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:17 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:17 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:17 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:17 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:17 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:17 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:17 --> Total execution time: 0.0310
DEBUG - 2014-01-31 00:14:19 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:19 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:19 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:19 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:19 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:19 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:19 --> Total execution time: 0.0300
DEBUG - 2014-01-31 00:14:19 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:19 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:19 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:19 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:19 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:19 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:19 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:19 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:19 --> Total execution time: 0.0300
DEBUG - 2014-01-31 00:14:20 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:20 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:20 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:20 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:20 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:20 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:20 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:20 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:20 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:20 --> Total execution time: 0.0310
DEBUG - 2014-01-31 00:14:21 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:21 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:21 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:21 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:21 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:21 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:21 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:21 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:21 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:21 --> Total execution time: 0.0280
DEBUG - 2014-01-31 00:14:22 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:22 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:22 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:22 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:22 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:22 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:22 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:22 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:22 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:22 --> Total execution time: 0.0230
DEBUG - 2014-01-31 00:14:25 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:25 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:25 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:25 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:25 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:25 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:25 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:25 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:25 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:25 --> Total execution time: 0.0320
DEBUG - 2014-01-31 00:14:26 --> Config Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Hooks Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Utf8 Class Initialized
DEBUG - 2014-01-31 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-31 00:14:26 --> URI Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Router Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Output Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Security Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Input Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-31 00:14:26 --> Language Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Loader Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Controller Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-31 00:14:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-31 00:14:26 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Database Driver Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:26 --> Session Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Helper loaded: string_helper
DEBUG - 2014-01-31 00:14:26 --> Session routines successfully run
DEBUG - 2014-01-31 00:14:26 --> Helper loaded: url_helper
DEBUG - 2014-01-31 00:14:26 --> Model Class Initialized
DEBUG - 2014-01-31 00:14:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-31 00:14:26 --> Final output sent to browser
DEBUG - 2014-01-31 00:14:26 --> Total execution time: 0.0320
