<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-07 17:23:19 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-07 17:23:19 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-07 17:23:19 --> Config Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:19 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:19 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:19 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:19 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:19 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:20 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:20 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:20 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:21 --> Session Class Initialized
DEBUG - 2014-05-07 17:23:21 --> Session Class Initialized
DEBUG - 2014-05-07 17:23:21 --> Session Class Initialized
DEBUG - 2014-05-07 17:23:21 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:23:21 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:23:21 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:23:21 --> A session cookie was not found.
DEBUG - 2014-05-07 17:23:21 --> A session cookie was not found.
DEBUG - 2014-05-07 17:23:21 --> A session cookie was not found.
DEBUG - 2014-05-07 17:23:21 --> Session routines successfully run
DEBUG - 2014-05-07 17:23:21 --> Session routines successfully run
DEBUG - 2014-05-07 17:23:21 --> Session routines successfully run
DEBUG - 2014-05-07 17:23:21 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:23:21 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:23:21 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:23:21 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:21 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:21 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:21 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:21 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:21 --> Total execution time: 2.4701
DEBUG - 2014-05-07 17:23:21 --> Total execution time: 2.4701
DEBUG - 2014-05-07 17:23:21 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:21 --> Total execution time: 2.4711
DEBUG - 2014-05-07 17:23:31 --> Config Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:31 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:31 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:31 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:32 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:32 --> Total execution time: 0.3020
DEBUG - 2014-05-07 17:23:34 --> Config Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:34 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:34 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:34 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:34 --> Total execution time: 0.0200
DEBUG - 2014-05-07 17:23:39 --> Config Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:39 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:39 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:39 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:39 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:39 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:23:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:23:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:23:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:23:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:23:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:23:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Helper loaded: email_helper
DEBUG - 2014-05-07 17:23:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:51 --> Model Class Initialized
DEBUG - 2014-05-07 17:23:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:23:52 --> Final output sent to browser
DEBUG - 2014-05-07 17:23:52 --> Total execution time: 3.1162
DEBUG - 2014-05-07 17:24:04 --> Config Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:24:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:24:04 --> URI Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Router Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Output Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Security Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Input Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:24:04 --> Language Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Loader Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Controller Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:24:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:24:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Image Lib Class Initialized
DEBUG - 2014-05-07 17:24:04 --> Final output sent to browser
DEBUG - 2014-05-07 17:24:04 --> Total execution time: 0.2330
DEBUG - 2014-05-07 17:24:06 --> Config Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:24:06 --> URI Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Router Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Output Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Security Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Input Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:24:06 --> Language Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Loader Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Controller Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:24:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:24:06 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:24:06 --> Image Lib Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:24:07 --> Final output sent to browser
DEBUG - 2014-05-07 17:24:07 --> Total execution time: 1.1441
DEBUG - 2014-05-07 17:24:07 --> Config Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:24:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:24:07 --> URI Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Router Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Output Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Security Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Input Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:24:07 --> Language Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Loader Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Controller Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:24:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:24:07 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Model Class Initialized
DEBUG - 2014-05-07 17:24:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:24:08 --> Final output sent to browser
DEBUG - 2014-05-07 17:24:08 --> Total execution time: 0.9411
DEBUG - 2014-05-07 17:30:32 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:32 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:32 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:32 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:32 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:32 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:32 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:32 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Session Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:30:32 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:32 --> A session cookie was not found.
DEBUG - 2014-05-07 17:30:32 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Session routines successfully run
DEBUG - 2014-05-07 17:30:32 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:32 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:32 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:32 --> Session Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:30:32 --> A session cookie was not found.
DEBUG - 2014-05-07 17:30:32 --> Session routines successfully run
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Session Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:30:32 --> A session cookie was not found.
DEBUG - 2014-05-07 17:30:32 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:32 --> Total execution time: 0.0180
DEBUG - 2014-05-07 17:30:32 --> Session routines successfully run
DEBUG - 2014-05-07 17:30:32 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:30:32 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:32 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:32 --> Total execution time: 0.0370
DEBUG - 2014-05-07 17:30:34 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:34 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:34 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:34 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:34 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:34 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:34 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:34 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:34 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:34 --> Session Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Session Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:34 --> A session cookie was not found.
DEBUG - 2014-05-07 17:30:34 --> Session routines successfully run
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:30:34 --> A session cookie was not found.
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:30:34 --> Session routines successfully run
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:34 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:34 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Total execution time: 0.0160
DEBUG - 2014-05-07 17:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:34 --> Session Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:30:34 --> A session cookie was not found.
DEBUG - 2014-05-07 17:30:34 --> Session routines successfully run
DEBUG - 2014-05-07 17:30:34 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:30:34 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:34 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:34 --> Total execution time: 0.1420
DEBUG - 2014-05-07 17:30:43 --> Config Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:30:43 --> URI Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Router Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Output Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Security Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Input Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:30:43 --> Language Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Loader Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Controller Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:30:43 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:44 --> Model Class Initialized
DEBUG - 2014-05-07 17:30:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:30:44 --> Final output sent to browser
DEBUG - 2014-05-07 17:30:44 --> Total execution time: 1.0301
DEBUG - 2014-05-07 17:31:03 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:03 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:03 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:03 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:03 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:03 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:03 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:03 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Session Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:31:03 --> A session cookie was not found.
DEBUG - 2014-05-07 17:31:03 --> Session routines successfully run
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:03 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:03 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:03 --> Session Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:31:03 --> A session cookie was not found.
DEBUG - 2014-05-07 17:31:03 --> Session routines successfully run
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:03 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:03 --> Total execution time: 0.0200
DEBUG - 2014-05-07 17:31:03 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:03 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:03 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:03 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:03 --> Session Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:31:03 --> A session cookie was not found.
DEBUG - 2014-05-07 17:31:03 --> Session routines successfully run
DEBUG - 2014-05-07 17:31:03 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:31:03 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:03 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:03 --> Total execution time: 0.0120
DEBUG - 2014-05-07 17:31:05 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:05 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:05 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:05 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:05 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:05 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:05 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:05 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:05 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Session Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:31:05 --> A session cookie was not found.
DEBUG - 2014-05-07 17:31:05 --> Session routines successfully run
DEBUG - 2014-05-07 17:31:05 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:05 --> Total execution time: 0.0120
DEBUG - 2014-05-07 17:31:05 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:05 --> Session Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Session Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:31:05 --> A session cookie was not found.
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:31:05 --> A session cookie was not found.
DEBUG - 2014-05-07 17:31:05 --> Session routines successfully run
DEBUG - 2014-05-07 17:31:05 --> Session routines successfully run
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:31:05 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:05 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:05 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:05 --> Total execution time: 0.0170
DEBUG - 2014-05-07 17:31:05 --> Total execution time: 0.0170
DEBUG - 2014-05-07 17:31:13 --> Config Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:31:13 --> URI Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Router Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Output Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Security Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Input Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:31:13 --> Language Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Loader Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Controller Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:31:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:31:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:14 --> Model Class Initialized
DEBUG - 2014-05-07 17:31:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:31:14 --> Final output sent to browser
DEBUG - 2014-05-07 17:31:14 --> Total execution time: 0.9751
DEBUG - 2014-05-07 17:32:25 --> Config Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Config Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Config Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:32:25 --> URI Class Initialized
DEBUG - 2014-05-07 17:32:25 --> URI Class Initialized
DEBUG - 2014-05-07 17:32:25 --> URI Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Router Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Router Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Router Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Output Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Output Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Output Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Security Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Security Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Security Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Input Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Input Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Input Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:32:25 --> Language Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Language Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Language Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Loader Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Controller Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Loader Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Controller Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:32:25 --> Loader Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:32:25 --> Controller Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:25 --> Session Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:32:25 --> A session cookie was not found.
DEBUG - 2014-05-07 17:32:25 --> Session routines successfully run
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:25 --> Final output sent to browser
DEBUG - 2014-05-07 17:32:25 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:32:25 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:25 --> Session Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:32:25 --> A session cookie was not found.
DEBUG - 2014-05-07 17:32:25 --> Session routines successfully run
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:25 --> Session Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:32:25 --> Final output sent to browser
DEBUG - 2014-05-07 17:32:25 --> A session cookie was not found.
DEBUG - 2014-05-07 17:32:25 --> Total execution time: 0.0260
DEBUG - 2014-05-07 17:32:25 --> Session routines successfully run
DEBUG - 2014-05-07 17:32:25 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:32:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:25 --> Final output sent to browser
DEBUG - 2014-05-07 17:32:25 --> Total execution time: 0.0280
DEBUG - 2014-05-07 17:32:26 --> Config Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Config Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Config Class Initialized
DEBUG - 2014-05-07 17:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:32:26 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:32:26 --> URI Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:32:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:32:26 --> Router Class Initialized
DEBUG - 2014-05-07 17:32:26 --> URI Class Initialized
DEBUG - 2014-05-07 17:32:26 --> URI Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Router Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Router Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Output Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Security Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Output Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Output Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Input Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Security Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Security Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Input Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:32:26 --> Input Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Language Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:32:26 --> Language Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Language Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Loader Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Loader Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Loader Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Controller Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Controller Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Controller Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:26 --> Session Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> A session cookie was not found.
DEBUG - 2014-05-07 17:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:26 --> Session routines successfully run
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:32:26 --> Session Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:32:26 --> A session cookie was not found.
DEBUG - 2014-05-07 17:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:26 --> Session routines successfully run
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:32:26 --> Final output sent to browser
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:26 --> Final output sent to browser
DEBUG - 2014-05-07 17:32:26 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:26 --> Session Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:32:26 --> A session cookie was not found.
DEBUG - 2014-05-07 17:32:26 --> Session routines successfully run
DEBUG - 2014-05-07 17:32:26 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:32:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:32:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:32:26 --> Final output sent to browser
DEBUG - 2014-05-07 17:32:26 --> Total execution time: 0.0210
DEBUG - 2014-05-07 17:33:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:33:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:33:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:33:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Session Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:33:49 --> A session cookie was not found.
DEBUG - 2014-05-07 17:33:49 --> Session Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Session routines successfully run
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:33:49 --> A session cookie was not found.
DEBUG - 2014-05-07 17:33:49 --> Session routines successfully run
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:33:49 --> Final output sent to browser
DEBUG - 2014-05-07 17:33:49 --> Total execution time: 0.0170
DEBUG - 2014-05-07 17:33:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Final output sent to browser
DEBUG - 2014-05-07 17:33:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Total execution time: 0.0160
DEBUG - 2014-05-07 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:33:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:33:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:33:49 --> Session Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:33:49 --> A session cookie was not found.
DEBUG - 2014-05-07 17:33:49 --> Session routines successfully run
DEBUG - 2014-05-07 17:33:49 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:33:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:33:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:33:49 --> Final output sent to browser
DEBUG - 2014-05-07 17:33:49 --> Total execution time: 0.0120
DEBUG - 2014-05-07 17:35:54 --> Config Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Config Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Config Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:35:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:35:54 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:35:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:35:54 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:35:54 --> URI Class Initialized
DEBUG - 2014-05-07 17:35:54 --> URI Class Initialized
DEBUG - 2014-05-07 17:35:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:35:54 --> URI Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Router Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Router Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Output Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Output Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Security Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Security Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Input Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Input Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:35:54 --> Language Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Language Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Loader Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Loader Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Controller Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Controller Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Router Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:35:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:35:54 --> Session Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Session Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:35:54 --> A session cookie was not found.
DEBUG - 2014-05-07 17:35:54 --> A session cookie was not found.
DEBUG - 2014-05-07 17:35:54 --> Session routines successfully run
DEBUG - 2014-05-07 17:35:54 --> Session routines successfully run
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:35:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:35:54 --> Output Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Security Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Input Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:35:54 --> Final output sent to browser
DEBUG - 2014-05-07 17:35:54 --> Final output sent to browser
DEBUG - 2014-05-07 17:35:54 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:35:54 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:35:54 --> Language Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Loader Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Controller Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:35:54 --> Session Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:35:54 --> A session cookie was not found.
DEBUG - 2014-05-07 17:35:54 --> Session routines successfully run
DEBUG - 2014-05-07 17:35:54 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:35:54 --> Model Class Initialized
DEBUG - 2014-05-07 17:35:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:35:54 --> Final output sent to browser
DEBUG - 2014-05-07 17:35:54 --> Total execution time: 0.0340
DEBUG - 2014-05-07 17:37:13 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:13 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:13 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:13 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:13 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:13 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:13 --> Session Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Session Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:37:13 --> A session cookie was not found.
DEBUG - 2014-05-07 17:37:13 --> A session cookie was not found.
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Session routines successfully run
DEBUG - 2014-05-07 17:37:13 --> Session routines successfully run
DEBUG - 2014-05-07 17:37:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:37:13 --> Session Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:37:13 --> A session cookie was not found.
DEBUG - 2014-05-07 17:37:13 --> Session routines successfully run
DEBUG - 2014-05-07 17:37:13 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:13 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:37:13 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:37:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:13 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:13 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:13 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:37:13 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:13 --> Total execution time: 0.0160
DEBUG - 2014-05-07 17:37:17 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:17 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:17 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:17 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:17 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:17 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:17 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:17 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:17 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:17 --> Session Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:37:17 --> A session cookie was not found.
DEBUG - 2014-05-07 17:37:17 --> Session routines successfully run
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:17 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:17 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:17 --> Session Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:37:17 --> A session cookie was not found.
DEBUG - 2014-05-07 17:37:17 --> Session routines successfully run
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:17 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:17 --> Total execution time: 0.0210
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:17 --> Session Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:37:17 --> A session cookie was not found.
DEBUG - 2014-05-07 17:37:17 --> Session routines successfully run
DEBUG - 2014-05-07 17:37:17 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:37:17 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:17 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:17 --> Total execution time: 0.0310
DEBUG - 2014-05-07 17:37:26 --> Config Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:37:26 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:37:26 --> URI Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Router Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Output Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Security Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Input Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:37:26 --> Language Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Loader Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Controller Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:37:26 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:37:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:27 --> Model Class Initialized
DEBUG - 2014-05-07 17:37:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:37:27 --> Final output sent to browser
DEBUG - 2014-05-07 17:37:27 --> Total execution time: 1.1211
DEBUG - 2014-05-07 17:39:48 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:48 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:48 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:48 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:48 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:48 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:48 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:48 --> Session Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:48 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:39:48 --> A session cookie was not found.
DEBUG - 2014-05-07 17:39:48 --> Session Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Session routines successfully run
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:39:48 --> A session cookie was not found.
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:39:48 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Session routines successfully run
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:48 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Final output sent to browser
DEBUG - 2014-05-07 17:39:48 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:39:48 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Final output sent to browser
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:48 --> Total execution time: 0.0160
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:48 --> Session Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:39:48 --> A session cookie was not found.
DEBUG - 2014-05-07 17:39:48 --> Session routines successfully run
DEBUG - 2014-05-07 17:39:48 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:39:48 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:48 --> Final output sent to browser
DEBUG - 2014-05-07 17:39:48 --> Total execution time: 0.0120
DEBUG - 2014-05-07 17:39:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:49 --> Session Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:39:49 --> A session cookie was not found.
DEBUG - 2014-05-07 17:39:49 --> Session routines successfully run
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:39:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Final output sent to browser
DEBUG - 2014-05-07 17:39:49 --> Total execution time: 0.0280
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:49 --> Session Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:39:49 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:49 --> A session cookie was not found.
DEBUG - 2014-05-07 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:49 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:49 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Session routines successfully run
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:49 --> Final output sent to browser
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Total execution time: 0.0380
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:49 --> Session Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:39:49 --> A session cookie was not found.
DEBUG - 2014-05-07 17:39:49 --> Session routines successfully run
DEBUG - 2014-05-07 17:39:49 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:39:49 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:39:49 --> Final output sent to browser
DEBUG - 2014-05-07 17:39:49 --> Total execution time: 0.0370
DEBUG - 2014-05-07 17:39:58 --> Config Class Initialized
DEBUG - 2014-05-07 17:39:58 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:39:59 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:39:59 --> URI Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Router Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Output Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Security Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Input Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:39:59 --> Language Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Loader Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Controller Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:39:59 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:39:59 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Model Class Initialized
DEBUG - 2014-05-07 17:39:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:40:00 --> Model Class Initialized
DEBUG - 2014-05-07 17:40:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:40:00 --> Final output sent to browser
DEBUG - 2014-05-07 17:40:00 --> Total execution time: 1.2701
DEBUG - 2014-05-07 17:42:16 --> Config Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Config Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Config Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:42:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:42:16 --> URI Class Initialized
DEBUG - 2014-05-07 17:42:16 --> URI Class Initialized
DEBUG - 2014-05-07 17:42:16 --> URI Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Router Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Router Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Router Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Output Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Output Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Output Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Security Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Security Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Security Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Input Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Input Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Input Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:42:16 --> Language Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Language Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Language Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Loader Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Loader Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Loader Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Controller Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Controller Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Controller Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:42:16 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Session Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:42:16 --> A session cookie was not found.
DEBUG - 2014-05-07 17:42:16 --> Session routines successfully run
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:42:16 --> Session Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:42:16 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:42:16 --> A session cookie was not found.
DEBUG - 2014-05-07 17:42:16 --> Session Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Session routines successfully run
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:42:16 --> A session cookie was not found.
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Session routines successfully run
DEBUG - 2014-05-07 17:42:16 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:42:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:42:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:42:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:42:16 --> Total execution time: 0.0190
DEBUG - 2014-05-07 17:42:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:42:16 --> Total execution time: 0.0200
DEBUG - 2014-05-07 17:51:01 --> Config Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Config Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Config Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:51:01 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:51:01 --> URI Class Initialized
DEBUG - 2014-05-07 17:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:51:01 --> Router Class Initialized
DEBUG - 2014-05-07 17:51:01 --> URI Class Initialized
DEBUG - 2014-05-07 17:51:01 --> URI Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Router Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Router Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Output Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Output Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Output Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Security Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Security Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Security Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Input Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Input Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Input Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:51:01 --> Language Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Language Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Language Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Loader Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Loader Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Loader Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Controller Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Controller Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Controller Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Session Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Session Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:51:01 --> A session cookie was not found.
DEBUG - 2014-05-07 17:51:01 --> Session Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Session routines successfully run
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:51:01 --> A session cookie was not found.
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:51:01 --> Session routines successfully run
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:51:01 --> A session cookie was not found.
DEBUG - 2014-05-07 17:51:01 --> Final output sent to browser
DEBUG - 2014-05-07 17:51:01 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:01 --> Session routines successfully run
DEBUG - 2014-05-07 17:51:01 --> Final output sent to browser
DEBUG - 2014-05-07 17:51:01 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:51:01 --> Total execution time: 0.0160
DEBUG - 2014-05-07 17:51:01 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:01 --> Final output sent to browser
DEBUG - 2014-05-07 17:51:01 --> Total execution time: 0.0170
DEBUG - 2014-05-07 17:51:15 --> Config Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:51:15 --> URI Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Router Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Output Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Security Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Input Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:51:15 --> Language Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Loader Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Controller Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:51:15 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:51:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:51:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:51:16 --> Total execution time: 1.0971
DEBUG - 2014-05-07 17:52:16 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:16 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:16 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:16 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:16 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:16 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:16 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:16 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Session Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:52:16 --> A session cookie was not found.
DEBUG - 2014-05-07 17:52:16 --> Session routines successfully run
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:16 --> Total execution time: 0.0220
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:16 --> Session Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:52:16 --> A session cookie was not found.
DEBUG - 2014-05-07 17:52:16 --> Session routines successfully run
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:16 --> Total execution time: 0.0290
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:16 --> Session Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:52:16 --> A session cookie was not found.
DEBUG - 2014-05-07 17:52:16 --> Session routines successfully run
DEBUG - 2014-05-07 17:52:16 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:52:16 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:16 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:16 --> Total execution time: 0.0340
DEBUG - 2014-05-07 17:52:19 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:19 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:19 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:19 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:19 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:19 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:19 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:19 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:19 --> Session Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Session Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:52:19 --> A session cookie was not found.
DEBUG - 2014-05-07 17:52:19 --> A session cookie was not found.
DEBUG - 2014-05-07 17:52:19 --> Session routines successfully run
DEBUG - 2014-05-07 17:52:19 --> Session routines successfully run
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:19 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:19 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:19 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:52:19 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:19 --> Session Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:52:19 --> A session cookie was not found.
DEBUG - 2014-05-07 17:52:19 --> Session routines successfully run
DEBUG - 2014-05-07 17:52:19 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:52:19 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:19 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:19 --> Total execution time: 0.0380
DEBUG - 2014-05-07 17:52:25 --> Config Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:52:25 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:52:25 --> URI Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Router Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Output Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Security Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Input Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:52:25 --> Language Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Loader Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Controller Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:52:25 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:52:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:26 --> Model Class Initialized
DEBUG - 2014-05-07 17:52:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:52:26 --> Final output sent to browser
DEBUG - 2014-05-07 17:52:26 --> Total execution time: 1.0011
DEBUG - 2014-05-07 17:53:55 --> Config Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Config Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:53:55 --> URI Class Initialized
DEBUG - 2014-05-07 17:53:55 --> URI Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Router Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Router Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Output Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Output Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Security Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Security Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Input Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Input Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:53:55 --> Language Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Language Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Loader Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Loader Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Controller Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Controller Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:55 --> Config Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Session Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:53:55 --> A session cookie was not found.
DEBUG - 2014-05-07 17:53:55 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Session routines successfully run
DEBUG - 2014-05-07 17:53:55 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:53:55 --> URI Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Final output sent to browser
DEBUG - 2014-05-07 17:53:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:55 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:53:55 --> Router Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Output Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Security Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Input Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:53:55 --> Language Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Loader Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Controller Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:55 --> Session Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:53:55 --> A session cookie was not found.
DEBUG - 2014-05-07 17:53:55 --> Session routines successfully run
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:55 --> Session Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:53:55 --> Final output sent to browser
DEBUG - 2014-05-07 17:53:55 --> A session cookie was not found.
DEBUG - 2014-05-07 17:53:55 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:53:55 --> Session routines successfully run
DEBUG - 2014-05-07 17:53:55 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:53:55 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:55 --> Final output sent to browser
DEBUG - 2014-05-07 17:53:55 --> Total execution time: 0.0290
DEBUG - 2014-05-07 17:53:57 --> Config Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Config Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Config Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:53:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:53:57 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:53:57 --> URI Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:53:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:53:57 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:53:57 --> Router Class Initialized
DEBUG - 2014-05-07 17:53:57 --> URI Class Initialized
DEBUG - 2014-05-07 17:53:57 --> URI Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Router Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Router Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Output Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Security Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Output Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Output Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Input Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Security Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:53:57 --> Security Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Input Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Language Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Input Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:53:57 --> Language Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Loader Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Language Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Controller Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Loader Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:53:57 --> Loader Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Controller Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Controller Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:57 --> Session Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:53:57 --> A session cookie was not found.
DEBUG - 2014-05-07 17:53:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:57 --> Session routines successfully run
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Session Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:53:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> A session cookie was not found.
DEBUG - 2014-05-07 17:53:57 --> Session Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:57 --> Session routines successfully run
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:53:57 --> A session cookie was not found.
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:53:57 --> Session routines successfully run
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Final output sent to browser
DEBUG - 2014-05-07 17:53:57 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:53:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:57 --> Total execution time: 0.0150
DEBUG - 2014-05-07 17:53:57 --> Model Class Initialized
DEBUG - 2014-05-07 17:53:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:53:57 --> Final output sent to browser
DEBUG - 2014-05-07 17:53:57 --> Total execution time: 0.0160
DEBUG - 2014-05-07 17:53:57 --> Final output sent to browser
DEBUG - 2014-05-07 17:53:57 --> Total execution time: 0.0180
DEBUG - 2014-05-07 17:54:47 --> Config Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Config Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Config Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:54:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:54:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:54:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:54:47 --> URI Class Initialized
DEBUG - 2014-05-07 17:54:47 --> URI Class Initialized
DEBUG - 2014-05-07 17:54:47 --> URI Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Router Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Router Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Router Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Output Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Output Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Output Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Security Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Security Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Security Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Input Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Input Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:54:47 --> Input Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:54:47 --> Language Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Language Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Language Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Loader Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Loader Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Loader Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Controller Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Controller Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Controller Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Session Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> A session cookie was not found.
DEBUG - 2014-05-07 17:54:47 --> Session Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:54:47 --> Session routines successfully run
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:54:47 --> A session cookie was not found.
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:54:47 --> Session Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Session routines successfully run
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:54:47 --> A session cookie was not found.
DEBUG - 2014-05-07 17:54:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Session routines successfully run
DEBUG - 2014-05-07 17:54:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:54:47 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:54:47 --> Final output sent to browser
DEBUG - 2014-05-07 17:54:47 --> Model Class Initialized
DEBUG - 2014-05-07 17:54:47 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:54:47 --> Final output sent to browser
DEBUG - 2014-05-07 17:54:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:54:47 --> Total execution time: 0.0130
DEBUG - 2014-05-07 17:54:47 --> Final output sent to browser
DEBUG - 2014-05-07 17:54:47 --> Total execution time: 0.0140
DEBUG - 2014-05-07 17:55:04 --> Config Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:55:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:55:04 --> Config Class Initialized
DEBUG - 2014-05-07 17:55:04 --> URI Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Router Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:55:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:55:04 --> Output Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Security Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Input Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:55:04 --> Language Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Loader Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Controller Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:55:04 --> URI Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:55:04 --> Session Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:55:04 --> A session cookie was not found.
DEBUG - 2014-05-07 17:55:04 --> Session routines successfully run
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:55:04 --> Router Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Final output sent to browser
DEBUG - 2014-05-07 17:55:04 --> Total execution time: 0.0120
DEBUG - 2014-05-07 17:55:04 --> Config Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Output Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Security Class Initialized
DEBUG - 2014-05-07 17:55:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:55:04 --> Input Class Initialized
DEBUG - 2014-05-07 17:55:04 --> URI Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:55:04 --> Router Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Language Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Loader Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Output Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Controller Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Security Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Input Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:55:04 --> Language Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Loader Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Controller Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:55:04 --> Session Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:55:04 --> A session cookie was not found.
DEBUG - 2014-05-07 17:55:04 --> Session routines successfully run
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:55:04 --> Final output sent to browser
DEBUG - 2014-05-07 17:55:04 --> Total execution time: 0.0120
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:55:04 --> Session Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: string_helper
DEBUG - 2014-05-07 17:55:04 --> A session cookie was not found.
DEBUG - 2014-05-07 17:55:04 --> Session routines successfully run
DEBUG - 2014-05-07 17:55:04 --> Helper loaded: url_helper
DEBUG - 2014-05-07 17:55:04 --> Model Class Initialized
DEBUG - 2014-05-07 17:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:55:04 --> Final output sent to browser
DEBUG - 2014-05-07 17:55:04 --> Total execution time: 0.0340
DEBUG - 2014-05-07 17:56:11 --> Config Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Hooks Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Utf8 Class Initialized
DEBUG - 2014-05-07 17:56:11 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 17:56:11 --> URI Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Router Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Output Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Security Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Input Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 17:56:11 --> Language Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Loader Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Controller Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 17:56:11 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 17:56:11 --> Model Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Model Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Database Driver Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Model Class Initialized
DEBUG - 2014-05-07 17:56:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:56:12 --> Model Class Initialized
DEBUG - 2014-05-07 17:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 17:56:12 --> Final output sent to browser
DEBUG - 2014-05-07 17:56:12 --> Total execution time: 0.9621
DEBUG - 2014-05-07 18:03:34 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:34 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:34 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:34 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:34 --> Session Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:34 --> A session cookie was not found.
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Session routines successfully run
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:34 --> Session Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:03:34 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:34 --> A session cookie was not found.
DEBUG - 2014-05-07 18:03:34 --> Session routines successfully run
DEBUG - 2014-05-07 18:03:34 --> Total execution time: 0.0150
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:34 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:34 --> Total execution time: 0.0170
DEBUG - 2014-05-07 18:03:34 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:34 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:34 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:34 --> Session Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:03:34 --> A session cookie was not found.
DEBUG - 2014-05-07 18:03:34 --> Session routines successfully run
DEBUG - 2014-05-07 18:03:34 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:03:34 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:34 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:34 --> Total execution time: 0.0100
DEBUG - 2014-05-07 18:03:36 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:36 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:36 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:36 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:36 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:36 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:36 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:36 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Session Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:03:36 --> A session cookie was not found.
DEBUG - 2014-05-07 18:03:36 --> Session routines successfully run
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:36 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:36 --> Total execution time: 0.0140
DEBUG - 2014-05-07 18:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:36 --> Session Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:36 --> A session cookie was not found.
DEBUG - 2014-05-07 18:03:36 --> Session Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Session routines successfully run
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:03:36 --> A session cookie was not found.
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Session routines successfully run
DEBUG - 2014-05-07 18:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:36 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:03:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:36 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:36 --> Total execution time: 0.0250
DEBUG - 2014-05-07 18:03:36 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:36 --> Total execution time: 0.0310
DEBUG - 2014-05-07 18:03:43 --> Config Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:03:43 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:03:43 --> URI Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Router Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Output Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Security Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Input Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:03:43 --> Language Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Loader Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Controller Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:03:43 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:03:43 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:46 --> Model Class Initialized
DEBUG - 2014-05-07 18:03:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:03:46 --> Final output sent to browser
DEBUG - 2014-05-07 18:03:46 --> Total execution time: 3.9222
DEBUG - 2014-05-07 18:10:51 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:51 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:51 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:51 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:51 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:51 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:51 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Session Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:51 --> A session cookie was not found.
DEBUG - 2014-05-07 18:10:51 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Session routines successfully run
DEBUG - 2014-05-07 18:10:51 --> Session Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:10:51 --> A session cookie was not found.
DEBUG - 2014-05-07 18:10:51 --> Session Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:10:51 --> A session cookie was not found.
DEBUG - 2014-05-07 18:10:51 --> Final output sent to browser
DEBUG - 2014-05-07 18:10:51 --> Session routines successfully run
DEBUG - 2014-05-07 18:10:51 --> Total execution time: 0.0140
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:51 --> Session routines successfully run
DEBUG - 2014-05-07 18:10:51 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:10:51 --> Final output sent to browser
DEBUG - 2014-05-07 18:10:51 --> Total execution time: 0.0170
DEBUG - 2014-05-07 18:10:51 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:51 --> Final output sent to browser
DEBUG - 2014-05-07 18:10:51 --> Total execution time: 0.0180
DEBUG - 2014-05-07 18:10:53 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:53 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:53 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:53 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:53 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:53 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:53 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:53 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:53 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:53 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:53 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:53 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:53 --> Session Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:10:53 --> A session cookie was not found.
DEBUG - 2014-05-07 18:10:53 --> Session routines successfully run
DEBUG - 2014-05-07 18:10:53 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:53 --> Final output sent to browser
DEBUG - 2014-05-07 18:10:53 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Total execution time: 0.0140
DEBUG - 2014-05-07 18:10:53 --> Session Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:10:53 --> A session cookie was not found.
DEBUG - 2014-05-07 18:10:53 --> Session routines successfully run
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:53 --> Session Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:10:53 --> A session cookie was not found.
DEBUG - 2014-05-07 18:10:53 --> Session routines successfully run
DEBUG - 2014-05-07 18:10:53 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:10:53 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:10:53 --> Final output sent to browser
DEBUG - 2014-05-07 18:10:53 --> Total execution time: 0.0210
DEBUG - 2014-05-07 18:10:53 --> Final output sent to browser
DEBUG - 2014-05-07 18:10:53 --> Total execution time: 0.0220
DEBUG - 2014-05-07 18:10:59 --> Config Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:10:59 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:10:59 --> URI Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Router Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Output Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Security Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Input Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:10:59 --> Language Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Loader Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Controller Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:10:59 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:10:59 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Model Class Initialized
DEBUG - 2014-05-07 18:10:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:11:00 --> Model Class Initialized
DEBUG - 2014-05-07 18:11:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:11:00 --> Final output sent to browser
DEBUG - 2014-05-07 18:11:00 --> Total execution time: 0.9851
DEBUG - 2014-05-07 18:15:27 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:27 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:27 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:27 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:27 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Session Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:15:27 --> Session Class Initialized
DEBUG - 2014-05-07 18:15:27 --> A session cookie was not found.
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:15:27 --> Session routines successfully run
DEBUG - 2014-05-07 18:15:27 --> A session cookie was not found.
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:15:27 --> Session routines successfully run
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:15:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Session Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:15:27 --> A session cookie was not found.
DEBUG - 2014-05-07 18:15:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:27 --> Session routines successfully run
DEBUG - 2014-05-07 18:15:27 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:27 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:15:27 --> Total execution time: 0.0140
DEBUG - 2014-05-07 18:15:27 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:27 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:27 --> Total execution time: 0.0160
DEBUG - 2014-05-07 18:15:27 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:27 --> Total execution time: 0.0180
DEBUG - 2014-05-07 18:15:29 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:29 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:29 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:29 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:29 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:29 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:29 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:29 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:29 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:29 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:29 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:29 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Session Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> A session cookie was not found.
DEBUG - 2014-05-07 18:15:29 --> Session Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Session routines successfully run
DEBUG - 2014-05-07 18:15:29 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:15:29 --> A session cookie was not found.
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Session routines successfully run
DEBUG - 2014-05-07 18:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:29 --> Total execution time: 0.0240
DEBUG - 2014-05-07 18:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:29 --> Total execution time: 0.0260
DEBUG - 2014-05-07 18:15:29 --> Session Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: string_helper
DEBUG - 2014-05-07 18:15:29 --> A session cookie was not found.
DEBUG - 2014-05-07 18:15:29 --> Session routines successfully run
DEBUG - 2014-05-07 18:15:29 --> Helper loaded: url_helper
DEBUG - 2014-05-07 18:15:29 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:29 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:29 --> Total execution time: 0.0290
DEBUG - 2014-05-07 18:15:36 --> Config Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:15:36 --> URI Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Router Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Output Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Security Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Input Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:15:36 --> Language Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Loader Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Controller Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:15:36 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:15:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:37 --> Model Class Initialized
DEBUG - 2014-05-07 18:15:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:15:37 --> Final output sent to browser
DEBUG - 2014-05-07 18:15:37 --> Total execution time: 1.2641
DEBUG - 2014-05-07 18:41:54 --> Config Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Hooks Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Utf8 Class Initialized
DEBUG - 2014-05-07 18:41:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-07 18:41:54 --> URI Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Router Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Output Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Security Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Input Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-07 18:41:54 --> Language Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Loader Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Controller Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-07 18:41:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-07 18:41:54 --> Model Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Model Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Database Driver Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Model Class Initialized
DEBUG - 2014-05-07 18:41:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-07 18:41:55 --> Final output sent to browser
DEBUG - 2014-05-07 18:41:55 --> Total execution time: 1.2181
