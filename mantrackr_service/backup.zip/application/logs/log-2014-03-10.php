<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-10 17:12:20 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-10 17:12:20 --> Config Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:12:20 --> URI Class Initialized
DEBUG - 2014-03-10 17:12:20 --> URI Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Config Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:12:20 --> URI Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Router Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Router Class Initialized
DEBUG - 2014-03-10 17:12:20 --> Router Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Output Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Output Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Output Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Security Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Security Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Security Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Input Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Input Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Input Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:12:21 --> Language Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Language Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Language Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Loader Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Loader Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Loader Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Controller Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Controller Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Controller Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:12:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:12:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:12:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:12:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:12:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:12:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:12:21 --> Database Driver Class Initialized
ERROR - 2014-03-10 17:12:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:22 --> Unable to connect to the database
ERROR - 2014-03-10 17:12:22 --> Unable to connect to the database
DEBUG - 2014-03-10 17:12:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-10 17:12:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-03-10 17:12:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:22 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:22 --> Unable to connect to the database
DEBUG - 2014-03-10 17:12:22 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-10 17:12:28 --> Config Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Config Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Config Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:12:28 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:12:28 --> URI Class Initialized
DEBUG - 2014-03-10 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:12:28 --> Router Class Initialized
DEBUG - 2014-03-10 17:12:28 --> URI Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Router Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Output Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Security Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Input Class Initialized
DEBUG - 2014-03-10 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:12:28 --> URI Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Output Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:12:28 --> Security Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Language Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Input Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:12:28 --> Language Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Loader Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Controller Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Loader Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Controller Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:12:28 --> Router Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:12:28 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:12:28 --> Output Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:12:28 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Security Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Input Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:12:28 --> Language Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Loader Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Controller Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:12:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:12:28 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Model Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:12:28 --> Database Driver Class Initialized
ERROR - 2014-03-10 17:12:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:29 --> Unable to connect to the database
DEBUG - 2014-03-10 17:12:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-03-10 17:12:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:29 --> Unable to connect to the database
DEBUG - 2014-03-10 17:12:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-03-10 17:12:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:12:29 --> Unable to connect to the database
DEBUG - 2014-03-10 17:12:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-10 17:13:00 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:00 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:00 --> No URI present. Default controller set.
DEBUG - 2014-03-10 17:13:00 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:00 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:00 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:01 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-03-10 17:13:01 --> Final output sent to browser
DEBUG - 2014-03-10 17:13:01 --> Total execution time: 0.0840
DEBUG - 2014-03-10 17:13:16 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:16 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:16 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:16 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:16 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:16 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:13:16 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:13:16 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:16 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:13:16 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:13:16 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:13:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:13:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:16 --> Database Driver Class Initialized
ERROR - 2014-03-10 17:13:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:13:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:13:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:13:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:13:17 --> Unable to connect to the database
ERROR - 2014-03-10 17:13:17 --> Unable to connect to the database
DEBUG - 2014-03-10 17:13:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-10 17:13:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2014-03-10 17:13:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:13:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-10 17:13:17 --> Unable to connect to the database
DEBUG - 2014-03-10 17:13:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-03-10 17:13:19 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:19 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:19 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:19 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:13:19 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:13:19 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:19 --> Config Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:13:19 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:19 --> URI Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:13:19 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:13:19 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Router Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Output Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Security Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Input Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:13:19 --> Language Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Loader Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Controller Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:13:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:13:19 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:19 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:13:20 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:13:20 --> Session Class Initialized
DEBUG - 2014-03-10 17:13:20 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:13:20 --> Session Class Initialized
DEBUG - 2014-03-10 17:13:20 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:13:20 --> Session Class Initialized
DEBUG - 2014-03-10 17:13:21 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:13:21 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:13:21 --> A session cookie was not found.
DEBUG - 2014-03-10 17:13:21 --> Session routines successfully run
DEBUG - 2014-03-10 17:13:21 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:13:21 --> A session cookie was not found.
DEBUG - 2014-03-10 17:13:21 --> Session routines successfully run
DEBUG - 2014-03-10 17:13:21 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:13:21 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:13:21 --> A session cookie was not found.
DEBUG - 2014-03-10 17:13:21 --> Session routines successfully run
DEBUG - 2014-03-10 17:13:21 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:13:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:21 --> Model Class Initialized
DEBUG - 2014-03-10 17:13:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:13:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:13:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:13:21 --> Final output sent to browser
DEBUG - 2014-03-10 17:13:21 --> Final output sent to browser
DEBUG - 2014-03-10 17:13:21 --> Total execution time: 1.8691
DEBUG - 2014-03-10 17:13:21 --> Total execution time: 1.8641
DEBUG - 2014-03-10 17:13:21 --> Final output sent to browser
DEBUG - 2014-03-10 17:13:21 --> Total execution time: 1.9011
DEBUG - 2014-03-10 17:15:01 --> Config Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:15:01 --> URI Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Router Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Output Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Security Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Input Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Config Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:15:01 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Language Class Initialized
DEBUG - 2014-03-10 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:15:01 --> URI Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Loader Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Router Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Controller Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:15:01 --> Output Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:15:01 --> Security Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Input Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:15:01 --> Config Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Language Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Loader Class Initialized
DEBUG - 2014-03-10 17:15:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Controller Class Initialized
DEBUG - 2014-03-10 17:15:01 --> URI Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:15:01 --> Router Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:15:01 --> Session Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Output Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:15:01 --> A session cookie was not found.
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Security Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Session routines successfully run
DEBUG - 2014-03-10 17:15:01 --> Input Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:15:01 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:15:01 --> Language Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:01 --> Final output sent to browser
DEBUG - 2014-03-10 17:15:01 --> Loader Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Total execution time: 0.0200
DEBUG - 2014-03-10 17:15:01 --> Controller Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Session Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:15:01 --> A session cookie was not found.
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:15:01 --> Session routines successfully run
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:15:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:01 --> Final output sent to browser
DEBUG - 2014-03-10 17:15:01 --> Total execution time: 0.0160
DEBUG - 2014-03-10 17:15:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:15:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:15:02 --> A session cookie was not found.
DEBUG - 2014-03-10 17:15:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:15:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:15:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:15:02 --> Total execution time: 0.0230
DEBUG - 2014-03-10 17:15:40 --> Config Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Config Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Config Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:15:40 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:15:40 --> URI Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:15:40 --> URI Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Router Class Initialized
DEBUG - 2014-03-10 17:15:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:15:40 --> Router Class Initialized
DEBUG - 2014-03-10 17:15:40 --> URI Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Router Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Output Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Output Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Output Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Security Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Security Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Security Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Input Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Input Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Input Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:15:40 --> Language Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Language Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:15:40 --> Loader Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Loader Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Language Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Controller Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Controller Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Loader Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:15:40 --> Controller Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:40 --> Session Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Session Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Session Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:15:40 --> Session routines successfully run
DEBUG - 2014-03-10 17:15:40 --> Session routines successfully run
DEBUG - 2014-03-10 17:15:40 --> Session routines successfully run
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:15:40 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:40 --> Model Class Initialized
DEBUG - 2014-03-10 17:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:15:40 --> Final output sent to browser
DEBUG - 2014-03-10 17:15:40 --> Final output sent to browser
DEBUG - 2014-03-10 17:15:40 --> Final output sent to browser
DEBUG - 2014-03-10 17:15:40 --> Total execution time: 0.0240
DEBUG - 2014-03-10 17:15:40 --> Total execution time: 0.0250
DEBUG - 2014-03-10 17:15:40 --> Total execution time: 0.0230
DEBUG - 2014-03-10 17:16:02 --> Config Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:16:02 --> URI Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Config Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Router Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:16:02 --> Output Class Initialized
DEBUG - 2014-03-10 17:16:02 --> URI Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Router Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Security Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Input Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Output Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:16:02 --> Security Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Language Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Input Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:16:02 --> Loader Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Language Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Controller Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Loader Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:16:02 --> Controller Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:16:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:16:02 --> Config Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:16:02 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> URI Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:02 --> Router Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:16:02 --> Total execution time: 0.0170
DEBUG - 2014-03-10 17:16:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:16:02 --> Total execution time: 0.0140
DEBUG - 2014-03-10 17:16:02 --> Output Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Security Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Input Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:16:02 --> Language Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Loader Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Controller Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:16:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:16:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:16:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:16:02 --> Total execution time: 0.0110
DEBUG - 2014-03-10 17:16:12 --> Config Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:16:12 --> URI Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Router Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Output Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Security Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Config Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Input Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:16:12 --> Language Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Loader Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Controller Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Config Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:12 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:16:12 --> URI Class Initialized
DEBUG - 2014-03-10 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:16:12 --> Router Class Initialized
DEBUG - 2014-03-10 17:16:12 --> URI Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Router Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Output Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Security Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Output Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Input Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Security Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:16:12 --> Input Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Language Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Session Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:16:12 --> Loader Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Language Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Controller Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:16:12 --> Loader Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:16:12 --> Controller Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:16:12 --> A session cookie was not found.
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Session routines successfully run
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Final output sent to browser
DEBUG - 2014-03-10 17:16:12 --> Total execution time: 0.0150
DEBUG - 2014-03-10 17:16:12 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:12 --> Session Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Session Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:16:12 --> A session cookie was not found.
DEBUG - 2014-03-10 17:16:12 --> A session cookie was not found.
DEBUG - 2014-03-10 17:16:12 --> Session routines successfully run
DEBUG - 2014-03-10 17:16:12 --> Session routines successfully run
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:16:12 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Model Class Initialized
DEBUG - 2014-03-10 17:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:16:12 --> Final output sent to browser
DEBUG - 2014-03-10 17:16:12 --> Total execution time: 0.0170
DEBUG - 2014-03-10 17:16:12 --> Final output sent to browser
DEBUG - 2014-03-10 17:16:12 --> Total execution time: 0.0140
DEBUG - 2014-03-10 17:21:02 --> Config Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:21:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:21:02 --> URI Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Router Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Output Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Security Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Input Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:21:02 --> Language Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Loader Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Controller Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:21:02 --> Config Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:21:02 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> URI Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Router Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Output Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Security Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Input Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:21:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:02 --> Language Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Loader Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Controller Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:21:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:02 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:21:02 --> Total execution time: 0.0170
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:02 --> Config Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:21:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:21:02 --> URI Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:21:02 --> Router Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:02 --> Output Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Security Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:21:02 --> Input Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Total execution time: 0.0120
DEBUG - 2014-03-10 17:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:21:02 --> Language Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Loader Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Controller Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:02 --> Session Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:21:02 --> Session routines successfully run
DEBUG - 2014-03-10 17:21:02 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:21:02 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:02 --> Final output sent to browser
DEBUG - 2014-03-10 17:21:02 --> Total execution time: 0.0110
DEBUG - 2014-03-10 17:21:09 --> Config Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:21:09 --> URI Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Config Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Router Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:21:09 --> Config Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Output Class Initialized
DEBUG - 2014-03-10 17:21:09 --> URI Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Hooks Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Router Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Utf8 Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Security Class Initialized
DEBUG - 2014-03-10 17:21:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 17:21:09 --> Input Class Initialized
DEBUG - 2014-03-10 17:21:09 --> URI Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Output Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:21:09 --> Router Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Security Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Language Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Output Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Input Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Loader Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:21:09 --> Security Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Controller Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Language Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Input Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 17:21:09 --> Loader Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:21:09 --> Controller Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Language Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Loader Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:21:09 --> Controller Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Database Driver Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:09 --> Session Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Session Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Session routines successfully run
DEBUG - 2014-03-10 17:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:21:09 --> Session routines successfully run
DEBUG - 2014-03-10 17:21:09 --> Session Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: string_helper
DEBUG - 2014-03-10 17:21:09 --> Session routines successfully run
DEBUG - 2014-03-10 17:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Helper loaded: url_helper
DEBUG - 2014-03-10 17:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:09 --> Model Class Initialized
DEBUG - 2014-03-10 17:21:09 --> Final output sent to browser
DEBUG - 2014-03-10 17:21:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 17:21:09 --> Final output sent to browser
DEBUG - 2014-03-10 17:21:09 --> Total execution time: 0.0240
DEBUG - 2014-03-10 17:21:09 --> Total execution time: 0.0220
DEBUG - 2014-03-10 17:21:09 --> Final output sent to browser
DEBUG - 2014-03-10 17:21:09 --> Total execution time: 0.0210
DEBUG - 2014-03-10 18:11:44 --> Config Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Config Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:11:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:11:44 --> Config Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:11:44 --> URI Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:11:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:11:44 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Router Class Initialized
DEBUG - 2014-03-10 18:11:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:11:44 --> URI Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Router Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Output Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Output Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Security Class Initialized
DEBUG - 2014-03-10 18:11:44 --> URI Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Router Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Input Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:11:44 --> Security Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Language Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Output Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Security Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Input Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Loader Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Input Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Controller Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:11:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:11:44 --> Language Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Language Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:11:44 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Loader Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Controller Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:11:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:11:44 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Loader Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Controller Class Initialized
DEBUG - 2014-03-10 18:11:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:11:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Session Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> A session cookie was not found.
DEBUG - 2014-03-10 18:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:11:45 --> Session routines successfully run
DEBUG - 2014-03-10 18:11:45 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:11:45 --> Session Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:11:45 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:11:45 --> A session cookie was not found.
DEBUG - 2014-03-10 18:11:45 --> Final output sent to browser
DEBUG - 2014-03-10 18:11:45 --> Total execution time: 0.0140
DEBUG - 2014-03-10 18:11:45 --> Session routines successfully run
DEBUG - 2014-03-10 18:11:45 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:11:45 --> Final output sent to browser
DEBUG - 2014-03-10 18:11:45 --> Total execution time: 0.0170
DEBUG - 2014-03-10 18:11:45 --> Session Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:11:45 --> A session cookie was not found.
DEBUG - 2014-03-10 18:11:45 --> Session routines successfully run
DEBUG - 2014-03-10 18:11:45 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:11:45 --> Model Class Initialized
DEBUG - 2014-03-10 18:11:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:11:45 --> Final output sent to browser
DEBUG - 2014-03-10 18:11:45 --> Total execution time: 0.0210
DEBUG - 2014-03-10 18:12:08 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:08 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:08 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:08 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:08 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:08 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:08 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:08 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:08 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:08 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:08 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:08 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:08 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:08 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:08 --> A session cookie was not found.
DEBUG - 2014-03-10 18:12:08 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:08 --> A session cookie was not found.
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:08 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:08 --> A session cookie was not found.
DEBUG - 2014-03-10 18:12:08 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:08 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:08 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:08 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:08 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:08 --> Total execution time: 0.0180
DEBUG - 2014-03-10 18:12:08 --> Total execution time: 0.0210
DEBUG - 2014-03-10 18:12:08 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:08 --> Total execution time: 0.0200
DEBUG - 2014-03-10 18:12:41 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:41 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:41 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:41 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:41 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:41 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:41 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:41 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:41 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:41 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:41 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:41 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:41 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:41 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:41 --> Total execution time: 0.0110
DEBUG - 2014-03-10 18:12:41 --> Total execution time: 0.0140
DEBUG - 2014-03-10 18:12:41 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:41 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:41 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:41 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:41 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:41 --> Total execution time: 0.0110
DEBUG - 2014-03-10 18:12:46 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:46 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:46 --> Config Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:12:46 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:12:46 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:46 --> URI Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Router Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:46 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Output Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:46 --> Security Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Input Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:12:46 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Language Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:46 --> Loader Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:46 --> Controller Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:46 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:46 --> Session Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:46 --> Total execution time: 0.0130
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Session routines successfully run
DEBUG - 2014-03-10 18:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:12:46 --> Model Class Initialized
DEBUG - 2014-03-10 18:12:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:12:46 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:46 --> Total execution time: 0.0130
DEBUG - 2014-03-10 18:12:46 --> Final output sent to browser
DEBUG - 2014-03-10 18:12:46 --> Total execution time: 0.0120
DEBUG - 2014-03-10 18:39:09 --> Config Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Config Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Config Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:39:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:39:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:39:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:39:09 --> URI Class Initialized
DEBUG - 2014-03-10 18:39:09 --> URI Class Initialized
DEBUG - 2014-03-10 18:39:09 --> URI Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Router Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Router Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Router Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Output Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Output Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Output Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Security Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Security Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Security Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Input Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Input Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Input Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:39:09 --> Language Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Language Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Language Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Loader Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Loader Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Loader Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Controller Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Controller Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Controller Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:39:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:39:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:39:09 --> Session Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Session Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Session Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:39:09 --> Session routines successfully run
DEBUG - 2014-03-10 18:39:09 --> Session routines successfully run
DEBUG - 2014-03-10 18:39:09 --> Session routines successfully run
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:39:09 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Model Class Initialized
DEBUG - 2014-03-10 18:39:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:39:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:39:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:39:09 --> Final output sent to browser
DEBUG - 2014-03-10 18:39:09 --> Final output sent to browser
DEBUG - 2014-03-10 18:39:09 --> Final output sent to browser
DEBUG - 2014-03-10 18:39:09 --> Total execution time: 0.0240
DEBUG - 2014-03-10 18:39:09 --> Total execution time: 0.0240
DEBUG - 2014-03-10 18:39:09 --> Total execution time: 0.0240
DEBUG - 2014-03-10 18:40:23 --> Config Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:40:23 --> URI Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Router Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Output Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Security Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Input Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:40:23 --> Language Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Loader Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Controller Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:40:23 --> Session Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:40:23 --> Session routines successfully run
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:40:23 --> Final output sent to browser
DEBUG - 2014-03-10 18:40:23 --> Total execution time: 0.0200
DEBUG - 2014-03-10 18:40:23 --> Config Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:40:23 --> URI Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Router Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Output Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Security Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Input Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:40:23 --> Language Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Loader Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Controller Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:40:23 --> Session Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:40:23 --> Session routines successfully run
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:40:23 --> Final output sent to browser
DEBUG - 2014-03-10 18:40:23 --> Total execution time: 0.0180
DEBUG - 2014-03-10 18:40:23 --> Config Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:40:23 --> URI Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Router Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Output Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Security Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Input Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:40:23 --> Language Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Loader Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Controller Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:40:23 --> Session Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:40:23 --> Session routines successfully run
DEBUG - 2014-03-10 18:40:23 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:40:23 --> Model Class Initialized
DEBUG - 2014-03-10 18:40:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:40:23 --> Final output sent to browser
DEBUG - 2014-03-10 18:40:23 --> Total execution time: 0.0170
DEBUG - 2014-03-10 18:52:13 --> Config Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:52:13 --> URI Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Router Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Config Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Output Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Security Class Initialized
DEBUG - 2014-03-10 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:52:13 --> Input Class Initialized
DEBUG - 2014-03-10 18:52:13 --> URI Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Config Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:52:13 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Router Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Language Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:52:13 --> Output Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Loader Class Initialized
DEBUG - 2014-03-10 18:52:13 --> URI Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Security Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Controller Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Router Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Input Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:52:13 --> Output Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Language Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Security Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Loader Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Input Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Controller Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:52:13 --> Language Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:52:13 --> Loader Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Controller Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:52:13 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Session Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:52:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:52:13 --> Session routines successfully run
DEBUG - 2014-03-10 18:52:13 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:52:13 --> Session Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:52:13 --> Session routines successfully run
DEBUG - 2014-03-10 18:52:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:52:13 --> Session Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Final output sent to browser
DEBUG - 2014-03-10 18:52:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:52:13 --> Total execution time: 0.0240
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:52:13 --> Session routines successfully run
DEBUG - 2014-03-10 18:52:13 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:52:13 --> Final output sent to browser
DEBUG - 2014-03-10 18:52:13 --> Total execution time: 0.0210
DEBUG - 2014-03-10 18:52:13 --> Model Class Initialized
DEBUG - 2014-03-10 18:52:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:52:13 --> Final output sent to browser
DEBUG - 2014-03-10 18:52:13 --> Total execution time: 0.0220
DEBUG - 2014-03-10 18:56:16 --> Config Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:56:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:56:16 --> URI Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Router Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Output Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Security Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Input Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:56:16 --> Language Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Loader Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Controller Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:16 --> Session Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:56:16 --> Session routines successfully run
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:16 --> Final output sent to browser
DEBUG - 2014-03-10 18:56:16 --> Total execution time: 0.0200
DEBUG - 2014-03-10 18:56:16 --> Config Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Config Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:56:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:56:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:56:16 --> URI Class Initialized
DEBUG - 2014-03-10 18:56:16 --> URI Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Router Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Router Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Output Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Output Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Security Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Security Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Input Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Input Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:56:16 --> Language Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Language Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Loader Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Loader Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Controller Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Controller Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:16 --> Session Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Session Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:56:16 --> Session routines successfully run
DEBUG - 2014-03-10 18:56:16 --> Session routines successfully run
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:56:16 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:16 --> Final output sent to browser
DEBUG - 2014-03-10 18:56:16 --> Total execution time: 0.0130
DEBUG - 2014-03-10 18:56:16 --> Final output sent to browser
DEBUG - 2014-03-10 18:56:16 --> Total execution time: 0.0140
DEBUG - 2014-03-10 18:56:22 --> Config Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Config Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Config Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Hooks Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Utf8 Class Initialized
DEBUG - 2014-03-10 18:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:56:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 18:56:22 --> URI Class Initialized
DEBUG - 2014-03-10 18:56:22 --> URI Class Initialized
DEBUG - 2014-03-10 18:56:22 --> URI Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Router Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Router Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Router Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Output Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Output Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Output Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Security Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Security Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Security Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Input Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Input Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Input Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 18:56:22 --> Language Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Language Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Language Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Loader Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Loader Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Loader Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Controller Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Controller Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Controller Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Database Driver Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:22 --> Session Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Session Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Session Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: string_helper
DEBUG - 2014-03-10 18:56:22 --> Session routines successfully run
DEBUG - 2014-03-10 18:56:22 --> Session routines successfully run
DEBUG - 2014-03-10 18:56:22 --> Session routines successfully run
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:56:22 --> Helper loaded: url_helper
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Model Class Initialized
DEBUG - 2014-03-10 18:56:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 18:56:22 --> Final output sent to browser
DEBUG - 2014-03-10 18:56:22 --> Final output sent to browser
DEBUG - 2014-03-10 18:56:22 --> Total execution time: 0.0230
DEBUG - 2014-03-10 18:56:22 --> Total execution time: 0.0230
DEBUG - 2014-03-10 18:56:22 --> Final output sent to browser
DEBUG - 2014-03-10 18:56:22 --> Total execution time: 0.0230
DEBUG - 2014-03-10 19:00:53 --> Config Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:00:53 --> URI Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Router Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Output Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Security Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Config Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:00:53 --> Config Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Input Class Initialized
DEBUG - 2014-03-10 19:00:53 --> URI Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:00:53 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Router Class Initialized
DEBUG - 2014-03-10 19:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:00:53 --> URI Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Output Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Router Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Language Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Output Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Loader Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Security Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Controller Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Input Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:00:53 --> Security Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Language Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:00:53 --> Input Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Loader Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:00:53 --> Controller Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Language Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Loader Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Controller Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:53 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Session Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:00:53 --> A session cookie was not found.
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Session routines successfully run
DEBUG - 2014-03-10 19:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:00:53 --> Session Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:53 --> A session cookie was not found.
DEBUG - 2014-03-10 19:00:53 --> Session routines successfully run
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:53 --> Session Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Final output sent to browser
DEBUG - 2014-03-10 19:00:53 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:00:53 --> Final output sent to browser
DEBUG - 2014-03-10 19:00:53 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:00:53 --> A session cookie was not found.
DEBUG - 2014-03-10 19:00:53 --> Session routines successfully run
DEBUG - 2014-03-10 19:00:53 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:00:53 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:53 --> Final output sent to browser
DEBUG - 2014-03-10 19:00:53 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:00:54 --> Config Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:00:54 --> URI Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Router Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Output Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Security Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Input Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:00:54 --> Config Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Language Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Config Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Loader Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:00:54 --> Controller Class Initialized
DEBUG - 2014-03-10 19:00:54 --> URI Class Initialized
DEBUG - 2014-03-10 19:00:54 --> URI Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:00:54 --> Router Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Router Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:00:54 --> Output Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Security Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Input Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:00:54 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Language Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Output Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Loader Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Controller Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Security Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:00:54 --> Input Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:00:54 --> Language Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Loader Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Controller Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Session Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:54 --> A session cookie was not found.
DEBUG - 2014-03-10 19:00:54 --> Session routines successfully run
DEBUG - 2014-03-10 19:00:54 --> Session Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:00:54 --> A session cookie was not found.
DEBUG - 2014-03-10 19:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:54 --> Session routines successfully run
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Session Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:00:54 --> A session cookie was not found.
DEBUG - 2014-03-10 19:00:54 --> Session routines successfully run
DEBUG - 2014-03-10 19:00:54 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:00:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:00:54 --> Final output sent to browser
DEBUG - 2014-03-10 19:00:54 --> Final output sent to browser
DEBUG - 2014-03-10 19:00:54 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:00:54 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:00:54 --> Final output sent to browser
DEBUG - 2014-03-10 19:00:54 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:01:16 --> Config Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:01:16 --> URI Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Router Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Output Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Security Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Input Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:01:16 --> Config Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Language Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Loader Class Initialized
DEBUG - 2014-03-10 19:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:01:16 --> Controller Class Initialized
DEBUG - 2014-03-10 19:01:16 --> URI Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Router Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:01:16 --> Output Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Config Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Security Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Input Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:01:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:01:16 --> Language Class Initialized
DEBUG - 2014-03-10 19:01:16 --> URI Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Router Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Loader Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Controller Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:01:16 --> Output Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:01:16 --> Session Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Security Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:01:16 --> Input Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Session routines successfully run
DEBUG - 2014-03-10 19:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:01:16 --> Language Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Loader Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:01:16 --> Controller Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Final output sent to browser
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:01:16 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:01:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Session Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:01:16 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Session routines successfully run
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:01:16 --> Final output sent to browser
DEBUG - 2014-03-10 19:01:16 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:01:16 --> Session Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:01:16 --> Session routines successfully run
DEBUG - 2014-03-10 19:01:16 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:01:16 --> Model Class Initialized
DEBUG - 2014-03-10 19:01:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:01:16 --> Final output sent to browser
DEBUG - 2014-03-10 19:01:16 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:05:07 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:07 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:07 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:07 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:07 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:07 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:07 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:07 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:07 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:07 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:07 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:07 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:07 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:07 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:07 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:07 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:07 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:07 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:07 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:07 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:07 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:07 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:07 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:07 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:05:07 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:05:07 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:07 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:07 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:05:15 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:15 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:15 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:15 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:15 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:15 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:15 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:15 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:15 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:15 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:15 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:15 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:15 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:15 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:15 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:15 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:15 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:15 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:15 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:05:15 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:15 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:15 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:15 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:15 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:15 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:05:15 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:05:55 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:55 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:55 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:55 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:55 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:55 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:55 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:55 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:55 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:55 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:55 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:55 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:55 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:55 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:55 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:55 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:55 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:55 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:05:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:55 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:55 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:05:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:55 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:55 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:05:56 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:56 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:56 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:56 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Config Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:56 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:56 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:56 --> URI Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:56 --> Router Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:56 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:56 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:56 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:56 --> Output Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:56 --> Security Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Input Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:05:56 --> Language Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Loader Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Controller Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:56 --> Total execution time: 0.0160
DEBUG - 2014-03-10 19:05:56 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:56 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:56 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:56 --> Session Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:05:56 --> A session cookie was not found.
DEBUG - 2014-03-10 19:05:56 --> Session routines successfully run
DEBUG - 2014-03-10 19:05:56 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:05:56 --> Model Class Initialized
DEBUG - 2014-03-10 19:05:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:05:56 --> Final output sent to browser
DEBUG - 2014-03-10 19:05:56 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:06:11 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:11 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:11 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:11 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:11 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:11 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:11 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:11 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:11 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:11 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:11 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:11 --> Total execution time: 0.0130
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:11 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:11 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:11 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:11 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:11 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:11 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:11 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:11 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:11 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:11 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:06:12 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:12 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:12 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:12 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:12 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:12 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:12 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:12 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:12 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:12 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:12 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:12 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:12 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:12 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:12 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:12 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:12 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:12 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:12 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:06:12 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:12 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:12 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:12 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:06:12 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:12 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:12 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:12 --> Total execution time: 0.0240
DEBUG - 2014-03-10 19:06:43 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:43 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:43 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:43 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:43 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:43 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:43 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:43 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:43 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:43 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:43 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:43 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:43 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:43 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:43 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:43 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:43 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:43 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:43 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:43 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:43 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:43 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:43 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:06:44 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:44 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:44 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:44 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:44 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:44 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:44 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:44 --> Config Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:44 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:06:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:06:44 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:44 --> URI Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Router Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:44 --> Output Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Security Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Input Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:06:44 --> Language Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Loader Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Controller Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:44 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:44 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:44 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:44 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:44 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:44 --> Total execution time: 0.0130
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:44 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:44 --> Session Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:06:44 --> A session cookie was not found.
DEBUG - 2014-03-10 19:06:44 --> Session routines successfully run
DEBUG - 2014-03-10 19:06:44 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:06:44 --> Model Class Initialized
DEBUG - 2014-03-10 19:06:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:06:44 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:44 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:06:44 --> Final output sent to browser
DEBUG - 2014-03-10 19:06:44 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:08:43 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:43 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:43 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:43 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:43 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:43 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:43 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:43 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:43 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:43 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:43 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:43 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:43 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:43 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:43 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:43 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:08:43 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:43 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:43 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:43 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:43 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:43 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:43 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:43 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:08:45 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:45 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:45 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:45 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:45 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:45 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:45 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:45 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:45 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:45 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:45 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:45 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:45 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:45 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:45 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:45 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:45 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:45 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:45 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:08:45 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:45 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:45 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:45 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:45 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:45 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:45 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:45 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:45 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:08:54 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:54 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:54 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:54 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:54 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:54 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:54 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:54 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:54 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:54 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:54 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:54 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:54 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:54 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:54 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:54 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:54 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:54 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:08:54 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:54 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:54 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:54 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:54 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:54 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:54 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:54 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:54 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:08:55 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:55 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:55 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:55 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:55 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Config Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:55 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:55 --> URI Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Router Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Output Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Security Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Input Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Language Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:55 --> Loader Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Controller Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:55 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:08:55 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:08:55 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:55 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:55 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:55 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:55 --> Session Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:08:55 --> A session cookie was not found.
DEBUG - 2014-03-10 19:08:55 --> Session routines successfully run
DEBUG - 2014-03-10 19:08:55 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:08:55 --> Model Class Initialized
DEBUG - 2014-03-10 19:08:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:08:55 --> Final output sent to browser
DEBUG - 2014-03-10 19:08:55 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:12:05 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:05 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:05 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:05 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:05 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:05 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:05 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:05 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:05 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:05 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:05 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:05 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:05 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:12:05 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:05 --> Total execution time: 0.0130
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:05 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:05 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:05 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:05 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:05 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:05 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:05 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:12:39 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:39 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:39 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:39 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:39 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:39 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:39 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:39 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:39 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:39 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:39 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:39 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:39 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:39 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:39 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:39 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:39 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:39 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:39 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:39 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:39 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:39 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:39 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:39 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:39 --> Total execution time: 0.0200
DEBUG - 2014-03-10 19:12:39 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:39 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:12:39 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:12:41 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:41 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:41 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:41 --> Config Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:41 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:41 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> URI Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Router Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Output Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Security Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Input Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:12:41 --> Language Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Loader Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Controller Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:41 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:41 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:41 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:41 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:41 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:41 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:41 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:41 --> Total execution time: 0.0160
DEBUG - 2014-03-10 19:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:41 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:41 --> Total execution time: 0.0210
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:41 --> Session Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:12:41 --> A session cookie was not found.
DEBUG - 2014-03-10 19:12:41 --> Session routines successfully run
DEBUG - 2014-03-10 19:12:41 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:12:41 --> Model Class Initialized
DEBUG - 2014-03-10 19:12:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:12:41 --> Final output sent to browser
DEBUG - 2014-03-10 19:12:41 --> Total execution time: 0.0260
DEBUG - 2014-03-10 19:17:46 --> Config Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Config Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Config Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:17:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:17:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:17:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:17:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:17:46 --> URI Class Initialized
DEBUG - 2014-03-10 19:17:46 --> URI Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Router Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Router Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Output Class Initialized
DEBUG - 2014-03-10 19:17:46 --> URI Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Router Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Output Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Security Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Output Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Input Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Security Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:17:46 --> Security Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Input Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Input Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:17:46 --> Language Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Language Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Loader Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:17:46 --> Language Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Loader Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Controller Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Controller Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Loader Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:17:46 --> Controller Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:46 --> Session Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:17:46 --> A session cookie was not found.
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Session Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Session routines successfully run
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:46 --> A session cookie was not found.
DEBUG - 2014-03-10 19:17:46 --> Session routines successfully run
DEBUG - 2014-03-10 19:17:46 --> Session Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> A session cookie was not found.
DEBUG - 2014-03-10 19:17:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:46 --> Session routines successfully run
DEBUG - 2014-03-10 19:17:46 --> Final output sent to browser
DEBUG - 2014-03-10 19:17:46 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:17:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:17:46 --> Final output sent to browser
DEBUG - 2014-03-10 19:17:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:46 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:17:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:46 --> Final output sent to browser
DEBUG - 2014-03-10 19:17:46 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:17:49 --> Config Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Config Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:17:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:17:49 --> URI Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Router Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:17:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:17:49 --> Output Class Initialized
DEBUG - 2014-03-10 19:17:49 --> URI Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Security Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Config Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Input Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:17:49 --> Router Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Language Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Output Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Loader Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Controller Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Security Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:17:49 --> Input Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:17:49 --> Language Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Loader Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Controller Class Initialized
DEBUG - 2014-03-10 19:17:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:17:49 --> URI Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:17:49 --> Router Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Output Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Security Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Input Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:17:49 --> Language Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Loader Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Controller Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:49 --> Session Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Session Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Session Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:17:49 --> A session cookie was not found.
DEBUG - 2014-03-10 19:17:49 --> A session cookie was not found.
DEBUG - 2014-03-10 19:17:49 --> Session routines successfully run
DEBUG - 2014-03-10 19:17:49 --> Session routines successfully run
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:17:49 --> A session cookie was not found.
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:17:49 --> Session routines successfully run
DEBUG - 2014-03-10 19:17:49 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:17:49 --> Final output sent to browser
DEBUG - 2014-03-10 19:17:49 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:17:49 --> Final output sent to browser
DEBUG - 2014-03-10 19:17:49 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:17:49 --> Final output sent to browser
DEBUG - 2014-03-10 19:17:49 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:18:18 --> Config Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:18:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:18:18 --> URI Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Config Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Router Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:18:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:18:18 --> Output Class Initialized
DEBUG - 2014-03-10 19:18:18 --> URI Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Security Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Router Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Input Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:18:18 --> Output Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Language Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Security Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Input Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Loader Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:18:18 --> Controller Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Language Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:18:18 --> Loader Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:18:18 --> Controller Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Session Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:18:18 --> Session Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Session routines successfully run
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:18:18 --> Config Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:18:18 --> Session routines successfully run
DEBUG - 2014-03-10 19:18:18 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:18 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:18 --> URI Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Final output sent to browser
DEBUG - 2014-03-10 19:18:18 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:18:18 --> Router Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Final output sent to browser
DEBUG - 2014-03-10 19:18:18 --> Total execution time: 0.0160
DEBUG - 2014-03-10 19:18:18 --> Output Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Security Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Input Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:18:18 --> Language Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Loader Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Controller Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:18 --> Session Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:18:18 --> Session routines successfully run
DEBUG - 2014-03-10 19:18:18 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:18:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:18 --> Final output sent to browser
DEBUG - 2014-03-10 19:18:18 --> Total execution time: 0.0100
DEBUG - 2014-03-10 19:18:22 --> Config Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:18:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:18:22 --> URI Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Config Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Router Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:18:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:18:22 --> URI Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Output Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Router Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Security Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Input Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Output Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:18:22 --> Security Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Input Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Language Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:18:22 --> Language Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Loader Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Config Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Controller Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Loader Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:18:22 --> Controller Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:18:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:18:22 --> URI Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:18:22 --> Router Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Output Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Security Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Input Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Language Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Loader Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Session Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:22 --> Controller Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:18:22 --> Session Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:18:22 --> Session routines successfully run
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:18:22 --> Session routines successfully run
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:22 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Final output sent to browser
DEBUG - 2014-03-10 19:18:22 --> Total execution time: 0.0200
DEBUG - 2014-03-10 19:18:22 --> Final output sent to browser
DEBUG - 2014-03-10 19:18:22 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:22 --> Session Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:18:22 --> Session routines successfully run
DEBUG - 2014-03-10 19:18:22 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:18:22 --> Model Class Initialized
DEBUG - 2014-03-10 19:18:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:18:22 --> Final output sent to browser
DEBUG - 2014-03-10 19:18:22 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:22:35 --> Config Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Config Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:22:35 --> URI Class Initialized
DEBUG - 2014-03-10 19:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:22:35 --> Router Class Initialized
DEBUG - 2014-03-10 19:22:35 --> URI Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Router Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Output Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Output Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Security Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Security Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Input Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Input Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:22:35 --> Language Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Language Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Loader Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Loader Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Controller Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Controller Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Config Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:22:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:22:35 --> URI Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Router Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:22:35 --> Session Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Output Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Session Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:22:35 --> Security Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:22:35 --> A session cookie was not found.
DEBUG - 2014-03-10 19:22:35 --> A session cookie was not found.
DEBUG - 2014-03-10 19:22:35 --> Input Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Session routines successfully run
DEBUG - 2014-03-10 19:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:22:35 --> Session routines successfully run
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:22:35 --> Language Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:22:35 --> Loader Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:22:35 --> Controller Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:22:35 --> Final output sent to browser
DEBUG - 2014-03-10 19:22:35 --> Final output sent to browser
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:22:35 --> Total execution time: 0.0230
DEBUG - 2014-03-10 19:22:35 --> Total execution time: 0.0240
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:22:35 --> Session Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:22:35 --> A session cookie was not found.
DEBUG - 2014-03-10 19:22:35 --> Session routines successfully run
DEBUG - 2014-03-10 19:22:35 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:22:35 --> Model Class Initialized
DEBUG - 2014-03-10 19:22:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:22:35 --> Final output sent to browser
DEBUG - 2014-03-10 19:22:35 --> Total execution time: 0.0160
DEBUG - 2014-03-10 19:27:18 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:18 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:18 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:18 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:18 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:18 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:18 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:18 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:18 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:18 --> A session cookie was not found.
DEBUG - 2014-03-10 19:27:18 --> A session cookie was not found.
DEBUG - 2014-03-10 19:27:18 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:18 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:18 --> A session cookie was not found.
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:18 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:18 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:18 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:27:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:18 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:18 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:18 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:27:18 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:27:46 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:46 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:46 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:46 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:46 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:46 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:46 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:46 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:46 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:46 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:46 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:46 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:46 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:46 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:46 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:46 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:46 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:27:46 --> Total execution time: 0.0220
DEBUG - 2014-03-10 19:27:46 --> Total execution time: 0.0240
DEBUG - 2014-03-10 19:27:49 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:49 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:49 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:49 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:49 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:49 --> Config Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:27:49 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:49 --> URI Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:49 --> Router Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Output Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:49 --> Security Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Input Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:49 --> Language Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:49 --> Loader Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Controller Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:27:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:49 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:49 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:49 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Total execution time: 0.0130
DEBUG - 2014-03-10 19:27:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:49 --> Session Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:27:49 --> Session routines successfully run
DEBUG - 2014-03-10 19:27:49 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:27:49 --> Model Class Initialized
DEBUG - 2014-03-10 19:27:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:27:49 --> Final output sent to browser
DEBUG - 2014-03-10 19:27:49 --> Total execution time: 0.0110
DEBUG - 2014-03-10 19:28:28 --> Config Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:28:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:28:28 --> URI Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Router Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Output Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Security Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Input Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:28:28 --> Language Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Loader Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Controller Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:28 --> Session Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:28:28 --> Session routines successfully run
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:28 --> Final output sent to browser
DEBUG - 2014-03-10 19:28:28 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:28:28 --> Config Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Config Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:28:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:28:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:28:28 --> URI Class Initialized
DEBUG - 2014-03-10 19:28:28 --> URI Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Router Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Router Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Output Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Output Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Security Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Security Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Input Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Input Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:28:28 --> Language Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Language Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Loader Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Loader Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Controller Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Controller Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:28 --> Session Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Session Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:28:28 --> Session routines successfully run
DEBUG - 2014-03-10 19:28:28 --> Session routines successfully run
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:28:28 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:28 --> Final output sent to browser
DEBUG - 2014-03-10 19:28:28 --> Final output sent to browser
DEBUG - 2014-03-10 19:28:28 --> Total execution time: 0.0120
DEBUG - 2014-03-10 19:28:28 --> Total execution time: 0.0120
DEBUG - 2014-03-10 19:28:36 --> Config Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:28:36 --> URI Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Router Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Output Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Security Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Input Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:28:36 --> Language Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Loader Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Controller Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:36 --> Session Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:28:36 --> Session routines successfully run
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:36 --> Final output sent to browser
DEBUG - 2014-03-10 19:28:36 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:28:36 --> Config Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Config Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:28:36 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:28:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:28:36 --> URI Class Initialized
DEBUG - 2014-03-10 19:28:36 --> URI Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Router Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Router Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Output Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Output Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Security Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Input Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Security Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:28:36 --> Input Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Language Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:28:36 --> Language Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Loader Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Controller Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Loader Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:28:36 --> Controller Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Session Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:28:36 --> Session Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Session routines successfully run
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:28:36 --> Session routines successfully run
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:28:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:36 --> Model Class Initialized
DEBUG - 2014-03-10 19:28:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:28:36 --> Final output sent to browser
DEBUG - 2014-03-10 19:28:36 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:28:36 --> Final output sent to browser
DEBUG - 2014-03-10 19:28:36 --> Total execution time: 0.0150
DEBUG - 2014-03-10 19:30:04 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:04 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:04 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:04 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:04 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:04 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:04 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:04 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:04 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:04 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:04 --> Session Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> A session cookie was not found.
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Session routines successfully run
DEBUG - 2014-03-10 19:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:04 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Session Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> A session cookie was not found.
DEBUG - 2014-03-10 19:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:04 --> Session routines successfully run
DEBUG - 2014-03-10 19:30:04 --> Session Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:30:04 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> A session cookie was not found.
DEBUG - 2014-03-10 19:30:04 --> Total execution time: 0.0140
DEBUG - 2014-03-10 19:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:04 --> Session routines successfully run
DEBUG - 2014-03-10 19:30:04 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:30:04 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:04 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:30:04 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:04 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:04 --> Total execution time: 0.0170
DEBUG - 2014-03-10 19:30:06 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:06 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:06 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:06 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:06 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:06 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:06 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:06 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:06 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:06 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:06 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:06 --> Session Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:30:06 --> Session Class Initialized
DEBUG - 2014-03-10 19:30:06 --> A session cookie was not found.
DEBUG - 2014-03-10 19:30:06 --> Session Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: string_helper
DEBUG - 2014-03-10 19:30:06 --> A session cookie was not found.
DEBUG - 2014-03-10 19:30:06 --> Session routines successfully run
DEBUG - 2014-03-10 19:30:06 --> Session routines successfully run
DEBUG - 2014-03-10 19:30:06 --> A session cookie was not found.
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:06 --> Session routines successfully run
DEBUG - 2014-03-10 19:30:06 --> Helper loaded: url_helper
DEBUG - 2014-03-10 19:30:06 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:06 --> Total execution time: 0.0180
DEBUG - 2014-03-10 19:30:06 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-10 19:30:06 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:06 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:06 --> Total execution time: 0.0160
DEBUG - 2014-03-10 19:30:06 --> Total execution time: 0.0190
DEBUG - 2014-03-10 19:30:47 --> Config Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Hooks Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Utf8 Class Initialized
DEBUG - 2014-03-10 19:30:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-10 19:30:47 --> URI Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Router Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Output Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Security Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Input Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-10 19:30:47 --> Language Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Loader Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Controller Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-10 19:30:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-10 19:30:47 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Model Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Database Driver Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Upload Class Initialized
DEBUG - 2014-03-10 19:30:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2014-03-10 19:30:47 --> You did not select a file to upload.
DEBUG - 2014-03-10 19:30:47 --> Final output sent to browser
DEBUG - 2014-03-10 19:30:47 --> Total execution time: 0.0820
