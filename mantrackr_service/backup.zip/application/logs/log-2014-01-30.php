<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-30 00:00:55 --> Config Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:00:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:00:55 --> URI Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Router Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Output Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Security Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Input Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:00:55 --> Language Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Loader Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Controller Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:00:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:00:55 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:00:55 --> Session Class Initialized
DEBUG - 2014-01-30 00:00:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:00:55 --> Session routines successfully run
DEBUG - 2014-01-30 00:00:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:00:55 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:00:55 --> Final output sent to browser
DEBUG - 2014-01-30 00:00:55 --> Total execution time: 0.0140
DEBUG - 2014-01-30 00:00:56 --> Config Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:00:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:00:56 --> URI Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Router Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Output Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Security Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Input Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:00:56 --> Language Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Loader Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Controller Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:00:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:00:56 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:00:56 --> Session Class Initialized
DEBUG - 2014-01-30 00:00:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:00:56 --> Session routines successfully run
DEBUG - 2014-01-30 00:00:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:00:56 --> Final output sent to browser
DEBUG - 2014-01-30 00:00:56 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:00:59 --> Config Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:00:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:00:59 --> URI Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Router Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Output Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Security Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Input Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:00:59 --> Language Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Loader Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Controller Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:00:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:00:59 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Model Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:00:59 --> Session Class Initialized
DEBUG - 2014-01-30 00:00:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:00:59 --> Session routines successfully run
DEBUG - 2014-01-30 00:00:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:00:59 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:00:59 --> Final output sent to browser
DEBUG - 2014-01-30 00:00:59 --> Total execution time: 0.0200
DEBUG - 2014-01-30 00:01:00 --> Config Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:01:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:01:00 --> URI Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Router Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Output Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Security Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Input Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:01:00 --> Language Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Loader Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Controller Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:01:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:01:00 --> Model Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Model Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Model Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:01:00 --> Session Class Initialized
DEBUG - 2014-01-30 00:01:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:01:00 --> Session routines successfully run
DEBUG - 2014-01-30 00:01:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:01:00 --> Final output sent to browser
DEBUG - 2014-01-30 00:01:00 --> Total execution time: 0.0090
DEBUG - 2014-01-30 00:01:42 --> Config Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:01:42 --> URI Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Router Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Output Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Security Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Input Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:01:42 --> Language Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Loader Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Controller Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:01:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:01:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:01:42 --> Session Class Initialized
DEBUG - 2014-01-30 00:01:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:01:42 --> Session routines successfully run
DEBUG - 2014-01-30 00:01:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:01:42 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:01:42 --> Final output sent to browser
DEBUG - 2014-01-30 00:01:42 --> Total execution time: 0.0120
DEBUG - 2014-01-30 00:02:17 --> Config Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:02:17 --> URI Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Router Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Output Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Security Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Input Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:02:17 --> Language Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Loader Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Controller Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:02:17 --> Model Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Model Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Model Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:02:17 --> Session Class Initialized
DEBUG - 2014-01-30 00:02:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:02:17 --> Session routines successfully run
DEBUG - 2014-01-30 00:02:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:02:17 --> Final output sent to browser
DEBUG - 2014-01-30 00:02:17 --> Total execution time: 0.0190
DEBUG - 2014-01-30 00:02:48 --> Config Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:02:48 --> URI Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Router Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Output Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Security Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Input Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:02:48 --> Language Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Loader Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Controller Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:02:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:02:48 --> Model Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Model Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Model Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:02:48 --> Session Class Initialized
DEBUG - 2014-01-30 00:02:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:02:48 --> Session routines successfully run
DEBUG - 2014-01-30 00:02:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:02:48 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:02:48 --> Final output sent to browser
DEBUG - 2014-01-30 00:02:48 --> Total execution time: 0.0190
DEBUG - 2014-01-30 00:03:12 --> Config Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:03:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:03:12 --> URI Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Router Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Output Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Security Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Input Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:03:12 --> Language Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Loader Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Controller Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:03:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:03:12 --> Model Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Model Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Model Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:03:12 --> Session Class Initialized
DEBUG - 2014-01-30 00:03:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:03:12 --> Session routines successfully run
DEBUG - 2014-01-30 00:03:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:03:12 --> Final output sent to browser
DEBUG - 2014-01-30 00:03:12 --> Total execution time: 0.0190
DEBUG - 2014-01-30 00:05:09 --> Config Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:05:09 --> URI Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Router Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Output Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Security Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Input Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:05:09 --> Language Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Loader Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Controller Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:05:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:05:09 --> Model Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Model Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Model Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:05:09 --> Session Class Initialized
DEBUG - 2014-01-30 00:05:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:05:09 --> Session routines successfully run
DEBUG - 2014-01-30 00:05:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:05:09 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:05:09 --> Final output sent to browser
DEBUG - 2014-01-30 00:05:09 --> Total execution time: 0.0190
DEBUG - 2014-01-30 00:05:13 --> Config Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:05:13 --> URI Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Router Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Output Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Security Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Input Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:05:13 --> Language Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Loader Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Controller Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:05:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:05:13 --> Model Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Model Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Model Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:05:13 --> Session Class Initialized
DEBUG - 2014-01-30 00:05:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:05:13 --> Session routines successfully run
DEBUG - 2014-01-30 00:05:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:05:13 --> Final output sent to browser
DEBUG - 2014-01-30 00:05:13 --> Total execution time: 0.0160
DEBUG - 2014-01-30 00:06:23 --> Config Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:06:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:06:23 --> URI Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Router Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Output Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Security Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Input Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:06:23 --> Language Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Loader Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Controller Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:06:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:06:23 --> Model Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Model Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Model Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:06:23 --> Session Class Initialized
DEBUG - 2014-01-30 00:06:23 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:06:23 --> Session routines successfully run
DEBUG - 2014-01-30 00:06:23 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:06:23 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:06:23 --> Final output sent to browser
DEBUG - 2014-01-30 00:06:23 --> Total execution time: 0.0170
DEBUG - 2014-01-30 00:08:36 --> Config Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:08:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:08:36 --> URI Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Router Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Output Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Security Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Input Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:08:36 --> Language Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Loader Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Controller Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:08:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Model Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:08:36 --> Session Class Initialized
DEBUG - 2014-01-30 00:08:36 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:08:36 --> Session routines successfully run
DEBUG - 2014-01-30 00:08:36 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:08:36 --> Final output sent to browser
DEBUG - 2014-01-30 00:08:36 --> Total execution time: 0.0200
DEBUG - 2014-01-30 00:11:25 --> Config Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:11:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:11:25 --> URI Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Router Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Output Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Security Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Input Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:11:25 --> Language Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Loader Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Controller Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:11:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:11:25 --> Model Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Model Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Model Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:11:25 --> Session Class Initialized
DEBUG - 2014-01-30 00:11:25 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:11:25 --> Session routines successfully run
DEBUG - 2014-01-30 00:11:25 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:11:25 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:11:25 --> Final output sent to browser
DEBUG - 2014-01-30 00:11:25 --> Total execution time: 0.0210
DEBUG - 2014-01-30 00:13:38 --> Config Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:13:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:13:38 --> URI Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Router Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Output Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Security Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Input Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:13:38 --> Language Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Loader Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Controller Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:13:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:13:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:13:38 --> Session Class Initialized
DEBUG - 2014-01-30 00:13:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:13:38 --> Session routines successfully run
DEBUG - 2014-01-30 00:13:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:13:38 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:13:38 --> Final output sent to browser
DEBUG - 2014-01-30 00:13:38 --> Total execution time: 0.0150
DEBUG - 2014-01-30 00:13:42 --> Config Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:13:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:13:42 --> URI Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Router Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Output Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Security Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Input Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:13:42 --> Language Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Loader Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Controller Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:13:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:13:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:13:42 --> Session Class Initialized
DEBUG - 2014-01-30 00:13:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:13:42 --> Session routines successfully run
DEBUG - 2014-01-30 00:13:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:13:42 --> Final output sent to browser
DEBUG - 2014-01-30 00:13:42 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:14:29 --> Config Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:14:29 --> URI Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Router Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Output Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Security Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Input Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:14:29 --> Language Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Loader Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Controller Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:14:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:14:29 --> Model Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Model Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Model Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:14:29 --> Session Class Initialized
DEBUG - 2014-01-30 00:14:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:14:29 --> Session routines successfully run
DEBUG - 2014-01-30 00:14:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:14:29 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:14:29 --> Final output sent to browser
DEBUG - 2014-01-30 00:14:29 --> Total execution time: 0.0210
DEBUG - 2014-01-30 00:14:30 --> Config Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:14:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:14:30 --> URI Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Router Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Output Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Security Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Input Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:14:30 --> Language Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Loader Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Controller Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:14:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:14:30 --> Model Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Model Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Model Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:14:30 --> Session Class Initialized
DEBUG - 2014-01-30 00:14:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:14:30 --> Session routines successfully run
DEBUG - 2014-01-30 00:14:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:14:30 --> Final output sent to browser
DEBUG - 2014-01-30 00:14:30 --> Total execution time: 0.0090
DEBUG - 2014-01-30 00:15:52 --> Config Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:15:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:15:52 --> URI Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Router Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Output Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Security Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Input Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:15:52 --> Language Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Loader Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Controller Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:15:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:15:52 --> Model Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Model Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Model Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:15:52 --> Session Class Initialized
DEBUG - 2014-01-30 00:15:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:15:52 --> Session routines successfully run
DEBUG - 2014-01-30 00:15:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:15:52 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:15:52 --> Final output sent to browser
DEBUG - 2014-01-30 00:15:52 --> Total execution time: 0.0210
DEBUG - 2014-01-30 00:15:53 --> Config Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:15:53 --> URI Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Router Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Output Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Security Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Input Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:15:53 --> Language Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Loader Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Controller Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:15:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:15:53 --> Model Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Model Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Model Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:15:53 --> Session Class Initialized
DEBUG - 2014-01-30 00:15:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:15:53 --> Session routines successfully run
DEBUG - 2014-01-30 00:15:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:15:53 --> Final output sent to browser
DEBUG - 2014-01-30 00:15:53 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:16:49 --> Config Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:16:49 --> URI Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Router Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Output Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Security Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Input Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:16:49 --> Language Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Loader Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Controller Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:16:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:16:49 --> Model Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Model Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Model Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:16:49 --> Session Class Initialized
DEBUG - 2014-01-30 00:16:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:16:49 --> Session routines successfully run
DEBUG - 2014-01-30 00:16:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:16:49 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:16:49 --> Final output sent to browser
DEBUG - 2014-01-30 00:16:49 --> Total execution time: 0.0150
DEBUG - 2014-01-30 00:16:50 --> Config Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:16:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:16:50 --> URI Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Router Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Output Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Security Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Input Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:16:50 --> Language Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Loader Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Controller Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:16:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:16:50 --> Model Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Model Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Model Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:16:50 --> Session Class Initialized
DEBUG - 2014-01-30 00:16:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:16:50 --> Session routines successfully run
DEBUG - 2014-01-30 00:16:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:16:50 --> Final output sent to browser
DEBUG - 2014-01-30 00:16:50 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:17:18 --> Config Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:17:18 --> URI Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Router Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Output Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Security Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Input Class Initialized
DEBUG - 2014-01-30 00:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:17:19 --> Language Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Loader Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Controller Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:17:19 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:17:19 --> Session Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:17:19 --> Session routines successfully run
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:17:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:17:19 --> Final output sent to browser
DEBUG - 2014-01-30 00:17:19 --> Total execution time: 0.0200
DEBUG - 2014-01-30 00:17:19 --> Config Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:17:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:17:19 --> URI Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Router Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Output Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Security Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Input Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:17:19 --> Language Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Loader Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Controller Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:17:19 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:17:19 --> Session Class Initialized
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:17:19 --> Session routines successfully run
DEBUG - 2014-01-30 00:17:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:17:19 --> Final output sent to browser
DEBUG - 2014-01-30 00:17:19 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:17:25 --> Config Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:17:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:17:25 --> URI Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Router Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Output Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Security Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Input Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:17:25 --> Language Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Loader Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Controller Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:17:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:17:25 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:17:25 --> Session Class Initialized
DEBUG - 2014-01-30 00:17:25 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:17:25 --> Session routines successfully run
DEBUG - 2014-01-30 00:17:25 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:17:25 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:17:25 --> Final output sent to browser
DEBUG - 2014-01-30 00:17:25 --> Total execution time: 0.0140
DEBUG - 2014-01-30 00:17:26 --> Config Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:17:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:17:26 --> URI Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Router Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Output Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Security Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Input Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:17:26 --> Language Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Loader Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Controller Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:17:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:17:26 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Model Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:17:26 --> Session Class Initialized
DEBUG - 2014-01-30 00:17:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:17:26 --> Session routines successfully run
DEBUG - 2014-01-30 00:17:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:17:26 --> Final output sent to browser
DEBUG - 2014-01-30 00:17:26 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:33:41 --> Config Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:33:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:33:41 --> URI Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Router Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Output Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Security Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Input Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:33:41 --> Language Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Loader Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Controller Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:33:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:33:41 --> Model Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Model Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Model Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:33:41 --> Session Class Initialized
DEBUG - 2014-01-30 00:33:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:33:41 --> Session routines successfully run
DEBUG - 2014-01-30 00:33:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:33:41 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:33:41 --> Final output sent to browser
DEBUG - 2014-01-30 00:33:41 --> Total execution time: 0.0220
DEBUG - 2014-01-30 00:33:42 --> Config Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:33:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:33:42 --> URI Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Router Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Output Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Security Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Input Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:33:42 --> Language Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Loader Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Controller Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:33:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:33:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Model Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:33:42 --> Session Class Initialized
DEBUG - 2014-01-30 00:33:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:33:42 --> Session routines successfully run
DEBUG - 2014-01-30 00:33:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:33:42 --> Final output sent to browser
DEBUG - 2014-01-30 00:33:42 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:34:28 --> Config Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:34:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:34:28 --> URI Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Router Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Output Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Security Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Input Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:34:28 --> Language Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Loader Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Controller Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:34:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:34:28 --> Model Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Model Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Model Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:34:28 --> Session Class Initialized
DEBUG - 2014-01-30 00:34:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:34:28 --> Session routines successfully run
DEBUG - 2014-01-30 00:34:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:34:28 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:34:28 --> Final output sent to browser
DEBUG - 2014-01-30 00:34:28 --> Total execution time: 0.0230
DEBUG - 2014-01-30 00:34:29 --> Config Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:34:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:34:29 --> URI Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Router Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Output Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Security Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Input Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:34:29 --> Language Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Loader Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Controller Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:34:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:34:29 --> Model Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Model Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Model Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:34:29 --> Session Class Initialized
DEBUG - 2014-01-30 00:34:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:34:29 --> Session routines successfully run
DEBUG - 2014-01-30 00:34:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:34:29 --> Final output sent to browser
DEBUG - 2014-01-30 00:34:29 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:43:56 --> Config Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:43:56 --> URI Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Router Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Output Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Security Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Input Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:43:56 --> Language Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Loader Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Controller Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:43:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:43:56 --> Model Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Model Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Model Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:43:56 --> Session Class Initialized
DEBUG - 2014-01-30 00:43:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:43:56 --> Session routines successfully run
DEBUG - 2014-01-30 00:43:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:43:56 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:43:56 --> Final output sent to browser
DEBUG - 2014-01-30 00:43:56 --> Total execution time: 0.0240
DEBUG - 2014-01-30 00:43:58 --> Config Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:43:58 --> URI Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Router Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Output Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Security Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Input Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:43:58 --> Language Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Loader Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Controller Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:43:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:43:58 --> Model Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Model Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Model Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:43:58 --> Session Class Initialized
DEBUG - 2014-01-30 00:43:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:43:58 --> Session routines successfully run
DEBUG - 2014-01-30 00:43:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:43:58 --> Final output sent to browser
DEBUG - 2014-01-30 00:43:58 --> Total execution time: 0.0810
DEBUG - 2014-01-30 00:44:01 --> Config Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:44:01 --> URI Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Router Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Output Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Security Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Input Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:44:01 --> Language Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Loader Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Controller Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:44:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:44:01 --> Model Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Model Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Model Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:44:01 --> Session Class Initialized
DEBUG - 2014-01-30 00:44:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:44:01 --> Session routines successfully run
DEBUG - 2014-01-30 00:44:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:44:01 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:44:01 --> Final output sent to browser
DEBUG - 2014-01-30 00:44:01 --> Total execution time: 0.0170
DEBUG - 2014-01-30 00:44:02 --> Config Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:44:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:44:02 --> URI Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Router Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Output Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Security Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Input Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:44:02 --> Language Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Loader Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Controller Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:44:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:44:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:44:02 --> Session Class Initialized
DEBUG - 2014-01-30 00:44:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:44:02 --> Session routines successfully run
DEBUG - 2014-01-30 00:44:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:44:02 --> Final output sent to browser
DEBUG - 2014-01-30 00:44:02 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:46:05 --> Config Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:46:05 --> URI Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Router Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Output Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Security Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Input Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:46:05 --> Language Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Loader Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Controller Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:46:05 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:46:05 --> Session Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:46:05 --> Session routines successfully run
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:46:05 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:46:05 --> Final output sent to browser
DEBUG - 2014-01-30 00:46:05 --> Total execution time: 0.0190
DEBUG - 2014-01-30 00:46:05 --> Config Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:46:05 --> URI Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Router Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Output Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Security Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Input Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:46:05 --> Language Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Loader Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Controller Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:46:05 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:46:05 --> Session Class Initialized
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:46:05 --> Session routines successfully run
DEBUG - 2014-01-30 00:46:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:46:05 --> Final output sent to browser
DEBUG - 2014-01-30 00:46:05 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:46:12 --> Config Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:46:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:46:12 --> URI Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Router Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Output Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Security Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Input Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:46:12 --> Language Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Loader Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Controller Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:46:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:46:12 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Model Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:46:12 --> Session Class Initialized
DEBUG - 2014-01-30 00:46:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:46:12 --> Session routines successfully run
DEBUG - 2014-01-30 00:46:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:46:12 --> Final output sent to browser
DEBUG - 2014-01-30 00:46:12 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:47:47 --> Config Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:47:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:47:47 --> URI Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Router Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Output Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Security Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Input Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:47:47 --> Language Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Loader Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Controller Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:47:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:47:47 --> Model Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Model Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Model Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:47:47 --> Session Class Initialized
DEBUG - 2014-01-30 00:47:47 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:47:47 --> Session routines successfully run
DEBUG - 2014-01-30 00:47:47 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:47:47 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:47:47 --> Final output sent to browser
DEBUG - 2014-01-30 00:47:47 --> Total execution time: 0.0220
DEBUG - 2014-01-30 00:47:48 --> Config Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:47:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:47:48 --> URI Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Router Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Output Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Security Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Input Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:47:48 --> Language Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Loader Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Controller Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:47:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:47:48 --> Session Class Initialized
DEBUG - 2014-01-30 00:47:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:47:48 --> Session routines successfully run
DEBUG - 2014-01-30 00:47:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:47:48 --> Final output sent to browser
DEBUG - 2014-01-30 00:47:48 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:48:02 --> Config Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:48:02 --> URI Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Router Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Output Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Security Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Input Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:48:02 --> Language Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Loader Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Controller Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:48:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:48:02 --> Session Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:48:02 --> Session routines successfully run
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:48:02 --> Config Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:48:02 --> URI Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Router Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Output Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Security Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Input Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:48:02 --> Language Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Loader Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Controller Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:48:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:48:02 --> Session Class Initialized
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:48:02 --> Session routines successfully run
DEBUG - 2014-01-30 00:48:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:48:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 00:48:02 --> Final output sent to browser
DEBUG - 2014-01-30 00:48:02 --> Total execution time: 0.0130
DEBUG - 2014-01-30 00:48:04 --> Config Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:48:04 --> URI Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Router Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Output Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Security Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Input Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:48:04 --> Language Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Loader Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Controller Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:48:04 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:48:04 --> Session Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:48:04 --> Session routines successfully run
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:48:04 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:48:04 --> Final output sent to browser
DEBUG - 2014-01-30 00:48:04 --> Total execution time: 0.0150
DEBUG - 2014-01-30 00:48:04 --> Config Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:48:04 --> URI Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Router Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Output Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Security Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Input Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:48:04 --> Language Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Loader Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Controller Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:48:04 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Model Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:48:04 --> Session Class Initialized
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:48:04 --> Session routines successfully run
DEBUG - 2014-01-30 00:48:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:48:04 --> Final output sent to browser
DEBUG - 2014-01-30 00:48:04 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:49:31 --> Config Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:49:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:49:31 --> URI Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Router Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Output Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Security Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Input Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:49:31 --> Language Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Loader Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Controller Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:49:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:49:31 --> Model Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Model Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Model Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:49:31 --> Session Class Initialized
DEBUG - 2014-01-30 00:49:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:49:31 --> Session routines successfully run
DEBUG - 2014-01-30 00:49:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:49:34 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:49:34 --> Final output sent to browser
DEBUG - 2014-01-30 00:49:34 --> Total execution time: 2.3651
DEBUG - 2014-01-30 00:49:35 --> Config Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:49:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:49:35 --> URI Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Router Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Output Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Security Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Input Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:49:35 --> Language Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Loader Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Controller Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:49:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:49:35 --> Model Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Model Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Model Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:49:35 --> Session Class Initialized
DEBUG - 2014-01-30 00:49:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:49:35 --> Session routines successfully run
DEBUG - 2014-01-30 00:49:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:51:35 --> Config Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:51:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:51:35 --> URI Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Router Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Output Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Security Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Input Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:51:35 --> Language Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Loader Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Controller Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:51:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:51:35 --> Model Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Model Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Model Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:51:35 --> Session Class Initialized
DEBUG - 2014-01-30 00:51:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:51:35 --> Session routines successfully run
DEBUG - 2014-01-30 00:51:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:51:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:51:35 --> Final output sent to browser
DEBUG - 2014-01-30 00:51:35 --> Total execution time: 0.0200
DEBUG - 2014-01-30 00:51:36 --> Config Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:51:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:51:36 --> URI Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Router Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Output Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Security Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Input Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:51:36 --> Language Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Loader Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Controller Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:51:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:51:36 --> Model Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Model Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Model Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:51:36 --> Session Class Initialized
DEBUG - 2014-01-30 00:51:36 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:51:36 --> Session routines successfully run
DEBUG - 2014-01-30 00:51:36 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:51:36 --> Final output sent to browser
DEBUG - 2014-01-30 00:51:36 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:53:10 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:10 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:10 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:10 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:10 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:10 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:10 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:53:10 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:10 --> Total execution time: 0.0130
DEBUG - 2014-01-30 00:53:11 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:11 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:11 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:11 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:11 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:11 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:11 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:11 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:53:16 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:16 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:16 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:16 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:16 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:16 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:16 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:53:16 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:16 --> Total execution time: 0.0200
DEBUG - 2014-01-30 00:53:17 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:17 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:17 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:17 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:17 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:17 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:17 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:17 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:53:38 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:38 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:38 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:38 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:38 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:38 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 00:53:38 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:38 --> Total execution time: 0.0160
DEBUG - 2014-01-30 00:53:38 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:38 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:38 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:38 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:38 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:38 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:38 --> Total execution time: 0.0100
DEBUG - 2014-01-30 00:53:44 --> Config Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:53:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:53:44 --> URI Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Router Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Output Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Security Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Input Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:53:44 --> Language Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Loader Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Controller Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:53:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:53:44 --> Session Class Initialized
DEBUG - 2014-01-30 00:53:44 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:53:44 --> Session routines successfully run
DEBUG - 2014-01-30 00:53:44 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:53:44 --> Final output sent to browser
DEBUG - 2014-01-30 00:53:44 --> Total execution time: 0.0110
DEBUG - 2014-01-30 00:56:21 --> Config Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 00:56:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 00:56:21 --> URI Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Router Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Output Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Security Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Input Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 00:56:21 --> Language Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Loader Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Controller Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 00:56:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 00:56:21 --> Model Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Model Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Model Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 00:56:21 --> Session Class Initialized
DEBUG - 2014-01-30 00:56:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 00:56:21 --> Session routines successfully run
DEBUG - 2014-01-30 00:56:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 00:56:21 --> Final output sent to browser
DEBUG - 2014-01-30 00:56:21 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:02:46 --> Config Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:02:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:02:46 --> URI Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Router Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Output Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Security Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Input Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:02:46 --> Language Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Loader Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Controller Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:02:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:02:46 --> Model Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Model Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Model Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:02:46 --> Session Class Initialized
DEBUG - 2014-01-30 01:02:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:02:46 --> Session routines successfully run
DEBUG - 2014-01-30 01:02:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:02:46 --> Final output sent to browser
DEBUG - 2014-01-30 01:02:46 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:02:49 --> Config Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:02:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:02:49 --> URI Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Router Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Output Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Security Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Input Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:02:49 --> Language Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Loader Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Controller Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:02:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:02:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:02:49 --> Session Class Initialized
DEBUG - 2014-01-30 01:02:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:02:49 --> Session routines successfully run
DEBUG - 2014-01-30 01:02:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:02:49 --> Final output sent to browser
DEBUG - 2014-01-30 01:02:49 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:04:08 --> Config Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:04:08 --> URI Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Router Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Output Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Security Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Input Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:04:08 --> Language Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Loader Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Controller Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:04:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:04:08 --> Model Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Model Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Model Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:04:08 --> Session Class Initialized
DEBUG - 2014-01-30 01:04:08 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:04:08 --> Session routines successfully run
DEBUG - 2014-01-30 01:04:08 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:04:08 --> Final output sent to browser
DEBUG - 2014-01-30 01:04:08 --> Total execution time: 0.0130
DEBUG - 2014-01-30 01:07:06 --> Config Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:07:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:07:06 --> URI Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Router Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Output Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Security Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Input Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:07:06 --> Language Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Loader Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Controller Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:07:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:07:06 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:07:06 --> Session Class Initialized
DEBUG - 2014-01-30 01:07:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:07:06 --> Session routines successfully run
DEBUG - 2014-01-30 01:07:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:07:06 --> Final output sent to browser
DEBUG - 2014-01-30 01:07:06 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:07:52 --> Config Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:07:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:07:52 --> URI Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Router Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Output Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Security Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Input Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:07:52 --> Language Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Loader Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Controller Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:07:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:07:52 --> Session Class Initialized
DEBUG - 2014-01-30 01:07:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:07:52 --> Session routines successfully run
DEBUG - 2014-01-30 01:07:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:07:52 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:07:52 --> Final output sent to browser
DEBUG - 2014-01-30 01:07:52 --> Total execution time: 0.0190
DEBUG - 2014-01-30 01:07:55 --> Config Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:07:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:07:55 --> URI Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Router Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Output Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Security Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Input Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:07:55 --> Language Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Loader Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Controller Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:07:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:07:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:07:55 --> Session Class Initialized
DEBUG - 2014-01-30 01:07:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:07:55 --> Session routines successfully run
DEBUG - 2014-01-30 01:07:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:07:55 --> Final output sent to browser
DEBUG - 2014-01-30 01:07:55 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:08:15 --> Config Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:08:15 --> URI Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Router Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Output Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Security Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Input Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:08:15 --> Language Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Loader Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Controller Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:08:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:08:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:08:15 --> Session Class Initialized
DEBUG - 2014-01-30 01:08:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:08:15 --> Session routines successfully run
DEBUG - 2014-01-30 01:08:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:08:15 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:08:15 --> Final output sent to browser
DEBUG - 2014-01-30 01:08:15 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:08:16 --> Config Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:08:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:08:16 --> URI Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Router Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Output Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Security Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Input Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:08:16 --> Language Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Loader Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Controller Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:08:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:08:16 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:08:16 --> Session Class Initialized
DEBUG - 2014-01-30 01:08:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:08:16 --> Session routines successfully run
DEBUG - 2014-01-30 01:08:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:08:16 --> Final output sent to browser
DEBUG - 2014-01-30 01:08:16 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:08:35 --> Config Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:08:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:08:35 --> URI Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Router Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Output Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Security Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Input Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:08:35 --> Language Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Loader Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Controller Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:08:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:08:35 --> Session Class Initialized
DEBUG - 2014-01-30 01:08:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:08:35 --> Session routines successfully run
DEBUG - 2014-01-30 01:08:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:08:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:08:35 --> Final output sent to browser
DEBUG - 2014-01-30 01:08:35 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:08:36 --> Config Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:08:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:08:36 --> URI Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Router Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Output Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Security Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Input Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:08:36 --> Language Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Loader Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Controller Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:08:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:08:36 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Model Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:08:36 --> Session Class Initialized
DEBUG - 2014-01-30 01:08:36 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:08:36 --> Session routines successfully run
DEBUG - 2014-01-30 01:08:36 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:08:36 --> Final output sent to browser
DEBUG - 2014-01-30 01:08:36 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:09:31 --> Config Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:09:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:09:31 --> URI Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Router Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Output Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Security Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Input Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:09:31 --> Language Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Loader Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Controller Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:09:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:09:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:09:31 --> Session Class Initialized
DEBUG - 2014-01-30 01:09:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:09:31 --> Session routines successfully run
DEBUG - 2014-01-30 01:09:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:09:31 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:09:31 --> Final output sent to browser
DEBUG - 2014-01-30 01:09:31 --> Total execution time: 0.0140
DEBUG - 2014-01-30 01:09:32 --> Config Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:09:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:09:32 --> URI Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Router Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Output Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Security Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Input Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:09:32 --> Language Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Loader Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Controller Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:09:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:09:32 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:09:32 --> Session Class Initialized
DEBUG - 2014-01-30 01:09:32 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:09:32 --> Session routines successfully run
DEBUG - 2014-01-30 01:09:32 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:09:32 --> Final output sent to browser
DEBUG - 2014-01-30 01:09:32 --> Total execution time: 0.0090
DEBUG - 2014-01-30 01:09:35 --> Config Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:09:35 --> URI Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Router Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Output Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Security Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Input Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:09:35 --> Language Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Loader Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Controller Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:09:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:09:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:09:35 --> Session Class Initialized
DEBUG - 2014-01-30 01:09:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:09:35 --> Session routines successfully run
DEBUG - 2014-01-30 01:09:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:09:35 --> Final output sent to browser
DEBUG - 2014-01-30 01:09:35 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:18:17 --> Config Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:18:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:18:17 --> URI Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Router Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Output Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Security Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Input Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:18:17 --> Language Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Loader Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Controller Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:18:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:18:17 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:18:17 --> Session Class Initialized
DEBUG - 2014-01-30 01:18:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:18:17 --> Session routines successfully run
DEBUG - 2014-01-30 01:18:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:18:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:18:17 --> Final output sent to browser
DEBUG - 2014-01-30 01:18:17 --> Total execution time: 0.0220
DEBUG - 2014-01-30 01:18:18 --> Config Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:18:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:18:18 --> URI Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Router Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Output Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Security Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Input Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:18:18 --> Language Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Loader Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Controller Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:18:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:18:18 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:18:18 --> Session Class Initialized
DEBUG - 2014-01-30 01:18:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:18:18 --> Session routines successfully run
DEBUG - 2014-01-30 01:18:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:18:18 --> Final output sent to browser
DEBUG - 2014-01-30 01:18:18 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:18:45 --> Config Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:18:45 --> URI Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Router Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Output Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Security Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Input Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:18:45 --> Language Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Loader Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Controller Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:18:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:18:45 --> Session Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:18:45 --> Session routines successfully run
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:18:45 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:18:45 --> Final output sent to browser
DEBUG - 2014-01-30 01:18:45 --> Total execution time: 0.0130
DEBUG - 2014-01-30 01:18:45 --> Config Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:18:45 --> URI Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Router Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Output Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Security Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Input Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:18:45 --> Language Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Loader Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Controller Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:18:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:18:45 --> Session Class Initialized
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:18:45 --> Session routines successfully run
DEBUG - 2014-01-30 01:18:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:18:45 --> Final output sent to browser
DEBUG - 2014-01-30 01:18:45 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:19:41 --> Config Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:19:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:19:41 --> URI Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Router Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Output Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Security Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Input Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:19:41 --> Language Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Loader Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Controller Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:19:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:19:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:19:41 --> Session Class Initialized
DEBUG - 2014-01-30 01:19:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:19:41 --> Session routines successfully run
DEBUG - 2014-01-30 01:19:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:19:41 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:19:41 --> Final output sent to browser
DEBUG - 2014-01-30 01:19:41 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:19:42 --> Config Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:19:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:19:42 --> URI Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Router Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Output Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Security Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Input Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:19:42 --> Language Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Loader Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Controller Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:19:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:19:42 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:19:42 --> Session Class Initialized
DEBUG - 2014-01-30 01:19:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:19:42 --> Session routines successfully run
DEBUG - 2014-01-30 01:19:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:19:42 --> Final output sent to browser
DEBUG - 2014-01-30 01:19:42 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:19:49 --> Config Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:19:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:19:49 --> URI Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Router Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Output Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Security Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Input Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:19:49 --> Language Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Loader Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Controller Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:19:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:19:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:19:49 --> Session Class Initialized
DEBUG - 2014-01-30 01:19:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:19:49 --> Session routines successfully run
DEBUG - 2014-01-30 01:19:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:19:49 --> Final output sent to browser
DEBUG - 2014-01-30 01:19:49 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:20:11 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:11 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:11 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:11 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:11 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:11 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:20:11 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:11 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:20:11 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:11 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:11 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:11 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:11 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:11 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:11 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:20:14 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:14 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:14 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:14 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:14 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:14 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:20:14 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:14 --> Total execution time: 0.0140
DEBUG - 2014-01-30 01:20:15 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:15 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:15 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:15 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:15 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:15 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:15 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:20:19 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:19 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:19 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:19 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:19 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:20 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:20 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:20 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:20 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:20:29 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:29 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:29 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:29 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:29 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:29 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:29 --> Total execution time: 0.0150
DEBUG - 2014-01-30 01:20:30 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:30 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:30 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:30 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:30 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:30 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:30 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:20:30 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:30 --> Total execution time: 0.0140
DEBUG - 2014-01-30 01:20:31 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:31 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:31 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:31 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:31 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:31 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:31 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:20:46 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:46 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:46 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:46 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:46 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:46 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:46 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:20:46 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:46 --> Total execution time: 0.0150
DEBUG - 2014-01-30 01:20:48 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:48 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:48 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:48 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:48 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:48 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:48 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:48 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:20:51 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:51 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:51 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:51 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:51 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:51 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:51 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:20:51 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:51 --> Total execution time: 0.0150
DEBUG - 2014-01-30 01:20:53 --> Config Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:20:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:20:53 --> URI Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Router Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Output Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Security Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Input Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:20:53 --> Language Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Loader Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Controller Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:20:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:20:53 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Model Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:20:53 --> Session Class Initialized
DEBUG - 2014-01-30 01:20:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:20:53 --> Session routines successfully run
DEBUG - 2014-01-30 01:20:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:20:53 --> Final output sent to browser
DEBUG - 2014-01-30 01:20:53 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:21:40 --> Config Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:21:40 --> URI Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Router Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Output Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Security Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Input Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:21:40 --> Language Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Loader Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Controller Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:21:40 --> Session Class Initialized
DEBUG - 2014-01-30 01:21:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:21:40 --> Session routines successfully run
DEBUG - 2014-01-30 01:21:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:21:40 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:21:40 --> Final output sent to browser
DEBUG - 2014-01-30 01:21:40 --> Total execution time: 0.0190
DEBUG - 2014-01-30 01:21:42 --> Config Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:21:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:21:42 --> URI Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Router Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Output Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Security Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Input Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:21:42 --> Language Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Loader Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Controller Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:21:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:21:42 --> Session Class Initialized
DEBUG - 2014-01-30 01:21:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:21:42 --> Session routines successfully run
DEBUG - 2014-01-30 01:21:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:21:42 --> Final output sent to browser
DEBUG - 2014-01-30 01:21:42 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:22:49 --> Config Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:22:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:22:49 --> URI Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Router Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Output Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Security Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Input Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:22:49 --> Language Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Loader Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Controller Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:22:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:22:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:22:49 --> Session Class Initialized
DEBUG - 2014-01-30 01:22:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:22:49 --> Session routines successfully run
DEBUG - 2014-01-30 01:22:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:22:49 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:22:49 --> Final output sent to browser
DEBUG - 2014-01-30 01:22:49 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:22:50 --> Config Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:22:50 --> URI Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Router Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Output Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Security Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Input Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:22:50 --> Language Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Loader Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Controller Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:22:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:22:50 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:22:50 --> Session Class Initialized
DEBUG - 2014-01-30 01:22:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:22:50 --> Session routines successfully run
DEBUG - 2014-01-30 01:22:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:22:50 --> Final output sent to browser
DEBUG - 2014-01-30 01:22:50 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:22:54 --> Config Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:22:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:22:54 --> URI Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Router Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Output Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Security Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Input Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:22:54 --> Language Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Loader Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Controller Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:22:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:22:54 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:22:54 --> Session Class Initialized
DEBUG - 2014-01-30 01:22:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:22:54 --> Session routines successfully run
DEBUG - 2014-01-30 01:22:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:22:54 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:22:54 --> Final output sent to browser
DEBUG - 2014-01-30 01:22:54 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:22:55 --> Config Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:22:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:22:55 --> URI Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Router Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Output Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Security Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Input Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:22:55 --> Language Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Loader Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Controller Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:22:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:22:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:22:55 --> Session Class Initialized
DEBUG - 2014-01-30 01:22:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:22:55 --> Session routines successfully run
DEBUG - 2014-01-30 01:22:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:22:55 --> Final output sent to browser
DEBUG - 2014-01-30 01:22:55 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:26:31 --> Config Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:26:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:26:31 --> URI Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Router Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Output Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Security Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Input Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:26:31 --> Language Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Loader Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Controller Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:26:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:26:31 --> Session Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:26:31 --> Session routines successfully run
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:26:31 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:26:31 --> Final output sent to browser
DEBUG - 2014-01-30 01:26:31 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:26:31 --> Config Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:26:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:26:31 --> URI Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Router Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Output Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Security Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Input Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:26:31 --> Language Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Loader Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Controller Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:26:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:26:31 --> Session Class Initialized
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:26:31 --> Session routines successfully run
DEBUG - 2014-01-30 01:26:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:26:31 --> Final output sent to browser
DEBUG - 2014-01-30 01:26:31 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:26:37 --> Config Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:26:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:26:37 --> URI Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Router Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Output Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Security Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Input Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:26:37 --> Language Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Loader Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Controller Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:26:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:26:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:26:37 --> Session Class Initialized
DEBUG - 2014-01-30 01:26:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:26:37 --> Session routines successfully run
DEBUG - 2014-01-30 01:26:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:26:37 --> Final output sent to browser
DEBUG - 2014-01-30 01:26:37 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:28:29 --> Config Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:28:29 --> URI Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Router Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Output Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Security Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Input Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:28:29 --> Language Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Loader Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Controller Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:28:29 --> Session Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:28:29 --> Session routines successfully run
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:28:29 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:28:29 --> Final output sent to browser
DEBUG - 2014-01-30 01:28:29 --> Total execution time: 0.0150
DEBUG - 2014-01-30 01:28:29 --> Config Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:28:29 --> URI Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Router Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Output Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Security Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Input Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:28:29 --> Language Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Loader Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Controller Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:28:29 --> Session Class Initialized
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:28:29 --> Session routines successfully run
DEBUG - 2014-01-30 01:28:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:28:29 --> Final output sent to browser
DEBUG - 2014-01-30 01:28:29 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:28:33 --> Config Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:28:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:28:33 --> URI Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Router Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Output Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Security Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Input Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:28:33 --> Language Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Loader Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Controller Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:28:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:28:33 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Model Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:28:33 --> Session Class Initialized
DEBUG - 2014-01-30 01:28:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:28:33 --> Session routines successfully run
DEBUG - 2014-01-30 01:28:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:28:33 --> Final output sent to browser
DEBUG - 2014-01-30 01:28:33 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:32:20 --> Config Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:32:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:32:20 --> URI Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Router Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Output Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Security Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Input Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:32:20 --> Language Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Loader Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Controller Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:32:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:32:20 --> Session Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:32:20 --> Session routines successfully run
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:32:20 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:32:20 --> Final output sent to browser
DEBUG - 2014-01-30 01:32:20 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:32:20 --> Config Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:32:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:32:20 --> URI Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Router Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Output Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Security Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Input Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:32:20 --> Language Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Loader Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Controller Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:32:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:32:20 --> Session Class Initialized
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:32:20 --> Session routines successfully run
DEBUG - 2014-01-30 01:32:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:32:20 --> Final output sent to browser
DEBUG - 2014-01-30 01:32:20 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:32:44 --> Config Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:32:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:32:44 --> URI Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Router Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Output Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Security Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Input Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:32:44 --> Language Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Loader Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Controller Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:32:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:32:44 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:32:44 --> Session Class Initialized
DEBUG - 2014-01-30 01:32:44 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:32:44 --> Session routines successfully run
DEBUG - 2014-01-30 01:32:44 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:32:44 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:32:44 --> Final output sent to browser
DEBUG - 2014-01-30 01:32:44 --> Total execution time: 0.0130
DEBUG - 2014-01-30 01:32:45 --> Config Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:32:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:32:45 --> URI Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Router Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Output Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Security Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Input Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:32:45 --> Language Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Loader Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Controller Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:32:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:32:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Model Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:32:45 --> Session Class Initialized
DEBUG - 2014-01-30 01:32:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:32:45 --> Session routines successfully run
DEBUG - 2014-01-30 01:32:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:32:45 --> Final output sent to browser
DEBUG - 2014-01-30 01:32:45 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:33:09 --> Config Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:33:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:33:09 --> URI Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Router Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Output Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Security Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Input Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:33:09 --> Language Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Loader Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Controller Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:33:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:33:09 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:33:09 --> Session Class Initialized
DEBUG - 2014-01-30 01:33:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:33:09 --> Session routines successfully run
DEBUG - 2014-01-30 01:33:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:33:09 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:33:09 --> Final output sent to browser
DEBUG - 2014-01-30 01:33:09 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:33:10 --> Config Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:33:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:33:10 --> URI Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Router Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Output Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Security Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Input Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:33:10 --> Language Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Loader Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Controller Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:33:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:33:10 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:33:10 --> Session Class Initialized
DEBUG - 2014-01-30 01:33:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:33:10 --> Session routines successfully run
DEBUG - 2014-01-30 01:33:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:33:10 --> Final output sent to browser
DEBUG - 2014-01-30 01:33:10 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:33:56 --> Config Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:33:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:33:56 --> URI Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Router Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Output Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Security Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Input Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:33:56 --> Language Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Loader Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Controller Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:33:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:33:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:33:56 --> Session Class Initialized
DEBUG - 2014-01-30 01:33:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:33:56 --> Session routines successfully run
DEBUG - 2014-01-30 01:33:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:33:56 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:33:56 --> Final output sent to browser
DEBUG - 2014-01-30 01:33:56 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:33:57 --> Config Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:33:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:33:57 --> URI Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Router Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Output Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Security Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Input Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:33:57 --> Language Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Loader Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Controller Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:33:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:33:57 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Model Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:33:57 --> Session Class Initialized
DEBUG - 2014-01-30 01:33:57 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:33:57 --> Session routines successfully run
DEBUG - 2014-01-30 01:33:57 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:33:57 --> Final output sent to browser
DEBUG - 2014-01-30 01:33:57 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:34:27 --> Config Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:34:27 --> URI Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Router Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Output Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Security Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Input Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:34:27 --> Language Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Loader Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Controller Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:34:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:34:27 --> Model Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Model Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Model Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:34:27 --> Session Class Initialized
DEBUG - 2014-01-30 01:34:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:34:27 --> Session routines successfully run
DEBUG - 2014-01-30 01:34:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:34:27 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:34:27 --> Final output sent to browser
DEBUG - 2014-01-30 01:34:27 --> Total execution time: 0.0120
DEBUG - 2014-01-30 01:34:28 --> Config Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:34:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:34:28 --> URI Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Router Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Output Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Security Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Input Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:34:28 --> Language Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Loader Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Controller Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:34:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:34:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:34:28 --> Session Class Initialized
DEBUG - 2014-01-30 01:34:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:34:28 --> Session routines successfully run
DEBUG - 2014-01-30 01:34:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:34:28 --> Final output sent to browser
DEBUG - 2014-01-30 01:34:28 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:37:22 --> Config Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:37:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:37:22 --> URI Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Router Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Output Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Security Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Input Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:37:22 --> Language Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Loader Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Controller Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:37:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:37:22 --> Model Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Model Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Model Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:37:22 --> Session Class Initialized
DEBUG - 2014-01-30 01:37:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:37:22 --> Session routines successfully run
DEBUG - 2014-01-30 01:37:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:37:22 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:37:22 --> Final output sent to browser
DEBUG - 2014-01-30 01:37:22 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:37:23 --> Config Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:37:23 --> URI Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Router Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Output Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Security Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Input Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:37:23 --> Language Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Loader Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Controller Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:37:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:37:23 --> Model Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Model Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Model Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:37:23 --> Session Class Initialized
DEBUG - 2014-01-30 01:37:23 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:37:23 --> Session routines successfully run
DEBUG - 2014-01-30 01:37:23 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:37:23 --> Final output sent to browser
DEBUG - 2014-01-30 01:37:23 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:39:11 --> Config Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:39:11 --> URI Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Router Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Output Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Security Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Input Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:39:11 --> Language Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Loader Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Controller Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:39:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:39:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:39:11 --> Session Class Initialized
DEBUG - 2014-01-30 01:39:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:39:11 --> Session routines successfully run
DEBUG - 2014-01-30 01:39:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:39:11 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:39:11 --> Final output sent to browser
DEBUG - 2014-01-30 01:39:11 --> Total execution time: 0.0160
DEBUG - 2014-01-30 01:39:12 --> Config Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:39:12 --> URI Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Router Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Output Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Security Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Input Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:39:12 --> Language Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Loader Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Controller Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:39:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:39:12 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:39:12 --> Session Class Initialized
DEBUG - 2014-01-30 01:39:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:39:12 --> Session routines successfully run
DEBUG - 2014-01-30 01:39:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:39:12 --> Final output sent to browser
DEBUG - 2014-01-30 01:39:12 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:39:35 --> Config Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:39:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:39:35 --> URI Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Router Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Output Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Security Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Input Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:39:35 --> Language Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Loader Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Controller Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:39:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:39:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:39:35 --> Session Class Initialized
DEBUG - 2014-01-30 01:39:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:39:35 --> Session routines successfully run
DEBUG - 2014-01-30 01:39:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:39:35 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 01:39:35 --> Final output sent to browser
DEBUG - 2014-01-30 01:39:35 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:39:37 --> Config Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:39:37 --> URI Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Router Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Output Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Security Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Input Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:39:37 --> Language Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Loader Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Controller Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:39:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:39:37 --> Session Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:39:37 --> Session routines successfully run
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:39:37 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:39:37 --> Final output sent to browser
DEBUG - 2014-01-30 01:39:37 --> Total execution time: 0.0180
DEBUG - 2014-01-30 01:39:37 --> Config Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:39:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:39:37 --> URI Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Router Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Output Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Security Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Input Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:39:37 --> Language Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Loader Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Controller Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:39:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Model Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:39:37 --> Session Class Initialized
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:39:37 --> Session routines successfully run
DEBUG - 2014-01-30 01:39:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:39:37 --> Final output sent to browser
DEBUG - 2014-01-30 01:39:37 --> Total execution time: 0.0090
DEBUG - 2014-01-30 01:43:02 --> Config Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:43:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:43:02 --> URI Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Router Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Output Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Security Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Input Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:43:02 --> Language Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Loader Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Controller Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:43:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:43:02 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:43:02 --> Session Class Initialized
DEBUG - 2014-01-30 01:43:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:43:02 --> Session routines successfully run
DEBUG - 2014-01-30 01:43:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:43:02 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:43:02 --> Final output sent to browser
DEBUG - 2014-01-30 01:43:02 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:43:03 --> Config Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:43:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:43:03 --> URI Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Router Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Output Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Security Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Input Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:43:03 --> Language Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Loader Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Controller Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:43:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:43:03 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:43:03 --> Session Class Initialized
DEBUG - 2014-01-30 01:43:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:43:03 --> Session routines successfully run
DEBUG - 2014-01-30 01:43:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:43:03 --> Final output sent to browser
DEBUG - 2014-01-30 01:43:03 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:43:28 --> Config Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:43:28 --> URI Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Router Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Output Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Security Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Input Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:43:28 --> Language Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Loader Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Controller Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:43:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:43:28 --> Session Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:43:28 --> Session routines successfully run
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:43:28 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:43:28 --> Final output sent to browser
DEBUG - 2014-01-30 01:43:28 --> Total execution time: 0.0220
DEBUG - 2014-01-30 01:43:28 --> Config Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:43:28 --> URI Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Router Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Output Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Security Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Input Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:43:28 --> Language Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Loader Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Controller Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:43:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:43:28 --> Session Class Initialized
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:43:28 --> Session routines successfully run
DEBUG - 2014-01-30 01:43:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:43:28 --> Final output sent to browser
DEBUG - 2014-01-30 01:43:28 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:43:55 --> Config Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:43:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:43:55 --> URI Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Router Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Output Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Security Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Input Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:43:55 --> Language Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Loader Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Controller Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:43:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:43:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:43:55 --> Session Class Initialized
DEBUG - 2014-01-30 01:43:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:43:55 --> Session routines successfully run
DEBUG - 2014-01-30 01:43:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:43:55 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:43:55 --> Final output sent to browser
DEBUG - 2014-01-30 01:43:55 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:43:56 --> Config Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:43:56 --> URI Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Router Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Output Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Security Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Input Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:43:56 --> Language Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Loader Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Controller Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:43:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:43:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:43:56 --> Session Class Initialized
DEBUG - 2014-01-30 01:43:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:43:56 --> Session routines successfully run
DEBUG - 2014-01-30 01:43:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:43:56 --> Final output sent to browser
DEBUG - 2014-01-30 01:43:56 --> Total execution time: 0.0110
DEBUG - 2014-01-30 01:45:13 --> Config Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:45:13 --> URI Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Router Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Output Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Security Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Input Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:45:13 --> Language Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Loader Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Controller Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:45:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:45:13 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:45:13 --> Session Class Initialized
DEBUG - 2014-01-30 01:45:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:45:13 --> Session routines successfully run
DEBUG - 2014-01-30 01:45:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:45:13 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:45:13 --> Final output sent to browser
DEBUG - 2014-01-30 01:45:13 --> Total execution time: 0.0210
DEBUG - 2014-01-30 01:45:14 --> Config Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:45:14 --> URI Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Router Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Output Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Security Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Input Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:45:14 --> Language Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Loader Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Controller Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:45:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:45:14 --> Session Class Initialized
DEBUG - 2014-01-30 01:45:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:45:14 --> Session routines successfully run
DEBUG - 2014-01-30 01:45:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:45:14 --> Final output sent to browser
DEBUG - 2014-01-30 01:45:14 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:45:41 --> Config Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:45:41 --> URI Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Router Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Output Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Security Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Input Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:45:41 --> Language Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Loader Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Controller Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:45:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:45:41 --> Session Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:45:41 --> Session routines successfully run
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:45:41 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:45:41 --> Final output sent to browser
DEBUG - 2014-01-30 01:45:41 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:45:41 --> Config Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:45:41 --> URI Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Router Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Output Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Security Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Input Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:45:41 --> Language Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Loader Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Controller Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:45:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Model Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:45:41 --> Session Class Initialized
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:45:41 --> Session routines successfully run
DEBUG - 2014-01-30 01:45:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:45:41 --> Final output sent to browser
DEBUG - 2014-01-30 01:45:41 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:46:14 --> Config Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:46:14 --> URI Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Router Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Output Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Security Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Input Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:46:14 --> Language Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Loader Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Controller Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:46:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:46:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:46:14 --> Session Class Initialized
DEBUG - 2014-01-30 01:46:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:46:14 --> Session routines successfully run
DEBUG - 2014-01-30 01:46:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:46:14 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:46:14 --> Final output sent to browser
DEBUG - 2014-01-30 01:46:14 --> Total execution time: 0.0160
DEBUG - 2014-01-30 01:46:15 --> Config Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:46:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:46:15 --> URI Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Router Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Output Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Security Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Input Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:46:15 --> Language Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Loader Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Controller Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:46:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:46:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:46:15 --> Session Class Initialized
DEBUG - 2014-01-30 01:46:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:46:15 --> Session routines successfully run
DEBUG - 2014-01-30 01:46:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:46:15 --> Final output sent to browser
DEBUG - 2014-01-30 01:46:15 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:46:24 --> Config Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:46:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:46:24 --> URI Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Router Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Output Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Security Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Input Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:46:24 --> Language Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Loader Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Controller Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:46:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:46:24 --> Session Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:46:24 --> Session routines successfully run
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:46:24 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:46:24 --> Final output sent to browser
DEBUG - 2014-01-30 01:46:24 --> Total execution time: 0.0200
DEBUG - 2014-01-30 01:46:24 --> Config Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:46:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:46:24 --> URI Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Router Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Output Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Security Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Input Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:46:24 --> Language Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Loader Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Controller Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:46:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:46:24 --> Session Class Initialized
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:46:24 --> Session routines successfully run
DEBUG - 2014-01-30 01:46:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:46:24 --> Final output sent to browser
DEBUG - 2014-01-30 01:46:24 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:47:24 --> Config Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:47:24 --> URI Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Router Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Output Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Security Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Input Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:47:24 --> Language Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Loader Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Controller Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:47:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:47:24 --> Session Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:47:24 --> Session routines successfully run
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:47:24 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:47:24 --> Final output sent to browser
DEBUG - 2014-01-30 01:47:24 --> Total execution time: 0.0150
DEBUG - 2014-01-30 01:47:24 --> Config Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:47:24 --> URI Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Router Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Output Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Security Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Input Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:47:24 --> Language Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Loader Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Controller Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:47:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Model Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:47:24 --> Session Class Initialized
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:47:24 --> Session routines successfully run
DEBUG - 2014-01-30 01:47:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:47:24 --> Final output sent to browser
DEBUG - 2014-01-30 01:47:24 --> Total execution time: 0.0100
DEBUG - 2014-01-30 01:56:55 --> Config Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:56:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:56:55 --> URI Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Router Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Output Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Security Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Input Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:56:55 --> Language Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Loader Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Controller Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:56:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:56:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Model Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:56:55 --> Session Class Initialized
DEBUG - 2014-01-30 01:56:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:56:55 --> Session routines successfully run
DEBUG - 2014-01-30 01:56:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:56:55 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 01:56:55 --> Final output sent to browser
DEBUG - 2014-01-30 01:56:55 --> Total execution time: 0.0190
DEBUG - 2014-01-30 01:56:56 --> Config Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 01:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 01:56:56 --> URI Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Router Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Output Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Security Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Input Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 01:56:56 --> Language Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Loader Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Controller Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 01:56:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 01:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 01:56:56 --> Session Class Initialized
DEBUG - 2014-01-30 01:56:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 01:56:56 --> Session routines successfully run
DEBUG - 2014-01-30 01:56:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 01:56:56 --> Final output sent to browser
DEBUG - 2014-01-30 01:56:56 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:05:52 --> Config Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:05:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:05:52 --> URI Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Router Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Output Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Security Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Input Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:05:52 --> Language Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Loader Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Controller Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:05:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:05:52 --> Model Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Model Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Model Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:05:52 --> Session Class Initialized
DEBUG - 2014-01-30 02:05:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:05:52 --> Session routines successfully run
DEBUG - 2014-01-30 02:05:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:05:52 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:05:52 --> Final output sent to browser
DEBUG - 2014-01-30 02:05:52 --> Total execution time: 0.0210
DEBUG - 2014-01-30 02:05:54 --> Config Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:05:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:05:54 --> URI Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Router Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Output Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Security Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Input Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:05:54 --> Language Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Loader Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Controller Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:05:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:05:54 --> Model Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Model Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Model Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:05:54 --> Session Class Initialized
DEBUG - 2014-01-30 02:05:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:05:54 --> Session routines successfully run
DEBUG - 2014-01-30 02:05:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:05:54 --> Final output sent to browser
DEBUG - 2014-01-30 02:05:54 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:06:53 --> Config Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:06:53 --> URI Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Router Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Output Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Security Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Input Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:06:53 --> Language Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Loader Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Controller Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:06:53 --> Session Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:06:53 --> Session routines successfully run
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:06:53 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:06:53 --> Final output sent to browser
DEBUG - 2014-01-30 02:06:53 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:06:53 --> Config Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:06:53 --> URI Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Router Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Output Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Security Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Input Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:06:53 --> Language Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Loader Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Controller Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:06:53 --> Session Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:06:53 --> Session routines successfully run
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:06:53 --> Final output sent to browser
DEBUG - 2014-01-30 02:06:53 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:06:53 --> Config Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:06:53 --> URI Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Router Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Output Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Security Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Input Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:06:53 --> Language Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Loader Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Controller Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:06:53 --> Session Class Initialized
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:06:53 --> Session routines successfully run
DEBUG - 2014-01-30 02:06:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:06:53 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:06:53 --> Final output sent to browser
DEBUG - 2014-01-30 02:06:53 --> Total execution time: 0.0120
DEBUG - 2014-01-30 02:06:54 --> Config Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:06:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:06:54 --> URI Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Router Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Output Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Security Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Input Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:06:54 --> Language Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Loader Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Controller Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:06:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:06:54 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Model Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:06:54 --> Session Class Initialized
DEBUG - 2014-01-30 02:06:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:06:54 --> Session routines successfully run
DEBUG - 2014-01-30 02:06:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:06:54 --> Final output sent to browser
DEBUG - 2014-01-30 02:06:54 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:07:06 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:06 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:06 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:06 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:06 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:06 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:07:06 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:06 --> Total execution time: 0.0170
DEBUG - 2014-01-30 02:07:09 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:09 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:09 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:09 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:09 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:09 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:07:09 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:09 --> Total execution time: 0.0180
DEBUG - 2014-01-30 02:07:09 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:09 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:09 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:09 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:09 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:09 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:09 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:07:32 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:32 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:32 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:32 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:32 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:32 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:32 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:32 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:32 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:07:32 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:32 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:07:33 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:33 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:33 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:33 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:33 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:33 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:33 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:07:33 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:33 --> Total execution time: 0.0190
DEBUG - 2014-01-30 02:07:33 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:33 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:33 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:33 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:33 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:33 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:33 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:33 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:07:34 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:34 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:34 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:34 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:34 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:34 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:34 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:34 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:34 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:07:34 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:34 --> Total execution time: 0.0110
DEBUG - 2014-01-30 02:07:35 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:35 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:35 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:35 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:35 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:35 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:35 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:07:35 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:35 --> Total execution time: 0.0160
DEBUG - 2014-01-30 02:07:35 --> Config Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:07:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:07:35 --> URI Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Router Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Output Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Security Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Input Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:07:35 --> Language Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Loader Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Controller Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:07:35 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Model Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:07:35 --> Session Class Initialized
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:07:35 --> Session routines successfully run
DEBUG - 2014-01-30 02:07:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:07:35 --> Final output sent to browser
DEBUG - 2014-01-30 02:07:35 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:11:04 --> Config Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:11:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:11:04 --> URI Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Router Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Output Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Security Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Input Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:11:04 --> Language Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Loader Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Controller Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:11:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:11:04 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:11:04 --> Session Class Initialized
DEBUG - 2014-01-30 02:11:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:11:04 --> Session routines successfully run
DEBUG - 2014-01-30 02:11:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:11:04 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:11:04 --> Final output sent to browser
DEBUG - 2014-01-30 02:11:04 --> Total execution time: 0.0130
DEBUG - 2014-01-30 02:11:05 --> Config Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:11:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:11:05 --> URI Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Router Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Output Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Security Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Input Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:11:05 --> Language Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Loader Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Controller Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:11:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:11:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:11:05 --> Session Class Initialized
DEBUG - 2014-01-30 02:11:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:11:05 --> Session routines successfully run
DEBUG - 2014-01-30 02:11:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:11:05 --> Final output sent to browser
DEBUG - 2014-01-30 02:11:05 --> Total execution time: 0.0110
DEBUG - 2014-01-30 02:11:13 --> Config Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:11:13 --> URI Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Router Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Output Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Security Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Input Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:11:13 --> Language Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Loader Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Controller Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:11:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:11:13 --> Session Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:11:13 --> Session routines successfully run
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:11:13 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:11:13 --> Final output sent to browser
DEBUG - 2014-01-30 02:11:13 --> Total execution time: 0.0210
DEBUG - 2014-01-30 02:11:13 --> Config Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:11:13 --> URI Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Router Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Output Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Security Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Input Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:11:13 --> Language Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Loader Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Controller Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:11:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:11:13 --> Session Class Initialized
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:11:13 --> Session routines successfully run
DEBUG - 2014-01-30 02:11:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:11:13 --> Final output sent to browser
DEBUG - 2014-01-30 02:11:13 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:14:40 --> Config Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:14:40 --> URI Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Router Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Output Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Security Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Input Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:14:40 --> Language Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Loader Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Controller Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:14:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:14:40 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:14:40 --> Session Class Initialized
DEBUG - 2014-01-30 02:14:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:14:40 --> Session routines successfully run
DEBUG - 2014-01-30 02:14:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:14:40 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:14:40 --> Final output sent to browser
DEBUG - 2014-01-30 02:14:40 --> Total execution time: 0.0210
DEBUG - 2014-01-30 02:14:41 --> Config Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:14:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:14:41 --> URI Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Router Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Output Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Security Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Input Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:14:41 --> Language Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Loader Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Controller Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:14:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:14:41 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:14:41 --> Session Class Initialized
DEBUG - 2014-01-30 02:14:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:14:41 --> Session routines successfully run
DEBUG - 2014-01-30 02:14:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:14:41 --> Final output sent to browser
DEBUG - 2014-01-30 02:14:41 --> Total execution time: 0.0110
DEBUG - 2014-01-30 02:14:46 --> Config Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:14:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:14:46 --> URI Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Router Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Output Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Security Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Input Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:14:46 --> Language Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Loader Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Controller Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:14:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:14:46 --> Session Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:14:46 --> Session routines successfully run
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:14:46 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:14:46 --> Final output sent to browser
DEBUG - 2014-01-30 02:14:46 --> Total execution time: 0.0130
DEBUG - 2014-01-30 02:14:46 --> Config Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:14:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:14:46 --> URI Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Router Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Output Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Security Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Input Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:14:46 --> Language Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Loader Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Controller Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:14:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:14:46 --> Session Class Initialized
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:14:46 --> Session routines successfully run
DEBUG - 2014-01-30 02:14:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:14:46 --> Final output sent to browser
DEBUG - 2014-01-30 02:14:46 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:15:03 --> Config Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:15:03 --> URI Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Router Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Output Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Security Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Input Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:15:03 --> Language Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Loader Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Controller Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:15:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:15:03 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:15:03 --> Session Class Initialized
DEBUG - 2014-01-30 02:15:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:15:03 --> Session routines successfully run
DEBUG - 2014-01-30 02:15:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:15:03 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:15:03 --> Final output sent to browser
DEBUG - 2014-01-30 02:15:03 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:15:04 --> Config Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:15:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:15:04 --> URI Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Router Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Output Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Security Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Input Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:15:04 --> Language Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Loader Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Controller Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:15:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:15:04 --> Session Class Initialized
DEBUG - 2014-01-30 02:15:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:15:04 --> Session routines successfully run
DEBUG - 2014-01-30 02:15:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:15:04 --> Final output sent to browser
DEBUG - 2014-01-30 02:15:04 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:15:07 --> Config Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:15:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:15:07 --> URI Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Router Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Output Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Security Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Input Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:15:07 --> Language Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Loader Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Controller Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:15:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:15:07 --> Session Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:15:07 --> Session routines successfully run
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:15:07 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:15:07 --> Final output sent to browser
DEBUG - 2014-01-30 02:15:07 --> Total execution time: 0.0220
DEBUG - 2014-01-30 02:15:07 --> Config Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:15:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:15:07 --> URI Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Router Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Output Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Security Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Input Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:15:07 --> Language Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Loader Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Controller Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:15:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:15:07 --> Session Class Initialized
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:15:07 --> Session routines successfully run
DEBUG - 2014-01-30 02:15:07 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:15:07 --> Final output sent to browser
DEBUG - 2014-01-30 02:15:07 --> Total execution time: 0.0090
DEBUG - 2014-01-30 02:15:13 --> Config Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:15:13 --> URI Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Router Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Output Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Security Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Input Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:15:13 --> Language Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Loader Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Controller Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:15:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:15:13 --> Session Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:15:13 --> Session routines successfully run
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:15:13 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:15:13 --> Final output sent to browser
DEBUG - 2014-01-30 02:15:13 --> Total execution time: 0.0170
DEBUG - 2014-01-30 02:15:13 --> Config Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:15:13 --> URI Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Router Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Output Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Security Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Input Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:15:13 --> Language Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Loader Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Controller Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:15:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:15:13 --> Session Class Initialized
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:15:13 --> Session routines successfully run
DEBUG - 2014-01-30 02:15:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:15:13 --> Final output sent to browser
DEBUG - 2014-01-30 02:15:13 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:16:06 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:06 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:06 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:06 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:06 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:06 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:06 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:16:06 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:06 --> Total execution time: 0.0120
DEBUG - 2014-01-30 02:16:07 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:07 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:07 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:07 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:07 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:07 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:07 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:07 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:07 --> Total execution time: 0.0110
DEBUG - 2014-01-30 02:16:09 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:09 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:09 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:09 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:09 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:09 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:16:09 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:09 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:16:11 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:11 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:11 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:11 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:11 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:11 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:11 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:16:11 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:11 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:16:11 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:11 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:11 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:11 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:11 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:11 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:11 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:11 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:16:20 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:20 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:20 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:20 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:20 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:20 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:20 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:16:20 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:20 --> Total execution time: 0.0210
DEBUG - 2014-01-30 02:16:20 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:20 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:20 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:20 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:20 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:20 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:20 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:20 --> Total execution time: 0.0110
DEBUG - 2014-01-30 02:16:28 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:28 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:28 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:28 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:28 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:28 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:28 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:16:28 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:28 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:16:29 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:29 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:29 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:29 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:29 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:29 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:29 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:29 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:16:38 --> Config Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:16:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:16:38 --> URI Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Router Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Output Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Security Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Input Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:16:38 --> Language Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Loader Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Controller Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:16:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:16:38 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Model Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:16:38 --> Session Class Initialized
DEBUG - 2014-01-30 02:16:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:16:38 --> Session routines successfully run
DEBUG - 2014-01-30 02:16:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:16:38 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:16:38 --> Final output sent to browser
DEBUG - 2014-01-30 02:16:38 --> Total execution time: 0.0180
DEBUG - 2014-01-30 02:17:05 --> Config Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:17:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:17:05 --> URI Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Router Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Output Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Security Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Input Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:17:05 --> Language Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Loader Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Controller Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:17:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:17:05 --> Session Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:17:05 --> Session routines successfully run
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:17:05 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:17:05 --> Final output sent to browser
DEBUG - 2014-01-30 02:17:05 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:17:05 --> Config Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:17:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:17:05 --> URI Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Router Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Output Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Security Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Input Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:17:05 --> Language Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Loader Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Controller Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:17:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:17:05 --> Session Class Initialized
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:17:05 --> Session routines successfully run
DEBUG - 2014-01-30 02:17:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:17:05 --> Final output sent to browser
DEBUG - 2014-01-30 02:17:05 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:17:12 --> Config Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:17:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:17:12 --> URI Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Router Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Output Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Security Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Input Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:17:12 --> Language Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Loader Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Controller Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:17:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:17:12 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:17:12 --> Session Class Initialized
DEBUG - 2014-01-30 02:17:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:17:12 --> Session routines successfully run
DEBUG - 2014-01-30 02:17:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:17:12 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:17:12 --> Final output sent to browser
DEBUG - 2014-01-30 02:17:12 --> Total execution time: 0.0120
DEBUG - 2014-01-30 02:17:13 --> Config Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:17:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:17:13 --> URI Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Router Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Output Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Security Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Input Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:17:13 --> Language Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Loader Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Controller Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:17:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:17:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:17:13 --> Session Class Initialized
DEBUG - 2014-01-30 02:17:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:17:13 --> Session routines successfully run
DEBUG - 2014-01-30 02:17:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:17:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:17:13 --> Final output sent to browser
DEBUG - 2014-01-30 02:17:13 --> Total execution time: 0.0190
DEBUG - 2014-01-30 02:17:15 --> Config Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:17:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:17:15 --> URI Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Router Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Output Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Security Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Input Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:17:15 --> Language Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Loader Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Controller Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:17:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:17:15 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:17:15 --> Session Class Initialized
DEBUG - 2014-01-30 02:17:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:17:15 --> Session routines successfully run
DEBUG - 2014-01-30 02:17:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:17:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:17:15 --> Final output sent to browser
DEBUG - 2014-01-30 02:17:15 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:17:17 --> Config Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:17:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:17:17 --> URI Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Router Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Output Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Security Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Input Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:17:17 --> Language Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Loader Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Controller Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:17:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:17:17 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Model Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:17:17 --> Session Class Initialized
DEBUG - 2014-01-30 02:17:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:17:17 --> Session routines successfully run
DEBUG - 2014-01-30 02:17:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:17:17 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:17:17 --> Final output sent to browser
DEBUG - 2014-01-30 02:17:17 --> Total execution time: 0.0170
DEBUG - 2014-01-30 02:18:08 --> Config Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:18:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:18:08 --> URI Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Router Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Output Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Security Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Input Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:18:08 --> Language Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Loader Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Controller Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:18:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:18:08 --> Model Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Model Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Model Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:18:08 --> Session Class Initialized
DEBUG - 2014-01-30 02:18:08 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:18:08 --> Session routines successfully run
DEBUG - 2014-01-30 02:18:08 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:18:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:18:08 --> Final output sent to browser
DEBUG - 2014-01-30 02:18:08 --> Total execution time: 0.0210
DEBUG - 2014-01-30 02:19:18 --> Config Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:19:18 --> URI Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Router Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Output Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Security Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Input Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:19:18 --> Language Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Loader Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Controller Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:19:18 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:19:18 --> Session Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:19:18 --> Session routines successfully run
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:19:18 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:19:18 --> Final output sent to browser
DEBUG - 2014-01-30 02:19:18 --> Total execution time: 0.0210
DEBUG - 2014-01-30 02:19:18 --> Config Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:19:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:19:18 --> URI Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Router Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Output Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Security Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Input Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:19:18 --> Language Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Loader Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Controller Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:19:18 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:19:18 --> Session Class Initialized
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:19:18 --> Session routines successfully run
DEBUG - 2014-01-30 02:19:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:19:18 --> Final output sent to browser
DEBUG - 2014-01-30 02:19:18 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:19:36 --> Config Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:19:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:19:36 --> URI Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Router Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Output Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Security Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Input Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:19:36 --> Language Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Loader Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Controller Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:19:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:19:36 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:19:36 --> Session Class Initialized
DEBUG - 2014-01-30 02:19:36 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:19:36 --> Session routines successfully run
DEBUG - 2014-01-30 02:19:36 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:19:36 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 02:19:36 --> Final output sent to browser
DEBUG - 2014-01-30 02:19:36 --> Total execution time: 0.0170
DEBUG - 2014-01-30 02:19:37 --> Config Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:19:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:19:37 --> URI Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Router Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Output Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Security Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Input Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:19:37 --> Language Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Loader Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Controller Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:19:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:19:37 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Model Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:19:37 --> Session Class Initialized
DEBUG - 2014-01-30 02:19:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:19:37 --> Session routines successfully run
DEBUG - 2014-01-30 02:19:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:19:37 --> Final output sent to browser
DEBUG - 2014-01-30 02:19:37 --> Total execution time: 0.0100
DEBUG - 2014-01-30 02:25:28 --> Config Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:25:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:25:28 --> URI Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Router Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Output Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Security Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Input Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:25:28 --> Language Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Loader Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Controller Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:25:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:25:28 --> Model Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Model Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Model Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:25:28 --> Session Class Initialized
DEBUG - 2014-01-30 02:25:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:25:28 --> Session routines successfully run
DEBUG - 2014-01-30 02:25:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:25:28 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:25:28 --> Final output sent to browser
DEBUG - 2014-01-30 02:25:28 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:25:30 --> Config Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:25:30 --> URI Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Router Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Output Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Security Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Input Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:25:30 --> Language Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Loader Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Controller Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:25:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:25:30 --> Model Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Model Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Model Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:25:30 --> Session Class Initialized
DEBUG - 2014-01-30 02:25:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:25:30 --> Session routines successfully run
DEBUG - 2014-01-30 02:25:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:25:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:25:30 --> Final output sent to browser
DEBUG - 2014-01-30 02:25:30 --> Total execution time: 0.0200
DEBUG - 2014-01-30 02:34:45 --> Config Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:34:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:34:45 --> URI Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Router Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Output Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Security Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Input Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:34:45 --> Language Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Loader Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Controller Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:34:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:34:45 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:34:45 --> Session Class Initialized
DEBUG - 2014-01-30 02:34:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:34:45 --> Session routines successfully run
DEBUG - 2014-01-30 02:34:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:34:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:34:45 --> Final output sent to browser
DEBUG - 2014-01-30 02:34:45 --> Total execution time: 0.0190
DEBUG - 2014-01-30 02:34:46 --> Config Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:34:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:34:46 --> URI Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Router Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Output Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Security Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Input Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:34:46 --> Language Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Loader Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Controller Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:34:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:34:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:34:46 --> Session Class Initialized
DEBUG - 2014-01-30 02:34:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:34:46 --> Session routines successfully run
DEBUG - 2014-01-30 02:34:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:34:46 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:34:46 --> Final output sent to browser
DEBUG - 2014-01-30 02:34:46 --> Total execution time: 0.0140
DEBUG - 2014-01-30 02:34:47 --> Config Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:34:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:34:47 --> URI Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Router Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Output Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Security Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Input Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:34:47 --> Language Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Loader Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Controller Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:34:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:34:47 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:34:47 --> Session Class Initialized
DEBUG - 2014-01-30 02:34:47 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:34:47 --> Session routines successfully run
DEBUG - 2014-01-30 02:34:47 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:34:47 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:34:47 --> Final output sent to browser
DEBUG - 2014-01-30 02:34:47 --> Total execution time: 0.0140
DEBUG - 2014-01-30 02:34:48 --> Config Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:34:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:34:48 --> URI Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Router Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Output Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Security Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Input Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:34:48 --> Language Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Loader Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Controller Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:34:48 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:34:48 --> Session Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:34:48 --> Session routines successfully run
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:34:48 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:34:48 --> Final output sent to browser
DEBUG - 2014-01-30 02:34:48 --> Total execution time: 0.0190
DEBUG - 2014-01-30 02:34:48 --> Config Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 02:34:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 02:34:48 --> URI Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Router Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Output Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Security Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Input Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 02:34:48 --> Language Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Loader Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Controller Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 02:34:48 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Model Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 02:34:48 --> Session Class Initialized
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 02:34:48 --> Session routines successfully run
DEBUG - 2014-01-30 02:34:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 02:34:48 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 02:34:48 --> Final output sent to browser
DEBUG - 2014-01-30 02:34:48 --> Total execution time: 0.0180
DEBUG - 2014-01-30 13:51:24 --> Config Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 13:51:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 13:51:24 --> URI Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Router Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Output Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Security Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Input Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 13:51:24 --> Language Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Loader Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Controller Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 13:51:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 13:51:24 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Database Driver Class Initialized
ERROR - 2014-01-30 13:51:24 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-30 13:51:24 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 13:51:24 --> Session Class Initialized
DEBUG - 2014-01-30 13:51:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 13:51:24 --> A session cookie was not found.
DEBUG - 2014-01-30 13:51:24 --> Session routines successfully run
DEBUG - 2014-01-30 13:51:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 13:51:24 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 13:51:24 --> Final output sent to browser
DEBUG - 2014-01-30 13:51:24 --> Total execution time: 0.0380
DEBUG - 2014-01-30 13:51:26 --> Config Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 13:51:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 13:51:26 --> URI Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Router Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Output Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Security Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Input Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 13:51:26 --> Language Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Loader Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Controller Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 13:51:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 13:51:26 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Database Driver Class Initialized
ERROR - 2014-01-30 13:51:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-30 13:51:26 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 13:51:26 --> Session Class Initialized
DEBUG - 2014-01-30 13:51:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 13:51:26 --> Session routines successfully run
DEBUG - 2014-01-30 13:51:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 13:51:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 13:51:26 --> Final output sent to browser
DEBUG - 2014-01-30 13:51:26 --> Total execution time: 0.0280
DEBUG - 2014-01-30 13:51:27 --> Config Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 13:51:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 13:51:27 --> URI Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Router Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Output Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Security Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Input Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 13:51:27 --> Language Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Loader Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Controller Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 13:51:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 13:51:27 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Database Driver Class Initialized
ERROR - 2014-01-30 13:51:27 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-30 13:51:27 --> Model Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 13:51:27 --> Session Class Initialized
DEBUG - 2014-01-30 13:51:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 13:51:27 --> Session routines successfully run
DEBUG - 2014-01-30 13:51:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 13:51:27 --> Final output sent to browser
DEBUG - 2014-01-30 13:51:27 --> Total execution time: 0.0270
DEBUG - 2014-01-30 18:53:01 --> Config Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 18:53:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 18:53:01 --> URI Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Router Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Output Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Security Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Input Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 18:53:01 --> Language Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Loader Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Controller Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 18:53:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 18:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 18:53:01 --> Session Class Initialized
DEBUG - 2014-01-30 18:53:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 18:53:01 --> A session cookie was not found.
DEBUG - 2014-01-30 18:53:01 --> Session routines successfully run
DEBUG - 2014-01-30 18:53:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 18:53:01 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 18:53:01 --> Final output sent to browser
DEBUG - 2014-01-30 18:53:01 --> Total execution time: 0.0170
DEBUG - 2014-01-30 18:53:03 --> Config Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 18:53:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 18:53:03 --> URI Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Router Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Output Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Security Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Input Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 18:53:03 --> Language Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Loader Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Controller Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 18:53:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 18:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 18:53:03 --> Session Class Initialized
DEBUG - 2014-01-30 18:53:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 18:53:03 --> Session routines successfully run
DEBUG - 2014-01-30 18:53:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 18:53:03 --> Final output sent to browser
DEBUG - 2014-01-30 18:53:03 --> Total execution time: 0.0110
DEBUG - 2014-01-30 19:00:41 --> Config Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:00:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:00:41 --> URI Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Router Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Output Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Security Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Input Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:00:41 --> Language Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Loader Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Controller Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:00:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:00:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:00:41 --> Session Class Initialized
DEBUG - 2014-01-30 19:00:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:00:41 --> Session routines successfully run
DEBUG - 2014-01-30 19:00:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:00:41 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:00:41 --> Final output sent to browser
DEBUG - 2014-01-30 19:00:41 --> Total execution time: 0.0750
DEBUG - 2014-01-30 19:00:42 --> Config Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:00:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:00:42 --> URI Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Router Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Output Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Security Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Input Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:00:42 --> Language Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Loader Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Controller Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:00:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:00:42 --> Model Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Model Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Model Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:00:42 --> Session Class Initialized
DEBUG - 2014-01-30 19:00:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:00:42 --> Session routines successfully run
DEBUG - 2014-01-30 19:00:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:00:42 --> Final output sent to browser
DEBUG - 2014-01-30 19:00:42 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:04:01 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:01 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:01 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:01 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:01 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:01 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:01 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:04:01 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:01 --> Total execution time: 0.0220
DEBUG - 2014-01-30 19:04:02 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:02 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:02 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:02 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:02 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:02 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:02 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:02 --> Total execution time: 0.0110
DEBUG - 2014-01-30 19:04:19 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:19 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:19 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:19 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:19 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:04:19 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:19 --> Total execution time: 0.0210
DEBUG - 2014-01-30 19:04:20 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:20 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:20 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:20 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:20 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:20 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:20 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:04:42 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:42 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:42 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:42 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:42 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:42 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:42 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:04:42 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:42 --> Total execution time: 0.0220
DEBUG - 2014-01-30 19:04:43 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:43 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:43 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:43 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:43 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:43 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:43 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:43 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:43 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:43 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:04:58 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:58 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:58 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:58 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:58 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:58 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:58 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:04:58 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:58 --> Total execution time: 0.0200
DEBUG - 2014-01-30 19:04:59 --> Config Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:04:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:04:59 --> URI Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Router Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Output Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Security Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Input Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:04:59 --> Language Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Loader Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Controller Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:04:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:04:59 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Model Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:04:59 --> Session Class Initialized
DEBUG - 2014-01-30 19:04:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:04:59 --> Session routines successfully run
DEBUG - 2014-01-30 19:04:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:04:59 --> Final output sent to browser
DEBUG - 2014-01-30 19:04:59 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:05:41 --> Config Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:05:41 --> URI Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Router Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Output Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Security Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Input Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:05:41 --> Language Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Loader Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Controller Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:05:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:05:41 --> Session Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:05:41 --> Session routines successfully run
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:05:41 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:05:41 --> Final output sent to browser
DEBUG - 2014-01-30 19:05:41 --> Total execution time: 0.0200
DEBUG - 2014-01-30 19:05:41 --> Config Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:05:41 --> URI Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Router Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Output Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Security Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Input Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:05:41 --> Language Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Loader Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Controller Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:05:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Model Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:05:41 --> Session Class Initialized
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:05:41 --> Session routines successfully run
DEBUG - 2014-01-30 19:05:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:05:41 --> Final output sent to browser
DEBUG - 2014-01-30 19:05:41 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:06:28 --> Config Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:06:28 --> URI Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Router Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Output Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Security Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Input Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:06:28 --> Language Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Loader Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Controller Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:06:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:06:28 --> Model Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Model Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Model Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:06:28 --> Session Class Initialized
DEBUG - 2014-01-30 19:06:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:06:28 --> Session routines successfully run
DEBUG - 2014-01-30 19:06:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:06:28 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:06:28 --> Final output sent to browser
DEBUG - 2014-01-30 19:06:28 --> Total execution time: 0.0210
DEBUG - 2014-01-30 19:06:29 --> Config Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:06:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:06:29 --> URI Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Router Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Output Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Security Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Input Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:06:29 --> Language Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Loader Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Controller Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:06:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:06:29 --> Model Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Model Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Model Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:06:29 --> Session Class Initialized
DEBUG - 2014-01-30 19:06:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:06:29 --> Session routines successfully run
DEBUG - 2014-01-30 19:06:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:06:29 --> Final output sent to browser
DEBUG - 2014-01-30 19:06:29 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:08:38 --> Config Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:08:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:08:38 --> URI Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Router Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Output Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Security Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Input Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:08:38 --> Language Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Loader Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Controller Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:08:38 --> Model Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Model Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Model Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:08:38 --> Session Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:08:38 --> Session routines successfully run
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:08:38 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:08:38 --> Final output sent to browser
DEBUG - 2014-01-30 19:08:38 --> Total execution time: 0.0200
DEBUG - 2014-01-30 19:08:38 --> Config Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:08:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:08:38 --> URI Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Router Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Output Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Security Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Input Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:08:38 --> Language Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Loader Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Controller Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:08:38 --> Model Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Model Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Model Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:08:38 --> Session Class Initialized
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:08:38 --> Session routines successfully run
DEBUG - 2014-01-30 19:08:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:08:38 --> Final output sent to browser
DEBUG - 2014-01-30 19:08:38 --> Total execution time: 0.0110
DEBUG - 2014-01-30 19:09:26 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:26 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:26 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:26 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:26 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:26 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:09:26 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:26 --> Total execution time: 0.0160
DEBUG - 2014-01-30 19:09:27 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:27 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:27 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:27 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:27 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:27 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:27 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:27 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:09:39 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:39 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:39 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:39 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:39 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:39 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:39 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:39 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:39 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:09:39 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:39 --> Total execution time: 0.0170
DEBUG - 2014-01-30 19:09:40 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:40 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:40 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:40 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:40 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:40 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:40 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:40 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:09:50 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:50 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:50 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:50 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:50 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:50 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:50 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:09:50 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:50 --> Total execution time: 0.0220
DEBUG - 2014-01-30 19:09:51 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:51 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:51 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:51 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:51 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:51 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:09:51 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:51 --> Total execution time: 0.0130
DEBUG - 2014-01-30 19:09:52 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:52 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:52 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:52 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:52 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:52 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:52 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:09:52 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:52 --> Total execution time: 0.0200
DEBUG - 2014-01-30 19:09:54 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:54 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:54 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:54 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:54 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:54 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:54 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:09:54 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:54 --> Total execution time: 0.0190
DEBUG - 2014-01-30 19:09:54 --> Config Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:09:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:09:54 --> URI Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Router Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Output Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Security Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Input Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:09:54 --> Language Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Loader Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Controller Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:09:54 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Model Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:09:54 --> Session Class Initialized
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:09:54 --> Session routines successfully run
DEBUG - 2014-01-30 19:09:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:09:54 --> Final output sent to browser
DEBUG - 2014-01-30 19:09:54 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:10:11 --> Config Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:10:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:10:11 --> URI Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Router Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Output Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Security Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Input Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:10:11 --> Language Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Loader Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Controller Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:10:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:10:11 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:10:11 --> Session Class Initialized
DEBUG - 2014-01-30 19:10:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:10:11 --> Session routines successfully run
DEBUG - 2014-01-30 19:10:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:10:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:10:11 --> Final output sent to browser
DEBUG - 2014-01-30 19:10:11 --> Total execution time: 0.0210
DEBUG - 2014-01-30 19:10:12 --> Config Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:10:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:10:12 --> URI Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Router Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Output Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Security Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Input Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:10:12 --> Language Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Loader Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Controller Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:10:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:10:12 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:10:12 --> Session Class Initialized
DEBUG - 2014-01-30 19:10:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:10:12 --> Session routines successfully run
DEBUG - 2014-01-30 19:10:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:10:12 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:10:12 --> Final output sent to browser
DEBUG - 2014-01-30 19:10:12 --> Total execution time: 0.0200
DEBUG - 2014-01-30 19:10:13 --> Config Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:10:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:10:13 --> URI Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Router Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Output Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Security Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Input Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:10:13 --> Language Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Loader Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Controller Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:10:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:10:13 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:10:13 --> Session Class Initialized
DEBUG - 2014-01-30 19:10:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:10:13 --> Session routines successfully run
DEBUG - 2014-01-30 19:10:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:10:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:10:13 --> Final output sent to browser
DEBUG - 2014-01-30 19:10:13 --> Total execution time: 0.0180
DEBUG - 2014-01-30 19:10:16 --> Config Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:10:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:10:16 --> URI Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Router Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Output Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Security Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Input Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:10:16 --> Language Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Loader Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Controller Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:10:16 --> Session Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:10:16 --> Session routines successfully run
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:10:16 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 19:10:16 --> Final output sent to browser
DEBUG - 2014-01-30 19:10:16 --> Total execution time: 0.0200
DEBUG - 2014-01-30 19:10:16 --> Config Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:10:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:10:16 --> URI Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Router Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Output Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Security Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Input Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:10:16 --> Language Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Loader Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Controller Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:10:16 --> Session Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:10:16 --> Session routines successfully run
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:10:16 --> Final output sent to browser
DEBUG - 2014-01-30 19:10:16 --> Total execution time: 0.0100
DEBUG - 2014-01-30 19:10:16 --> Config Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:10:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:10:16 --> URI Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Router Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Output Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Security Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Input Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:10:16 --> Language Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Loader Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Controller Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Model Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:10:16 --> Session Class Initialized
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:10:16 --> Session routines successfully run
DEBUG - 2014-01-30 19:10:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:10:16 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:10:16 --> Final output sent to browser
DEBUG - 2014-01-30 19:10:16 --> Total execution time: 0.0160
DEBUG - 2014-01-30 19:15:53 --> Config Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:15:53 --> URI Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Router Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Output Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Security Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Input Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:15:53 --> Language Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Loader Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Controller Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:15:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:15:53 --> Model Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Model Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Model Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:15:53 --> Session Class Initialized
DEBUG - 2014-01-30 19:15:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:15:53 --> Session routines successfully run
DEBUG - 2014-01-30 19:15:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:15:53 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:15:53 --> Final output sent to browser
DEBUG - 2014-01-30 19:15:53 --> Total execution time: 0.0230
DEBUG - 2014-01-30 19:18:35 --> Config Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:18:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:18:35 --> URI Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Router Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Output Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Security Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Input Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:18:35 --> Language Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Loader Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Controller Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:18:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:18:35 --> Model Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Model Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Model Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:18:35 --> Session Class Initialized
DEBUG - 2014-01-30 19:18:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:18:35 --> Session routines successfully run
DEBUG - 2014-01-30 19:18:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:18:35 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 19:18:35 --> Final output sent to browser
DEBUG - 2014-01-30 19:18:35 --> Total execution time: 0.0120
DEBUG - 2014-01-30 19:42:20 --> Config Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:42:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:42:20 --> URI Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Router Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Output Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Security Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Input Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:42:20 --> Language Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Loader Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Controller Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:42:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:42:20 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:42:20 --> Session Class Initialized
DEBUG - 2014-01-30 19:42:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:42:20 --> Session routines successfully run
DEBUG - 2014-01-30 19:42:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:42:20 --> Final output sent to browser
DEBUG - 2014-01-30 19:42:20 --> Total execution time: 0.0210
DEBUG - 2014-01-30 19:42:21 --> Config Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:42:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:42:21 --> URI Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Router Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Output Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Security Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Input Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:42:21 --> Language Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Loader Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Controller Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:42:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:42:21 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:42:21 --> Session Class Initialized
DEBUG - 2014-01-30 19:42:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:42:21 --> Session routines successfully run
DEBUG - 2014-01-30 19:42:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:42:21 --> Final output sent to browser
DEBUG - 2014-01-30 19:42:21 --> Total execution time: 0.0140
DEBUG - 2014-01-30 19:42:31 --> Config Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 19:42:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 19:42:31 --> URI Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Router Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Output Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Security Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Input Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 19:42:31 --> Language Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Loader Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Controller Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 19:42:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 19:42:31 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Model Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 19:42:31 --> Session Class Initialized
DEBUG - 2014-01-30 19:42:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 19:42:31 --> Session routines successfully run
DEBUG - 2014-01-30 19:42:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 19:42:31 --> Final output sent to browser
DEBUG - 2014-01-30 19:42:31 --> Total execution time: 0.0130
DEBUG - 2014-01-30 20:08:05 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:05 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:05 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:05 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:05 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:05 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-01-30 20:08:05 --> Severity: Notice  --> Undefined variable: showAll F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\report_model.php 29
ERROR - 2014-01-30 20:08:05 --> Severity: Notice  --> Undefined variable: showAll F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\report_model.php 35
ERROR - 2014-01-30 20:08:05 --> Severity: Notice  --> Undefined variable: showAll F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\report_model.php 41
ERROR - 2014-01-30 20:08:05 --> Severity: Notice  --> Undefined variable: showAll F:\ZServer61\Apache2\htdocs\mantrackr_service\application\models\report_model.php 47
DEBUG - 2014-01-30 20:08:05 --> Final output sent to browser
DEBUG - 2014-01-30 20:08:05 --> Total execution time: 0.0240
DEBUG - 2014-01-30 20:08:24 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:24 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:24 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:24 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:24 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:24 --> Final output sent to browser
DEBUG - 2014-01-30 20:08:24 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:08:26 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:26 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:26 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:26 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:26 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:26 --> Final output sent to browser
DEBUG - 2014-01-30 20:08:26 --> Total execution time: 0.0160
DEBUG - 2014-01-30 20:08:33 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:33 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:33 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:33 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:33 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:33 --> Final output sent to browser
DEBUG - 2014-01-30 20:08:33 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:08:35 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:35 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:35 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:35 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:35 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:35 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:35 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:35 --> Final output sent to browser
DEBUG - 2014-01-30 20:08:35 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:08:44 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:44 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:44 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:44 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:44 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:44 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:44 --> Final output sent to browser
DEBUG - 2014-01-30 20:08:44 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:08:48 --> Config Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:08:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:08:48 --> URI Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Router Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Output Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Security Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Input Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:08:48 --> Language Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Loader Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Controller Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:08:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:08:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:08:48 --> Session Class Initialized
DEBUG - 2014-01-30 20:08:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:08:48 --> Session routines successfully run
DEBUG - 2014-01-30 20:08:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:08:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:08:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:09:55 --> Final output sent to browser
DEBUG - 2014-01-30 20:09:55 --> Total execution time: 66.6768
DEBUG - 2014-01-30 20:10:14 --> Config Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:10:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:10:14 --> URI Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Router Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Output Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Security Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Input Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:10:14 --> Language Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Loader Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Controller Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:10:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:10:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:10:14 --> Session Class Initialized
DEBUG - 2014-01-30 20:10:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:10:14 --> Session routines successfully run
DEBUG - 2014-01-30 20:10:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:10:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:10:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:10:29 --> Final output sent to browser
DEBUG - 2014-01-30 20:10:29 --> Total execution time: 15.2809
DEBUG - 2014-01-30 20:11:51 --> Config Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:11:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:11:51 --> URI Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Router Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Output Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Security Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Input Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:11:51 --> Language Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Loader Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Controller Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:11:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:11:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:11:51 --> Session Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:11:51 --> Session routines successfully run
DEBUG - 2014-01-30 20:11:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:11:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:11:51 --> Final output sent to browser
DEBUG - 2014-01-30 20:11:51 --> Total execution time: 0.0450
DEBUG - 2014-01-30 20:11:56 --> Config Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:11:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:11:56 --> URI Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Router Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Output Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Security Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Input Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:11:56 --> Language Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Loader Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Controller Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:11:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:11:56 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Model Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:11:56 --> Session Class Initialized
DEBUG - 2014-01-30 20:11:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:11:56 --> Session routines successfully run
DEBUG - 2014-01-30 20:11:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:13:46 --> Config Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:13:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:13:46 --> URI Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Router Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Output Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Security Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Input Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:13:46 --> Language Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Loader Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Controller Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:13:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:13:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:13:46 --> Session Class Initialized
DEBUG - 2014-01-30 20:13:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:13:46 --> Session routines successfully run
DEBUG - 2014-01-30 20:13:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:14:04 --> Config Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:14:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:14:04 --> URI Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Router Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Output Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Security Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Input Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:14:04 --> Language Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Loader Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Controller Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:14:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:14:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:14:04 --> Session Class Initialized
DEBUG - 2014-01-30 20:14:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:14:04 --> Session routines successfully run
DEBUG - 2014-01-30 20:14:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:14:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:14:48 --> Final output sent to browser
DEBUG - 2014-01-30 20:14:48 --> Total execution time: 43.6075
DEBUG - 2014-01-30 20:14:56 --> Config Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:14:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:14:56 --> URI Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Router Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Output Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Security Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Input Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:14:56 --> Language Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Loader Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Controller Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:14:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:14:56 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Model Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:14:56 --> Session Class Initialized
DEBUG - 2014-01-30 20:14:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:14:56 --> Session routines successfully run
DEBUG - 2014-01-30 20:14:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:15:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:16 --> Final output sent to browser
DEBUG - 2014-01-30 20:15:16 --> Total execution time: 19.7861
DEBUG - 2014-01-30 20:15:29 --> Config Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:15:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:15:29 --> URI Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Router Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Output Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Security Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Input Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:15:29 --> Language Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Loader Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Controller Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:15:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:15:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:29 --> Session Class Initialized
DEBUG - 2014-01-30 20:15:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:15:29 --> Session routines successfully run
DEBUG - 2014-01-30 20:15:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:15:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:48 --> Final output sent to browser
DEBUG - 2014-01-30 20:15:48 --> Total execution time: 18.9071
DEBUG - 2014-01-30 20:15:55 --> Config Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:15:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:15:55 --> URI Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Router Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Output Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Security Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Input Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:15:55 --> Language Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Loader Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Controller Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:15:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:15:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:55 --> Session Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:15:55 --> Session routines successfully run
DEBUG - 2014-01-30 20:15:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:15:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:55 --> Final output sent to browser
DEBUG - 2014-01-30 20:15:55 --> Total execution time: 0.0130
DEBUG - 2014-01-30 20:15:59 --> Config Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:15:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:15:59 --> URI Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Router Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Output Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Security Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Input Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:15:59 --> Language Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Loader Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Controller Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:15:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:15:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:59 --> Session Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:15:59 --> Session routines successfully run
DEBUG - 2014-01-30 20:15:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:15:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:15:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:15:59 --> Final output sent to browser
DEBUG - 2014-01-30 20:15:59 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:16:01 --> Config Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:16:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:16:01 --> URI Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Router Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Output Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Security Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Input Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:16:01 --> Language Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Loader Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Controller Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:16:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:16:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:16:01 --> Session Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:16:01 --> Session routines successfully run
DEBUG - 2014-01-30 20:16:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:16:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:16:01 --> Final output sent to browser
DEBUG - 2014-01-30 20:16:01 --> Total execution time: 0.0160
DEBUG - 2014-01-30 20:16:03 --> Config Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:16:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:16:03 --> URI Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Router Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Output Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Security Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Input Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:16:03 --> Language Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Loader Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Controller Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:16:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:16:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:16:03 --> Session Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:16:03 --> Session routines successfully run
DEBUG - 2014-01-30 20:16:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:16:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:16:03 --> Final output sent to browser
DEBUG - 2014-01-30 20:16:03 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:16:05 --> Config Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:16:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:16:05 --> URI Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Router Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Output Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Security Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Input Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:16:05 --> Language Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Loader Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Controller Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:16:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:16:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:16:05 --> Session Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:16:05 --> Session routines successfully run
DEBUG - 2014-01-30 20:16:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:16:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:16:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:16:05 --> Final output sent to browser
DEBUG - 2014-01-30 20:16:05 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:18:21 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:21 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:21 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:21 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:21 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:18:21 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:21 --> Total execution time: 0.0230
DEBUG - 2014-01-30 20:18:23 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:23 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:23 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:23 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:23 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:23 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:23 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:23 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:18:26 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:26 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:26 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:26 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:26 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:18:26 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:26 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:18:27 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:27 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:27 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:27 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:27 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:27 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:27 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:18:39 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:39 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:39 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:39 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:39 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:39 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:39 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:18:39 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:39 --> Total execution time: 0.0170
DEBUG - 2014-01-30 20:18:40 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:40 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:40 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:40 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:40 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:40 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:40 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:18:43 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:43 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:43 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:43 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:43 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:43 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:43 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:43 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:18:47 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:47 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:47 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:47 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:47 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:47 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:47 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:47 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:18:48 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:48 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:48 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:48 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:48 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:48 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:48 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:18:50 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:50 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:50 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:50 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:50 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:50 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:50 --> Total execution time: 0.0150
DEBUG - 2014-01-30 20:18:51 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:51 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:51 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:51 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:51 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:51 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:51 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:18:52 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:52 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:52 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:52 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:52 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:52 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:52 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:18:53 --> Config Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:18:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:18:53 --> URI Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Router Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Output Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Security Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Input Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:18:53 --> Language Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Loader Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Controller Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:18:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:18:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:53 --> Session Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:18:53 --> Session routines successfully run
DEBUG - 2014-01-30 20:18:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:18:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:18:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:18:53 --> Final output sent to browser
DEBUG - 2014-01-30 20:18:53 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:21:39 --> Config Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:21:39 --> URI Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Router Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Output Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Security Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Input Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:21:39 --> Language Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Loader Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Controller Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:21:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:21:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:39 --> Session Class Initialized
DEBUG - 2014-01-30 20:21:39 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:21:39 --> Session routines successfully run
DEBUG - 2014-01-30 20:21:39 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:21:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:21:39 --> Final output sent to browser
DEBUG - 2014-01-30 20:21:39 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:21:40 --> Config Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:21:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:21:40 --> URI Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Router Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Output Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Security Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Input Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:21:40 --> Language Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Loader Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Controller Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:21:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:40 --> Session Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:21:40 --> Session routines successfully run
DEBUG - 2014-01-30 20:21:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:21:40 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:40 --> Final output sent to browser
DEBUG - 2014-01-30 20:21:40 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:21:42 --> Config Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:21:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:21:42 --> URI Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Router Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Output Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Security Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Input Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:21:42 --> Language Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Loader Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Controller Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:21:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:42 --> Session Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:21:42 --> Session routines successfully run
DEBUG - 2014-01-30 20:21:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:21:42 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:42 --> Final output sent to browser
DEBUG - 2014-01-30 20:21:42 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:21:44 --> Config Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:21:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:21:44 --> URI Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Router Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Output Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Security Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Input Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:21:44 --> Language Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Loader Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Controller Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:21:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:21:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:44 --> Session Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:21:44 --> Session routines successfully run
DEBUG - 2014-01-30 20:21:44 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:21:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:44 --> Final output sent to browser
DEBUG - 2014-01-30 20:21:44 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:21:45 --> Config Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:21:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:21:45 --> URI Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Router Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Output Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Security Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Input Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:21:45 --> Language Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Loader Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Controller Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:21:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:21:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:45 --> Session Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:21:45 --> Session routines successfully run
DEBUG - 2014-01-30 20:21:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:21:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:21:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:21:45 --> Final output sent to browser
DEBUG - 2014-01-30 20:21:45 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:08 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:08 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:08 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:08 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:08 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:08 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:08 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:23:08 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:08 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:23:09 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:09 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:09 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:09 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:09 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:09 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:09 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:09 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:09 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:23:11 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:11 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:11 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:11 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:11 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:11 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:11 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:23:13 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:13 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:13 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:13 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:13 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:13 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:13 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:23:16 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:16 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:16 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:16 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:16 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:16 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:16 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:23:17 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:17 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:17 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:17 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:17 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:17 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:17 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:17 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:17 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:19 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:19 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:19 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:19 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:19 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:19 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:19 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:21 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:21 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:21 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:21 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:21 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:21 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:21 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:22 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:22 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:22 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:22 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:22 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:22 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:22 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:23:23 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:23 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:23 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:23 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:23 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:23 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:23 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:23 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:24 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:24 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:24 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:24 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:24 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:24 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:24 --> Total execution time: 0.0170
DEBUG - 2014-01-30 20:23:28 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:28 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:28 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:28 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:28 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:28 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:28 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:33 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:33 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:33 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:33 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:33 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:33 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:33 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:34 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:34 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:34 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:34 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:34 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:34 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:34 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:34 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:23:36 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:36 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:36 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:36 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:36 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:36 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:36 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:36 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:38 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:38 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:38 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:38 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:38 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:38 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:38 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:38 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:38 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:38 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:23:39 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:39 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:39 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:39 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:39 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:39 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:39 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:39 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:23:59 --> Config Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:23:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:23:59 --> URI Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Router Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Output Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Security Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Input Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:23:59 --> Language Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Loader Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Controller Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:23:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:23:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:59 --> Session Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:23:59 --> Session routines successfully run
DEBUG - 2014-01-30 20:23:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:23:59 --> Model Class Initialized
DEBUG - 2014-01-30 20:23:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:23:59 --> Final output sent to browser
DEBUG - 2014-01-30 20:23:59 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:24:00 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:00 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:00 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:00 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:00 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:00 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:00 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:24:02 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:02 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:02 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:02 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:02 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:02 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:02 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:02 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:02 --> Total execution time: 0.0150
DEBUG - 2014-01-30 20:24:03 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:03 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:03 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:03 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:03 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:03 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:03 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:24:05 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:05 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:05 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:05 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:05 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:24:05 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:05 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:24:06 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:06 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:06 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:06 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:06 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:06 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:06 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:24:25 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:25 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:25 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:25 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:25 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:25 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:25 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:25 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:24:27 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:27 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:27 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:27 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:27 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:27 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:27 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:24:28 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:28 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:28 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:28 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:28 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:28 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:28 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:28 --> Total execution time: 0.0170
DEBUG - 2014-01-30 20:24:30 --> Config Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:24:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:24:30 --> URI Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Router Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Output Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Security Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Input Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:24:30 --> Language Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Loader Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Controller Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:24:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:24:30 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:30 --> Session Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:24:30 --> Session routines successfully run
DEBUG - 2014-01-30 20:24:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:24:30 --> Model Class Initialized
DEBUG - 2014-01-30 20:24:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:24:30 --> Final output sent to browser
DEBUG - 2014-01-30 20:24:30 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:26:06 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:06 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:06 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:06 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:06 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:06 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 20:26:06 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:06 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:26:06 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:06 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:06 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:06 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:06 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:06 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:06 --> Total execution time: 0.0100
DEBUG - 2014-01-30 20:26:11 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:11 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:11 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:11 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:11 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:26:11 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:11 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:26:12 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:12 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:12 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:12 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:12 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:12 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:12 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:12 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:12 --> Total execution time: 0.0100
DEBUG - 2014-01-30 20:26:13 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:13 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:13 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:13 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:13 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:26:13 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:13 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:26:14 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:14 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:14 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:14 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:14 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:14 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:14 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:26:15 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:15 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:15 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:15 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:15 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:26:15 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:15 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:26:16 --> Config Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:26:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:26:16 --> URI Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Router Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Output Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Security Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Input Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:26:16 --> Language Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Loader Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Controller Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:26:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:26:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:16 --> Session Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:26:16 --> Session routines successfully run
DEBUG - 2014-01-30 20:26:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:26:16 --> Model Class Initialized
DEBUG - 2014-01-30 20:26:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:26:16 --> Final output sent to browser
DEBUG - 2014-01-30 20:26:16 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:28:14 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:14 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:14 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:14 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:14 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:28:14 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:14 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:28:15 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:15 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:15 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:15 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:15 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:15 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:15 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:15 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:28:18 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:18 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:18 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:18 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:18 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:18 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:18 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:28:18 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:18 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:28:19 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:19 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:19 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:19 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:19 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:19 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:19 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:28:24 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:24 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:24 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:24 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:24 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:24 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:28:24 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:24 --> Total execution time: 0.0170
DEBUG - 2014-01-30 20:28:24 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:24 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:24 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:24 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:24 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:24 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:24 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:28:49 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:49 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:49 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:49 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:49 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:49 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:28:49 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:49 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:28:50 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:50 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:50 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:50 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:50 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:50 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:50 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:28:51 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:51 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:51 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:51 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:51 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:28:51 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:51 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:28:52 --> Config Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:28:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:28:52 --> URI Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Router Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Output Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Security Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Input Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:28:52 --> Language Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Loader Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Controller Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:28:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:28:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:52 --> Session Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:28:52 --> Session routines successfully run
DEBUG - 2014-01-30 20:28:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:28:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:28:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:28:52 --> Final output sent to browser
DEBUG - 2014-01-30 20:28:52 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:29:04 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:04 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:04 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:04 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:04 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:04 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:04 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:04 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:29:05 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:05 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:05 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:05 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:05 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:05 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:05 --> Total execution time: 0.0100
DEBUG - 2014-01-30 20:29:06 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:06 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:06 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:06 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:06 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:06 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:06 --> Total execution time: 0.0160
DEBUG - 2014-01-30 20:29:07 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:07 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:07 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:07 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:07 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:07 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:07 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:07 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:29:18 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:18 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:18 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:18 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:18 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:18 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:18 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:18 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:18 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:29:19 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:19 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:19 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:19 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:19 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:19 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:19 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:19 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:29:20 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:20 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:20 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:20 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:20 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:20 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:20 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:20 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:20 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:29:21 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:21 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:21 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:21 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:21 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:21 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:21 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:29:21 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:21 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:21 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:21 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:21 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:21 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:21 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:29:22 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:22 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:22 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:22 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:22 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:22 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:22 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:22 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:29:23 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:23 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:23 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:23 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:23 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:23 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:23 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:23 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:23 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:23 --> Total execution time: 0.0170
DEBUG - 2014-01-30 20:29:24 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:24 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:24 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:24 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:24 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:24 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:24 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:29:24 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:24 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:24 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:24 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:24 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:24 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:24 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:24 --> Total execution time: 0.0170
DEBUG - 2014-01-30 20:29:25 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:25 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:25 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:25 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:25 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:25 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:25 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:25 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:25 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:29:26 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:26 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:26 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:26 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:26 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:26 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:29:26 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:26 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:29:27 --> Config Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:29:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:29:27 --> URI Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Router Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Output Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Security Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Input Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:29:27 --> Language Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Loader Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Controller Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:29:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:29:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:27 --> Session Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:29:27 --> Session routines successfully run
DEBUG - 2014-01-30 20:29:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:29:27 --> Model Class Initialized
DEBUG - 2014-01-30 20:29:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:29:27 --> Final output sent to browser
DEBUG - 2014-01-30 20:29:27 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:36:51 --> Config Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:36:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:36:51 --> URI Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Router Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Output Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Security Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Input Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:36:51 --> Language Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Loader Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Controller Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:36:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:36:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:51 --> Session Class Initialized
DEBUG - 2014-01-30 20:36:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:36:51 --> Session routines successfully run
DEBUG - 2014-01-30 20:36:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:36:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:36:51 --> Final output sent to browser
DEBUG - 2014-01-30 20:36:51 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:36:53 --> Config Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:36:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:36:53 --> URI Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Router Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Output Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Security Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Input Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:36:53 --> Language Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Loader Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Controller Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:36:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:36:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:53 --> Session Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:36:53 --> Session routines successfully run
DEBUG - 2014-01-30 20:36:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:36:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:53 --> Final output sent to browser
DEBUG - 2014-01-30 20:36:53 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:36:55 --> Config Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:36:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:36:55 --> URI Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Router Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Output Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Security Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Input Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:36:55 --> Language Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Loader Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Controller Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:36:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:36:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:55 --> Session Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:36:55 --> Session routines successfully run
DEBUG - 2014-01-30 20:36:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:36:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:55 --> Final output sent to browser
DEBUG - 2014-01-30 20:36:55 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:36:57 --> Config Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:36:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:36:57 --> URI Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Router Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Output Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Security Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Input Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:36:57 --> Language Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Loader Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Controller Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:36:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:36:57 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:57 --> Session Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:36:57 --> Session routines successfully run
DEBUG - 2014-01-30 20:36:57 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:36:57 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:57 --> Final output sent to browser
DEBUG - 2014-01-30 20:36:57 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:36:58 --> Config Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:36:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:36:58 --> URI Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Router Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Output Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Security Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Input Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:36:58 --> Language Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Loader Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Controller Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:36:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:36:58 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:58 --> Session Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:36:58 --> Session routines successfully run
DEBUG - 2014-01-30 20:36:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:36:58 --> Model Class Initialized
DEBUG - 2014-01-30 20:36:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:36:58 --> Final output sent to browser
DEBUG - 2014-01-30 20:36:58 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:37:00 --> Config Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:37:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:37:00 --> URI Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Router Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Output Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Security Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Input Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:37:00 --> Language Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Loader Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Controller Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:37:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:37:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:00 --> Session Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:37:00 --> Session routines successfully run
DEBUG - 2014-01-30 20:37:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:37:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:00 --> Final output sent to browser
DEBUG - 2014-01-30 20:37:00 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:37:03 --> Config Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:37:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:37:03 --> URI Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Router Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Output Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Security Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Input Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:37:03 --> Language Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Loader Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Controller Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:37:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:37:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:03 --> Session Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:37:03 --> Session routines successfully run
DEBUG - 2014-01-30 20:37:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:37:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:03 --> Final output sent to browser
DEBUG - 2014-01-30 20:37:03 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:37:04 --> Config Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:37:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:37:04 --> URI Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Router Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Output Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Security Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Input Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:37:04 --> Language Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Loader Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Controller Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:37:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:37:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:04 --> Session Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:37:04 --> Session routines successfully run
DEBUG - 2014-01-30 20:37:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:37:04 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:04 --> Final output sent to browser
DEBUG - 2014-01-30 20:37:04 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:37:06 --> Config Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:37:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:37:06 --> URI Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Router Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Output Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Security Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Input Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:37:06 --> Language Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Loader Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Controller Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:37:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:37:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:06 --> Session Class Initialized
DEBUG - 2014-01-30 20:37:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:37:06 --> Session routines successfully run
DEBUG - 2014-01-30 20:37:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:37:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:37:06 --> Final output sent to browser
DEBUG - 2014-01-30 20:37:06 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:37:07 --> Config Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:37:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:37:07 --> URI Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Router Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Output Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Security Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Input Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:37:07 --> Language Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Loader Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Controller Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:37:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:37:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:07 --> Session Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:37:07 --> Session routines successfully run
DEBUG - 2014-01-30 20:37:07 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:37:07 --> Model Class Initialized
DEBUG - 2014-01-30 20:37:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:37:07 --> Final output sent to browser
DEBUG - 2014-01-30 20:37:07 --> Total execution time: 0.0130
DEBUG - 2014-01-30 20:42:43 --> Config Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:42:43 --> URI Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Router Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Output Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Security Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Input Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:42:43 --> Language Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Loader Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Controller Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:42:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:42:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:42:43 --> Session Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:42:43 --> Session routines successfully run
DEBUG - 2014-01-30 20:42:43 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:42:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:42:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:42:43 --> Final output sent to browser
DEBUG - 2014-01-30 20:42:43 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:51:08 --> Config Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:51:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:51:08 --> URI Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Router Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Output Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Security Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Input Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:51:08 --> Language Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Loader Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Controller Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:51:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:51:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:08 --> Session Class Initialized
DEBUG - 2014-01-30 20:51:08 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:51:08 --> Session routines successfully run
DEBUG - 2014-01-30 20:51:08 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:51:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:51:08 --> Final output sent to browser
DEBUG - 2014-01-30 20:51:08 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:51:10 --> Config Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:51:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:51:10 --> URI Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Router Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Output Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Security Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Input Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:51:10 --> Language Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Loader Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Controller Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:51:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:51:10 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:10 --> Session Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:51:10 --> Session routines successfully run
DEBUG - 2014-01-30 20:51:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:51:10 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:10 --> Final output sent to browser
DEBUG - 2014-01-30 20:51:10 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:51:13 --> Config Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:51:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:51:13 --> URI Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Router Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Output Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Security Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Input Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:51:13 --> Language Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Loader Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Controller Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:51:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:51:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:13 --> Session Class Initialized
DEBUG - 2014-01-30 20:51:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:51:13 --> Session routines successfully run
DEBUG - 2014-01-30 20:51:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:51:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:51:13 --> Final output sent to browser
DEBUG - 2014-01-30 20:51:13 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:51:14 --> Config Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:51:14 --> URI Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Router Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Output Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Security Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Input Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:51:14 --> Language Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Loader Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Controller Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:51:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:14 --> Session Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:51:14 --> Session routines successfully run
DEBUG - 2014-01-30 20:51:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:51:14 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:14 --> Final output sent to browser
DEBUG - 2014-01-30 20:51:14 --> Total execution time: 0.0110
DEBUG - 2014-01-30 20:51:29 --> Config Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:51:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:51:29 --> URI Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Router Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Output Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Security Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Input Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:51:29 --> Language Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Loader Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Controller Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:51:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:51:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:29 --> Session Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:51:29 --> Session routines successfully run
DEBUG - 2014-01-30 20:51:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:51:29 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:29 --> Final output sent to browser
DEBUG - 2014-01-30 20:51:29 --> Total execution time: 0.0130
DEBUG - 2014-01-30 20:51:34 --> Config Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:51:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:51:34 --> URI Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Router Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Output Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Security Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Input Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:51:34 --> Language Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Loader Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Controller Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:51:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:51:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:51:34 --> Session Class Initialized
DEBUG - 2014-01-30 20:51:34 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:51:34 --> Session routines successfully run
DEBUG - 2014-01-30 20:51:34 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:51:35 --> Model Class Initialized
DEBUG - 2014-01-30 20:51:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:20 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:20 --> Total execution time: 45.6516
DEBUG - 2014-01-30 20:52:37 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:37 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:37 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:37 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:37 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:37 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 20:52:37 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:37 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:52:39 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:39 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:39 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:39 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:39 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:39 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:39 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:39 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:39 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:52:43 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:43 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:43 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:43 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:43 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:43 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:43 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:43 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:52:45 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:45 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:45 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:45 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:45 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:45 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:45 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:45 --> Total execution time: 0.0130
DEBUG - 2014-01-30 20:52:47 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:47 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:47 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:47 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:47 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:47 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:47 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:47 --> Total execution time: 0.0140
DEBUG - 2014-01-30 20:52:49 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:49 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:49 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:49 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:49 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:49 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:49 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:49 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:52:51 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:51 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:51 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:51 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:51 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:51 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:51 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:51 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:52:52 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:52 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:52 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:52 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:52 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:52 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:52 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:52 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:52:53 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:53 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:53 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:53 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:53 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:53 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:53 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:53 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:52:54 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:54 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:54 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:54 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:54 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:54 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:54 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:54 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:54 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:52:55 --> Config Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:52:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:52:55 --> URI Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Router Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Output Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Security Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Input Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:52:55 --> Language Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Loader Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Controller Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:52:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:52:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:55 --> Session Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:52:55 --> Session routines successfully run
DEBUG - 2014-01-30 20:52:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:52:55 --> Model Class Initialized
DEBUG - 2014-01-30 20:52:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:52:55 --> Final output sent to browser
DEBUG - 2014-01-30 20:52:55 --> Total execution time: 0.0130
DEBUG - 2014-01-30 20:53:00 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:00 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:00 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:00 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:00 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:00 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:00 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:00 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:53:01 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:01 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:01 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:01 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:01 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:01 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:01 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:01 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:53:03 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:03 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:03 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:03 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:03 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:03 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:03 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:03 --> Total execution time: 0.0150
DEBUG - 2014-01-30 20:53:05 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:05 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:05 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:05 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:05 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:05 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:05 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:05 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:53:31 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:31 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:31 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:31 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:31 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:31 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:31 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:31 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:31 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:53:32 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:32 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:32 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:32 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:32 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:32 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:33 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:33 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:33 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:33 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:33 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:33 --> Total execution time: 0.0150
DEBUG - 2014-01-30 20:53:34 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:34 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:34 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:34 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:34 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:34 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:34 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:34 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:34 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:53:36 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:36 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:36 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:36 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:36 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:36 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:36 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:36 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:36 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:36 --> Total execution time: 0.0190
DEBUG - 2014-01-30 20:53:37 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:37 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:37 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:37 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:37 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:37 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:37 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:37 --> Total execution time: 0.0220
DEBUG - 2014-01-30 20:53:41 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:41 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:41 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:41 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:41 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:41 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:41 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:41 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:41 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:53:43 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:43 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:43 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:43 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:43 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:43 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:43 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:43 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:43 --> Total execution time: 0.0120
DEBUG - 2014-01-30 20:53:44 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:44 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:44 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:44 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:44 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:44 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:44 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:44 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:44 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:53:46 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:46 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:46 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:46 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:46 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:46 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:46 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:53:46 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:46 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:46 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:46 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:46 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:46 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:46 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:46 --> Total execution time: 0.0200
DEBUG - 2014-01-30 20:53:47 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:47 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:47 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:47 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:47 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:47 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:47 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:47 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:47 --> Total execution time: 0.0210
DEBUG - 2014-01-30 20:53:48 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:48 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:48 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:48 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:48 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:48 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:48 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:48 --> Total execution time: 0.0180
DEBUG - 2014-01-30 20:53:50 --> Config Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 20:53:50 --> URI Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Router Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Output Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Security Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Input Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 20:53:50 --> Language Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Loader Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Controller Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 20:53:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 20:53:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:50 --> Session Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 20:53:50 --> Session routines successfully run
DEBUG - 2014-01-30 20:53:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 20:53:50 --> Model Class Initialized
DEBUG - 2014-01-30 20:53:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 20:53:50 --> Final output sent to browser
DEBUG - 2014-01-30 20:53:50 --> Total execution time: 0.0210
DEBUG - 2014-01-30 21:06:27 --> Config Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 21:06:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 21:06:27 --> URI Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Router Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Output Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Security Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Input Class Initialized
DEBUG - 2014-01-30 21:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 21:06:27 --> Language Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Config Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 21:06:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 21:06:58 --> URI Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Router Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Output Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Security Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Input Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 21:06:58 --> Language Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Loader Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Controller Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 21:06:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 21:06:58 --> Model Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Model Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Model Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 21:06:58 --> Session Class Initialized
DEBUG - 2014-01-30 21:06:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 21:06:58 --> Session routines successfully run
DEBUG - 2014-01-30 21:06:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 21:06:58 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 21:06:58 --> Final output sent to browser
DEBUG - 2014-01-30 21:06:58 --> Total execution time: 0.0230
DEBUG - 2014-01-30 21:07:00 --> Config Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 21:07:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 21:07:00 --> URI Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Router Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Output Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Security Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Input Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 21:07:00 --> Language Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Loader Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Controller Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 21:07:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 21:07:00 --> Model Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Model Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Model Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 21:07:00 --> Session Class Initialized
DEBUG - 2014-01-30 21:07:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 21:07:00 --> Session routines successfully run
DEBUG - 2014-01-30 21:07:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 21:07:00 --> Final output sent to browser
DEBUG - 2014-01-30 21:07:00 --> Total execution time: 0.0120
DEBUG - 2014-01-30 21:23:13 --> Config Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 21:23:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 21:23:13 --> URI Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Router Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Output Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Security Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Input Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 21:23:13 --> Language Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Loader Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Controller Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 21:23:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 21:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 21:23:13 --> Session Class Initialized
DEBUG - 2014-01-30 21:23:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 21:23:13 --> Session routines successfully run
DEBUG - 2014-01-30 21:23:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 21:23:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 21:23:13 --> Final output sent to browser
DEBUG - 2014-01-30 21:23:13 --> Total execution time: 0.0230
DEBUG - 2014-01-30 21:23:14 --> Config Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 21:23:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 21:23:14 --> URI Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Router Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Output Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Security Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Input Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 21:23:14 --> Language Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Loader Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Controller Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 21:23:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 21:23:14 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 21:23:14 --> Session Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 21:23:14 --> Session routines successfully run
DEBUG - 2014-01-30 21:23:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 21:23:14 --> Model Class Initialized
DEBUG - 2014-01-30 21:23:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 21:23:14 --> Final output sent to browser
DEBUG - 2014-01-30 21:23:14 --> Total execution time: 0.0120
DEBUG - 2014-01-30 22:00:16 --> Config Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:00:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:00:16 --> URI Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Router Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Output Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Security Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Input Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:00:16 --> Language Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Loader Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Controller Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:00:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:00:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:16 --> Session Class Initialized
DEBUG - 2014-01-30 22:00:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:00:16 --> Session routines successfully run
DEBUG - 2014-01-30 22:00:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:00:16 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:00:16 --> Final output sent to browser
DEBUG - 2014-01-30 22:00:16 --> Total execution time: 0.0260
DEBUG - 2014-01-30 22:00:18 --> Config Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:00:18 --> URI Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Router Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Output Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Security Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Input Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:00:18 --> Language Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Loader Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Controller Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:00:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:18 --> Session Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:00:18 --> Session routines successfully run
DEBUG - 2014-01-30 22:00:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:00:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:18 --> Final output sent to browser
DEBUG - 2014-01-30 22:00:18 --> Total execution time: 0.0130
DEBUG - 2014-01-30 22:00:22 --> Config Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:00:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:00:22 --> URI Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Router Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Output Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Security Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Input Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:00:22 --> Language Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Loader Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Controller Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:00:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:00:22 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:22 --> Session Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:00:22 --> Session routines successfully run
DEBUG - 2014-01-30 22:00:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:00:22 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:22 --> Final output sent to browser
DEBUG - 2014-01-30 22:00:22 --> Total execution time: 0.0210
DEBUG - 2014-01-30 22:00:24 --> Config Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:00:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:00:24 --> URI Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Router Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Output Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Security Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Input Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:00:24 --> Language Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Loader Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Controller Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:00:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:00:24 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:24 --> Session Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:00:24 --> Session routines successfully run
DEBUG - 2014-01-30 22:00:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:00:24 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:24 --> Final output sent to browser
DEBUG - 2014-01-30 22:00:24 --> Total execution time: 0.0160
DEBUG - 2014-01-30 22:00:26 --> Config Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:00:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:00:26 --> URI Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Router Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Output Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Security Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Input Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:00:26 --> Language Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Loader Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Controller Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:00:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:00:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:26 --> Session Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:00:26 --> Session routines successfully run
DEBUG - 2014-01-30 22:00:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:00:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:26 --> Final output sent to browser
DEBUG - 2014-01-30 22:00:26 --> Total execution time: 0.0200
DEBUG - 2014-01-30 22:00:27 --> Config Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:00:27 --> URI Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Router Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Output Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Security Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Input Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:00:27 --> Language Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Loader Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Controller Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:00:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:00:27 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:27 --> Session Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:00:27 --> Session routines successfully run
DEBUG - 2014-01-30 22:00:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:00:27 --> Model Class Initialized
DEBUG - 2014-01-30 22:00:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:00:27 --> Final output sent to browser
DEBUG - 2014-01-30 22:00:27 --> Total execution time: 0.0190
DEBUG - 2014-01-30 22:03:15 --> Config Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:03:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:03:15 --> URI Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Router Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Output Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Security Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Input Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:03:15 --> Language Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Loader Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Controller Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:03:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:03:15 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:15 --> Session Class Initialized
DEBUG - 2014-01-30 22:03:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:03:15 --> Session routines successfully run
DEBUG - 2014-01-30 22:03:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:03:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:03:15 --> Final output sent to browser
DEBUG - 2014-01-30 22:03:15 --> Total execution time: 0.0210
DEBUG - 2014-01-30 22:03:16 --> Config Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:03:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:03:16 --> URI Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Router Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Output Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Security Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Input Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:03:16 --> Language Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Loader Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Controller Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:03:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:03:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:16 --> Session Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:03:16 --> Session routines successfully run
DEBUG - 2014-01-30 22:03:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:03:16 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:16 --> Final output sent to browser
DEBUG - 2014-01-30 22:03:16 --> Total execution time: 0.0110
DEBUG - 2014-01-30 22:03:17 --> Config Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:03:17 --> URI Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Router Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Output Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Security Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Input Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:03:17 --> Language Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Loader Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Controller Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:03:17 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:17 --> Session Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:03:17 --> Session routines successfully run
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:03:17 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 22:03:17 --> Final output sent to browser
DEBUG - 2014-01-30 22:03:17 --> Total execution time: 0.0120
DEBUG - 2014-01-30 22:03:17 --> Config Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:03:17 --> URI Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Router Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Output Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Security Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Input Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:03:17 --> Language Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Loader Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Controller Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:03:17 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:17 --> Session Class Initialized
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:03:17 --> Session routines successfully run
DEBUG - 2014-01-30 22:03:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:03:17 --> Final output sent to browser
DEBUG - 2014-01-30 22:03:17 --> Total execution time: 0.0100
DEBUG - 2014-01-30 22:03:18 --> Config Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:03:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:03:18 --> URI Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Router Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Output Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Security Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Input Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:03:18 --> Language Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Loader Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Controller Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:03:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:03:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:18 --> Session Class Initialized
DEBUG - 2014-01-30 22:03:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:03:18 --> Session routines successfully run
DEBUG - 2014-01-30 22:03:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:03:18 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:03:18 --> Final output sent to browser
DEBUG - 2014-01-30 22:03:18 --> Total execution time: 0.0220
DEBUG - 2014-01-30 22:03:19 --> Config Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:03:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:03:19 --> URI Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Router Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Output Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Security Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Input Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:03:19 --> Language Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Loader Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Controller Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:03:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:03:19 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:19 --> Session Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:03:19 --> Session routines successfully run
DEBUG - 2014-01-30 22:03:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:03:19 --> Model Class Initialized
DEBUG - 2014-01-30 22:03:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:03:19 --> Final output sent to browser
DEBUG - 2014-01-30 22:03:19 --> Total execution time: 0.0130
DEBUG - 2014-01-30 22:54:05 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:05 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:05 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:05 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:05 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:05 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:05 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:05 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:05 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:05 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:05 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:05 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:05 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-30 22:54:05 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:05 --> Total execution time: 0.0180
DEBUG - 2014-01-30 22:54:10 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:10 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:10 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:10 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:10 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:10 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:10 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:10 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:10 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:10 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:10 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:10 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:10 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:10 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:10 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:10 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:54:10 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:10 --> Total execution time: 0.0110
DEBUG - 2014-01-30 22:54:11 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:11 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:11 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:11 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:11 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:11 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:11 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:11 --> Total execution time: 0.0110
DEBUG - 2014-01-30 22:54:26 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:26 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:26 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:26 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:26 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 22:54:26 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:26 --> Total execution time: 0.0210
DEBUG - 2014-01-30 22:54:26 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:26 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:26 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:26 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:26 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:26 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:26 --> Total execution time: 0.0100
DEBUG - 2014-01-30 22:54:41 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:41 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:41 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:41 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:41 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:41 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:54:41 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:41 --> Total execution time: 0.0210
DEBUG - 2014-01-30 22:54:41 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:41 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:41 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:41 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:41 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:41 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:41 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:41 --> Total execution time: 0.0120
DEBUG - 2014-01-30 22:54:42 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:42 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:42 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:42 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:42 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:42 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:42 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:42 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:42 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:54:42 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:42 --> Total execution time: 0.0200
DEBUG - 2014-01-30 22:54:43 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:43 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:43 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:43 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:43 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:43 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:43 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:43 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:43 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:43 --> Total execution time: 0.0110
DEBUG - 2014-01-30 22:54:45 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:45 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:45 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:45 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:45 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 22:54:45 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:45 --> Total execution time: 0.0220
DEBUG - 2014-01-30 22:54:45 --> Config Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Hooks Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Utf8 Class Initialized
DEBUG - 2014-01-30 22:54:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 22:54:45 --> URI Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Router Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Output Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Security Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Input Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 22:54:45 --> Language Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Loader Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Controller Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Database Driver Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:45 --> Session Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: string_helper
DEBUG - 2014-01-30 22:54:45 --> Session routines successfully run
DEBUG - 2014-01-30 22:54:45 --> Helper loaded: url_helper
DEBUG - 2014-01-30 22:54:45 --> Model Class Initialized
DEBUG - 2014-01-30 22:54:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 22:54:45 --> Final output sent to browser
DEBUG - 2014-01-30 22:54:45 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:00:58 --> Config Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:00:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:00:58 --> URI Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Router Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Output Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Security Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Input Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:00:58 --> Language Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Loader Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Controller Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:00:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:00:58 --> Session Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:00:58 --> Session routines successfully run
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:00:58 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:00:58 --> Final output sent to browser
DEBUG - 2014-01-30 23:00:58 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:00:58 --> Config Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:00:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:00:58 --> URI Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Router Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Output Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Security Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Input Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:00:58 --> Language Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Loader Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Controller Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:00:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:00:58 --> Session Class Initialized
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:00:58 --> Session routines successfully run
DEBUG - 2014-01-30 23:00:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:00:58 --> Final output sent to browser
DEBUG - 2014-01-30 23:00:58 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:24 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:24 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:24 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:24 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:24 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:24 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:03:24 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:24 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:03:24 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:24 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:24 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:24 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:24 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:24 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:24 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:03:26 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:26 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:26 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:26 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:26 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:26 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:26 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:03:26 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:26 --> Total execution time: 0.0180
DEBUG - 2014-01-30 23:03:26 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:26 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:26 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:26 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:26 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:26 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:26 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:26 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:26 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:27 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:27 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:27 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:27 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:27 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:27 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:03:27 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:27 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:27 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:27 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:27 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:27 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:27 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:27 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:27 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:28 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:28 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:28 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:28 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:28 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:28 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:28 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:03:28 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:28 --> Total execution time: 0.0180
DEBUG - 2014-01-30 23:03:28 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:28 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:28 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:28 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:28 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:28 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:28 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:28 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:28 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:03:28 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:29 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:29 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:29 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:29 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:03:29 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:29 --> Total execution time: 0.0180
DEBUG - 2014-01-30 23:03:29 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:29 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:29 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:29 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:29 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:29 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:29 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:03:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:30 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:03:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:30 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:03:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:30 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:03:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:03:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:30 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:03:31 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:31 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:31 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:31 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:31 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:31 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:31 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:31 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:31 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:31 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:31 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:31 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:31 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:03:31 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:31 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:03:31 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:31 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:31 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:31 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:31 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:31 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:31 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:31 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:03:32 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:32 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:32 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:32 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:32 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:32 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:03:32 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:32 --> Total execution time: 0.0210
DEBUG - 2014-01-30 23:03:32 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:32 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:32 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:32 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:32 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:32 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:32 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:32 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:33 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:33 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:33 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:33 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:33 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:33 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:03:33 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:33 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:03:33 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:33 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:33 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:33 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:33 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:33 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:33 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:03:33 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:33 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:33 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:33 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:33 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:03:33 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:33 --> Total execution time: 0.0200
DEBUG - 2014-01-30 23:03:34 --> Config Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:03:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:03:34 --> URI Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Router Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Output Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Security Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Input Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:03:34 --> Language Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Loader Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Controller Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:03:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:03:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:34 --> Session Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:03:34 --> Session routines successfully run
DEBUG - 2014-01-30 23:03:34 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:03:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:03:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:03:34 --> Final output sent to browser
DEBUG - 2014-01-30 23:03:34 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:09 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:09 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:09 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:09 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:09 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:09 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:09 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:09 --> Total execution time: 0.0200
DEBUG - 2014-01-30 23:04:09 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:09 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:09 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:09 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:09 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:09 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:09 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:10 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:10 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:10 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:10 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:10 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:10 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:10 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:10 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:04:10 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:10 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:10 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:10 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:10 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:10 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:10 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:11 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:11 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:11 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:11 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:11 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:11 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:11 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:11 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:11 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:11 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:11 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:11 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:11 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:11 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:12 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:12 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:12 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:12 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:12 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:12 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:12 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:12 --> Total execution time: 0.0170
DEBUG - 2014-01-30 23:04:12 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:12 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:12 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:12 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:12 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:12 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:12 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:04:13 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:13 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:13 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:13 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:13 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:13 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:13 --> Total execution time: 0.0150
DEBUG - 2014-01-30 23:04:13 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:13 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:13 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:13 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:13 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:13 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:13 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:13 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:13 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:13 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:13 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:13 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:13 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:13 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:04:14 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:14 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:14 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:14 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:14 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:14 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:14 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:15 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:15 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:15 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:15 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:15 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:15 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:15 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:15 --> Total execution time: 0.0210
DEBUG - 2014-01-30 23:04:15 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:15 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:15 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:15 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:15 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:15 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:15 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:04:15 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:15 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:15 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:15 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:15 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:15 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:15 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:04:16 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:16 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:16 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:16 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:16 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:16 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:16 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:16 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:16 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:16 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:16 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:16 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:16 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:16 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:16 --> Total execution time: 0.0200
DEBUG - 2014-01-30 23:04:16 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:16 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:16 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:16 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:16 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:16 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:16 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:16 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:04:17 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:17 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:17 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:17 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:17 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:17 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:17 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:17 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:04:17 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:17 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:17 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:17 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:17 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:17 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:17 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:17 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:17 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:18 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:18 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:18 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:18 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:18 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:18 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:18 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:18 --> Total execution time: 0.0180
DEBUG - 2014-01-30 23:04:18 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:18 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:18 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:18 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:18 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:18 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:18 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:04:19 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:19 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:19 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:19 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:19 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:19 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:19 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:19 --> Total execution time: 0.0150
DEBUG - 2014-01-30 23:04:19 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:19 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:19 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:19 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:19 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:19 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:19 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:19 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:19 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:19 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:19 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:19 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:19 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:19 --> Total execution time: 0.0210
DEBUG - 2014-01-30 23:04:19 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:19 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:19 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:19 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:19 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:19 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:19 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:04:20 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:20 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:20 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:20 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:20 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:20 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:20 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:20 --> Total execution time: 0.0140
DEBUG - 2014-01-30 23:04:20 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:20 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:20 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:20 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:20 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:20 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:20 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:21 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:21 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:21 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:21 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:21 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:21 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:21 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:21 --> Total execution time: 0.0200
DEBUG - 2014-01-30 23:04:21 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:21 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:21 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:21 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:21 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:21 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:21 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:04:21 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:21 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:21 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:21 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:21 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:21 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:21 --> Total execution time: 0.0160
DEBUG - 2014-01-30 23:04:21 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:21 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:21 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:21 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:21 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:21 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:21 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:21 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:21 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:22 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:22 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:22 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:22 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:22 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:22 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:04:22 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:22 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:04:22 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:22 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:22 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:22 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:22 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:22 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:22 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:04:22 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:22 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:22 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:22 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:22 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:22 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:04:22 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:22 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:04:22 --> Config Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:04:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:04:22 --> URI Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Router Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Output Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Security Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Input Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:04:22 --> Language Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Loader Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Controller Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:22 --> Session Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:04:22 --> Session routines successfully run
DEBUG - 2014-01-30 23:04:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:04:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:04:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:04:22 --> Final output sent to browser
DEBUG - 2014-01-30 23:04:22 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:26:40 --> Config Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:26:40 --> URI Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Router Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Output Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Security Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Input Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:26:40 --> Language Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Loader Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Controller Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:26:40 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:40 --> Session Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:26:40 --> Session routines successfully run
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:26:40 --> Config Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:26:40 --> URI Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Router Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Output Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Security Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Input Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:26:40 --> Language Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Loader Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Controller Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:26:40 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:40 --> Session Class Initialized
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:26:40 --> Session routines successfully run
DEBUG - 2014-01-30 23:26:40 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:26:40 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:26:40 --> Final output sent to browser
DEBUG - 2014-01-30 23:26:40 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:26:41 --> Config Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:26:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:26:41 --> URI Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Router Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Output Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Security Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Input Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:26:41 --> Language Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Loader Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Controller Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:26:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:26:41 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:41 --> Session Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:26:41 --> Session routines successfully run
DEBUG - 2014-01-30 23:26:41 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:26:41 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:41 --> Final output sent to browser
DEBUG - 2014-01-30 23:26:41 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:26:52 --> Config Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:26:52 --> URI Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Router Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Output Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Security Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Input Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:26:52 --> Language Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Loader Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Controller Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:26:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:26:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:52 --> Session Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:26:52 --> Session routines successfully run
DEBUG - 2014-01-30 23:26:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:26:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:52 --> Final output sent to browser
DEBUG - 2014-01-30 23:26:52 --> Total execution time: 0.0240
DEBUG - 2014-01-30 23:26:53 --> Config Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:26:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:26:53 --> URI Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Router Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Output Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Security Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Input Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:26:53 --> Language Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Loader Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Controller Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:26:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:26:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:53 --> Session Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:26:53 --> Session routines successfully run
DEBUG - 2014-01-30 23:26:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:26:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:26:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:26:53 --> Final output sent to browser
DEBUG - 2014-01-30 23:26:53 --> Total execution time: 0.0300
DEBUG - 2014-01-30 23:28:03 --> Config Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:28:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:28:03 --> URI Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Router Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Output Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Security Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Input Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:28:03 --> Language Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Loader Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Controller Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:28:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:28:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:03 --> Session Class Initialized
DEBUG - 2014-01-30 23:28:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:28:03 --> Session routines successfully run
DEBUG - 2014-01-30 23:28:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:28:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:28:03 --> Final output sent to browser
DEBUG - 2014-01-30 23:28:03 --> Total execution time: 0.0210
DEBUG - 2014-01-30 23:28:05 --> Config Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:28:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:28:05 --> URI Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Router Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Output Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Security Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Input Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:28:05 --> Language Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Loader Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Controller Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:28:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:28:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:05 --> Session Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:28:05 --> Session routines successfully run
DEBUG - 2014-01-30 23:28:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:28:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:05 --> Final output sent to browser
DEBUG - 2014-01-30 23:28:05 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:28:13 --> Config Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:28:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:28:13 --> URI Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Router Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Output Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Security Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Input Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:28:13 --> Language Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Loader Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Controller Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:28:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:28:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:13 --> Session Class Initialized
DEBUG - 2014-01-30 23:28:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:28:13 --> Session routines successfully run
DEBUG - 2014-01-30 23:28:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:28:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:28:13 --> Final output sent to browser
DEBUG - 2014-01-30 23:28:13 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:28:14 --> Config Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:28:14 --> URI Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Router Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Output Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Security Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Input Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:28:14 --> Language Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Loader Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Controller Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:28:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:14 --> Session Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:28:14 --> Session routines successfully run
DEBUG - 2014-01-30 23:28:14 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:28:14 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:14 --> Final output sent to browser
DEBUG - 2014-01-30 23:28:14 --> Total execution time: 0.0110
DEBUG - 2014-01-30 23:28:29 --> Config Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:28:29 --> URI Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Router Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Output Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Security Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Input Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:28:29 --> Language Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Loader Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Controller Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:28:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:29 --> Session Class Initialized
DEBUG - 2014-01-30 23:28:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:28:29 --> Session routines successfully run
DEBUG - 2014-01-30 23:28:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:28:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:28:29 --> Final output sent to browser
DEBUG - 2014-01-30 23:28:29 --> Total execution time: 0.0230
DEBUG - 2014-01-30 23:28:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:28:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:28:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:28:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:28:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:28:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:28:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:28:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:28:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:28:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:28:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:28:30 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:29:56 --> Config Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:29:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:29:56 --> URI Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Router Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Output Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Security Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Input Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:29:56 --> Language Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Loader Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Controller Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:29:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:29:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:29:56 --> Session Class Initialized
DEBUG - 2014-01-30 23:29:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:29:56 --> Session routines successfully run
DEBUG - 2014-01-30 23:29:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:29:56 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:29:56 --> Final output sent to browser
DEBUG - 2014-01-30 23:29:56 --> Total execution time: 0.0220
DEBUG - 2014-01-30 23:29:57 --> Config Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:29:57 --> URI Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Router Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Output Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Security Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Input Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:29:57 --> Language Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Loader Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Controller Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:29:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:29:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:29:57 --> Session Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:29:57 --> Session routines successfully run
DEBUG - 2014-01-30 23:29:57 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:29:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:29:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:29:57 --> Final output sent to browser
DEBUG - 2014-01-30 23:29:57 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:38:29 --> Config Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:38:29 --> URI Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Router Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Output Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Security Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Input Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:38:29 --> Language Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Loader Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Controller Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:38:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:38:29 --> Session Class Initialized
DEBUG - 2014-01-30 23:38:29 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:38:29 --> Session routines successfully run
DEBUG - 2014-01-30 23:38:29 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:38:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:38:29 --> Final output sent to browser
DEBUG - 2014-01-30 23:38:29 --> Total execution time: 0.0210
DEBUG - 2014-01-30 23:38:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:38:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:38:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:38:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:38:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:38:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:38:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:38:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:38:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:38:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:38:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:38:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:38:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:38:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:38:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:38:30 --> Total execution time: 0.0140
DEBUG - 2014-01-30 23:38:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:38:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:38:30 --> Total execution time: 0.0270
DEBUG - 2014-01-30 23:40:44 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:44 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:44 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:44 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:44 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:44 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:44 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:44 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:44 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:44 --> Total execution time: 0.0390
DEBUG - 2014-01-30 23:40:50 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:50 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:50 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:50 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:50 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:50 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:50 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:50 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:50 --> Total execution time: 0.0280
DEBUG - 2014-01-30 23:40:53 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:53 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:53 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:54 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:54 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:54 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:54 --> Total execution time: 0.0300
DEBUG - 2014-01-30 23:40:54 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:54 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:54 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:54 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:54 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:54 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:54 --> Total execution time: 0.0230
DEBUG - 2014-01-30 23:40:55 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:55 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:55 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:55 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:55 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:55 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:55 --> Total execution time: 0.0420
DEBUG - 2014-01-30 23:40:56 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:56 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:56 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:56 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:56 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:56 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:56 --> Total execution time: 0.0250
DEBUG - 2014-01-30 23:40:57 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:57 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:57 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:57 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:57 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:57 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:57 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:57 --> Total execution time: 0.0290
DEBUG - 2014-01-30 23:40:59 --> Config Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:40:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:40:59 --> URI Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Router Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Output Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Security Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Input Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:40:59 --> Language Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Loader Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Controller Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:40:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:40:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:59 --> Session Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:40:59 --> Session routines successfully run
DEBUG - 2014-01-30 23:40:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:40:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:40:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:40:59 --> Final output sent to browser
DEBUG - 2014-01-30 23:40:59 --> Total execution time: 0.0370
DEBUG - 2014-01-30 23:41:00 --> Config Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:41:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:41:00 --> URI Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Router Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Output Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Security Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Input Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:41:00 --> Language Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Loader Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Controller Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:41:00 --> Session Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:41:00 --> Session routines successfully run
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:41:00 --> Final output sent to browser
DEBUG - 2014-01-30 23:41:00 --> Total execution time: 0.0290
DEBUG - 2014-01-30 23:41:00 --> Config Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:41:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:41:00 --> URI Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Router Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Output Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Security Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Input Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:41:00 --> Language Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Loader Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Controller Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:41:00 --> Session Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:41:00 --> Session routines successfully run
DEBUG - 2014-01-30 23:41:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:41:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:41:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:41:00 --> Final output sent to browser
DEBUG - 2014-01-30 23:41:00 --> Total execution time: 0.0250
DEBUG - 2014-01-30 23:43:15 --> Config Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:43:15 --> URI Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Router Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Output Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Security Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Input Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:43:15 --> Language Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Loader Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Controller Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:15 --> Session Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:43:15 --> Session routines successfully run
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:15 --> Final output sent to browser
DEBUG - 2014-01-30 23:43:15 --> Total execution time: 0.0250
DEBUG - 2014-01-30 23:43:15 --> Config Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:43:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:43:15 --> URI Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Router Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Output Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Security Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Input Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:43:15 --> Language Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Loader Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Controller Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:15 --> Session Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:43:15 --> Session routines successfully run
DEBUG - 2014-01-30 23:43:15 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:43:15 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:15 --> Final output sent to browser
DEBUG - 2014-01-30 23:43:15 --> Total execution time: 0.0260
DEBUG - 2014-01-30 23:43:19 --> Config Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:43:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:43:19 --> URI Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Router Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Output Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Security Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Input Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:43:19 --> Language Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Loader Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Controller Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:43:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:43:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:19 --> Session Class Initialized
DEBUG - 2014-01-30 23:43:19 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:43:19 --> Session routines successfully run
DEBUG - 2014-01-30 23:43:19 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:43:19 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:43:19 --> Final output sent to browser
DEBUG - 2014-01-30 23:43:19 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:43:20 --> Config Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:43:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:43:20 --> URI Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Router Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Output Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Security Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Config Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Input Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:43:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:43:20 --> URI Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Language Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Router Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Loader Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Controller Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Output Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:43:20 --> Security Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:43:20 --> Input Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Language Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Loader Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Controller Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:43:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Session Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:43:20 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Session routines successfully run
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:20 --> Session Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:43:20 --> Session routines successfully run
DEBUG - 2014-01-30 23:43:20 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:43:20 --> Final output sent to browser
DEBUG - 2014-01-30 23:43:20 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:43:20 --> Model Class Initialized
DEBUG - 2014-01-30 23:43:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:43:20 --> Final output sent to browser
DEBUG - 2014-01-30 23:43:20 --> Total execution time: 0.0240
DEBUG - 2014-01-30 23:44:18 --> Config Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:44:18 --> URI Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Router Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Output Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Security Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Input Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:44:18 --> Language Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Loader Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Controller Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:44:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:44:18 --> Session Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:44:18 --> Session routines successfully run
DEBUG - 2014-01-30 23:44:18 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:44:18 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:44:18 --> Final output sent to browser
DEBUG - 2014-01-30 23:44:18 --> Total execution time: 0.0250
DEBUG - 2014-01-30 23:44:22 --> Config Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:44:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:44:22 --> URI Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Router Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Output Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Security Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Input Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:44:22 --> Language Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Loader Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Controller Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:44:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:44:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:44:22 --> Session Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:44:22 --> Session routines successfully run
DEBUG - 2014-01-30 23:44:22 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:44:22 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:44:22 --> Final output sent to browser
DEBUG - 2014-01-30 23:44:22 --> Total execution time: 0.0420
DEBUG - 2014-01-30 23:44:24 --> Config Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:44:24 --> URI Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Router Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Output Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Security Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Input Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:44:24 --> Language Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Loader Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Controller Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:44:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:44:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:44:24 --> Session Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:44:24 --> Session routines successfully run
DEBUG - 2014-01-30 23:44:24 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:44:24 --> Model Class Initialized
DEBUG - 2014-01-30 23:44:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:44:24 --> Final output sent to browser
DEBUG - 2014-01-30 23:44:24 --> Total execution time: 0.0310
DEBUG - 2014-01-30 23:45:00 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:00 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:00 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:00 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:00 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:00 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:00 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:00 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:00 --> Total execution time: 0.0240
DEBUG - 2014-01-30 23:45:01 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:01 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:01 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:01 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:01 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:01 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:01 --> Total execution time: 0.0330
DEBUG - 2014-01-30 23:45:02 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:02 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:02 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:02 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:02 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:02 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:02 --> Total execution time: 0.0410
DEBUG - 2014-01-30 23:45:03 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:03 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:03 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:03 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:03 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:03 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:03 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:03 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:03 --> Total execution time: 0.0420
DEBUG - 2014-01-30 23:45:04 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:04 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:04 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:04 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:04 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:04 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:04 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:04 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:05 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:05 --> Total execution time: 0.0430
DEBUG - 2014-01-30 23:45:06 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:06 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:06 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:06 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:06 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:06 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:06 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:06 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:06 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:06 --> Total execution time: 0.0320
DEBUG - 2014-01-30 23:45:07 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:07 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:07 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:07 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:07 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:07 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:07 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:07 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:07 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:07 --> Total execution time: 0.0380
DEBUG - 2014-01-30 23:45:08 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:08 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:08 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:08 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:08 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:08 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:08 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:08 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:08 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:08 --> Total execution time: 0.0300
DEBUG - 2014-01-30 23:45:09 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:09 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:09 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:09 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:09 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:09 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:09 --> Total execution time: 0.0430
DEBUG - 2014-01-30 23:45:10 --> Config Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:45:10 --> URI Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Router Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Output Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Security Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Input Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:45:10 --> Language Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Loader Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Controller Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:45:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:45:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:10 --> Session Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:45:10 --> Session routines successfully run
DEBUG - 2014-01-30 23:45:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:45:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:45:10 --> Final output sent to browser
DEBUG - 2014-01-30 23:45:10 --> Total execution time: 0.0360
DEBUG - 2014-01-30 23:47:27 --> Config Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:47:27 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:47:27 --> URI Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Router Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Output Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Security Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Input Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:47:27 --> Language Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Loader Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Controller Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:47:27 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:47:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:27 --> Session Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:47:27 --> Session routines successfully run
DEBUG - 2014-01-30 23:47:27 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:47:27 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:27 --> Final output sent to browser
DEBUG - 2014-01-30 23:47:27 --> Total execution time: 0.0330
DEBUG - 2014-01-30 23:47:46 --> Config Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:47:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:47:46 --> URI Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Router Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Output Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Security Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Input Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:47:46 --> Language Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Loader Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Controller Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:47:46 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:47:46 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:46 --> Session Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:47:46 --> Session routines successfully run
DEBUG - 2014-01-30 23:47:46 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:47:46 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:46 --> Final output sent to browser
DEBUG - 2014-01-30 23:47:46 --> Total execution time: 0.0380
DEBUG - 2014-01-30 23:47:48 --> Config Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:47:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:47:48 --> URI Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Router Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Output Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Security Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Input Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:47:48 --> Language Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Loader Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Controller Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:47:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:48 --> Session Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:47:48 --> Session routines successfully run
DEBUG - 2014-01-30 23:47:48 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:47:48 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:48 --> Final output sent to browser
DEBUG - 2014-01-30 23:47:48 --> Total execution time: 0.0320
DEBUG - 2014-01-30 23:47:49 --> Config Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:47:49 --> URI Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Router Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Output Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Security Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Input Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:47:49 --> Language Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Loader Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Controller Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:47:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:47:49 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:49 --> Session Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:47:49 --> Session routines successfully run
DEBUG - 2014-01-30 23:47:49 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:47:49 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:49 --> Final output sent to browser
DEBUG - 2014-01-30 23:47:49 --> Total execution time: 0.0300
DEBUG - 2014-01-30 23:47:53 --> Config Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:47:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:47:53 --> URI Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Router Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Output Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Security Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Input Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:47:53 --> Language Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Loader Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Controller Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:47:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:47:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:53 --> Session Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:47:53 --> Session routines successfully run
DEBUG - 2014-01-30 23:47:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:47:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:47:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:47:53 --> Final output sent to browser
DEBUG - 2014-01-30 23:47:53 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:48:12 --> Config Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:48:12 --> URI Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Router Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Output Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Security Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Input Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:48:12 --> Language Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Loader Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Controller Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:48:12 --> Session Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:48:12 --> Session routines successfully run
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:48:12 --> Final output sent to browser
DEBUG - 2014-01-30 23:48:12 --> Total execution time: 0.0420
DEBUG - 2014-01-30 23:48:12 --> Config Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:48:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:48:12 --> URI Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Router Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Output Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Security Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Input Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:48:12 --> Language Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Loader Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Controller Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:48:12 --> Session Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:48:12 --> Session routines successfully run
DEBUG - 2014-01-30 23:48:12 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:48:12 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:48:12 --> Final output sent to browser
DEBUG - 2014-01-30 23:48:12 --> Total execution time: 0.0330
DEBUG - 2014-01-30 23:48:13 --> Config Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:48:13 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:48:13 --> URI Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Router Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Output Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Security Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Input Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:48:13 --> Language Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Loader Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Controller Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:48:13 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:48:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:48:13 --> Session Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:48:13 --> Session routines successfully run
DEBUG - 2014-01-30 23:48:13 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:48:13 --> Model Class Initialized
DEBUG - 2014-01-30 23:48:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:48:13 --> Final output sent to browser
DEBUG - 2014-01-30 23:48:13 --> Total execution time: 0.0400
DEBUG - 2014-01-30 23:56:51 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:51 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:51 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:51 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:51 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:51 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:51 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:51 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:56:51 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:51 --> Total execution time: 0.0230
DEBUG - 2014-01-30 23:56:52 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:52 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:52 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:52 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:52 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:52 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:52 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:52 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:52 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:52 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:52 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:52 --> Total execution time: 0.0150
DEBUG - 2014-01-30 23:56:52 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:52 --> Total execution time: 0.0260
DEBUG - 2014-01-30 23:56:53 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:53 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:53 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:53 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:53 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:53 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:53 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:53 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:56:53 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:53 --> Total execution time: 0.0180
DEBUG - 2014-01-30 23:56:54 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:54 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:54 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:54 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:54 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:54 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:54 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:54 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:54 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:54 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:54 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:54 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:54 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:56:54 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:54 --> Total execution time: 0.0250
DEBUG - 2014-01-30 23:56:55 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:55 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:55 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:55 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:55 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:55 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:55 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:55 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:56:55 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:55 --> Total execution time: 0.0150
DEBUG - 2014-01-30 23:56:56 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:56 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:56 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:56 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:56 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:56 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:56 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:56 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:56 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:56:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:56 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:56 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:56 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:56 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:56 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:56 --> Total execution time: 0.0280
DEBUG - 2014-01-30 23:56:57 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:57 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:57 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:57 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:57 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:57 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:57 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:56:57 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:57 --> Total execution time: 0.0160
DEBUG - 2014-01-30 23:56:58 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:58 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:58 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:58 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:58 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:58 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:58 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:58 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:58 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:58 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:56:58 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:58 --> Total execution time: 0.0250
DEBUG - 2014-01-30 23:56:58 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:58 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:58 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:58 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:58 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:58 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:58 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:56:58 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:58 --> Total execution time: 0.0170
DEBUG - 2014-01-30 23:56:59 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:59 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Config Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:56:59 --> URI Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:59 --> Router Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Output Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Security Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:59 --> Input Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Language Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Loader Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Controller Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:59 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:59 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Session Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:56:59 --> Session routines successfully run
DEBUG - 2014-01-30 23:56:59 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:56:59 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:59 --> Total execution time: 0.0130
DEBUG - 2014-01-30 23:56:59 --> Model Class Initialized
DEBUG - 2014-01-30 23:56:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:56:59 --> Final output sent to browser
DEBUG - 2014-01-30 23:56:59 --> Total execution time: 0.0260
DEBUG - 2014-01-30 23:57:01 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:01 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:01 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:01 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:01 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:01 --> File loaded: application/views/admin/members.php
DEBUG - 2014-01-30 23:57:01 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:01 --> Total execution time: 0.0200
DEBUG - 2014-01-30 23:57:01 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:01 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:01 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:01 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:01 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:01 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:01 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:01 --> Total execution time: 0.0100
DEBUG - 2014-01-30 23:57:02 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:02 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:02 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:02 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:02 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-30 23:57:02 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:02 --> Total execution time: 0.0190
DEBUG - 2014-01-30 23:57:02 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:02 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:02 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:02 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:02 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:02 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:02 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:02 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:02 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:02 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:02 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:02 --> Total execution time: 0.0120
DEBUG - 2014-01-30 23:57:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:02 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:02 --> Total execution time: 0.0280
DEBUG - 2014-01-30 23:57:04 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:04 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:05 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:05 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:05 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:05 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:05 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:05 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:05 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:05 --> Total execution time: 0.0340
DEBUG - 2014-01-30 23:57:09 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:09 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:09 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:09 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:09 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:09 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:09 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:09 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:09 --> Total execution time: 0.0280
DEBUG - 2014-01-30 23:57:10 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:10 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:10 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:10 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:10 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:10 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:10 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:10 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:10 --> Total execution time: 0.0420
DEBUG - 2014-01-30 23:57:11 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:11 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:11 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:11 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:11 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:11 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:11 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:11 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:11 --> Total execution time: 0.0270
DEBUG - 2014-01-30 23:57:30 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:30 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:30 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:30 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:30 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:30 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:30 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:30 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:30 --> Total execution time: 0.0440
DEBUG - 2014-01-30 23:57:32 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:32 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:32 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:32 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:32 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:32 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:32 --> Total execution time: 0.0420
DEBUG - 2014-01-30 23:57:32 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:32 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:32 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:32 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:32 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:32 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:32 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:32 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:32 --> Total execution time: 0.0280
DEBUG - 2014-01-30 23:57:33 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:33 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:33 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:33 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:33 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:33 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:33 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:33 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:33 --> Total execution time: 0.0430
DEBUG - 2014-01-30 23:57:34 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:34 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:34 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:34 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:34 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:34 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:34 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:34 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:34 --> Total execution time: 0.0410
DEBUG - 2014-01-30 23:57:37 --> Config Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Hooks Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Utf8 Class Initialized
DEBUG - 2014-01-30 23:57:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-30 23:57:37 --> URI Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Router Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Output Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Security Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Input Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-30 23:57:37 --> Language Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Loader Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Controller Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-30 23:57:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-30 23:57:37 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Database Driver Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:37 --> Session Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Helper loaded: string_helper
DEBUG - 2014-01-30 23:57:37 --> Session routines successfully run
DEBUG - 2014-01-30 23:57:37 --> Helper loaded: url_helper
DEBUG - 2014-01-30 23:57:37 --> Model Class Initialized
DEBUG - 2014-01-30 23:57:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-30 23:57:37 --> Final output sent to browser
DEBUG - 2014-01-30 23:57:37 --> Total execution time: 0.0440
