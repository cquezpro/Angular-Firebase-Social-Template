<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-15 05:52:43 --> Config Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Hooks Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Utf8 Class Initialized
DEBUG - 2014-03-15 05:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 05:52:43 --> URI Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Router Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Output Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Security Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Input Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 05:52:43 --> Language Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Loader Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Controller Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 05:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 05:52:43 --> Model Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Model Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Database Driver Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Model Class Initialized
DEBUG - 2014-03-15 05:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 05:52:43 --> Final output sent to browser
DEBUG - 2014-03-15 05:52:43 --> Total execution time: 0.0100
DEBUG - 2014-03-15 05:52:49 --> Config Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Hooks Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Utf8 Class Initialized
DEBUG - 2014-03-15 05:52:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 05:52:49 --> URI Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Router Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Output Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Security Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Input Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 05:52:49 --> Language Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Loader Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Controller Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 05:52:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 05:52:49 --> Model Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Model Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Database Driver Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Model Class Initialized
DEBUG - 2014-03-15 05:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 05:52:49 --> Final output sent to browser
DEBUG - 2014-03-15 05:52:49 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:30:27 --> Config Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:30:27 --> URI Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Router Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Output Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Security Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Input Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:30:27 --> Language Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Loader Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Controller Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:30:27 --> Config Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Config Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:30:27 --> URI Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:30:27 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:30:27 --> URI Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Router Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Router Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Output Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Output Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:27 --> Security Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Session Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Input Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:30:27 --> A session cookie was not found.
DEBUG - 2014-03-15 12:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:30:27 --> Session routines successfully run
DEBUG - 2014-03-15 12:30:27 --> Language Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Security Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:30:27 --> Loader Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:27 --> Input Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Controller Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:30:27 --> Language Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Loader Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Final output sent to browser
DEBUG - 2014-03-15 12:30:27 --> Controller Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
ERROR - 2014-03-15 12:30:27 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-15 12:30:27 --> Database Driver Class Initialized
ERROR - 2014-03-15 12:30:27 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:27 --> Session Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:30:27 --> A session cookie was not found.
DEBUG - 2014-03-15 12:30:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:27 --> Session routines successfully run
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:30:27 --> Session Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:30:27 --> Final output sent to browser
DEBUG - 2014-03-15 12:30:27 --> Total execution time: 0.0160
DEBUG - 2014-03-15 12:30:27 --> A session cookie was not found.
DEBUG - 2014-03-15 12:30:27 --> Session routines successfully run
DEBUG - 2014-03-15 12:30:27 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:30:27 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:27 --> Final output sent to browser
DEBUG - 2014-03-15 12:30:27 --> Total execution time: 0.0250
DEBUG - 2014-03-15 12:30:37 --> Config Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:30:37 --> URI Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Router Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Output Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Security Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Input Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:30:37 --> Language Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Loader Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Controller Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:30:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:30:37 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:37 --> Final output sent to browser
DEBUG - 2014-03-15 12:30:37 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:30:46 --> Config Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:30:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:30:46 --> URI Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Router Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Output Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Security Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Input Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:30:46 --> Language Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Loader Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Controller Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:30:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:30:46 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:46 --> Final output sent to browser
DEBUG - 2014-03-15 12:30:46 --> Total execution time: 0.0100
DEBUG - 2014-03-15 12:30:54 --> Config Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:30:54 --> URI Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Router Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Output Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Security Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Input Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:30:54 --> Language Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Loader Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Controller Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:30:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:30:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:30:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:30:54 --> Final output sent to browser
DEBUG - 2014-03-15 12:30:54 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:31:47 --> Config Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:31:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:31:47 --> URI Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Router Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Output Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Security Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Input Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:31:47 --> Language Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Loader Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Controller Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:31:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:31:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Helper loaded: email_helper
DEBUG - 2014-03-15 12:31:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:31:49 --> Final output sent to browser
DEBUG - 2014-03-15 12:31:49 --> Total execution time: 1.9321
DEBUG - 2014-03-15 12:31:55 --> Config Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:31:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:31:55 --> URI Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Router Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Output Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Security Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Input Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:31:55 --> Language Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Loader Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Controller Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:31:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:31:55 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Image Lib Class Initialized
DEBUG - 2014-03-15 12:31:55 --> Final output sent to browser
DEBUG - 2014-03-15 12:31:55 --> Total execution time: 0.0800
DEBUG - 2014-03-15 12:31:58 --> Config Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:31:58 --> URI Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Router Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Output Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Security Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Input Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:31:58 --> Language Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Loader Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Controller Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:31:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:31:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Database Driver Class Initialized
ERROR - 2014-03-15 12:31:58 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-15 12:31:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:31:58 --> Image Lib Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:31:59 --> Final output sent to browser
DEBUG - 2014-03-15 12:31:59 --> Total execution time: 0.8941
DEBUG - 2014-03-15 12:31:59 --> Config Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:31:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:31:59 --> URI Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Router Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Output Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Security Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Input Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:31:59 --> Language Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Loader Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Controller Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:31:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:31:59 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Model Class Initialized
DEBUG - 2014-03-15 12:31:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:32:00 --> Final output sent to browser
DEBUG - 2014-03-15 12:32:00 --> Total execution time: 0.8760
DEBUG - 2014-03-15 12:35:44 --> Config Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Config Class Initialized
DEBUG - 2014-03-15 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:35:44 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:35:44 --> URI Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:35:44 --> Router Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Config Class Initialized
DEBUG - 2014-03-15 12:35:44 --> URI Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Output Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:35:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:35:44 --> URI Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Router Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Output Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Security Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Router Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Input Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:35:44 --> Output Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Language Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Security Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Input Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:35:44 --> Loader Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Language Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Controller Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Loader Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:35:44 --> Security Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Controller Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Input Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:35:44 --> Language Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Loader Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Controller Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:35:44 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:44 --> Session Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:44 --> A session cookie was not found.
DEBUG - 2014-03-15 12:35:44 --> Session routines successfully run
DEBUG - 2014-03-15 12:35:44 --> Session Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:35:44 --> A session cookie was not found.
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:44 --> Session Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:35:44 --> A session cookie was not found.
DEBUG - 2014-03-15 12:35:44 --> Session routines successfully run
DEBUG - 2014-03-15 12:35:44 --> Final output sent to browser
DEBUG - 2014-03-15 12:35:44 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:35:44 --> Session routines successfully run
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:44 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:35:44 --> Final output sent to browser
DEBUG - 2014-03-15 12:35:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:44 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:35:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:44 --> Final output sent to browser
DEBUG - 2014-03-15 12:35:44 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:35:47 --> Config Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:35:47 --> Config Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:35:47 --> URI Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Router Class Initialized
DEBUG - 2014-03-15 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:35:47 --> URI Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Router Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Output Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Security Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Output Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Input Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:35:47 --> Security Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Config Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Language Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Input Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:35:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Language Class Initialized
DEBUG - 2014-03-15 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:35:47 --> Loader Class Initialized
DEBUG - 2014-03-15 12:35:47 --> URI Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Controller Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Router Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Loader Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Controller Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:35:47 --> Output Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:35:47 --> Security Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Input Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:35:47 --> Language Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Loader Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Controller Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Session Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:35:47 --> A session cookie was not found.
DEBUG - 2014-03-15 12:35:47 --> Session routines successfully run
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Final output sent to browser
DEBUG - 2014-03-15 12:35:47 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:47 --> Session Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:35:47 --> A session cookie was not found.
DEBUG - 2014-03-15 12:35:47 --> Session routines successfully run
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:47 --> Session Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:35:47 --> A session cookie was not found.
DEBUG - 2014-03-15 12:35:47 --> Final output sent to browser
DEBUG - 2014-03-15 12:35:47 --> Session routines successfully run
DEBUG - 2014-03-15 12:35:47 --> Total execution time: 0.0150
DEBUG - 2014-03-15 12:35:47 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:35:47 --> Model Class Initialized
DEBUG - 2014-03-15 12:35:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:35:47 --> Final output sent to browser
DEBUG - 2014-03-15 12:35:47 --> Total execution time: 0.0160
DEBUG - 2014-03-15 12:36:02 --> Config Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:36:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:36:02 --> URI Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Router Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Output Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Security Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Input Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:36:02 --> Language Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Loader Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Controller Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:36:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:36:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:36:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:36:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:36:03 --> Total execution time: 0.9531
DEBUG - 2014-03-15 12:43:28 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:28 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:28 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:28 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:28 --> Session Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Session Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:43:28 --> A session cookie was not found.
DEBUG - 2014-03-15 12:43:28 --> A session cookie was not found.
DEBUG - 2014-03-15 12:43:28 --> Session routines successfully run
DEBUG - 2014-03-15 12:43:28 --> Session routines successfully run
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:28 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:28 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:28 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:43:28 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:43:28 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:28 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:28 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:28 --> Session Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:43:28 --> A session cookie was not found.
DEBUG - 2014-03-15 12:43:28 --> Session routines successfully run
DEBUG - 2014-03-15 12:43:28 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:43:28 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:28 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:28 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:43:29 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:29 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:29 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:29 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:29 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:29 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:29 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:29 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:29 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:29 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Session Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:29 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:43:29 --> A session cookie was not found.
DEBUG - 2014-03-15 12:43:29 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:29 --> Session routines successfully run
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:29 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:43:29 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:29 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:29 --> Session Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:43:29 --> A session cookie was not found.
DEBUG - 2014-03-15 12:43:29 --> Session Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Session routines successfully run
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:43:29 --> A session cookie was not found.
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:43:29 --> Session routines successfully run
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:29 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:29 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:29 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:29 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:43:29 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:43:37 --> Config Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:43:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:43:37 --> URI Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Router Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Output Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Security Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Input Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:43:37 --> Language Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Loader Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Controller Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:43:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:43:37 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Model Class Initialized
DEBUG - 2014-03-15 12:43:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:43:38 --> Final output sent to browser
DEBUG - 2014-03-15 12:43:38 --> Total execution time: 0.9371
DEBUG - 2014-03-15 12:44:09 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:09 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:09 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:09 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:09 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:09 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:09 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:09 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:09 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Session Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:44:09 --> A session cookie was not found.
DEBUG - 2014-03-15 12:44:09 --> Session routines successfully run
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:44:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:09 --> Session Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:44:09 --> A session cookie was not found.
DEBUG - 2014-03-15 12:44:09 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Session routines successfully run
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:44:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:09 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:09 --> Total execution time: 0.0150
DEBUG - 2014-03-15 12:44:09 --> Session Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:44:09 --> A session cookie was not found.
DEBUG - 2014-03-15 12:44:09 --> Session routines successfully run
DEBUG - 2014-03-15 12:44:09 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:44:09 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:09 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:09 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:44:11 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:11 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:11 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:11 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:11 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:11 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:11 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:11 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:11 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:11 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:11 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Session Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:44:11 --> A session cookie was not found.
DEBUG - 2014-03-15 12:44:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Session routines successfully run
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Session Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:44:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:11 --> A session cookie was not found.
DEBUG - 2014-03-15 12:44:11 --> Session routines successfully run
DEBUG - 2014-03-15 12:44:11 --> Session Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:44:11 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> A session cookie was not found.
DEBUG - 2014-03-15 12:44:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:11 --> Session routines successfully run
DEBUG - 2014-03-15 12:44:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:44:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:11 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:11 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:44:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:11 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:11 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:44:18 --> Config Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:44:18 --> URI Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Router Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Output Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Security Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Input Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:44:18 --> Language Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Loader Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Controller Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:44:18 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Model Class Initialized
DEBUG - 2014-03-15 12:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:44:19 --> Final output sent to browser
DEBUG - 2014-03-15 12:44:19 --> Total execution time: 0.9201
DEBUG - 2014-03-15 12:46:01 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:01 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:01 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:01 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:01 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:01 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:01 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:01 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:01 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:01 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:01 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:01 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:01 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:01 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:46:01 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:01 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:01 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:46:01 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:01 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:01 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:01 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:01 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:01 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:01 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:01 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:01 --> Total execution time: 0.0210
DEBUG - 2014-03-15 12:46:02 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:02 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:02 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:02 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:02 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:02 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:02 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:02 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:02 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:02 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:02 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:02 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:03 --> Total execution time: 0.0160
DEBUG - 2014-03-15 12:46:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:03 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:03 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:03 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:03 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:03 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:03 --> Total execution time: 0.0230
DEBUG - 2014-03-15 12:46:03 --> Total execution time: 0.0220
DEBUG - 2014-03-15 12:46:11 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:11 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:11 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:12 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:12 --> Total execution time: 0.9061
DEBUG - 2014-03-15 12:46:53 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:53 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:53 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:53 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:53 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:53 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:53 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:53 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:53 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:46:53 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:53 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:53 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:53 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:53 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:53 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:53 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:53 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:53 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:53 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:53 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:53 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:53 --> Total execution time: 0.0140
DEBUG - 2014-03-15 12:46:54 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:54 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Config Class Initialized
DEBUG - 2014-03-15 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:54 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:54 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:46:54 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:54 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:54 --> URI Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Router Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Output Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Security Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Input Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:46:54 --> Language Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Loader Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Controller Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:54 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:54 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:54 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:54 --> Total execution time: 0.0190
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:54 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:54 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:54 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:54 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:54 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:54 --> Session Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:46:54 --> A session cookie was not found.
DEBUG - 2014-03-15 12:46:54 --> Session routines successfully run
DEBUG - 2014-03-15 12:46:54 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:46:54 --> Model Class Initialized
DEBUG - 2014-03-15 12:46:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:46:54 --> Final output sent to browser
DEBUG - 2014-03-15 12:46:54 --> Total execution time: 0.0240
DEBUG - 2014-03-15 12:47:02 --> Config Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:47:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:47:02 --> URI Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Router Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Output Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Security Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Input Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:47:02 --> Language Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Loader Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Controller Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:47:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:47:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Model Class Initialized
DEBUG - 2014-03-15 12:47:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:47:02 --> Final output sent to browser
DEBUG - 2014-03-15 12:47:02 --> Total execution time: 0.9251
DEBUG - 2014-03-15 12:50:41 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:41 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:41 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:41 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:41 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:41 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:41 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Session Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:50:41 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:41 --> A session cookie was not found.
DEBUG - 2014-03-15 12:50:41 --> Session routines successfully run
DEBUG - 2014-03-15 12:50:41 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:50:41 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:41 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:41 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:41 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:50:41 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:41 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:41 --> Session Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:50:41 --> A session cookie was not found.
DEBUG - 2014-03-15 12:50:41 --> Session routines successfully run
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:41 --> Session Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:50:41 --> A session cookie was not found.
DEBUG - 2014-03-15 12:50:41 --> Session routines successfully run
DEBUG - 2014-03-15 12:50:41 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:50:41 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:41 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:41 --> Total execution time: 0.0210
DEBUG - 2014-03-15 12:50:41 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:41 --> Total execution time: 0.0260
DEBUG - 2014-03-15 12:50:42 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:42 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:42 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:42 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:42 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:42 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:42 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:42 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:42 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:42 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:42 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:42 --> Session Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:50:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:42 --> A session cookie was not found.
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Session routines successfully run
DEBUG - 2014-03-15 12:50:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:42 --> Session Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:50:42 --> Session Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:50:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:42 --> A session cookie was not found.
DEBUG - 2014-03-15 12:50:42 --> Session routines successfully run
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:50:42 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:42 --> Total execution time: 0.0320
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:42 --> A session cookie was not found.
DEBUG - 2014-03-15 12:50:42 --> Session routines successfully run
DEBUG - 2014-03-15 12:50:42 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:50:42 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:42 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:42 --> Total execution time: 0.0340
DEBUG - 2014-03-15 12:50:42 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:42 --> Total execution time: 0.0350
DEBUG - 2014-03-15 12:50:50 --> Config Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:50:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:50:50 --> URI Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Router Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Output Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Security Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Input Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:50:50 --> Language Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Loader Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Controller Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:50:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:50:50 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Model Class Initialized
DEBUG - 2014-03-15 12:50:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:50:51 --> Final output sent to browser
DEBUG - 2014-03-15 12:50:51 --> Total execution time: 0.8961
DEBUG - 2014-03-15 12:52:57 --> Config Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Config Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Config Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:52:57 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:52:57 --> URI Class Initialized
DEBUG - 2014-03-15 12:52:57 --> URI Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:52:57 --> Router Class Initialized
DEBUG - 2014-03-15 12:52:57 --> URI Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Router Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Output Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Output Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Security Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Security Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Input Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Router Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:52:57 --> Input Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:52:57 --> Language Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Output Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Loader Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Security Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Controller Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Language Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:52:57 --> Input Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:52:57 --> Loader Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Controller Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:52:57 --> Language Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Loader Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Controller Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Session Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> A session cookie was not found.
DEBUG - 2014-03-15 12:52:57 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Session routines successfully run
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:52:57 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:57 --> Final output sent to browser
DEBUG - 2014-03-15 12:52:57 --> Total execution time: 0.0150
DEBUG - 2014-03-15 12:52:57 --> Session Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:52:57 --> A session cookie was not found.
DEBUG - 2014-03-15 12:52:57 --> Session routines successfully run
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:57 --> Session Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:52:57 --> A session cookie was not found.
DEBUG - 2014-03-15 12:52:57 --> Session routines successfully run
DEBUG - 2014-03-15 12:52:57 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:52:57 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:57 --> Final output sent to browser
DEBUG - 2014-03-15 12:52:57 --> Total execution time: 0.0210
DEBUG - 2014-03-15 12:52:57 --> Final output sent to browser
DEBUG - 2014-03-15 12:52:57 --> Total execution time: 0.0220
DEBUG - 2014-03-15 12:52:58 --> Config Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:52:58 --> URI Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Router Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Output Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Security Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Input Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:52:58 --> Language Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Config Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Loader Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Controller Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Config Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:52:58 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:52:58 --> URI Class Initialized
DEBUG - 2014-03-15 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Router Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> URI Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Router Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Output Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Security Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Output Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Input Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Security Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Input Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Language Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:52:58 --> Loader Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Session Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Controller Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Language Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:52:58 --> A session cookie was not found.
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:52:58 --> Loader Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Session routines successfully run
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:52:58 --> Controller Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Final output sent to browser
DEBUG - 2014-03-15 12:52:58 --> Total execution time: 0.0110
DEBUG - 2014-03-15 12:52:58 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:58 --> Session Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:58 --> A session cookie was not found.
DEBUG - 2014-03-15 12:52:58 --> Session routines successfully run
DEBUG - 2014-03-15 12:52:58 --> Session Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> A session cookie was not found.
DEBUG - 2014-03-15 12:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:58 --> Session routines successfully run
DEBUG - 2014-03-15 12:52:58 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:52:58 --> Final output sent to browser
DEBUG - 2014-03-15 12:52:58 --> Model Class Initialized
DEBUG - 2014-03-15 12:52:58 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:52:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:52:58 --> Final output sent to browser
DEBUG - 2014-03-15 12:52:58 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:53:06 --> Config Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:53:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:53:06 --> URI Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Router Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Output Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Security Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Input Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:53:06 --> Language Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Loader Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Controller Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:53:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:53:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:53:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:53:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:53:07 --> Total execution time: 0.9271
DEBUG - 2014-03-15 12:55:05 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:05 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:05 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:05 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:05 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:05 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:05 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Session Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:05 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:55:05 --> A session cookie was not found.
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Session routines successfully run
DEBUG - 2014-03-15 12:55:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:55:05 --> Session Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:55:05 --> A session cookie was not found.
DEBUG - 2014-03-15 12:55:05 --> Session routines successfully run
DEBUG - 2014-03-15 12:55:05 --> Session Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:55:05 --> A session cookie was not found.
DEBUG - 2014-03-15 12:55:05 --> Session routines successfully run
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:55:05 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:05 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:55:05 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:05 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:05 --> Total execution time: 0.0190
DEBUG - 2014-03-15 12:55:05 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:05 --> Total execution time: 0.0220
DEBUG - 2014-03-15 12:55:07 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:07 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:07 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:07 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:07 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:07 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Session Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:55:07 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:07 --> A session cookie was not found.
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:07 --> Session routines successfully run
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:55:07 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:07 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:07 --> Session Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:07 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:55:07 --> A session cookie was not found.
DEBUG - 2014-03-15 12:55:07 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Session routines successfully run
DEBUG - 2014-03-15 12:55:07 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:55:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:07 --> Total execution time: 0.0150
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:07 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:07 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:07 --> Session Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:55:07 --> A session cookie was not found.
DEBUG - 2014-03-15 12:55:07 --> Session routines successfully run
DEBUG - 2014-03-15 12:55:07 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:55:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:07 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:55:14 --> Config Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:55:14 --> URI Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Router Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Output Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Security Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Input Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:55:14 --> Language Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Loader Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Controller Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:55:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:55:14 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Model Class Initialized
DEBUG - 2014-03-15 12:55:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:55:15 --> Final output sent to browser
DEBUG - 2014-03-15 12:55:15 --> Total execution time: 0.9281
DEBUG - 2014-03-15 12:56:03 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:03 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:03 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:03 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:03 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:03 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:03 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:03 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:03 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:03 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:03 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:03 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:03 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:03 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:03 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:03 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:56:03 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:03 --> Total execution time: 0.0180
DEBUG - 2014-03-15 12:56:03 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:03 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:03 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:56:12 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:12 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:12 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:12 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:12 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:12 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:12 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:12 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:12 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:12 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:12 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:12 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:12 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:12 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:12 --> Total execution time: 0.0120
DEBUG - 2014-03-15 12:56:12 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:12 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:12 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:12 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:12 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:12 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:12 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:12 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:12 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:12 --> Total execution time: 0.0160
DEBUG - 2014-03-15 12:56:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:12 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:12 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:56:44 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:44 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:44 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:44 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:44 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:44 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:44 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:44 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:44 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:44 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:44 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:44 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:44 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:44 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:44 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:44 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:44 --> Session Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:56:44 --> Total execution time: 0.0160
DEBUG - 2014-03-15 12:56:44 --> A session cookie was not found.
DEBUG - 2014-03-15 12:56:44 --> Session routines successfully run
DEBUG - 2014-03-15 12:56:44 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:44 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:56:44 --> Total execution time: 0.0160
DEBUG - 2014-03-15 12:56:44 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:44 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:44 --> Total execution time: 0.0190
DEBUG - 2014-03-15 12:56:52 --> Config Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:56:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:56:52 --> URI Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Router Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Output Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Security Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Input Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:56:52 --> Language Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Loader Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Controller Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:56:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:56:52 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Model Class Initialized
DEBUG - 2014-03-15 12:56:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:56:52 --> Final output sent to browser
DEBUG - 2014-03-15 12:56:52 --> Total execution time: 0.9311
DEBUG - 2014-03-15 12:58:04 --> Config Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Config Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Config Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:58:04 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:58:04 --> URI Class Initialized
DEBUG - 2014-03-15 12:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:58:04 --> Router Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:58:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:58:04 --> URI Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Output Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Router Class Initialized
DEBUG - 2014-03-15 12:58:04 --> URI Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Router Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Output Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Security Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Output Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Security Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Input Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Input Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:58:04 --> Security Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Language Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Input Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Language Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Loader Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:58:04 --> Loader Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Controller Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Language Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Controller Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:58:04 --> Loader Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Controller Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:58:04 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Session Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:58:04 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:58:04 --> A session cookie was not found.
DEBUG - 2014-03-15 12:58:04 --> Session routines successfully run
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Session Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:04 --> Final output sent to browser
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:58:04 --> Total execution time: 0.0140
DEBUG - 2014-03-15 12:58:04 --> Session Class Initialized
DEBUG - 2014-03-15 12:58:04 --> A session cookie was not found.
DEBUG - 2014-03-15 12:58:04 --> Session routines successfully run
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:58:04 --> A session cookie was not found.
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Session routines successfully run
DEBUG - 2014-03-15 12:58:04 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:04 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:04 --> Final output sent to browser
DEBUG - 2014-03-15 12:58:04 --> Final output sent to browser
DEBUG - 2014-03-15 12:58:04 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:58:04 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:58:07 --> Config Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:58:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:58:07 --> URI Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Router Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Output Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Security Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Input Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:58:07 --> Language Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Config Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Config Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Loader Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Controller Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:58:07 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:58:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:58:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:58:07 --> URI Class Initialized
DEBUG - 2014-03-15 12:58:07 --> URI Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Router Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Router Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Output Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Output Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Security Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Security Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Input Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:58:07 --> Input Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Language Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:58:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:07 --> Language Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Loader Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Session Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Controller Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:58:07 --> Loader Class Initialized
DEBUG - 2014-03-15 12:58:07 --> A session cookie was not found.
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:58:07 --> Controller Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Session routines successfully run
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:58:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:07 --> Session Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:58:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:07 --> A session cookie was not found.
DEBUG - 2014-03-15 12:58:07 --> Session routines successfully run
DEBUG - 2014-03-15 12:58:07 --> Session Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:58:07 --> A session cookie was not found.
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Session routines successfully run
DEBUG - 2014-03-15 12:58:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:07 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:58:07 --> Model Class Initialized
DEBUG - 2014-03-15 12:58:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:58:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:58:07 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:58:07 --> Final output sent to browser
DEBUG - 2014-03-15 12:58:07 --> Total execution time: 0.0130
DEBUG - 2014-03-15 12:59:05 --> Config Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Config Class Initialized
DEBUG - 2014-03-15 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:59:05 --> URI Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Router Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Config Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:59:05 --> Output Class Initialized
DEBUG - 2014-03-15 12:59:05 --> URI Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Router Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Security Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Input Class Initialized
DEBUG - 2014-03-15 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:59:05 --> URI Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Router Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Output Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:59:05 --> Security Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Language Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Output Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Loader Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Security Class Initialized
DEBUG - 2014-03-15 12:59:05 --> Input Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:59:06 --> Language Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Loader Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Controller Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:59:06 --> Controller Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Input Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:59:06 --> Language Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Loader Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Controller Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:06 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Session Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> A session cookie was not found.
DEBUG - 2014-03-15 12:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:06 --> Session routines successfully run
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:59:06 --> Session Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:59:06 --> A session cookie was not found.
DEBUG - 2014-03-15 12:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:06 --> Session routines successfully run
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:59:06 --> Session Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: string_helper
DEBUG - 2014-03-15 12:59:06 --> A session cookie was not found.
DEBUG - 2014-03-15 12:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:06 --> Session routines successfully run
DEBUG - 2014-03-15 12:59:06 --> Helper loaded: url_helper
DEBUG - 2014-03-15 12:59:06 --> Final output sent to browser
DEBUG - 2014-03-15 12:59:06 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:06 --> Total execution time: 0.0180
DEBUG - 2014-03-15 12:59:06 --> Final output sent to browser
DEBUG - 2014-03-15 12:59:06 --> Total execution time: 0.0170
DEBUG - 2014-03-15 12:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:06 --> Final output sent to browser
DEBUG - 2014-03-15 12:59:06 --> Total execution time: 0.0200
DEBUG - 2014-03-15 12:59:13 --> Config Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Hooks Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Utf8 Class Initialized
DEBUG - 2014-03-15 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 12:59:13 --> URI Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Router Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Output Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Security Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Input Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 12:59:13 --> Language Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Loader Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Controller Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 12:59:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 12:59:13 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Database Driver Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Model Class Initialized
DEBUG - 2014-03-15 12:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 12:59:14 --> Final output sent to browser
DEBUG - 2014-03-15 12:59:14 --> Total execution time: 0.9441
DEBUG - 2014-03-15 13:00:10 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:10 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:10 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:10 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:10 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:10 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:10 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:10 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:10 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:10 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:10 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:10 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:10 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:10 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:10 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:10 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:10 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:10 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:10 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:10 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:10 --> Total execution time: 0.0130
DEBUG - 2014-03-15 13:00:10 --> Total execution time: 0.0120
DEBUG - 2014-03-15 13:00:10 --> Total execution time: 0.0130
DEBUG - 2014-03-15 13:00:11 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:11 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:11 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:11 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:11 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:11 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:11 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:11 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:11 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:11 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:11 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:11 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:11 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:11 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:11 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:11 --> Total execution time: 0.0150
DEBUG - 2014-03-15 13:00:11 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:11 --> Total execution time: 0.0170
DEBUG - 2014-03-15 13:00:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:11 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:11 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:11 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:11 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:11 --> Total execution time: 0.0220
DEBUG - 2014-03-15 13:00:19 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:19 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:19 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:19 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:20 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:20 --> Total execution time: 1.0581
DEBUG - 2014-03-15 13:00:53 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:53 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:53 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:53 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:53 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:53 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:53 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:53 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:53 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:53 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:53 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:53 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:53 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:53 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:53 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:53 --> Total execution time: 0.0150
DEBUG - 2014-03-15 13:00:53 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:53 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:53 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:53 --> Total execution time: 0.0160
DEBUG - 2014-03-15 13:00:53 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:53 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:53 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:53 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:53 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:53 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:53 --> Total execution time: 0.0210
DEBUG - 2014-03-15 13:00:54 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Config Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:00:54 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:54 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:54 --> URI Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Router Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:54 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Output Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:54 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Security Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Input Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Language Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:54 --> Loader Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Controller Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:00:54 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:00:54 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:54 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:54 --> Total execution time: 0.0120
DEBUG - 2014-03-15 13:00:54 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:54 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:54 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:54 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:54 --> Total execution time: 0.0160
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:54 --> Session Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:00:54 --> A session cookie was not found.
DEBUG - 2014-03-15 13:00:54 --> Session routines successfully run
DEBUG - 2014-03-15 13:00:54 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:00:54 --> Model Class Initialized
DEBUG - 2014-03-15 13:00:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:00:54 --> Final output sent to browser
DEBUG - 2014-03-15 13:00:54 --> Total execution time: 0.0210
DEBUG - 2014-03-15 13:01:03 --> Config Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:01:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:01:03 --> URI Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Router Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Output Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Security Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Input Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:01:03 --> Language Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Loader Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Controller Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:01:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:01:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:01:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:01:04 --> Final output sent to browser
DEBUG - 2014-03-15 13:01:04 --> Total execution time: 0.9121
DEBUG - 2014-03-15 13:02:47 --> Config Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Config Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:02:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:02:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:02:47 --> URI Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Config Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Router Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:02:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:02:47 --> URI Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Router Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Output Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Security Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:02:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:02:47 --> Input Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Output Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:02:47 --> URI Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Security Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Language Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Router Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Loader Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Controller Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Output Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:02:47 --> Security Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Input Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:02:47 --> Language Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Input Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Loader Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Controller Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:02:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:02:47 --> Language Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Loader Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:47 --> Controller Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Session Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:02:47 --> A session cookie was not found.
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Session routines successfully run
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Final output sent to browser
DEBUG - 2014-03-15 13:02:47 --> Total execution time: 0.0120
DEBUG - 2014-03-15 13:02:47 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:47 --> Session Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:02:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:47 --> Session Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:02:47 --> A session cookie was not found.
DEBUG - 2014-03-15 13:02:47 --> A session cookie was not found.
DEBUG - 2014-03-15 13:02:47 --> Session routines successfully run
DEBUG - 2014-03-15 13:02:47 --> Session routines successfully run
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:02:47 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:47 --> Final output sent to browser
DEBUG - 2014-03-15 13:02:47 --> Final output sent to browser
DEBUG - 2014-03-15 13:02:47 --> Total execution time: 0.0160
DEBUG - 2014-03-15 13:02:47 --> Total execution time: 0.0170
DEBUG - 2014-03-15 13:02:51 --> Config Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Config Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Config Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:02:51 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:02:51 --> URI Class Initialized
DEBUG - 2014-03-15 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:02:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:02:51 --> Router Class Initialized
DEBUG - 2014-03-15 13:02:51 --> URI Class Initialized
DEBUG - 2014-03-15 13:02:51 --> URI Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Router Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Router Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Output Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Output Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Security Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Security Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Input Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Input Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:02:51 --> Language Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Output Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Loader Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Language Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Controller Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Security Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:02:51 --> Loader Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Input Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Controller Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:02:51 --> Language Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Loader Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Controller Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Session Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Session Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:02:51 --> A session cookie was not found.
DEBUG - 2014-03-15 13:02:51 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Session routines successfully run
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:02:51 --> A session cookie was not found.
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Session routines successfully run
DEBUG - 2014-03-15 13:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:51 --> Final output sent to browser
DEBUG - 2014-03-15 13:02:51 --> Total execution time: 0.0140
DEBUG - 2014-03-15 13:02:51 --> Final output sent to browser
DEBUG - 2014-03-15 13:02:51 --> Total execution time: 0.0140
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:51 --> Session Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:02:51 --> A session cookie was not found.
DEBUG - 2014-03-15 13:02:51 --> Session routines successfully run
DEBUG - 2014-03-15 13:02:51 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:02:51 --> Model Class Initialized
DEBUG - 2014-03-15 13:02:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:02:51 --> Final output sent to browser
DEBUG - 2014-03-15 13:02:51 --> Total execution time: 0.0190
DEBUG - 2014-03-15 13:03:01 --> Config Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:03:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:03:01 --> URI Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Router Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Output Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Security Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Input Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:03:01 --> Language Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Loader Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Controller Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:03:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:03:01 --> Model Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Model Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Model Class Initialized
DEBUG - 2014-03-15 13:03:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:03:02 --> Final output sent to browser
DEBUG - 2014-03-15 13:03:02 --> Total execution time: 0.9511
DEBUG - 2014-03-15 13:06:03 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:03 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:03 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:03 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:03 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:03 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:03 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:03 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:03 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Session Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:06:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:03 --> A session cookie was not found.
DEBUG - 2014-03-15 13:06:03 --> Session routines successfully run
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:06:03 --> Session Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:06:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:03 --> A session cookie was not found.
DEBUG - 2014-03-15 13:06:03 --> Session routines successfully run
DEBUG - 2014-03-15 13:06:03 --> Session Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:06:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:06:03 --> A session cookie was not found.
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:03 --> Total execution time: 0.0170
DEBUG - 2014-03-15 13:06:03 --> Session routines successfully run
DEBUG - 2014-03-15 13:06:03 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:06:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:03 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:03 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:03 --> Total execution time: 0.0200
DEBUG - 2014-03-15 13:06:03 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:03 --> Total execution time: 0.0190
DEBUG - 2014-03-15 13:06:05 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:05 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:05 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:05 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:05 --> Session Class Initialized
DEBUG - 2014-03-15 13:06:05 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:05 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:06:05 --> A session cookie was not found.
DEBUG - 2014-03-15 13:06:05 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Session routines successfully run
DEBUG - 2014-03-15 13:06:05 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:06:05 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:05 --> Total execution time: 0.0140
DEBUG - 2014-03-15 13:06:05 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:05 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Session Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:06:05 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:05 --> A session cookie was not found.
DEBUG - 2014-03-15 13:06:05 --> Session routines successfully run
DEBUG - 2014-03-15 13:06:05 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:05 --> Total execution time: 0.0170
DEBUG - 2014-03-15 13:06:05 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:05 --> Session Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:06:05 --> A session cookie was not found.
DEBUG - 2014-03-15 13:06:05 --> Session routines successfully run
DEBUG - 2014-03-15 13:06:05 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:06:05 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:05 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:05 --> Total execution time: 0.0260
DEBUG - 2014-03-15 13:06:12 --> Config Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:06:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:06:12 --> URI Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Router Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Output Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Security Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Input Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:06:12 --> Language Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Loader Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Controller Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:06:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:06:12 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Model Class Initialized
DEBUG - 2014-03-15 13:06:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:06:13 --> Final output sent to browser
DEBUG - 2014-03-15 13:06:13 --> Total execution time: 0.9221
DEBUG - 2014-03-15 13:07:11 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:11 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:11 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:11 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:11 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:11 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:11 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:11 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:11 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:11 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:11 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Total execution time: 0.0140
DEBUG - 2014-03-15 13:07:11 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:11 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:11 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:11 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:11 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:11 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:11 --> Total execution time: 0.0220
DEBUG - 2014-03-15 13:07:11 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:11 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:11 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:11 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:11 --> Total execution time: 0.0240
DEBUG - 2014-03-15 13:07:13 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:13 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:13 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:13 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:13 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:13 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:13 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:13 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:13 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:13 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:13 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:13 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:13 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:13 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:13 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:13 --> Total execution time: 0.0180
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:13 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:13 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:13 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:13 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:13 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:13 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:13 --> Total execution time: 0.0180
DEBUG - 2014-03-15 13:07:13 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:13 --> Total execution time: 0.0190
DEBUG - 2014-03-15 13:07:24 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:24 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:24 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:24 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:25 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:25 --> Total execution time: 0.8911
DEBUG - 2014-03-15 13:07:42 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:42 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:42 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:42 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:42 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:42 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:42 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:42 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:42 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:42 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:42 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:42 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:42 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:42 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:42 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:42 --> Total execution time: 0.0130
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:42 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:42 --> Total execution time: 0.0140
DEBUG - 2014-03-15 13:07:42 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:42 --> Session Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: string_helper
DEBUG - 2014-03-15 13:07:42 --> A session cookie was not found.
DEBUG - 2014-03-15 13:07:42 --> Session routines successfully run
DEBUG - 2014-03-15 13:07:42 --> Helper loaded: url_helper
DEBUG - 2014-03-15 13:07:42 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:42 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:42 --> Total execution time: 0.0200
DEBUG - 2014-03-15 13:07:49 --> Config Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Hooks Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Utf8 Class Initialized
DEBUG - 2014-03-15 13:07:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-15 13:07:49 --> URI Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Router Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Output Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Security Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Input Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-15 13:07:49 --> Language Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Loader Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Controller Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-15 13:07:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-15 13:07:49 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Database Driver Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Model Class Initialized
DEBUG - 2014-03-15 13:07:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-15 13:07:50 --> Final output sent to browser
DEBUG - 2014-03-15 13:07:50 --> Total execution time: 0.9041
