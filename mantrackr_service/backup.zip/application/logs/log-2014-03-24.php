<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-03-24 00:02:05 --> Config Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Config Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Config Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:02:05 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:02:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:02:05 --> URI Class Initialized
DEBUG - 2014-03-24 00:02:05 --> URI Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Router Class Initialized
DEBUG - 2014-03-24 00:02:05 --> URI Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Router Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Router Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Output Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Output Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Output Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Security Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Security Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Input Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:02:05 --> Security Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Input Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Language Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:02:05 --> Input Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Language Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Loader Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Loader Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Controller Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:02:05 --> Controller Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Language Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Loader Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Controller Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:02:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:02:05 --> Session Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:02:05 --> A session cookie was not found.
DEBUG - 2014-03-24 00:02:05 --> Session routines successfully run
DEBUG - 2014-03-24 00:02:05 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Session Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:02:05 --> A session cookie was not found.
DEBUG - 2014-03-24 00:02:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:05 --> Session routines successfully run
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:02:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:05 --> Final output sent to browser
DEBUG - 2014-03-24 00:02:05 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Session Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:02:05 --> A session cookie was not found.
DEBUG - 2014-03-24 00:02:05 --> Session routines successfully run
DEBUG - 2014-03-24 00:02:05 --> Final output sent to browser
DEBUG - 2014-03-24 00:02:05 --> Total execution time: 0.0140
DEBUG - 2014-03-24 00:02:05 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:02:05 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:05 --> Final output sent to browser
DEBUG - 2014-03-24 00:02:05 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:02:16 --> Config Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:02:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:02:16 --> URI Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Router Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Output Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Security Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Input Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:02:16 --> Language Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Loader Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Controller Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:02:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:02:16 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Model Class Initialized
DEBUG - 2014-03-24 00:02:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:02:17 --> Final output sent to browser
DEBUG - 2014-03-24 00:02:17 --> Total execution time: 0.9741
DEBUG - 2014-03-24 00:03:48 --> Config Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:03:48 --> URI Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Router Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Output Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Config Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Security Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Config Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Input Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:03:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:03:48 --> Language Class Initialized
DEBUG - 2014-03-24 00:03:48 --> URI Class Initialized
DEBUG - 2014-03-24 00:03:48 --> URI Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Router Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Loader Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Router Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Controller Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Output Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Output Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:03:48 --> Security Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Security Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:03:48 --> Input Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Input Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Language Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Language Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Loader Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Loader Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Controller Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Controller Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:48 --> Session Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:03:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:48 --> A session cookie was not found.
DEBUG - 2014-03-24 00:03:48 --> Session routines successfully run
DEBUG - 2014-03-24 00:03:48 --> Session Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:03:48 --> A session cookie was not found.
DEBUG - 2014-03-24 00:03:48 --> Session routines successfully run
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:03:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:48 --> Session Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:03:48 --> Final output sent to browser
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:03:48 --> A session cookie was not found.
DEBUG - 2014-03-24 00:03:48 --> Session routines successfully run
DEBUG - 2014-03-24 00:03:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:03:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:48 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:48 --> Final output sent to browser
DEBUG - 2014-03-24 00:03:48 --> Total execution time: 0.0170
DEBUG - 2014-03-24 00:03:48 --> Final output sent to browser
DEBUG - 2014-03-24 00:03:48 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:03:50 --> Config Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Config Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Config Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:03:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:03:50 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:03:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:03:50 --> URI Class Initialized
DEBUG - 2014-03-24 00:03:50 --> URI Class Initialized
DEBUG - 2014-03-24 00:03:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:03:50 --> Router Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Router Class Initialized
DEBUG - 2014-03-24 00:03:50 --> URI Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Router Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Output Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Security Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Output Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Output Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Input Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Security Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:03:50 --> Security Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Input Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Input Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Language Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:03:50 --> Language Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Loader Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Language Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Controller Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Loader Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:03:50 --> Controller Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Loader Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:03:50 --> Controller Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:50 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Session Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:03:50 --> A session cookie was not found.
DEBUG - 2014-03-24 00:03:50 --> Session Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Session routines successfully run
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:03:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:50 --> A session cookie was not found.
DEBUG - 2014-03-24 00:03:50 --> Session routines successfully run
DEBUG - 2014-03-24 00:03:50 --> Session Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:03:50 --> A session cookie was not found.
DEBUG - 2014-03-24 00:03:50 --> Final output sent to browser
DEBUG - 2014-03-24 00:03:50 --> Session routines successfully run
DEBUG - 2014-03-24 00:03:50 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:03:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:03:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:03:50 --> Final output sent to browser
DEBUG - 2014-03-24 00:03:50 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:03:50 --> Final output sent to browser
DEBUG - 2014-03-24 00:03:50 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:04:01 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:01 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:01 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:01 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:02 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:02 --> Total execution time: 0.9671
DEBUG - 2014-03-24 00:04:55 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:55 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:55 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:55 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:55 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:55 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Session Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:55 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:55 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:04:55 --> Session Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:04:55 --> A session cookie was not found.
DEBUG - 2014-03-24 00:04:55 --> Session routines successfully run
DEBUG - 2014-03-24 00:04:55 --> A session cookie was not found.
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:04:55 --> Session routines successfully run
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:55 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:04:55 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:55 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:55 --> Session Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:04:55 --> A session cookie was not found.
DEBUG - 2014-03-24 00:04:55 --> Session routines successfully run
DEBUG - 2014-03-24 00:04:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:04:55 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:55 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:55 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:04:57 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:57 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:57 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:57 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:57 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:57 --> Config Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:04:57 --> URI Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:57 --> Router Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Output Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Security Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Input Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:04:57 --> Language Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Loader Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:57 --> Controller Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Session Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:04:57 --> A session cookie was not found.
DEBUG - 2014-03-24 00:04:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:57 --> Session routines successfully run
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Session Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> A session cookie was not found.
DEBUG - 2014-03-24 00:04:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:57 --> Session routines successfully run
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:57 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:57 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:04:57 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:57 --> Total execution time: 0.0140
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:57 --> Session Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:04:57 --> A session cookie was not found.
DEBUG - 2014-03-24 00:04:57 --> Session routines successfully run
DEBUG - 2014-03-24 00:04:57 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:04:57 --> Model Class Initialized
DEBUG - 2014-03-24 00:04:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:04:57 --> Final output sent to browser
DEBUG - 2014-03-24 00:04:57 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:05:00 --> Config Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:05:00 --> URI Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Router Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Output Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Config Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Security Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Config Class Initialized
DEBUG - 2014-03-24 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:05:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Input Class Initialized
DEBUG - 2014-03-24 00:05:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:05:00 --> URI Class Initialized
DEBUG - 2014-03-24 00:05:00 --> URI Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Router Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Language Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Loader Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Router Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Controller Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:05:00 --> Output Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Output Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Security Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Security Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:05:00 --> Input Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Language Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Loader Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Input Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Controller Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:00 --> Language Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Loader Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Session Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:05:00 --> A session cookie was not found.
DEBUG - 2014-03-24 00:05:00 --> Session routines successfully run
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:00 --> Controller Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:05:00 --> Session Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:00 --> A session cookie was not found.
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:05:00 --> Session routines successfully run
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Final output sent to browser
DEBUG - 2014-03-24 00:05:00 --> Final output sent to browser
DEBUG - 2014-03-24 00:05:00 --> Total execution time: 0.0140
DEBUG - 2014-03-24 00:05:00 --> Total execution time: 0.0180
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:00 --> Session Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:05:00 --> A session cookie was not found.
DEBUG - 2014-03-24 00:05:00 --> Session routines successfully run
DEBUG - 2014-03-24 00:05:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:05:00 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:00 --> Final output sent to browser
DEBUG - 2014-03-24 00:05:00 --> Total execution time: 0.0190
DEBUG - 2014-03-24 00:05:09 --> Config Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:05:09 --> URI Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Router Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Output Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Security Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Input Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:05:09 --> Language Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Loader Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Controller Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:05:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:05:09 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Model Class Initialized
DEBUG - 2014-03-24 00:05:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:05:10 --> Final output sent to browser
DEBUG - 2014-03-24 00:05:10 --> Total execution time: 0.9661
DEBUG - 2014-03-24 00:06:28 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:28 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:28 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:28 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:28 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:28 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:28 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:28 --> Session Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:06:28 --> A session cookie was not found.
DEBUG - 2014-03-24 00:06:28 --> Session Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Session routines successfully run
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:06:28 --> A session cookie was not found.
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Session routines successfully run
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Session Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:06:28 --> A session cookie was not found.
DEBUG - 2014-03-24 00:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:28 --> Session routines successfully run
DEBUG - 2014-03-24 00:06:28 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:06:28 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:28 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:28 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:29 --> Total execution time: 0.0170
DEBUG - 2014-03-24 00:06:29 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:29 --> Total execution time: 0.0180
DEBUG - 2014-03-24 00:06:29 --> Total execution time: 0.0170
DEBUG - 2014-03-24 00:06:30 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:30 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:30 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:30 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:30 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:30 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:30 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:30 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:30 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:30 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Session Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Session Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:30 --> A session cookie was not found.
DEBUG - 2014-03-24 00:06:30 --> A session cookie was not found.
DEBUG - 2014-03-24 00:06:30 --> Session routines successfully run
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Session routines successfully run
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:30 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:30 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:06:30 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:06:30 --> Session Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:06:30 --> A session cookie was not found.
DEBUG - 2014-03-24 00:06:30 --> Session routines successfully run
DEBUG - 2014-03-24 00:06:30 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:06:30 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:30 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:30 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:06:39 --> Config Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:06:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:06:39 --> URI Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Router Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Output Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Security Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Input Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:06:39 --> Language Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Loader Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Controller Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:06:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:06:39 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Model Class Initialized
DEBUG - 2014-03-24 00:06:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:06:40 --> Final output sent to browser
DEBUG - 2014-03-24 00:06:40 --> Total execution time: 0.9721
DEBUG - 2014-03-24 00:48:35 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:35 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:35 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:35 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:35 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:35 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:35 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:35 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:35 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:35 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:35 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:35 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:35 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:35 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:35 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:35 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:35 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:35 --> Total execution time: 0.0220
DEBUG - 2014-03-24 00:48:35 --> Total execution time: 0.0220
DEBUG - 2014-03-24 00:48:35 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:35 --> Total execution time: 0.0250
DEBUG - 2014-03-24 00:48:36 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:36 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:36 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:36 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:36 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:36 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:36 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:36 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:36 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:36 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:36 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:36 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:36 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:36 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:36 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:48:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:36 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:36 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:36 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:36 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:36 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:48:53 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:53 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:53 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:53 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:53 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:53 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:53 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:53 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:53 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:53 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:53 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:53 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:53 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:53 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:48:53 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:53 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:53 --> Total execution time: 0.0170
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:53 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:53 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:53 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:53 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:53 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:53 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:53 --> Total execution time: 0.0220
DEBUG - 2014-03-24 00:48:54 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:54 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:54 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:54 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:54 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Config Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:54 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:54 --> URI Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:54 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Router Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:54 --> Output Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Security Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Input Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:48:54 --> Language Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Loader Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:54 --> Controller Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:48:54 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:54 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:54 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:54 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:48:54 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:54 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:54 --> Session Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:48:54 --> A session cookie was not found.
DEBUG - 2014-03-24 00:48:54 --> Session routines successfully run
DEBUG - 2014-03-24 00:48:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 00:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:48:54 --> Final output sent to browser
DEBUG - 2014-03-24 00:48:54 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:49:09 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:09 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:09 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:09 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:10 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:10 --> Total execution time: 0.9531
DEBUG - 2014-03-24 00:49:50 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:50 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:50 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:50 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:50 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:50 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:50 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:50 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:50 --> Session Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:49:50 --> A session cookie was not found.
DEBUG - 2014-03-24 00:49:50 --> Session routines successfully run
DEBUG - 2014-03-24 00:49:50 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:49:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:50 --> Session Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:49:50 --> A session cookie was not found.
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:50 --> Total execution time: 0.0130
DEBUG - 2014-03-24 00:49:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:50 --> Session Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Session routines successfully run
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> A session cookie was not found.
DEBUG - 2014-03-24 00:49:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:50 --> Session routines successfully run
DEBUG - 2014-03-24 00:49:50 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:49:50 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:50 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:50 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:49:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:50 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:50 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:49:52 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:52 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:52 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:52 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:52 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Config Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:52 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:52 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> URI Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Router Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Output Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Security Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Input Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:52 --> Language Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Session Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Loader Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Controller Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:49:52 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> A session cookie was not found.
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Session routines successfully run
DEBUG - 2014-03-24 00:49:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:49:52 --> Session Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:49:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:52 --> A session cookie was not found.
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Session routines successfully run
DEBUG - 2014-03-24 00:49:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:49:52 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:52 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:49:52 --> Session Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:49:52 --> A session cookie was not found.
DEBUG - 2014-03-24 00:49:52 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:52 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:49:52 --> Session routines successfully run
DEBUG - 2014-03-24 00:49:52 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:49:52 --> Model Class Initialized
DEBUG - 2014-03-24 00:49:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:49:52 --> Final output sent to browser
DEBUG - 2014-03-24 00:49:52 --> Total execution time: 0.0140
DEBUG - 2014-03-24 00:50:03 --> Config Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:50:03 --> URI Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Router Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Output Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Security Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Input Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:50:03 --> Language Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Loader Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Controller Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:50:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:50:03 --> Model Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Model Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Model Class Initialized
DEBUG - 2014-03-24 00:50:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:50:04 --> Final output sent to browser
DEBUG - 2014-03-24 00:50:04 --> Total execution time: 0.9691
DEBUG - 2014-03-24 00:53:26 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:26 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:26 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:26 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:26 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:26 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:26 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:26 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:26 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:26 --> Session Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Session Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:53:26 --> A session cookie was not found.
DEBUG - 2014-03-24 00:53:26 --> A session cookie was not found.
DEBUG - 2014-03-24 00:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:26 --> Session routines successfully run
DEBUG - 2014-03-24 00:53:26 --> Session routines successfully run
DEBUG - 2014-03-24 00:53:26 --> Session Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:53:26 --> A session cookie was not found.
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Session routines successfully run
DEBUG - 2014-03-24 00:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:26 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:26 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:26 --> Total execution time: 0.0160
DEBUG - 2014-03-24 00:53:26 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:26 --> Total execution time: 0.0170
DEBUG - 2014-03-24 00:53:26 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:26 --> Total execution time: 0.0180
DEBUG - 2014-03-24 00:53:27 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:27 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:27 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:27 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:27 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:27 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:27 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:27 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:27 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Session Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:53:27 --> A session cookie was not found.
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Session routines successfully run
DEBUG - 2014-03-24 00:53:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:53:27 --> Session Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:53:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:27 --> A session cookie was not found.
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:27 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:27 --> Session routines successfully run
DEBUG - 2014-03-24 00:53:27 --> Session Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Total execution time: 0.0120
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> A session cookie was not found.
DEBUG - 2014-03-24 00:53:27 --> Session routines successfully run
DEBUG - 2014-03-24 00:53:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:27 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:53:27 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:27 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:27 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:53:27 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:27 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:53:37 --> Config Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:53:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:53:37 --> URI Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Router Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Output Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Security Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Input Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:53:37 --> Language Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Loader Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Controller Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:53:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:53:37 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Model Class Initialized
DEBUG - 2014-03-24 00:53:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:53:38 --> Final output sent to browser
DEBUG - 2014-03-24 00:53:38 --> Total execution time: 1.0671
DEBUG - 2014-03-24 00:54:56 --> Config Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Config Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:54:56 --> URI Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:54:56 --> URI Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Router Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Router Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Output Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Output Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Security Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Security Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Input Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Input Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:54:56 --> Config Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:54:56 --> Language Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Language Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:54:56 --> Loader Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Controller Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Loader Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:54:56 --> Controller Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:54:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:54:56 --> Session Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Session Class Initialized
DEBUG - 2014-03-24 00:54:56 --> URI Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:54:56 --> Router Class Initialized
DEBUG - 2014-03-24 00:54:56 --> A session cookie was not found.
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:54:56 --> A session cookie was not found.
DEBUG - 2014-03-24 00:54:56 --> Session routines successfully run
DEBUG - 2014-03-24 00:54:56 --> Session routines successfully run
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:54:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:54:56 --> Final output sent to browser
DEBUG - 2014-03-24 00:54:56 --> Final output sent to browser
DEBUG - 2014-03-24 00:54:56 --> Total execution time: 0.0140
DEBUG - 2014-03-24 00:54:56 --> Total execution time: 0.0150
DEBUG - 2014-03-24 00:54:56 --> Output Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Security Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Input Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:54:56 --> Language Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Loader Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Controller Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:54:56 --> Session Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 00:54:56 --> A session cookie was not found.
DEBUG - 2014-03-24 00:54:56 --> Session routines successfully run
DEBUG - 2014-03-24 00:54:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 00:54:56 --> Model Class Initialized
DEBUG - 2014-03-24 00:54:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:54:56 --> Final output sent to browser
DEBUG - 2014-03-24 00:54:56 --> Total execution time: 0.0240
DEBUG - 2014-03-24 00:55:04 --> Config Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 00:55:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 00:55:04 --> URI Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Router Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Output Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Security Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Input Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 00:55:04 --> Language Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Loader Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Controller Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 00:55:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 00:55:04 --> Model Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Model Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Model Class Initialized
DEBUG - 2014-03-24 00:55:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 00:55:06 --> Final output sent to browser
DEBUG - 2014-03-24 00:55:06 --> Total execution time: 1.9711
DEBUG - 2014-03-24 01:04:40 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:40 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:40 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:41 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:41 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:41 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:41 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:41 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:41 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:41 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:41 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:41 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:41 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:41 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:41 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:41 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:04:41 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:41 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:41 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:41 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:41 --> Total execution time: 0.0180
DEBUG - 2014-03-24 01:04:41 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:41 --> Total execution time: 0.0180
DEBUG - 2014-03-24 01:04:42 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:42 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:42 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:42 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:42 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:42 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:42 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:42 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:42 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:42 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:42 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:42 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:42 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:42 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:04:42 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:42 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:42 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:04:42 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:42 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:42 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:42 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:42 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:04:45 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:45 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:45 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:45 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:45 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:45 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:45 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:45 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:45 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:45 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:45 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:45 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:45 --> Session Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:04:45 --> A session cookie was not found.
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Session routines successfully run
DEBUG - 2014-03-24 01:04:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:04:45 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:45 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:45 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:45 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:04:45 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:04:45 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:45 --> Total execution time: 0.0150
DEBUG - 2014-03-24 01:04:53 --> Config Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:04:53 --> URI Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Router Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Output Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Security Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Input Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:04:53 --> Language Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Loader Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Controller Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:04:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:04:53 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Model Class Initialized
DEBUG - 2014-03-24 01:04:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:04:54 --> Final output sent to browser
DEBUG - 2014-03-24 01:04:54 --> Total execution time: 0.9871
DEBUG - 2014-03-24 01:44:18 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:18 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:18 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:18 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:18 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:18 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:18 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:18 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:18 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:18 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:18 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:18 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:18 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:18 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:44:18 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:18 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:18 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:18 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:18 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:18 --> Total execution time: 0.0180
DEBUG - 2014-03-24 01:44:19 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:19 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:19 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:19 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:19 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:19 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:19 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:19 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:19 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:19 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:19 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:19 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:19 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:19 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:19 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:19 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:19 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:19 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:19 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:19 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:19 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:19 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:19 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:19 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:19 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:44:25 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:25 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:25 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:25 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:25 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:25 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:25 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:25 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:25 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:25 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:25 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:25 --> Session Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:44:25 --> A session cookie was not found.
DEBUG - 2014-03-24 01:44:25 --> Session routines successfully run
DEBUG - 2014-03-24 01:44:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:44:25 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:25 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:25 --> Total execution time: 0.0180
DEBUG - 2014-03-24 01:44:32 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:32 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:32 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:32 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:38 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:38 --> Total execution time: 5.9763
DEBUG - 2014-03-24 01:44:41 --> Config Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:44:41 --> URI Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Router Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Output Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Security Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Input Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:44:41 --> Language Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Loader Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Controller Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:44:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:44:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Model Class Initialized
DEBUG - 2014-03-24 01:44:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:44:41 --> Final output sent to browser
DEBUG - 2014-03-24 01:44:41 --> Total execution time: 0.9521
DEBUG - 2014-03-24 01:57:11 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:11 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:11 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:11 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:11 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:11 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:11 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:11 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:11 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:11 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:11 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:11 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:11 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:11 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:11 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:11 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:11 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:11 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:11 --> Total execution time: 0.0160
DEBUG - 2014-03-24 01:57:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:11 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:11 --> Total execution time: 0.0160
DEBUG - 2014-03-24 01:57:13 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:13 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:13 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:13 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:13 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:13 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:13 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:13 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:13 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:13 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:13 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:13 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:13 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:13 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:13 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:13 --> Total execution time: 0.0110
DEBUG - 2014-03-24 01:57:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:13 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:13 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:13 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:57:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:13 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:13 --> Total execution time: 0.0150
DEBUG - 2014-03-24 01:57:20 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:20 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:20 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:20 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:20 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:20 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:20 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:20 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:20 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:20 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:20 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:20 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:20 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:20 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:57:20 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:20 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:20 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:57:20 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:20 --> Total execution time: 0.0160
DEBUG - 2014-03-24 01:57:23 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:23 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:23 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:23 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:23 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:23 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:23 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:23 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:23 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:23 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:23 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:23 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:23 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:57:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:23 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:23 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:23 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:23 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:23 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:23 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:23 --> Total execution time: 0.0150
DEBUG - 2014-03-24 01:57:24 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:24 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:24 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:24 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:24 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:24 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:24 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:24 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:24 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:24 --> Session Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:57:24 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:24 --> A session cookie was not found.
DEBUG - 2014-03-24 01:57:24 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:24 --> Session routines successfully run
DEBUG - 2014-03-24 01:57:24 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:24 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:24 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:24 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:57:24 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:24 --> Total execution time: 0.0150
DEBUG - 2014-03-24 01:57:30 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:30 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:30 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:30 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:31 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:31 --> Total execution time: 1.1211
DEBUG - 2014-03-24 01:57:51 --> Config Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:57:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:57:51 --> URI Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Router Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Output Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Security Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Input Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:57:51 --> Language Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Loader Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Controller Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:57:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:57:51 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Model Class Initialized
DEBUG - 2014-03-24 01:57:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:57:56 --> Final output sent to browser
DEBUG - 2014-03-24 01:57:56 --> Total execution time: 4.9573
DEBUG - 2014-03-24 01:59:08 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:08 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:08 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:08 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:08 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:08 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:08 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:08 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:08 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:08 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:08 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:08 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:08 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:08 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:08 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:08 --> Total execution time: 0.0170
DEBUG - 2014-03-24 01:59:08 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:08 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:08 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:08 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:08 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:08 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:08 --> Total execution time: 0.0200
DEBUG - 2014-03-24 01:59:08 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:08 --> Total execution time: 0.0200
DEBUG - 2014-03-24 01:59:09 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:09 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:09 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:09 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:09 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:09 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:09 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:09 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:09 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:09 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:09 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:09 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:09 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:09 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:59:09 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:09 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:09 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:09 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:09 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:09 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:09 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:59:09 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:09 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:59:11 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:11 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:11 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:11 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:11 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:11 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:11 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:11 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:11 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:11 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:11 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:11 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:11 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:11 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:11 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:11 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:11 --> Total execution time: 0.0160
DEBUG - 2014-03-24 01:59:11 --> Total execution time: 0.0160
DEBUG - 2014-03-24 01:59:13 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:13 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:13 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:13 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:13 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:13 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:13 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:13 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:13 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:13 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:13 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:13 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:13 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:13 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Session Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 01:59:13 --> A session cookie was not found.
DEBUG - 2014-03-24 01:59:13 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:13 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:13 --> Session routines successfully run
DEBUG - 2014-03-24 01:59:13 --> Total execution time: 0.0120
DEBUG - 2014-03-24 01:59:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 01:59:13 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:13 --> Total execution time: 0.0130
DEBUG - 2014-03-24 01:59:13 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:13 --> Total execution time: 0.0140
DEBUG - 2014-03-24 01:59:21 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:21 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:21 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:21 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:22 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:22 --> Total execution time: 0.9461
DEBUG - 2014-03-24 01:59:29 --> Config Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Hooks Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Utf8 Class Initialized
DEBUG - 2014-03-24 01:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 01:59:29 --> URI Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Router Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Output Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Security Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Input Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 01:59:29 --> Language Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Loader Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Controller Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 01:59:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 01:59:29 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Database Driver Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Model Class Initialized
DEBUG - 2014-03-24 01:59:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 01:59:30 --> Final output sent to browser
DEBUG - 2014-03-24 01:59:30 --> Total execution time: 0.9661
DEBUG - 2014-03-24 02:01:20 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:20 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:20 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:20 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:20 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:20 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:20 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:20 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Session Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> A session cookie was not found.
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Session Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Session routines successfully run
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:01:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> A session cookie was not found.
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Session routines successfully run
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:01:20 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:20 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Session Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:01:20 --> A session cookie was not found.
DEBUG - 2014-03-24 02:01:20 --> Session routines successfully run
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:20 --> Total execution time: 0.0190
DEBUG - 2014-03-24 02:01:20 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:20 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:20 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:20 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:20 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:20 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:20 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:20 --> Session Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> A session cookie was not found.
DEBUG - 2014-03-24 02:01:20 --> Session Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Session routines successfully run
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:01:20 --> A session cookie was not found.
DEBUG - 2014-03-24 02:01:20 --> Session routines successfully run
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:01:20 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:20 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:20 --> Session Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:01:20 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:01:20 --> A session cookie was not found.
DEBUG - 2014-03-24 02:01:20 --> Session routines successfully run
DEBUG - 2014-03-24 02:01:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:01:20 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:20 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:20 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:01:27 --> Config Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:01:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:01:27 --> URI Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Router Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Output Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Security Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Input Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:01:27 --> Language Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Loader Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Controller Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:01:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:01:27 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Model Class Initialized
DEBUG - 2014-03-24 02:01:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:01:32 --> Final output sent to browser
DEBUG - 2014-03-24 02:01:32 --> Total execution time: 5.6583
DEBUG - 2014-03-24 02:13:59 --> Config Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Config Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Config Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:13:59 --> URI Class Initialized
DEBUG - 2014-03-24 02:13:59 --> URI Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Router Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Router Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Output Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Output Class Initialized
DEBUG - 2014-03-24 02:13:59 --> URI Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Security Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Security Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Input Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:13:59 --> Router Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Input Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Language Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:13:59 --> Language Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Loader Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Loader Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Controller Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Controller Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Output Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Security Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Input Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:13:59 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Language Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Loader Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Controller Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:13:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:13:59 --> Session Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:13:59 --> A session cookie was not found.
DEBUG - 2014-03-24 02:13:59 --> Session Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Session routines successfully run
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> A session cookie was not found.
DEBUG - 2014-03-24 02:13:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:13:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:13:59 --> Session routines successfully run
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Final output sent to browser
DEBUG - 2014-03-24 02:13:59 --> Total execution time: 0.0150
DEBUG - 2014-03-24 02:13:59 --> Session Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:13:59 --> A session cookie was not found.
DEBUG - 2014-03-24 02:13:59 --> Session routines successfully run
DEBUG - 2014-03-24 02:13:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:13:59 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:13:59 --> Model Class Initialized
DEBUG - 2014-03-24 02:13:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:13:59 --> Final output sent to browser
DEBUG - 2014-03-24 02:13:59 --> Total execution time: 0.0170
DEBUG - 2014-03-24 02:13:59 --> Final output sent to browser
DEBUG - 2014-03-24 02:13:59 --> Total execution time: 0.0180
DEBUG - 2014-03-24 02:14:00 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:00 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:00 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:00 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:00 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:00 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:00 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:00 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:00 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:00 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:00 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:00 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:00 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:00 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:00 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:00 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:00 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:00 --> Total execution time: 0.0220
DEBUG - 2014-03-24 02:14:00 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:00 --> Total execution time: 0.0190
DEBUG - 2014-03-24 02:14:00 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:00 --> Total execution time: 0.0150
DEBUG - 2014-03-24 02:14:07 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:07 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:07 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:07 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:08 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:08 --> Total execution time: 0.9401
DEBUG - 2014-03-24 02:14:24 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:24 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:24 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:24 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:24 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:24 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:24 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:24 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:24 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:24 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:24 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:24 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:24 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:24 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:24 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:24 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:24 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:24 --> Total execution time: 0.0170
DEBUG - 2014-03-24 02:14:24 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:24 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:24 --> Total execution time: 0.0180
DEBUG - 2014-03-24 02:14:25 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:25 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:25 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:25 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:25 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Config Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:14:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> URI Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Router Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Output Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Security Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Input Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:14:25 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Language Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:25 --> Loader Class Initialized
DEBUG - 2014-03-24 02:14:25 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:25 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Controller Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:14:25 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:25 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:14:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:25 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:25 --> Session Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:14:25 --> A session cookie was not found.
DEBUG - 2014-03-24 02:14:25 --> Session routines successfully run
DEBUG - 2014-03-24 02:14:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:14:25 --> Model Class Initialized
DEBUG - 2014-03-24 02:14:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:14:25 --> Final output sent to browser
DEBUG - 2014-03-24 02:14:25 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:16:47 --> Config Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:16:47 --> URI Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Router Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Output Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Security Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Config Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Config Class Initialized
DEBUG - 2014-03-24 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:16:47 --> Input Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:16:47 --> URI Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:16:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Router Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Language Class Initialized
DEBUG - 2014-03-24 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:16:47 --> URI Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Router Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Loader Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Output Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Controller Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Output Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:16:47 --> Security Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Security Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:16:47 --> Input Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Input Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Language Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Loader Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Controller Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:16:47 --> Language Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:16:47 --> Loader Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Controller Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:16:47 --> Session Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:16:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:16:47 --> A session cookie was not found.
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Session routines successfully run
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:47 --> Session Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:16:47 --> Final output sent to browser
DEBUG - 2014-03-24 02:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:47 --> A session cookie was not found.
DEBUG - 2014-03-24 02:16:47 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:16:47 --> Session routines successfully run
DEBUG - 2014-03-24 02:16:47 --> Session Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:16:47 --> A session cookie was not found.
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:47 --> Session routines successfully run
DEBUG - 2014-03-24 02:16:47 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:16:47 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:47 --> Final output sent to browser
DEBUG - 2014-03-24 02:16:47 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:16:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:47 --> Final output sent to browser
DEBUG - 2014-03-24 02:16:47 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:16:54 --> Config Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:16:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:16:54 --> URI Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Router Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Output Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Security Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Input Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:16:54 --> Language Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Loader Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Controller Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:16:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:16:54 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Model Class Initialized
DEBUG - 2014-03-24 02:16:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:16:55 --> Final output sent to browser
DEBUG - 2014-03-24 02:16:55 --> Total execution time: 0.9511
DEBUG - 2014-03-24 02:20:09 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:09 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:09 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:09 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:09 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:09 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:09 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:09 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Session Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:20:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:09 --> A session cookie was not found.
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Session routines successfully run
DEBUG - 2014-03-24 02:20:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:09 --> Session Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:20:09 --> A session cookie was not found.
DEBUG - 2014-03-24 02:20:09 --> Session routines successfully run
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:09 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:09 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:09 --> Session Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:20:09 --> A session cookie was not found.
DEBUG - 2014-03-24 02:20:09 --> Session routines successfully run
DEBUG - 2014-03-24 02:20:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:20:09 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:09 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:09 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:20:09 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:09 --> Total execution time: 0.0200
DEBUG - 2014-03-24 02:20:10 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:10 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:10 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:10 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:10 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:10 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:10 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:10 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:10 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Session Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> A session cookie was not found.
DEBUG - 2014-03-24 02:20:10 --> Session routines successfully run
DEBUG - 2014-03-24 02:20:10 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:20:10 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:10 --> Session Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:20:10 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:10 --> A session cookie was not found.
DEBUG - 2014-03-24 02:20:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:10 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:10 --> Session routines successfully run
DEBUG - 2014-03-24 02:20:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:20:11 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:11 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:11 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:11 --> Total execution time: 0.0150
DEBUG - 2014-03-24 02:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:11 --> Session Class Initialized
DEBUG - 2014-03-24 02:20:11 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:20:11 --> A session cookie was not found.
DEBUG - 2014-03-24 02:20:11 --> Session routines successfully run
DEBUG - 2014-03-24 02:20:11 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:20:11 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:11 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:11 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:20:22 --> Config Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:20:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:20:22 --> URI Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Router Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Output Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Security Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Input Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:20:22 --> Language Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Loader Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Controller Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:20:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:20:22 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Model Class Initialized
DEBUG - 2014-03-24 02:20:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:20:23 --> Final output sent to browser
DEBUG - 2014-03-24 02:20:23 --> Total execution time: 0.9351
DEBUG - 2014-03-24 02:25:06 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:06 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:06 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:06 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:06 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:06 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:06 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:06 --> Session Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:06 --> Session Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:25:06 --> Session Class Initialized
DEBUG - 2014-03-24 02:25:06 --> A session cookie was not found.
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:25:06 --> A session cookie was not found.
DEBUG - 2014-03-24 02:25:06 --> Session routines successfully run
DEBUG - 2014-03-24 02:25:06 --> A session cookie was not found.
DEBUG - 2014-03-24 02:25:06 --> Session routines successfully run
DEBUG - 2014-03-24 02:25:06 --> Session routines successfully run
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:25:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:06 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:06 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:06 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:25:06 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:06 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:25:06 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:25:08 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:08 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:08 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:08 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:08 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:08 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:08 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:08 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:08 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Session Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:25:08 --> Session Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> A session cookie was not found.
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:25:08 --> A session cookie was not found.
DEBUG - 2014-03-24 02:25:08 --> Session routines successfully run
DEBUG - 2014-03-24 02:25:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Session routines successfully run
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:08 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:08 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:08 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:25:08 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:25:08 --> Session Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:25:08 --> A session cookie was not found.
DEBUG - 2014-03-24 02:25:08 --> Session routines successfully run
DEBUG - 2014-03-24 02:25:08 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:25:08 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:08 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:08 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:25:15 --> Config Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:25:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:25:15 --> URI Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Router Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Output Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Security Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Input Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:25:15 --> Language Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Loader Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Controller Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:25:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:25:15 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Model Class Initialized
DEBUG - 2014-03-24 02:25:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:25:16 --> Final output sent to browser
DEBUG - 2014-03-24 02:25:16 --> Total execution time: 1.0421
DEBUG - 2014-03-24 02:26:04 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:04 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:04 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:04 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:04 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:04 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:04 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:04 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Session Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> A session cookie was not found.
DEBUG - 2014-03-24 02:26:04 --> Session routines successfully run
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:04 --> Session Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:04 --> Session Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:26:04 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:26:04 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:26:04 --> A session cookie was not found.
DEBUG - 2014-03-24 02:26:04 --> A session cookie was not found.
DEBUG - 2014-03-24 02:26:04 --> Session routines successfully run
DEBUG - 2014-03-24 02:26:04 --> Session routines successfully run
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:26:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:04 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:04 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:04 --> Total execution time: 0.0210
DEBUG - 2014-03-24 02:26:04 --> Total execution time: 0.0210
DEBUG - 2014-03-24 02:26:06 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:06 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:06 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:06 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:06 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:06 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:06 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:06 --> Session Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Session Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:26:06 --> A session cookie was not found.
DEBUG - 2014-03-24 02:26:06 --> A session cookie was not found.
DEBUG - 2014-03-24 02:26:06 --> Session routines successfully run
DEBUG - 2014-03-24 02:26:06 --> Session routines successfully run
DEBUG - 2014-03-24 02:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:26:06 --> Session Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:06 --> A session cookie was not found.
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:06 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:06 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:06 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:26:06 --> Session routines successfully run
DEBUG - 2014-03-24 02:26:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:26:06 --> Total execution time: 0.0210
DEBUG - 2014-03-24 02:26:06 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:06 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:06 --> Total execution time: 0.0200
DEBUG - 2014-03-24 02:26:14 --> Config Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:26:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:26:14 --> URI Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Router Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Output Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Security Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Input Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:26:14 --> Language Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Loader Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Controller Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:26:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:26:14 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Model Class Initialized
DEBUG - 2014-03-24 02:26:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:26:15 --> Final output sent to browser
DEBUG - 2014-03-24 02:26:15 --> Total execution time: 1.1231
DEBUG - 2014-03-24 02:33:33 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:33 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:33 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:33 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:33 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:33 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:33 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:33 --> Session Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:33:33 --> A session cookie was not found.
DEBUG - 2014-03-24 02:33:33 --> Session routines successfully run
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:33 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:33 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:33:33 --> Session Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:33:33 --> A session cookie was not found.
DEBUG - 2014-03-24 02:33:33 --> Session routines successfully run
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:33 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:33 --> Total execution time: 0.0170
DEBUG - 2014-03-24 02:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:33 --> Session Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:33:33 --> A session cookie was not found.
DEBUG - 2014-03-24 02:33:33 --> Session routines successfully run
DEBUG - 2014-03-24 02:33:33 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:33:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:33 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:33 --> Total execution time: 0.0210
DEBUG - 2014-03-24 02:33:34 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:34 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:34 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:34 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:34 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:34 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:34 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Session Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:33:34 --> A session cookie was not found.
DEBUG - 2014-03-24 02:33:34 --> Session routines successfully run
DEBUG - 2014-03-24 02:33:34 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:34 --> Session Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:34 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:33:34 --> A session cookie was not found.
DEBUG - 2014-03-24 02:33:34 --> Session routines successfully run
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:34 --> Session Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:33:34 --> Total execution time: 0.0150
DEBUG - 2014-03-24 02:33:34 --> A session cookie was not found.
DEBUG - 2014-03-24 02:33:34 --> Session routines successfully run
DEBUG - 2014-03-24 02:33:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:33:34 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:34 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:34 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:33:41 --> Config Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:33:41 --> URI Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Router Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Output Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Security Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Input Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:33:41 --> Language Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Loader Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Controller Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:33:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:33:41 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Model Class Initialized
DEBUG - 2014-03-24 02:33:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:33:42 --> Final output sent to browser
DEBUG - 2014-03-24 02:33:42 --> Total execution time: 0.9341
DEBUG - 2014-03-24 02:34:31 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:31 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:31 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:31 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:31 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:31 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:31 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Session Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:34:31 --> A session cookie was not found.
DEBUG - 2014-03-24 02:34:31 --> Session routines successfully run
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Session Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:34:31 --> A session cookie was not found.
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:31 --> Session routines successfully run
DEBUG - 2014-03-24 02:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:31 --> Session Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:34:31 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:31 --> A session cookie was not found.
DEBUG - 2014-03-24 02:34:31 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:34:31 --> Session routines successfully run
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:34:31 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:31 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:31 --> Total execution time: 0.0170
DEBUG - 2014-03-24 02:34:31 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:31 --> Total execution time: 0.0170
DEBUG - 2014-03-24 02:34:33 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:33 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:33 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:33 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:33 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:33 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:33 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:33 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:33 --> Session Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Session Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:34:33 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:34:33 --> A session cookie was not found.
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:33 --> A session cookie was not found.
DEBUG - 2014-03-24 02:34:33 --> Session routines successfully run
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:33 --> Session routines successfully run
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:34:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:33 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:33 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:34:33 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:33 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:33 --> Session Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:34:33 --> A session cookie was not found.
DEBUG - 2014-03-24 02:34:33 --> Session routines successfully run
DEBUG - 2014-03-24 02:34:33 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:34:33 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:33 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:33 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:34:44 --> Config Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:34:44 --> URI Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Router Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Output Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Security Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Input Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:34:44 --> Language Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Loader Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Controller Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:34:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:34:44 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Model Class Initialized
DEBUG - 2014-03-24 02:34:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:34:45 --> Final output sent to browser
DEBUG - 2014-03-24 02:34:45 --> Total execution time: 0.9441
DEBUG - 2014-03-24 02:57:38 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:38 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:38 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:38 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:38 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:38 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:38 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:38 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:38 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:38 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:38 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:38 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:38 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:38 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:38 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:38 --> Total execution time: 0.0150
DEBUG - 2014-03-24 02:57:38 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:38 --> Total execution time: 0.0150
DEBUG - 2014-03-24 02:57:39 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:39 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:39 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:39 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:39 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:39 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:39 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:39 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:39 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:39 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:39 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:39 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:39 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:39 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:39 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Total execution time: 0.0120
DEBUG - 2014-03-24 02:57:39 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:39 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:39 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:39 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:39 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:39 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:39 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:39 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:57:45 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:45 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:45 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:45 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:45 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:45 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:45 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:45 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:45 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:45 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:45 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:45 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:45 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Total execution time: 0.0190
DEBUG - 2014-03-24 02:57:45 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:45 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:45 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:45 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:45 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:45 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:45 --> Total execution time: 0.0180
DEBUG - 2014-03-24 02:57:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:45 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:45 --> Total execution time: 0.0190
DEBUG - 2014-03-24 02:57:46 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:46 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:46 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:46 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:46 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:46 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:46 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:46 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:46 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:46 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:46 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:46 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:46 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:46 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:46 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:46 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:46 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:57:46 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:46 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:46 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:46 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:46 --> Total execution time: 0.0110
DEBUG - 2014-03-24 02:57:48 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:48 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:48 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:48 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:48 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:48 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:48 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:48 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:48 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:48 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:48 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:48 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:48 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:48 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:48 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:48 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:57:48 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:48 --> Total execution time: 0.0140
DEBUG - 2014-03-24 02:57:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:48 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:48 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:57:49 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:49 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:49 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:49 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:49 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:49 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:49 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:49 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:49 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:49 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:49 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:49 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:49 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:49 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:57:49 --> Session Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 02:57:49 --> A session cookie was not found.
DEBUG - 2014-03-24 02:57:49 --> Session routines successfully run
DEBUG - 2014-03-24 02:57:49 --> Total execution time: 0.0130
DEBUG - 2014-03-24 02:57:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 02:57:49 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:49 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:49 --> Total execution time: 0.0160
DEBUG - 2014-03-24 02:57:56 --> Config Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:57:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:57:56 --> URI Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Router Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Output Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Security Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Input Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:57:56 --> Language Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Loader Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Controller Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:57:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:57:56 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Model Class Initialized
DEBUG - 2014-03-24 02:57:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:57:57 --> Final output sent to browser
DEBUG - 2014-03-24 02:57:57 --> Total execution time: 0.9721
DEBUG - 2014-03-24 02:58:02 --> Config Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:58:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:58:02 --> URI Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Router Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Output Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Security Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Input Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:58:02 --> Language Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Loader Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Controller Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:58:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:58:02 --> Model Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Model Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Model Class Initialized
DEBUG - 2014-03-24 02:58:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:58:03 --> Final output sent to browser
DEBUG - 2014-03-24 02:58:03 --> Total execution time: 0.9331
DEBUG - 2014-03-24 02:58:10 --> Config Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Hooks Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Utf8 Class Initialized
DEBUG - 2014-03-24 02:58:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 02:58:10 --> URI Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Router Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Output Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Security Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Input Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 02:58:10 --> Language Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Loader Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Controller Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 02:58:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 02:58:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Database Driver Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Model Class Initialized
DEBUG - 2014-03-24 02:58:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 02:58:11 --> Final output sent to browser
DEBUG - 2014-03-24 02:58:11 --> Total execution time: 0.9501
DEBUG - 2014-03-24 03:02:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:02:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:02:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:13 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:02:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:02:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:02:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:02:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:02:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:02:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:13 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:02:13 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:02:15 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:15 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:15 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:15 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:15 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:15 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:15 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:15 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:15 --> Session Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:02:15 --> Session Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> A session cookie was not found.
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Session routines successfully run
DEBUG - 2014-03-24 03:02:15 --> A session cookie was not found.
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:02:15 --> Session routines successfully run
DEBUG - 2014-03-24 03:02:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:15 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:15 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:15 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:02:15 --> Session Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:02:15 --> A session cookie was not found.
DEBUG - 2014-03-24 03:02:15 --> Session routines successfully run
DEBUG - 2014-03-24 03:02:15 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:02:15 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:15 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:15 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:02:22 --> Config Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:02:22 --> URI Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Router Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Output Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Security Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Input Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:02:22 --> Language Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Loader Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Controller Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:02:22 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:02:22 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Model Class Initialized
DEBUG - 2014-03-24 03:02:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:02:23 --> Final output sent to browser
DEBUG - 2014-03-24 03:02:23 --> Total execution time: 1.1061
DEBUG - 2014-03-24 03:07:35 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:35 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:35 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:35 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:35 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:35 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:35 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:35 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:35 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:35 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:35 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:35 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:35 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:35 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:07:35 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:35 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:35 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:35 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:35 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:35 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:35 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:35 --> Total execution time: 0.0200
DEBUG - 2014-03-24 03:07:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:36 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:36 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:07:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:36 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:36 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:36 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:36 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:07:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:07:43 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:43 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:43 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:43 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:44 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:44 --> Total execution time: 0.9101
DEBUG - 2014-03-24 03:07:54 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:54 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:54 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:54 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:54 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:54 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:54 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:54 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:54 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:54 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:54 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:07:54 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:54 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:54 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:54 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:54 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:54 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:54 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:54 --> Total execution time: 0.0180
DEBUG - 2014-03-24 03:07:55 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:55 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:55 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Config Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:55 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:55 --> URI Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Router Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:55 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Output Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Security Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Input Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:07:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Language Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Loader Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Controller Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:07:55 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:55 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:55 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:55 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:55 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:55 --> Session Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:07:55 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:07:55 --> A session cookie was not found.
DEBUG - 2014-03-24 03:07:55 --> Session routines successfully run
DEBUG - 2014-03-24 03:07:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:07:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:07:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:07:55 --> Final output sent to browser
DEBUG - 2014-03-24 03:07:55 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:08:03 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:03 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:03 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:04 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:04 --> Total execution time: 0.9531
DEBUG - 2014-03-24 03:08:23 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:23 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:23 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:23 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:23 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:23 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:23 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:23 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:23 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Session Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:23 --> A session cookie was not found.
DEBUG - 2014-03-24 03:08:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Session routines successfully run
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:23 --> Session Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> A session cookie was not found.
DEBUG - 2014-03-24 03:08:23 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:23 --> Session routines successfully run
DEBUG - 2014-03-24 03:08:23 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:23 --> Session Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:08:23 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:23 --> A session cookie was not found.
DEBUG - 2014-03-24 03:08:23 --> Session routines successfully run
DEBUG - 2014-03-24 03:08:23 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:08:23 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:08:23 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:23 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:23 --> Total execution time: 0.0170
DEBUG - 2014-03-24 03:08:25 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:25 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:25 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:25 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:25 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:25 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:25 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:25 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:25 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Session Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:08:25 --> A session cookie was not found.
DEBUG - 2014-03-24 03:08:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Session routines successfully run
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:08:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:25 --> Session Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:08:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:08:25 --> Session Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:08:25 --> A session cookie was not found.
DEBUG - 2014-03-24 03:08:25 --> A session cookie was not found.
DEBUG - 2014-03-24 03:08:25 --> Session routines successfully run
DEBUG - 2014-03-24 03:08:25 --> Session routines successfully run
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:08:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:25 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:25 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:25 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:08:25 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:25 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:08:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:08:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:08:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:08:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:08:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:08:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:08:37 --> Final output sent to browser
DEBUG - 2014-03-24 03:08:37 --> Total execution time: 0.9401
DEBUG - 2014-03-24 03:11:18 --> Config Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Config Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Config Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:11:18 --> URI Class Initialized
DEBUG - 2014-03-24 03:11:18 --> URI Class Initialized
DEBUG - 2014-03-24 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:11:18 --> Router Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Router Class Initialized
DEBUG - 2014-03-24 03:11:18 --> URI Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Router Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Output Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Output Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Security Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Input Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Output Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:11:18 --> Language Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Security Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Security Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Loader Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Input Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Controller Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:11:18 --> Input Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:11:18 --> Language Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:11:18 --> Language Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Loader Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Controller Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Loader Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Controller Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Session Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Session Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:11:18 --> A session cookie was not found.
DEBUG - 2014-03-24 03:11:18 --> A session cookie was not found.
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Session routines successfully run
DEBUG - 2014-03-24 03:11:18 --> Session routines successfully run
DEBUG - 2014-03-24 03:11:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:11:18 --> Session Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:11:18 --> A session cookie was not found.
DEBUG - 2014-03-24 03:11:18 --> Session routines successfully run
DEBUG - 2014-03-24 03:11:18 --> Final output sent to browser
DEBUG - 2014-03-24 03:11:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:11:18 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:11:18 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:18 --> Final output sent to browser
DEBUG - 2014-03-24 03:11:18 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:11:18 --> Final output sent to browser
DEBUG - 2014-03-24 03:11:18 --> Total execution time: 0.0170
DEBUG - 2014-03-24 03:11:20 --> Config Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Config Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:11:20 --> URI Class Initialized
DEBUG - 2014-03-24 03:11:20 --> URI Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Router Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Router Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Output Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Output Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Security Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Security Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Input Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Input Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:11:20 --> Language Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Config Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:11:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Loader Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Language Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Controller Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:11:20 --> Loader Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:11:20 --> Controller Class Initialized
DEBUG - 2014-03-24 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:11:20 --> URI Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Router Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:11:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Output Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Security Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Input Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:11:20 --> Language Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Session Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:11:20 --> Loader Class Initialized
DEBUG - 2014-03-24 03:11:20 --> A session cookie was not found.
DEBUG - 2014-03-24 03:11:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:20 --> Controller Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Session routines successfully run
DEBUG - 2014-03-24 03:11:20 --> Session Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> A session cookie was not found.
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:11:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:20 --> Session routines successfully run
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Final output sent to browser
DEBUG - 2014-03-24 03:11:20 --> Total execution time: 0.0110
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Final output sent to browser
DEBUG - 2014-03-24 03:11:20 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:11:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:20 --> Session Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:11:20 --> A session cookie was not found.
DEBUG - 2014-03-24 03:11:20 --> Session routines successfully run
DEBUG - 2014-03-24 03:11:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:11:20 --> Model Class Initialized
DEBUG - 2014-03-24 03:11:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:11:20 --> Final output sent to browser
DEBUG - 2014-03-24 03:11:20 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:13:37 --> Config Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:13:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:13:37 --> URI Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Router Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Output Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Security Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Config Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Input Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:13:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:13:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:13:37 --> URI Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Router Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Output Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Security Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Input Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:13:37 --> Language Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Language Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Loader Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Controller Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Loader Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Controller Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:37 --> Session Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:13:37 --> A session cookie was not found.
DEBUG - 2014-03-24 03:13:37 --> Session routines successfully run
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:37 --> Final output sent to browser
DEBUG - 2014-03-24 03:13:37 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:13:37 --> Config Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:13:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:13:37 --> URI Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Session Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Router Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:13:37 --> A session cookie was not found.
DEBUG - 2014-03-24 03:13:37 --> Session routines successfully run
DEBUG - 2014-03-24 03:13:37 --> Output Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Security Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Input Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Language Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:37 --> Loader Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Final output sent to browser
DEBUG - 2014-03-24 03:13:37 --> Total execution time: 0.0220
DEBUG - 2014-03-24 03:13:37 --> Controller Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:37 --> Session Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:13:37 --> A session cookie was not found.
DEBUG - 2014-03-24 03:13:37 --> Session routines successfully run
DEBUG - 2014-03-24 03:13:37 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:13:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:37 --> Final output sent to browser
DEBUG - 2014-03-24 03:13:37 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:13:46 --> Config Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:13:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:13:46 --> URI Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Router Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Output Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Security Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Input Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:13:46 --> Language Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Loader Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Controller Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:13:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:13:46 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Model Class Initialized
DEBUG - 2014-03-24 03:13:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:13:47 --> Final output sent to browser
DEBUG - 2014-03-24 03:13:47 --> Total execution time: 0.9961
DEBUG - 2014-03-24 03:15:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:15:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:15:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:15:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:15:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:13 --> Total execution time: 0.0180
DEBUG - 2014-03-24 03:15:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:13 --> Total execution time: 0.0190
DEBUG - 2014-03-24 03:15:14 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:14 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:14 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:14 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:14 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:14 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:14 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:14 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Session Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:15:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:14 --> A session cookie was not found.
DEBUG - 2014-03-24 03:15:14 --> Session routines successfully run
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Session Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:14 --> Session Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:15:14 --> A session cookie was not found.
DEBUG - 2014-03-24 03:15:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:14 --> A session cookie was not found.
DEBUG - 2014-03-24 03:15:14 --> Session routines successfully run
DEBUG - 2014-03-24 03:15:14 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:15:14 --> Session routines successfully run
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:15:14 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:14 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:15:14 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:15:37 --> Config Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:15:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:15:37 --> URI Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Router Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Output Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Security Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Input Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:15:37 --> Language Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Loader Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Controller Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:15:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:15:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Model Class Initialized
DEBUG - 2014-03-24 03:15:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:15:38 --> Final output sent to browser
DEBUG - 2014-03-24 03:15:38 --> Total execution time: 0.9291
DEBUG - 2014-03-24 03:18:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:36 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:36 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:36 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:36 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:36 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:18:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:36 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:36 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:36 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:36 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:36 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:36 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:36 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:36 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:18:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:36 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:18:38 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:38 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:38 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:38 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:38 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:38 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:38 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:38 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:38 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:38 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:38 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:38 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:38 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:38 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:38 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:38 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:38 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:38 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:38 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:18:41 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:41 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:41 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:41 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:41 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:41 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:41 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:41 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:41 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:41 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:41 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:41 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:41 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:41 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:41 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:18:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:41 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:41 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:41 --> Total execution time: 0.0170
DEBUG - 2014-03-24 03:18:42 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:42 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:42 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:42 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:42 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:42 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:42 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:42 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:42 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:42 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:42 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:42 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:42 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:42 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:42 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:42 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:42 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:42 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:42 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:42 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:42 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:42 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:42 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:44 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:44 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:44 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:44 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:44 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:44 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:44 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:44 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:44 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:44 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:44 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:44 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:44 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:44 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:44 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:44 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:44 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:44 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:44 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:44 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:44 --> Total execution time: 0.0170
DEBUG - 2014-03-24 03:18:45 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:45 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:45 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:45 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:45 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:45 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:45 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:45 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:45 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:45 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:45 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:45 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:45 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:45 --> Session Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:18:45 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:45 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:45 --> A session cookie was not found.
DEBUG - 2014-03-24 03:18:45 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:18:45 --> Session routines successfully run
DEBUG - 2014-03-24 03:18:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:18:45 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:45 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:45 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:18:51 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:51 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:51 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:51 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:51 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:51 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:18:53 --> Final output sent to browser
DEBUG - 2014-03-24 03:18:53 --> Total execution time: 1.5921
DEBUG - 2014-03-24 03:18:59 --> Config Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:18:59 --> URI Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Router Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Output Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Security Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Input Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:18:59 --> Language Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Loader Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Controller Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:18:59 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:18:59 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Model Class Initialized
DEBUG - 2014-03-24 03:18:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:19:05 --> Final output sent to browser
DEBUG - 2014-03-24 03:19:05 --> Total execution time: 5.9383
DEBUG - 2014-03-24 03:19:08 --> Config Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:19:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:19:08 --> URI Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Router Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Output Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Security Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Input Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:19:08 --> Language Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Loader Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Controller Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:19:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:19:08 --> Model Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Model Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Model Class Initialized
DEBUG - 2014-03-24 03:19:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:19:09 --> Final output sent to browser
DEBUG - 2014-03-24 03:19:09 --> Total execution time: 0.9371
DEBUG - 2014-03-24 03:45:01 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:01 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:01 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:01 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:01 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:01 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:01 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:01 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:01 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:01 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:01 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:45:01 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:01 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:01 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:01 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:01 --> Total execution time: 0.0170
DEBUG - 2014-03-24 03:45:01 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:01 --> Total execution time: 0.0180
DEBUG - 2014-03-24 03:45:03 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:03 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:03 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:03 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:03 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:03 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:03 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:03 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:03 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:03 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:03 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:03 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:03 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:03 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:45:03 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:03 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:03 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:03 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:03 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:03 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:03 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:45:10 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:10 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:10 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:10 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:13 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:13 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:45:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:13 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:45:13 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:13 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:13 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:13 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:13 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:13 --> Total execution time: 0.0190
DEBUG - 2014-03-24 03:45:14 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:14 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:14 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:14 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:14 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:14 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:14 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:14 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:14 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:14 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:14 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:14 --> Session Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:14 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:14 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:14 --> A session cookie was not found.
DEBUG - 2014-03-24 03:45:14 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Session routines successfully run
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:14 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:14 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:45:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:14 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:45:14 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:45:14 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:14 --> Total execution time: 4.5943
DEBUG - 2014-03-24 03:45:21 --> Config Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:45:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:45:21 --> URI Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Router Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Output Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Security Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Input Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:45:21 --> Language Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Loader Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Controller Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:45:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:45:21 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Model Class Initialized
DEBUG - 2014-03-24 03:45:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:45:22 --> Final output sent to browser
DEBUG - 2014-03-24 03:45:22 --> Total execution time: 0.9821
DEBUG - 2014-03-24 03:46:48 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:48 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:48 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:48 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:48 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:48 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:48 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:48 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:48 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:48 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:48 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:48 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:48 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:48 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:48 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:48 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:46:48 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:48 --> Total execution time: 0.0180
DEBUG - 2014-03-24 03:46:49 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:49 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:49 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:49 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:49 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:49 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:49 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:49 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:49 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:49 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:49 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:49 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:49 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:49 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:49 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:49 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:49 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:49 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:49 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:49 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:49 --> Total execution time: 0.0190
DEBUG - 2014-03-24 03:46:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:49 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:49 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:49 --> Total execution time: 0.0230
DEBUG - 2014-03-24 03:46:53 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:53 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:53 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:53 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:53 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:53 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:53 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:53 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:53 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:53 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:53 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:53 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:53 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:53 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:53 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:53 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:53 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:53 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:53 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:53 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:53 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:53 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:46:53 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:46:55 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Config Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:55 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:46:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:55 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:55 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:46:55 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:55 --> URI Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:55 --> Router Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Output Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:55 --> Security Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:55 --> Input Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:55 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Language Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Loader Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:55 --> Controller Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:55 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:55 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:55 --> Session Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:55 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:46:55 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:55 --> A session cookie was not found.
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:55 --> Session routines successfully run
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:55 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:55 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:55 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:46:55 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 03:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:46:55 --> Final output sent to browser
DEBUG - 2014-03-24 03:46:55 --> Total execution time: 0.0160
DEBUG - 2014-03-24 03:47:01 --> Config Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:47:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:47:01 --> URI Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Router Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Output Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Security Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Input Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:47:01 --> Language Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Loader Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Controller Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:47:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:47:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:05 --> Final output sent to browser
DEBUG - 2014-03-24 03:47:05 --> Total execution time: 3.9512
DEBUG - 2014-03-24 03:47:24 --> Config Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Config Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Config Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:47:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:47:24 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:47:24 --> URI Class Initialized
DEBUG - 2014-03-24 03:47:24 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:47:24 --> Router Class Initialized
DEBUG - 2014-03-24 03:47:24 --> URI Class Initialized
DEBUG - 2014-03-24 03:47:24 --> URI Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Router Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Router Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Output Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Output Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Security Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Output Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Security Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Input Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Security Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Input Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:47:24 --> Input Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:47:24 --> Language Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Language Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Language Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Loader Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Loader Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Loader Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Controller Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Controller Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Controller Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:24 --> Session Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Session Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:47:24 --> Session Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:47:24 --> A session cookie was not found.
DEBUG - 2014-03-24 03:47:24 --> A session cookie was not found.
DEBUG - 2014-03-24 03:47:24 --> Session routines successfully run
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:47:24 --> Session routines successfully run
DEBUG - 2014-03-24 03:47:24 --> A session cookie was not found.
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:47:24 --> Session routines successfully run
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:24 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:24 --> Final output sent to browser
DEBUG - 2014-03-24 03:47:24 --> Final output sent to browser
DEBUG - 2014-03-24 03:47:24 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:47:24 --> Total execution time: 0.0150
DEBUG - 2014-03-24 03:47:24 --> Final output sent to browser
DEBUG - 2014-03-24 03:47:24 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:47:32 --> Config Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:47:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:47:32 --> URI Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Router Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Output Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Security Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Input Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:47:32 --> Language Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Loader Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Controller Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:47:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:47:32 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Model Class Initialized
DEBUG - 2014-03-24 03:47:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:47:36 --> Final output sent to browser
DEBUG - 2014-03-24 03:47:36 --> Total execution time: 3.9642
DEBUG - 2014-03-24 03:48:00 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:00 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:00 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:00 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:00 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:00 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:00 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:00 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Session Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:48:00 --> A session cookie was not found.
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:00 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:00 --> Session Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:48:00 --> A session cookie was not found.
DEBUG - 2014-03-24 03:48:00 --> Session routines successfully run
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:00 --> Session routines successfully run
DEBUG - 2014-03-24 03:48:00 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:00 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:00 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Total execution time: 0.0140
DEBUG - 2014-03-24 03:48:00 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:00 --> Total execution time: 0.0190
DEBUG - 2014-03-24 03:48:00 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:00 --> Session Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:48:00 --> A session cookie was not found.
DEBUG - 2014-03-24 03:48:00 --> Session routines successfully run
DEBUG - 2014-03-24 03:48:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:48:00 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:00 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:00 --> Total execution time: 0.0220
DEBUG - 2014-03-24 03:48:02 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:02 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:02 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:02 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:02 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:02 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:02 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:02 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:02 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:02 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:02 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Session Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:48:02 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:02 --> A session cookie was not found.
DEBUG - 2014-03-24 03:48:02 --> Session Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:02 --> Session routines successfully run
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:48:02 --> A session cookie was not found.
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Session routines successfully run
DEBUG - 2014-03-24 03:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:02 --> Total execution time: 0.0120
DEBUG - 2014-03-24 03:48:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:02 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:02 --> Session Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: string_helper
DEBUG - 2014-03-24 03:48:02 --> A session cookie was not found.
DEBUG - 2014-03-24 03:48:02 --> Session routines successfully run
DEBUG - 2014-03-24 03:48:02 --> Helper loaded: url_helper
DEBUG - 2014-03-24 03:48:02 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:02 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:02 --> Total execution time: 0.0130
DEBUG - 2014-03-24 03:48:09 --> Config Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 03:48:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 03:48:09 --> URI Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Router Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Output Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Security Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Input Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 03:48:09 --> Language Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Loader Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Controller Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 03:48:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 03:48:09 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Model Class Initialized
DEBUG - 2014-03-24 03:48:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 03:48:10 --> Final output sent to browser
DEBUG - 2014-03-24 03:48:10 --> Total execution time: 0.9521
DEBUG - 2014-03-24 04:18:37 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:37 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:37 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:37 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:37 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:37 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:37 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:37 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:37 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:18:37 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:37 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:37 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:37 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:37 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:37 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:37 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:37 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:18:37 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:37 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:37 --> Total execution time: 0.0170
DEBUG - 2014-03-24 04:18:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:39 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:18:39 --> Total execution time: 0.0110
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:39 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:18:42 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:42 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:42 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:42 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:42 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:42 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:42 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:42 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:42 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:42 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:42 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:42 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:42 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:42 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:42 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:42 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:42 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:42 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:42 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:42 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:42 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:42 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:18:42 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:42 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:18:43 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:43 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:43 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:43 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:43 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:43 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:43 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:43 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:43 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:43 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:43 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:43 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:43 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:43 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:43 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:43 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:43 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:43 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:43 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:43 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:43 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:43 --> Total execution time: 0.0110
DEBUG - 2014-03-24 04:18:43 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:43 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:43 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:18:46 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:46 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:46 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:46 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:46 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:46 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:46 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:46 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:46 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:46 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:46 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:46 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:46 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:46 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:46 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:46 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:46 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:46 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:18:46 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:46 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:46 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:46 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:46 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:46 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:46 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:46 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:18:48 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:48 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:48 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:48 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:48 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:48 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:48 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:48 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:48 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:48 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:48 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:48 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:48 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:48 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:48 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:48 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:48 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:18:48 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:48 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:18:48 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:18:49 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:49 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:49 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Config Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:49 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:18:49 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:49 --> URI Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Router Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Output Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Security Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Input Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:18:49 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Language Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Loader Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:49 --> Controller Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:49 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Session Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:49 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:18:49 --> A session cookie was not found.
DEBUG - 2014-03-24 04:18:49 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:49 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:49 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:18:49 --> Session routines successfully run
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:49 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:49 --> Model Class Initialized
DEBUG - 2014-03-24 04:18:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:18:49 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:49 --> Final output sent to browser
DEBUG - 2014-03-24 04:18:49 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:18:49 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:19:19 --> Config Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:19:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:19:19 --> URI Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Router Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Output Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Security Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Input Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:19:19 --> Language Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Loader Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Controller Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:19:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:19:19 --> Model Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Model Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Model Class Initialized
DEBUG - 2014-03-24 04:19:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:19:20 --> Final output sent to browser
DEBUG - 2014-03-24 04:19:20 --> Total execution time: 0.9901
DEBUG - 2014-03-24 04:19:28 --> Config Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:19:28 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:19:28 --> URI Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Router Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Output Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Security Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Input Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:19:28 --> Language Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Loader Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Controller Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:19:28 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:19:28 --> Model Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Model Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Model Class Initialized
DEBUG - 2014-03-24 04:19:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:19:32 --> Final output sent to browser
DEBUG - 2014-03-24 04:19:32 --> Total execution time: 3.9342
DEBUG - 2014-03-24 04:20:19 --> Config Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:20:19 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:20:19 --> URI Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Router Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Output Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Security Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Input Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:20:19 --> Language Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Loader Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Controller Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:20:19 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:20:19 --> Model Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Model Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Model Class Initialized
DEBUG - 2014-03-24 04:20:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:20:20 --> Final output sent to browser
DEBUG - 2014-03-24 04:20:20 --> Total execution time: 0.9771
DEBUG - 2014-03-24 04:33:38 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:38 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:38 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:38 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:38 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:38 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:38 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:38 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:38 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:38 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:38 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:38 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:33:38 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:38 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:33:38 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:38 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:38 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:38 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:38 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:38 --> Total execution time: 0.0190
DEBUG - 2014-03-24 04:33:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:39 --> Total execution time: 0.0110
DEBUG - 2014-03-24 04:33:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:39 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:33:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:39 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:33:44 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:44 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:44 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:44 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:44 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:44 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:44 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:44 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:44 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:44 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:44 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:44 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:44 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:44 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:44 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:44 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:44 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:44 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:44 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:44 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:33:44 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:44 --> Total execution time: 0.0180
DEBUG - 2014-03-24 04:33:45 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:45 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:45 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:45 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:45 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:45 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:45 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:45 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:45 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:45 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:45 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:45 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:45 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:45 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:45 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:45 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:45 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:45 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:45 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:33:45 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:33:47 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:47 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:47 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:47 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:47 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:47 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:47 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:47 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:47 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:47 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:47 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:47 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:47 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:47 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:33:47 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:47 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:47 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:47 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:47 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:47 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:47 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:47 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:33:48 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:48 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:48 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:48 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:48 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:48 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:48 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:48 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:48 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:48 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:48 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:48 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:48 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:48 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:48 --> Session Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:33:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:48 --> A session cookie was not found.
DEBUG - 2014-03-24 04:33:48 --> Session routines successfully run
DEBUG - 2014-03-24 04:33:48 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:48 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:48 --> Total execution time: 0.0120
DEBUG - 2014-03-24 04:33:48 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:33:48 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:33:48 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:48 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:48 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:33:54 --> Config Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:33:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:33:54 --> URI Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Router Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Output Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Security Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Input Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:33:54 --> Language Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Loader Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Controller Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:33:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:33:54 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Model Class Initialized
DEBUG - 2014-03-24 04:33:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:33:56 --> Final output sent to browser
DEBUG - 2014-03-24 04:33:56 --> Total execution time: 1.9351
DEBUG - 2014-03-24 04:34:02 --> Config Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:34:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:34:02 --> URI Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Router Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Output Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Security Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Input Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:34:02 --> Language Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Loader Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Controller Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:34:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:34:02 --> Model Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Model Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Model Class Initialized
DEBUG - 2014-03-24 04:34:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:34:03 --> Final output sent to browser
DEBUG - 2014-03-24 04:34:03 --> Total execution time: 0.9711
DEBUG - 2014-03-24 04:35:29 --> Config Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:35:29 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:35:29 --> URI Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Router Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Output Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Security Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Input Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:35:29 --> Language Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Loader Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Controller Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:35:29 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:35:29 --> Model Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Model Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Model Class Initialized
DEBUG - 2014-03-24 04:35:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:35:33 --> Final output sent to browser
DEBUG - 2014-03-24 04:35:33 --> Total execution time: 3.9802
DEBUG - 2014-03-24 04:45:31 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:31 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:31 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:31 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:31 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:31 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:31 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:31 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:31 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:31 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:31 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:31 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:31 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:31 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:31 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:31 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:31 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:31 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:31 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:31 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:31 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:31 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:31 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:31 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:31 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:31 --> Total execution time: 0.0180
DEBUG - 2014-03-24 04:45:32 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:32 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:32 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:32 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:32 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:32 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:32 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:32 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:32 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:32 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:32 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:32 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:32 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:32 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:32 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:32 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:45:32 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:32 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:32 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:32 --> Total execution time: 0.0190
DEBUG - 2014-03-24 04:45:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:32 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:32 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:32 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:45:35 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:35 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:35 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:35 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:35 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:35 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:35 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:35 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:35 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:35 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:35 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:35 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:45:35 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:35 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:35 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:35 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:35 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:35 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:45:35 --> Total execution time: 0.0160
DEBUG - 2014-03-24 04:45:36 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:36 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:36 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:36 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:36 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:36 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:36 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:36 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:36 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:36 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:36 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:36 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:36 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:36 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:36 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:36 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:36 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:45:36 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:36 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:45:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:39 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:39 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:39 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:39 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:45:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:39 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:39 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:39 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:39 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:45:39 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:39 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:39 --> Total execution time: 0.0190
DEBUG - 2014-03-24 04:45:41 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:41 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:41 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:41 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:41 --> Config Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:41 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:45:41 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:41 --> URI Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:41 --> Router Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Output Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Security Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Input Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:45:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Language Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:41 --> Loader Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Controller Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:45:41 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:41 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:41 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:41 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:41 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:45:41 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:41 --> Session Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Total execution time: 0.0140
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:45:41 --> A session cookie was not found.
DEBUG - 2014-03-24 04:45:41 --> Session routines successfully run
DEBUG - 2014-03-24 04:45:41 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:45:41 --> Model Class Initialized
DEBUG - 2014-03-24 04:45:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:45:41 --> Final output sent to browser
DEBUG - 2014-03-24 04:45:41 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:46:02 --> Config Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:46:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:46:02 --> URI Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Router Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Output Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Security Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Input Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:46:02 --> Language Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Loader Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Controller Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:46:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:46:02 --> Model Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Model Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Model Class Initialized
DEBUG - 2014-03-24 04:46:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:46:04 --> Final output sent to browser
DEBUG - 2014-03-24 04:46:04 --> Total execution time: 1.9411
DEBUG - 2014-03-24 04:46:10 --> Config Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:46:10 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:46:10 --> URI Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Router Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Output Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Security Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Input Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:46:10 --> Language Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Loader Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Controller Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:46:10 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:46:10 --> Model Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Model Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Model Class Initialized
DEBUG - 2014-03-24 04:46:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:46:11 --> Final output sent to browser
DEBUG - 2014-03-24 04:46:11 --> Total execution time: 1.0081
DEBUG - 2014-03-24 04:47:34 --> Config Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:47:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:47:34 --> URI Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Router Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Output Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Security Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Input Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:47:34 --> Language Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Loader Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Controller Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:47:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:47:34 --> Model Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Model Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Model Class Initialized
DEBUG - 2014-03-24 04:47:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:47:34 --> Final output sent to browser
DEBUG - 2014-03-24 04:47:34 --> Total execution time: 0.9411
DEBUG - 2014-03-24 04:50:20 --> Config Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:50:20 --> URI Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Router Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Config Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Config Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Output Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Hooks Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:50:20 --> Utf8 Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Security Class Initialized
DEBUG - 2014-03-24 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 04:50:20 --> URI Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Input Class Initialized
DEBUG - 2014-03-24 04:50:20 --> URI Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Router Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Router Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:50:20 --> Output Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Output Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Language Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Security Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Security Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Input Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Input Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Loader Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 04:50:20 --> Controller Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Language Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:50:20 --> Loader Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Language Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:50:20 --> Controller Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:50:20 --> Loader Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Controller Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:50:20 --> Database Driver Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Session Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:50:20 --> A session cookie was not found.
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Session Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Session routines successfully run
DEBUG - 2014-03-24 04:50:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:50:20 --> A session cookie was not found.
DEBUG - 2014-03-24 04:50:20 --> Session routines successfully run
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:50:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:50:20 --> Session Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: string_helper
DEBUG - 2014-03-24 04:50:20 --> Final output sent to browser
DEBUG - 2014-03-24 04:50:20 --> A session cookie was not found.
DEBUG - 2014-03-24 04:50:20 --> Final output sent to browser
DEBUG - 2014-03-24 04:50:20 --> Session routines successfully run
DEBUG - 2014-03-24 04:50:20 --> Total execution time: 0.0130
DEBUG - 2014-03-24 04:50:20 --> Total execution time: 0.0150
DEBUG - 2014-03-24 04:50:20 --> Helper loaded: url_helper
DEBUG - 2014-03-24 04:50:20 --> Model Class Initialized
DEBUG - 2014-03-24 04:50:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 04:50:20 --> Final output sent to browser
DEBUG - 2014-03-24 04:50:20 --> Total execution time: 0.0160
DEBUG - 2014-03-24 17:42:05 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:05 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:05 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:05 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:05 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:05 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:05 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:05 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:05 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:05 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Database Driver Class Initialized
ERROR - 2014-03-24 17:42:05 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-24 17:42:05 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-03-24 17:42:05 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:05 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:05 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:05 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:05 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:05 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:05 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:05 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:05 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:05 --> Total execution time: 0.0530
DEBUG - 2014-03-24 17:42:05 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:05 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:05 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:05 --> Total execution time: 0.0520
DEBUG - 2014-03-24 17:42:05 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:05 --> Total execution time: 0.0570
DEBUG - 2014-03-24 17:42:15 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:15 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:15 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:15 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Database Driver Class Initialized
ERROR - 2014-03-24 17:42:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-03-24 17:42:15 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:16 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:16 --> Total execution time: 0.9531
DEBUG - 2014-03-24 17:42:40 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:40 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:40 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:40 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:40 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:40 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:40 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:40 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:40 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:40 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:40 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:40 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Total execution time: 0.0140
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:40 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:40 --> Total execution time: 0.0160
DEBUG - 2014-03-24 17:42:40 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:40 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:40 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:40 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:40 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:40 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:40 --> Total execution time: 0.0200
DEBUG - 2014-03-24 17:42:42 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:42 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:42 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Config Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:42 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:42 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:42:42 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:42 --> URI Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Router Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:42 --> Output Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Security Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Input Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:42:42 --> Language Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Loader Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:42 --> Controller Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:42 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:42 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:42:42 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:42 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:42 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:42 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:42 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:42 --> Total execution time: 0.0130
DEBUG - 2014-03-24 17:42:42 --> Total execution time: 0.0130
DEBUG - 2014-03-24 17:42:42 --> Session Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:42:42 --> A session cookie was not found.
DEBUG - 2014-03-24 17:42:42 --> Session routines successfully run
DEBUG - 2014-03-24 17:42:42 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:42:42 --> Model Class Initialized
DEBUG - 2014-03-24 17:42:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:42:42 --> Final output sent to browser
DEBUG - 2014-03-24 17:42:42 --> Total execution time: 0.0140
DEBUG - 2014-03-24 17:43:01 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:01 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:01 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:01 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:01 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:01 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:01 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:01 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:01 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:01 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:01 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:01 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Total execution time: 0.0150
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:01 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:01 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:01 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:01 --> Total execution time: 0.0170
DEBUG - 2014-03-24 17:43:01 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:01 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:01 --> Total execution time: 0.0190
DEBUG - 2014-03-24 17:43:08 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:08 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:08 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:08 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:08 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:08 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:09 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:09 --> Total execution time: 0.9541
DEBUG - 2014-03-24 17:43:25 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:25 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:25 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:25 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:25 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:25 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:25 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:25 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:25 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:25 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:25 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:25 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:25 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:25 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:25 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:25 --> Total execution time: 0.0110
DEBUG - 2014-03-24 17:43:25 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:25 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:25 --> Total execution time: 0.0130
DEBUG - 2014-03-24 17:43:25 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:25 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:25 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:25 --> Total execution time: 0.0180
DEBUG - 2014-03-24 17:43:26 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:26 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:26 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:26 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:26 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:26 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:26 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:26 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:26 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:26 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:26 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:26 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:26 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:26 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:26 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:26 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:26 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:26 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:26 --> Total execution time: 0.0120
DEBUG - 2014-03-24 17:43:26 --> Total execution time: 0.0120
DEBUG - 2014-03-24 17:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:26 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:26 --> Total execution time: 0.0130
DEBUG - 2014-03-24 17:43:34 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:34 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:34 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:34 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:35 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:35 --> Total execution time: 0.9871
DEBUG - 2014-03-24 17:43:54 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:54 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:54 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:54 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:54 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:54 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:54 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:54 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:54 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:54 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:54 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:54 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:54 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:54 --> Total execution time: 0.0130
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Total execution time: 0.0150
DEBUG - 2014-03-24 17:43:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:54 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:54 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:54 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:54 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:54 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:54 --> Total execution time: 0.0190
DEBUG - 2014-03-24 17:43:56 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:56 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:56 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Config Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:43:56 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:56 --> URI Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Router Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:56 --> Output Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:56 --> Security Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Input Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:43:56 --> Language Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:56 --> Loader Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Controller Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:56 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:56 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:56 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:56 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:43:56 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:56 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:56 --> Total execution time: 0.0130
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:56 --> Total execution time: 0.0150
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:56 --> Session Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 17:43:56 --> A session cookie was not found.
DEBUG - 2014-03-24 17:43:56 --> Session routines successfully run
DEBUG - 2014-03-24 17:43:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 17:43:56 --> Model Class Initialized
DEBUG - 2014-03-24 17:43:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:43:56 --> Final output sent to browser
DEBUG - 2014-03-24 17:43:56 --> Total execution time: 0.0160
DEBUG - 2014-03-24 17:44:04 --> Config Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 17:44:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 17:44:04 --> URI Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Router Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Output Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Security Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Input Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 17:44:04 --> Language Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Loader Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Controller Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 17:44:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 17:44:04 --> Model Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Model Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Model Class Initialized
DEBUG - 2014-03-24 17:44:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 17:44:05 --> Final output sent to browser
DEBUG - 2014-03-24 17:44:05 --> Total execution time: 0.9661
DEBUG - 2014-03-24 18:32:25 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:25 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:25 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:25 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:25 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:25 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:25 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:25 --> Session Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:32:25 --> A session cookie was not found.
DEBUG - 2014-03-24 18:32:25 --> Session routines successfully run
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:25 --> Session Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:32:25 --> A session cookie was not found.
DEBUG - 2014-03-24 18:32:25 --> Session routines successfully run
DEBUG - 2014-03-24 18:32:25 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:25 --> Session Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:32:25 --> A session cookie was not found.
DEBUG - 2014-03-24 18:32:25 --> Session routines successfully run
DEBUG - 2014-03-24 18:32:25 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:25 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:25 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:32:25 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:25 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:32:27 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:27 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:27 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:27 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:27 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:27 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Session Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Session Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:32:27 --> A session cookie was not found.
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:32:27 --> A session cookie was not found.
DEBUG - 2014-03-24 18:32:27 --> Session routines successfully run
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:27 --> Session routines successfully run
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:27 --> Total execution time: 0.0120
DEBUG - 2014-03-24 18:32:27 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:27 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:27 --> Total execution time: 0.0130
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:27 --> Session Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:32:27 --> A session cookie was not found.
DEBUG - 2014-03-24 18:32:27 --> Session routines successfully run
DEBUG - 2014-03-24 18:32:27 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:32:27 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:27 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:27 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:32:35 --> Config Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:32:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:32:35 --> URI Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Router Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Output Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Security Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Input Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:32:35 --> Language Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Loader Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Controller Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:32:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:32:35 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Model Class Initialized
DEBUG - 2014-03-24 18:32:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:32:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:32:36 --> Total execution time: 0.9611
DEBUG - 2014-03-24 18:34:09 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:09 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:09 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:09 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:09 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:09 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:09 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:09 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Session Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:34:09 --> A session cookie was not found.
DEBUG - 2014-03-24 18:34:09 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Session routines successfully run
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:34:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:09 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:09 --> Total execution time: 0.0130
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Session Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:34:09 --> A session cookie was not found.
DEBUG - 2014-03-24 18:34:09 --> Session routines successfully run
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Session Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:34:09 --> A session cookie was not found.
DEBUG - 2014-03-24 18:34:09 --> Session routines successfully run
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:09 --> Total execution time: 0.0220
DEBUG - 2014-03-24 18:34:09 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:09 --> Total execution time: 0.0230
DEBUG - 2014-03-24 18:34:09 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:09 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:09 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:09 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:09 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:09 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:09 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:09 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Session Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:34:09 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:09 --> A session cookie was not found.
DEBUG - 2014-03-24 18:34:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Session routines successfully run
DEBUG - 2014-03-24 18:34:10 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:34:10 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:10 --> Session Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:10 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:34:10 --> A session cookie was not found.
DEBUG - 2014-03-24 18:34:10 --> Total execution time: 0.0130
DEBUG - 2014-03-24 18:34:10 --> Session routines successfully run
DEBUG - 2014-03-24 18:34:10 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:34:10 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:10 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:10 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:34:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:10 --> Session Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:34:10 --> A session cookie was not found.
DEBUG - 2014-03-24 18:34:10 --> Session routines successfully run
DEBUG - 2014-03-24 18:34:10 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:34:10 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:10 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:10 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:34:21 --> Config Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:34:21 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:34:21 --> URI Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Router Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Output Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Security Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Input Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:34:21 --> Language Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Loader Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Controller Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:34:21 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:34:21 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Model Class Initialized
DEBUG - 2014-03-24 18:34:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:34:22 --> Final output sent to browser
DEBUG - 2014-03-24 18:34:22 --> Total execution time: 0.9321
DEBUG - 2014-03-24 18:35:03 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:03 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:03 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:03 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:03 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:03 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:03 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:03 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:03 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:03 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:03 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:03 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:03 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:03 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:03 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:03 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:03 --> Total execution time: 0.0190
DEBUG - 2014-03-24 18:35:06 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:06 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:06 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:06 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:06 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:06 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:06 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:06 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:06 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:06 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:06 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:06 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:06 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:06 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:06 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:06 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:06 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:06 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:06 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:06 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:06 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:06 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:06 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:06 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:35:06 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:06 --> Total execution time: 0.0240
DEBUG - 2014-03-24 18:35:58 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Config Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:35:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:58 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:35:58 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:58 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:58 --> URI Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Router Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Output Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Security Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Input Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:58 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:35:58 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Language Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Loader Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Controller Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:58 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:58 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:58 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:58 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:58 --> Session Class Initialized
DEBUG - 2014-03-24 18:35:58 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:35:58 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:58 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:35:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:58 --> A session cookie was not found.
DEBUG - 2014-03-24 18:35:58 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:58 --> Session routines successfully run
DEBUG - 2014-03-24 18:35:58 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:35:58 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:35:58 --> Model Class Initialized
DEBUG - 2014-03-24 18:35:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:35:58 --> Final output sent to browser
DEBUG - 2014-03-24 18:35:58 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:36:07 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:07 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:07 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:07 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:07 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:07 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:07 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:07 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:07 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:07 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:07 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:07 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:07 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:07 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:07 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:07 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:07 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:07 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:07 --> Total execution time: 0.0220
DEBUG - 2014-03-24 18:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:07 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:07 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:36:18 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:18 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:18 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:18 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:18 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:18 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:18 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:18 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:18 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:18 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:18 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:18 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:18 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:18 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:18 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:18 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:36:18 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:18 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:18 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:18 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:36:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:18 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:18 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:36:36 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:36 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:36 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:36 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:36 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:36 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:36 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:36 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:36 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:36 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:36 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:36 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:36 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:36:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:36 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:36:36 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:36:39 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:39 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:39 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Config Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:39 --> URI Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Router Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Output Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Security Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:39 --> Input Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:39 --> Language Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Loader Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Controller Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:39 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:39 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:39 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:39 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:39 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:39 --> Session Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:39 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:36:39 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:39 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:36:39 --> A session cookie was not found.
DEBUG - 2014-03-24 18:36:39 --> Session routines successfully run
DEBUG - 2014-03-24 18:36:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:36:39 --> Model Class Initialized
DEBUG - 2014-03-24 18:36:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:36:39 --> Final output sent to browser
DEBUG - 2014-03-24 18:36:39 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:37:00 --> Config Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:37:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:37:00 --> URI Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Router Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Output Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Security Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Input Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:37:00 --> Language Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Loader Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Controller Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:37:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:37:00 --> Model Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Model Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Model Class Initialized
DEBUG - 2014-03-24 18:37:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:37:01 --> Final output sent to browser
DEBUG - 2014-03-24 18:37:01 --> Total execution time: 1.0491
DEBUG - 2014-03-24 18:38:56 --> Config Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Config Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Config Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:38:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:38:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:38:56 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:38:56 --> URI Class Initialized
DEBUG - 2014-03-24 18:38:56 --> URI Class Initialized
DEBUG - 2014-03-24 18:38:56 --> URI Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Router Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Router Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Router Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Output Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Output Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Security Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Input Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:38:56 --> Security Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Output Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Language Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Input Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:38:56 --> Loader Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Language Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Controller Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Loader Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:38:56 --> Security Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Controller Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:38:56 --> Input Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:38:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Language Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Loader Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Controller Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Session Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:56 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:38:56 --> A session cookie was not found.
DEBUG - 2014-03-24 18:38:56 --> Session routines successfully run
DEBUG - 2014-03-24 18:38:56 --> Session Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> A session cookie was not found.
DEBUG - 2014-03-24 18:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:56 --> Session routines successfully run
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:38:56 --> Final output sent to browser
DEBUG - 2014-03-24 18:38:56 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:38:56 --> Session Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:38:56 --> A session cookie was not found.
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Session routines successfully run
DEBUG - 2014-03-24 18:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:56 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:38:56 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:56 --> Final output sent to browser
DEBUG - 2014-03-24 18:38:56 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:38:56 --> Final output sent to browser
DEBUG - 2014-03-24 18:38:56 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:38:57 --> Config Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Config Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:38:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:38:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:38:57 --> URI Class Initialized
DEBUG - 2014-03-24 18:38:57 --> URI Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Router Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Router Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Output Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Output Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Security Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Security Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Input Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Input Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:38:57 --> Language Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Language Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Config Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Loader Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Loader Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Controller Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Controller Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:38:57 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> URI Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Router Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Output Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Security Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Input Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:38:57 --> Language Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:57 --> Session Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Loader Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Session Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:38:57 --> Controller Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:38:57 --> A session cookie was not found.
DEBUG - 2014-03-24 18:38:57 --> A session cookie was not found.
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:38:57 --> Session routines successfully run
DEBUG - 2014-03-24 18:38:57 --> Session routines successfully run
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:38:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:57 --> Final output sent to browser
DEBUG - 2014-03-24 18:38:57 --> Total execution time: 0.0130
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:57 --> Final output sent to browser
DEBUG - 2014-03-24 18:38:57 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:38:57 --> Session Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:38:57 --> A session cookie was not found.
DEBUG - 2014-03-24 18:38:57 --> Session routines successfully run
DEBUG - 2014-03-24 18:38:57 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:38:57 --> Model Class Initialized
DEBUG - 2014-03-24 18:38:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:38:57 --> Final output sent to browser
DEBUG - 2014-03-24 18:38:57 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:39:42 --> Config Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:39:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:39:42 --> URI Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Router Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Output Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Security Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Input Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:39:42 --> Language Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Loader Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Controller Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:39:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:39:42 --> Model Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Model Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Model Class Initialized
DEBUG - 2014-03-24 18:39:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:39:46 --> Final output sent to browser
DEBUG - 2014-03-24 18:39:46 --> Total execution time: 3.9502
DEBUG - 2014-03-24 18:42:03 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:03 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:03 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:03 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:03 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:03 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:03 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:03 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:03 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Session Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:42:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:03 --> A session cookie was not found.
DEBUG - 2014-03-24 18:42:03 --> Session routines successfully run
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:03 --> Session Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:42:03 --> A session cookie was not found.
DEBUG - 2014-03-24 18:42:03 --> Session routines successfully run
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:03 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:03 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:03 --> Session Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:42:03 --> A session cookie was not found.
DEBUG - 2014-03-24 18:42:03 --> Session routines successfully run
DEBUG - 2014-03-24 18:42:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:42:03 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:03 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:03 --> Total execution time: 0.0220
DEBUG - 2014-03-24 18:42:04 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:04 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:04 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:04 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:04 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:04 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:04 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:04 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:04 --> Session Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:42:04 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:04 --> A session cookie was not found.
DEBUG - 2014-03-24 18:42:04 --> Session routines successfully run
DEBUG - 2014-03-24 18:42:04 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Session Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:42:04 --> A session cookie was not found.
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:42:04 --> Session routines successfully run
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:04 --> Total execution time: 0.0120
DEBUG - 2014-03-24 18:42:04 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:04 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:04 --> Session Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:42:04 --> A session cookie was not found.
DEBUG - 2014-03-24 18:42:04 --> Session routines successfully run
DEBUG - 2014-03-24 18:42:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:42:04 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:04 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:04 --> Total execution time: 0.0150
DEBUG - 2014-03-24 18:42:11 --> Config Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:42:11 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:42:11 --> URI Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Router Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Output Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Security Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Input Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:42:11 --> Language Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Loader Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Controller Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:42:11 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:42:11 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Model Class Initialized
DEBUG - 2014-03-24 18:42:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:42:12 --> Final output sent to browser
DEBUG - 2014-03-24 18:42:12 --> Total execution time: 0.9791
DEBUG - 2014-03-24 18:43:17 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:17 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:17 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:17 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:17 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:17 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:17 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:17 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:17 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:17 --> Session Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:43:17 --> A session cookie was not found.
DEBUG - 2014-03-24 18:43:17 --> Session routines successfully run
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:17 --> Session Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:43:17 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:17 --> A session cookie was not found.
DEBUG - 2014-03-24 18:43:17 --> Total execution time: 0.0120
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:17 --> Session Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Session routines successfully run
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:43:17 --> A session cookie was not found.
DEBUG - 2014-03-24 18:43:17 --> Session routines successfully run
DEBUG - 2014-03-24 18:43:17 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:43:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:17 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:17 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:43:17 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:17 --> Total execution time: 0.0210
DEBUG - 2014-03-24 18:43:18 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:18 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:18 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:18 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:18 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:18 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:18 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:18 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:18 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:18 --> Session Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Session Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:43:18 --> A session cookie was not found.
DEBUG - 2014-03-24 18:43:18 --> A session cookie was not found.
DEBUG - 2014-03-24 18:43:18 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Session routines successfully run
DEBUG - 2014-03-24 18:43:18 --> Session routines successfully run
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:18 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:18 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:43:18 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:18 --> Total execution time: 0.0130
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:18 --> Session Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:43:18 --> A session cookie was not found.
DEBUG - 2014-03-24 18:43:18 --> Session routines successfully run
DEBUG - 2014-03-24 18:43:18 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:43:18 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:18 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:18 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:43:26 --> Config Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:43:26 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:43:26 --> URI Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Router Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Output Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Security Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Input Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:43:26 --> Language Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Loader Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Controller Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:43:26 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Model Class Initialized
DEBUG - 2014-03-24 18:43:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:43:27 --> Final output sent to browser
DEBUG - 2014-03-24 18:43:27 --> Total execution time: 0.9481
DEBUG - 2014-03-24 18:45:34 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:34 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:34 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:34 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:34 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:34 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:34 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:34 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:34 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:34 --> Session Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Session Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> A session cookie was not found.
DEBUG - 2014-03-24 18:45:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:34 --> Session routines successfully run
DEBUG - 2014-03-24 18:45:34 --> Session Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:45:34 --> A session cookie was not found.
DEBUG - 2014-03-24 18:45:34 --> Session routines successfully run
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:34 --> A session cookie was not found.
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:45:34 --> Session routines successfully run
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:45:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:34 --> Total execution time: 0.0160
DEBUG - 2014-03-24 18:45:34 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:34 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:34 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:34 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:45:34 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:45:36 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:36 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:36 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:36 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:36 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:36 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:36 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:36 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:36 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:36 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:36 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:36 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:36 --> Session Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:45:36 --> A session cookie was not found.
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Session routines successfully run
DEBUG - 2014-03-24 18:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Session Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:36 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:45:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:36 --> Total execution time: 0.0120
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:36 --> A session cookie was not found.
DEBUG - 2014-03-24 18:45:36 --> Session Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:45:36 --> A session cookie was not found.
DEBUG - 2014-03-24 18:45:36 --> Session routines successfully run
DEBUG - 2014-03-24 18:45:36 --> Session routines successfully run
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:45:36 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:36 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:36 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:45:36 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:36 --> Total execution time: 0.0170
DEBUG - 2014-03-24 18:45:43 --> Config Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:45:43 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:45:43 --> URI Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Router Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Output Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Security Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Input Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:45:43 --> Language Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Loader Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Controller Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:45:43 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:45:43 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Model Class Initialized
DEBUG - 2014-03-24 18:45:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:45:44 --> Final output sent to browser
DEBUG - 2014-03-24 18:45:44 --> Total execution time: 0.9561
DEBUG - 2014-03-24 18:51:15 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:15 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:15 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:15 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:15 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:15 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:15 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:15 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:15 --> Session Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Session Class Initialized
DEBUG - 2014-03-24 18:51:15 --> A session cookie was not found.
DEBUG - 2014-03-24 18:51:15 --> Session routines successfully run
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:51:15 --> A session cookie was not found.
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:51:15 --> Session routines successfully run
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:15 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:15 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:15 --> Session Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:51:15 --> A session cookie was not found.
DEBUG - 2014-03-24 18:51:15 --> Session routines successfully run
DEBUG - 2014-03-24 18:51:15 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:51:15 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:15 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:15 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:15 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:51:15 --> Total execution time: 0.0180
DEBUG - 2014-03-24 18:51:17 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:17 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:17 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:17 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:17 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:17 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:17 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:17 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:17 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:17 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:17 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:17 --> Session Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:51:17 --> A session cookie was not found.
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:17 --> Session Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Session routines successfully run
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:51:17 --> A session cookie was not found.
DEBUG - 2014-03-24 18:51:17 --> Session Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Session routines successfully run
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: string_helper
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:51:17 --> A session cookie was not found.
DEBUG - 2014-03-24 18:51:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:17 --> Session routines successfully run
DEBUG - 2014-03-24 18:51:17 --> Helper loaded: url_helper
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:17 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:17 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:51:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:17 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:17 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:17 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:51:17 --> Total execution time: 0.0140
DEBUG - 2014-03-24 18:51:25 --> Config Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 18:51:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 18:51:25 --> URI Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Router Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Output Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Security Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Input Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 18:51:25 --> Language Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Loader Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Controller Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 18:51:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 18:51:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Model Class Initialized
DEBUG - 2014-03-24 18:51:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 18:51:25 --> Final output sent to browser
DEBUG - 2014-03-24 18:51:25 --> Total execution time: 0.9501
DEBUG - 2014-03-24 19:21:30 --> Config Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Config Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Config Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:21:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:21:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:21:30 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:21:30 --> URI Class Initialized
DEBUG - 2014-03-24 19:21:30 --> URI Class Initialized
DEBUG - 2014-03-24 19:21:30 --> URI Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Router Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Router Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Output Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Security Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Input Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Output Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:21:30 --> Router Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Security Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Input Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:21:30 --> Language Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Output Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Language Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Security Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Input Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:21:30 --> Loader Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Language Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Controller Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:21:30 --> Loader Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Controller Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Loader Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Controller Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:30 --> Session Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:21:30 --> Session Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:21:30 --> A session cookie was not found.
DEBUG - 2014-03-24 19:21:30 --> A session cookie was not found.
DEBUG - 2014-03-24 19:21:30 --> Session routines successfully run
DEBUG - 2014-03-24 19:21:30 --> Session routines successfully run
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:30 --> Final output sent to browser
DEBUG - 2014-03-24 19:21:30 --> Final output sent to browser
DEBUG - 2014-03-24 19:21:30 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:21:30 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:21:30 --> Session Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:21:30 --> A session cookie was not found.
DEBUG - 2014-03-24 19:21:30 --> Session routines successfully run
DEBUG - 2014-03-24 19:21:30 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:21:30 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:30 --> Final output sent to browser
DEBUG - 2014-03-24 19:21:30 --> Total execution time: 0.0190
DEBUG - 2014-03-24 19:21:31 --> Config Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Config Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:21:31 --> URI Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Router Class Initialized
DEBUG - 2014-03-24 19:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:21:31 --> URI Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Output Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Router Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Security Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Input Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Output Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:21:31 --> Security Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Language Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Input Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Loader Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:21:31 --> Controller Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Language Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Config Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:21:31 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:21:31 --> Loader Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Controller Class Initialized
DEBUG - 2014-03-24 19:21:31 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:21:31 --> URI Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:21:31 --> Router Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Output Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Security Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Input Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:21:31 --> Language Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Session Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Loader Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:21:31 --> A session cookie was not found.
DEBUG - 2014-03-24 19:21:31 --> Controller Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Session routines successfully run
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Session Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:31 --> A session cookie was not found.
DEBUG - 2014-03-24 19:21:31 --> Session routines successfully run
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Final output sent to browser
DEBUG - 2014-03-24 19:21:31 --> Total execution time: 0.0120
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:31 --> Session Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Final output sent to browser
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:21:31 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:21:31 --> A session cookie was not found.
DEBUG - 2014-03-24 19:21:31 --> Session routines successfully run
DEBUG - 2014-03-24 19:21:31 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:21:31 --> Model Class Initialized
DEBUG - 2014-03-24 19:21:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:21:31 --> Final output sent to browser
DEBUG - 2014-03-24 19:21:31 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:22:38 --> Config Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:22:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:22:38 --> URI Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Router Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Output Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Security Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Input Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:22:38 --> Language Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Loader Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Controller Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:22:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:22:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:22:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:22:39 --> Final output sent to browser
DEBUG - 2014-03-24 19:22:39 --> Total execution time: 0.9601
DEBUG - 2014-03-24 19:24:03 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:03 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:03 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:03 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:03 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:03 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:03 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:03 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:03 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:03 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Session Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:03 --> Session Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:24:03 --> A session cookie was not found.
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:24:03 --> Session routines successfully run
DEBUG - 2014-03-24 19:24:03 --> Session Class Initialized
DEBUG - 2014-03-24 19:24:03 --> A session cookie was not found.
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:24:03 --> A session cookie was not found.
DEBUG - 2014-03-24 19:24:03 --> Session routines successfully run
DEBUG - 2014-03-24 19:24:03 --> Session routines successfully run
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:03 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:03 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:03 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:24:03 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:03 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:24:03 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:03 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:24:09 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:09 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:09 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:09 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:09 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:09 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:09 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:09 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Session Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Session Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:24:09 --> A session cookie was not found.
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:24:09 --> A session cookie was not found.
DEBUG - 2014-03-24 19:24:09 --> Session routines successfully run
DEBUG - 2014-03-24 19:24:09 --> Session routines successfully run
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:09 --> Session Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:09 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:24:09 --> A session cookie was not found.
DEBUG - 2014-03-24 19:24:09 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:09 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:24:09 --> Session routines successfully run
DEBUG - 2014-03-24 19:24:09 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:24:09 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:09 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:09 --> Total execution time: 0.0170
DEBUG - 2014-03-24 19:24:16 --> Config Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:24:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:24:16 --> URI Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Router Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Output Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Security Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Input Class Initialized
DEBUG - 2014-03-24 19:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:24:17 --> Language Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Loader Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Controller Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:24:17 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:24:17 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Model Class Initialized
DEBUG - 2014-03-24 19:24:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:24:17 --> Final output sent to browser
DEBUG - 2014-03-24 19:24:17 --> Total execution time: 0.9691
DEBUG - 2014-03-24 19:30:12 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:12 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:12 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:12 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:12 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:12 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:12 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:12 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:12 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:12 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:12 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:12 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:12 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:12 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:12 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:12 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:12 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:12 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:12 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:12 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:12 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:12 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:12 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:12 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:30:12 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:30:12 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:30:13 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:13 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:13 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:13 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:13 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:13 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:13 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:13 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:13 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:13 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:13 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:13 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:13 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:13 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:13 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:13 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:13 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:13 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:13 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:30:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:13 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:13 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:30:13 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:13 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:13 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:13 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:13 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:13 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:13 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:13 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:30:16 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:16 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:16 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:16 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:16 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:16 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:16 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:16 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:16 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:16 --> Session Class Initialized
DEBUG - 2014-03-24 19:30:16 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:16 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:30:16 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:16 --> A session cookie was not found.
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:16 --> Session routines successfully run
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:16 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:30:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:16 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:16 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:16 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:16 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:30:16 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:16 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:30:16 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:30:23 --> Config Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:30:23 --> URI Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Router Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Output Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Security Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Input Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:30:23 --> Language Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Loader Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Controller Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:30:23 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:30:23 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Model Class Initialized
DEBUG - 2014-03-24 19:30:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:30:24 --> Final output sent to browser
DEBUG - 2014-03-24 19:30:24 --> Total execution time: 1.0921
DEBUG - 2014-03-24 19:35:32 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:32 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:32 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:32 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:32 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:32 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:32 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:32 --> Session Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:32 --> A session cookie was not found.
DEBUG - 2014-03-24 19:35:32 --> Session routines successfully run
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:32 --> Session Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:35:32 --> A session cookie was not found.
DEBUG - 2014-03-24 19:35:32 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:32 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:35:32 --> Session routines successfully run
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:32 --> Session Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:35:32 --> A session cookie was not found.
DEBUG - 2014-03-24 19:35:32 --> Session routines successfully run
DEBUG - 2014-03-24 19:35:32 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:35:32 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:35:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:32 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:32 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:35:35 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:35 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:35 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:35 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:35 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:35 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:35 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:35 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:35 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:35 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:35 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Session Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> A session cookie was not found.
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:35 --> Session routines successfully run
DEBUG - 2014-03-24 19:35:35 --> Session Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:35:35 --> Session Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:35:35 --> A session cookie was not found.
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:35 --> Session routines successfully run
DEBUG - 2014-03-24 19:35:35 --> A session cookie was not found.
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:35:35 --> Session routines successfully run
DEBUG - 2014-03-24 19:35:35 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:35 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:35 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:35 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:35 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:35:35 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:35 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:35:42 --> Config Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:35:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:35:42 --> URI Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Router Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Output Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Security Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Input Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:35:42 --> Language Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Loader Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Controller Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:35:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:35:42 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Model Class Initialized
DEBUG - 2014-03-24 19:35:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:35:43 --> Final output sent to browser
DEBUG - 2014-03-24 19:35:43 --> Total execution time: 0.9421
DEBUG - 2014-03-24 19:36:04 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:04 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:04 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:04 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:04 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:04 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:04 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Session Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:36:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> A session cookie was not found.
DEBUG - 2014-03-24 19:36:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:04 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Session Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Session routines successfully run
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:36:04 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> A session cookie was not found.
DEBUG - 2014-03-24 19:36:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:04 --> Session routines successfully run
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:04 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:36:04 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:04 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:04 --> Session Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:36:04 --> A session cookie was not found.
DEBUG - 2014-03-24 19:36:04 --> Session routines successfully run
DEBUG - 2014-03-24 19:36:04 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:36:04 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:04 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:04 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:36:07 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:07 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:07 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:07 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:07 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:07 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:07 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Session Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:36:07 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:07 --> A session cookie was not found.
DEBUG - 2014-03-24 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:07 --> Session routines successfully run
DEBUG - 2014-03-24 19:36:07 --> Session Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> A session cookie was not found.
DEBUG - 2014-03-24 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:07 --> Session routines successfully run
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:07 --> Session Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:36:07 --> A session cookie was not found.
DEBUG - 2014-03-24 19:36:07 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:07 --> Session routines successfully run
DEBUG - 2014-03-24 19:36:07 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:36:07 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:36:07 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:07 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:07 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:36:07 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:07 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:36:33 --> Config Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:36:33 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:36:33 --> URI Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Router Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Output Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Security Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Input Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:36:33 --> Language Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Loader Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Controller Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:36:33 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:36:33 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Model Class Initialized
DEBUG - 2014-03-24 19:36:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:36:34 --> Final output sent to browser
DEBUG - 2014-03-24 19:36:34 --> Total execution time: 0.9491
DEBUG - 2014-03-24 19:39:00 --> Config Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:39:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:39:00 --> URI Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Router Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Config Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:39:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:39:00 --> Output Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Config Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:39:00 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:39:00 --> URI Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Router Class Initialized
DEBUG - 2014-03-24 19:39:00 --> URI Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Router Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Output Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Security Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Output Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Input Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Security Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Security Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Input Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:39:00 --> Input Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:39:00 --> Language Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Language Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Loader Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Controller Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Loader Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Controller Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:39:00 --> Language Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Loader Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:39:00 --> Controller Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:39:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Session Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> A session cookie was not found.
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Session routines successfully run
DEBUG - 2014-03-24 19:39:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Session Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:39:00 --> Final output sent to browser
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:39:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:00 --> Session Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:39:00 --> A session cookie was not found.
DEBUG - 2014-03-24 19:39:00 --> A session cookie was not found.
DEBUG - 2014-03-24 19:39:00 --> Session routines successfully run
DEBUG - 2014-03-24 19:39:00 --> Session routines successfully run
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:39:00 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:00 --> Final output sent to browser
DEBUG - 2014-03-24 19:39:00 --> Total execution time: 0.0200
DEBUG - 2014-03-24 19:39:00 --> Final output sent to browser
DEBUG - 2014-03-24 19:39:00 --> Total execution time: 0.0170
DEBUG - 2014-03-24 19:39:01 --> Config Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Config Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:39:01 --> URI Class Initialized
DEBUG - 2014-03-24 19:39:01 --> URI Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Router Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Router Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Config Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Output Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Output Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Security Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Input Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:39:01 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Language Class Initialized
DEBUG - 2014-03-24 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:39:01 --> Security Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Input Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:39:01 --> Loader Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Language Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Controller Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:39:01 --> Loader Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:39:01 --> URI Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Controller Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Router Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Output Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Security Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:39:01 --> Input Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:39:01 --> Language Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Loader Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Controller Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Session Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:39:01 --> A session cookie was not found.
DEBUG - 2014-03-24 19:39:01 --> Session routines successfully run
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:39:01 --> Session Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:39:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:01 --> A session cookie was not found.
DEBUG - 2014-03-24 19:39:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:01 --> Session routines successfully run
DEBUG - 2014-03-24 19:39:01 --> Session Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:39:01 --> A session cookie was not found.
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Session routines successfully run
DEBUG - 2014-03-24 19:39:01 --> Final output sent to browser
DEBUG - 2014-03-24 19:39:01 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:39:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:01 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:39:01 --> Model Class Initialized
DEBUG - 2014-03-24 19:39:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:39:01 --> Final output sent to browser
DEBUG - 2014-03-24 19:39:01 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:39:01 --> Final output sent to browser
DEBUG - 2014-03-24 19:39:01 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:43:25 --> Config Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:43:25 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:43:25 --> URI Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Router Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Output Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Security Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Input Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:43:25 --> Language Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Loader Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Controller Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:43:25 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Model Class Initialized
DEBUG - 2014-03-24 19:43:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:43:26 --> Final output sent to browser
DEBUG - 2014-03-24 19:43:26 --> Total execution time: 0.9881
DEBUG - 2014-03-24 19:46:38 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:38 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:38 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:38 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:38 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:38 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:38 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Session Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:46:38 --> A session cookie was not found.
DEBUG - 2014-03-24 19:46:38 --> Session routines successfully run
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:38 --> Session Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:38 --> Session Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:46:38 --> A session cookie was not found.
DEBUG - 2014-03-24 19:46:38 --> A session cookie was not found.
DEBUG - 2014-03-24 19:46:38 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:38 --> Session routines successfully run
DEBUG - 2014-03-24 19:46:38 --> Session routines successfully run
DEBUG - 2014-03-24 19:46:38 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:46:38 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:38 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:38 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:38 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:46:38 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:46:39 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:39 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:39 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:39 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:39 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:39 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:39 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:39 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:39 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Session Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:46:39 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:39 --> A session cookie was not found.
DEBUG - 2014-03-24 19:46:39 --> Session routines successfully run
DEBUG - 2014-03-24 19:46:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:39 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:39 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:39 --> Session Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:39 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:46:39 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:46:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:39 --> A session cookie was not found.
DEBUG - 2014-03-24 19:46:39 --> Session Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Session routines successfully run
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:46:39 --> A session cookie was not found.
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:46:39 --> Session routines successfully run
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:46:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:39 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:39 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:39 --> Total execution time: 0.0170
DEBUG - 2014-03-24 19:46:39 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:39 --> Total execution time: 0.0170
DEBUG - 2014-03-24 19:46:47 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:47 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:47 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:47 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:47 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:47 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:47 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:47 --> Total execution time: 0.0180
DEBUG - 2014-03-24 19:46:55 --> Config Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:46:55 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:46:55 --> URI Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Router Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Output Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Security Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Input Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:46:55 --> Language Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Loader Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Controller Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:46:55 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Model Class Initialized
DEBUG - 2014-03-24 19:46:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:46:56 --> Final output sent to browser
DEBUG - 2014-03-24 19:46:56 --> Total execution time: 0.9271
DEBUG - 2014-03-24 19:48:52 --> Config Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Config Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Config Class Initialized
DEBUG - 2014-03-24 19:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:48:52 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:48:52 --> URI Class Initialized
DEBUG - 2014-03-24 19:48:52 --> URI Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Router Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Router Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Output Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Output Class Initialized
DEBUG - 2014-03-24 19:48:52 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:48:52 --> Security Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Security Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Input Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:48:52 --> URI Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Language Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Router Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Input Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:48:52 --> Loader Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Controller Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Output Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:48:52 --> Security Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:48:52 --> Input Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Language Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Loader Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Controller Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:48:52 --> Language Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:48:52 --> Loader Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Controller Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:48:52 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:48:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Session Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:48:52 --> A session cookie was not found.
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Session routines successfully run
DEBUG - 2014-03-24 19:48:52 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Session Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:48:52 --> A session cookie was not found.
DEBUG - 2014-03-24 19:48:52 --> Session routines successfully run
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:48:52 --> Final output sent to browser
DEBUG - 2014-03-24 19:48:52 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Final output sent to browser
DEBUG - 2014-03-24 19:48:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:52 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:48:52 --> Session Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:48:52 --> A session cookie was not found.
DEBUG - 2014-03-24 19:48:52 --> Session routines successfully run
DEBUG - 2014-03-24 19:48:52 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:48:52 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:52 --> Final output sent to browser
DEBUG - 2014-03-24 19:48:52 --> Total execution time: 0.0190
DEBUG - 2014-03-24 19:48:54 --> Config Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Config Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:48:54 --> URI Class Initialized
DEBUG - 2014-03-24 19:48:54 --> URI Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Router Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Router Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Output Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Output Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Security Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Security Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Input Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Input Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Config Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:48:54 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:48:54 --> Language Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Language Class Initialized
DEBUG - 2014-03-24 19:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:48:54 --> Loader Class Initialized
DEBUG - 2014-03-24 19:48:54 --> URI Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Controller Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Loader Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Controller Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Router Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:48:54 --> Output Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Security Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Input Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:48:54 --> Language Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Loader Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Controller Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:48:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:54 --> Session Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> A session cookie was not found.
DEBUG - 2014-03-24 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:54 --> Session routines successfully run
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:48:54 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Session Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:48:54 --> A session cookie was not found.
DEBUG - 2014-03-24 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:54 --> Session routines successfully run
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Final output sent to browser
DEBUG - 2014-03-24 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:54 --> Total execution time: 0.0120
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:54 --> Session Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:48:54 --> A session cookie was not found.
DEBUG - 2014-03-24 19:48:54 --> Final output sent to browser
DEBUG - 2014-03-24 19:48:54 --> Session routines successfully run
DEBUG - 2014-03-24 19:48:54 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:48:54 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:48:54 --> Model Class Initialized
DEBUG - 2014-03-24 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:48:54 --> Final output sent to browser
DEBUG - 2014-03-24 19:48:54 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:49:02 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:02 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:02 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:02 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:02 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:02 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:03 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:03 --> Total execution time: 0.9531
DEBUG - 2014-03-24 19:49:32 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:32 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:32 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:32 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:32 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:32 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:32 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:32 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:32 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:32 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:32 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:32 --> Session Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Session Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:49:32 --> A session cookie was not found.
DEBUG - 2014-03-24 19:49:32 --> A session cookie was not found.
DEBUG - 2014-03-24 19:49:32 --> Session routines successfully run
DEBUG - 2014-03-24 19:49:32 --> Session routines successfully run
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:32 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:32 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:32 --> Total execution time: 0.0150
DEBUG - 2014-03-24 19:49:32 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:32 --> Session Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:49:32 --> A session cookie was not found.
DEBUG - 2014-03-24 19:49:32 --> Session routines successfully run
DEBUG - 2014-03-24 19:49:32 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:49:32 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:32 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:32 --> Total execution time: 0.0160
DEBUG - 2014-03-24 19:49:34 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:34 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:34 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:34 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:34 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:34 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:34 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:34 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:34 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:34 --> Session Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Session Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Session Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: string_helper
DEBUG - 2014-03-24 19:49:34 --> A session cookie was not found.
DEBUG - 2014-03-24 19:49:34 --> A session cookie was not found.
DEBUG - 2014-03-24 19:49:34 --> A session cookie was not found.
DEBUG - 2014-03-24 19:49:34 --> Session routines successfully run
DEBUG - 2014-03-24 19:49:34 --> Session routines successfully run
DEBUG - 2014-03-24 19:49:34 --> Session routines successfully run
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:49:34 --> Helper loaded: url_helper
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:34 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:34 --> Total execution time: 0.0130
DEBUG - 2014-03-24 19:49:34 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:34 --> Total execution time: 0.0120
DEBUG - 2014-03-24 19:49:34 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:34 --> Total execution time: 0.0140
DEBUG - 2014-03-24 19:49:42 --> Config Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Hooks Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Utf8 Class Initialized
DEBUG - 2014-03-24 19:49:42 --> UTF-8 Support Enabled
DEBUG - 2014-03-24 19:49:42 --> URI Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Router Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Output Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Security Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Input Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-03-24 19:49:42 --> Language Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Loader Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Controller Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-03-24 19:49:42 --> Helper loaded: utilities_helper
DEBUG - 2014-03-24 19:49:42 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Database Driver Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Model Class Initialized
DEBUG - 2014-03-24 19:49:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-03-24 19:49:50 --> Final output sent to browser
DEBUG - 2014-03-24 19:49:50 --> Total execution time: 7.3704
