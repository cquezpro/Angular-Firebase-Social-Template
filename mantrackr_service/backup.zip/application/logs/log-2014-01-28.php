<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-28 15:16:07 --> Config Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Hooks Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Utf8 Class Initialized
DEBUG - 2014-01-28 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 15:16:07 --> URI Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Router Class Initialized
DEBUG - 2014-01-28 15:16:07 --> No URI present. Default controller set.
DEBUG - 2014-01-28 15:16:07 --> Output Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Security Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Input Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 15:16:07 --> Language Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Loader Class Initialized
DEBUG - 2014-01-28 15:16:07 --> Controller Class Initialized
DEBUG - 2014-01-28 15:16:07 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-01-28 15:16:07 --> Final output sent to browser
DEBUG - 2014-01-28 15:16:07 --> Total execution time: 0.1270
DEBUG - 2014-01-28 17:40:06 --> Config Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Hooks Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Utf8 Class Initialized
DEBUG - 2014-01-28 17:40:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 17:40:06 --> URI Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Router Class Initialized
DEBUG - 2014-01-28 17:40:06 --> No URI present. Default controller set.
DEBUG - 2014-01-28 17:40:06 --> Output Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Security Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Input Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 17:40:06 --> Language Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Loader Class Initialized
DEBUG - 2014-01-28 17:40:06 --> Controller Class Initialized
DEBUG - 2014-01-28 17:40:06 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-01-28 17:40:06 --> Final output sent to browser
DEBUG - 2014-01-28 17:40:06 --> Total execution time: 0.0130
DEBUG - 2014-01-28 17:59:30 --> Config Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Hooks Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Utf8 Class Initialized
DEBUG - 2014-01-28 17:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 17:59:30 --> URI Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Router Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Output Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Security Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Input Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 17:59:30 --> Language Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Loader Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Controller Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 17:59:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Database Driver Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Model Class Initialized
DEBUG - 2014-01-28 17:59:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 17:59:30 --> Session Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:07 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:07 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:00:07 --> Session Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:00:07 --> A session cookie was not found.
DEBUG - 2014-01-28 18:00:07 --> Session routines successfully run
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:00:07 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:07 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:07 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:00:07 --> Session Class Initialized
DEBUG - 2014-01-28 18:00:07 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:00:07 --> Session routines successfully run
ERROR - 2014-01-28 18:00:07 --> 404 Page Not Found --> admin/login
DEBUG - 2014-01-28 18:00:33 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:33 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:33 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:33 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:33 --> Final output sent to browser
DEBUG - 2014-01-28 18:00:33 --> Total execution time: 0.0120
DEBUG - 2014-01-28 18:00:52 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:52 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:52 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:52 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:52 --> Final output sent to browser
DEBUG - 2014-01-28 18:00:52 --> Total execution time: 0.0130
DEBUG - 2014-01-28 18:00:56 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:56 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:56 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:56 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:56 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:00:57 --> Session Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:00:57 --> Session routines successfully run
DEBUG - 2014-01-28 18:00:57 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:00:57 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:57 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:57 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:57 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:00:57 --> Session Class Initialized
DEBUG - 2014-01-28 18:00:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:00:57 --> Session routines successfully run
ERROR - 2014-01-28 18:00:57 --> 404 Page Not Found --> admin/login
DEBUG - 2014-01-28 18:00:58 --> Config Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:00:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:00:58 --> URI Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Router Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Output Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Security Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Input Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:00:58 --> Language Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Loader Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Controller Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:00:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:00:58 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Model Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:00:58 --> Session Class Initialized
DEBUG - 2014-01-28 18:00:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:00:58 --> Session routines successfully run
ERROR - 2014-01-28 18:00:58 --> 404 Page Not Found --> admin/login
DEBUG - 2014-01-28 18:01:18 --> Config Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:01:18 --> URI Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Router Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Output Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Security Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Input Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:01:18 --> Language Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Loader Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Controller Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:01:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:01:18 --> Model Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Model Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Model Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:01:18 --> Session Class Initialized
DEBUG - 2014-01-28 18:01:18 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:01:18 --> Session routines successfully run
DEBUG - 2014-01-28 18:01:24 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:01:37 --> Config Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:01:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:01:37 --> URI Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Router Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Output Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Security Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Input Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:01:37 --> Language Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Loader Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Controller Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:01:37 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:01:37 --> Model Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Model Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Model Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:01:37 --> Session Class Initialized
DEBUG - 2014-01-28 18:01:37 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:01:37 --> Session routines successfully run
ERROR - 2014-01-28 18:01:37 --> 404 Page Not Found --> admin/login
DEBUG - 2014-01-28 18:30:04 --> Config Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:30:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:30:04 --> URI Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Router Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Output Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Security Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Input Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:30:04 --> Language Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Loader Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Controller Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:30:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:30:04 --> Model Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Model Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Model Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:30:04 --> Session Class Initialized
DEBUG - 2014-01-28 18:30:04 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:30:04 --> Session routines successfully run
DEBUG - 2014-01-28 18:30:04 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:30:04 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:30:04 --> Final output sent to browser
DEBUG - 2014-01-28 18:30:04 --> Total execution time: 0.0190
DEBUG - 2014-01-28 18:30:07 --> Config Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:30:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:30:07 --> URI Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Router Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Output Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Security Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Input Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:30:07 --> Language Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Loader Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Controller Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:30:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:30:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Model Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:30:07 --> Session Class Initialized
DEBUG - 2014-01-28 18:30:07 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:30:07 --> Session routines successfully run
DEBUG - 2014-01-28 18:30:07 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:30:07 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:30:07 --> Final output sent to browser
DEBUG - 2014-01-28 18:30:07 --> Total execution time: 0.0170
DEBUG - 2014-01-28 18:36:01 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:01 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:01 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:01 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:01 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:01 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:01 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:01 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:01 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:01 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:01 --> Total execution time: 0.0360
DEBUG - 2014-01-28 18:36:03 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:03 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:03 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:03 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:03 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:03 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:03 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:03 --> Total execution time: 0.0100
DEBUG - 2014-01-28 18:36:12 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:12 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:12 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:12 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:12 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:12 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:12 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:12 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:12 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:12 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:12 --> Total execution time: 0.0190
DEBUG - 2014-01-28 18:36:14 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:14 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:14 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:14 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:14 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:14 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:14 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:14 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:14 --> Total execution time: 0.0150
DEBUG - 2014-01-28 18:36:23 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:23 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:23 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:23 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:23 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:23 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:23 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:23 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:23 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:23 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:23 --> Total execution time: 0.0120
DEBUG - 2014-01-28 18:36:24 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:24 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:24 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:24 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:24 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:24 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:24 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:24 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:24 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:24 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:24 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:24 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:24 --> Total execution time: 0.0110
DEBUG - 2014-01-28 18:36:25 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:25 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:25 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:25 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:25 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:25 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:25 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:25 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:36:25 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:36:25 --> Final output sent to browser
DEBUG - 2014-01-28 18:36:25 --> Total execution time: 0.0140
DEBUG - 2014-01-28 18:36:45 --> Config Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:36:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:36:45 --> URI Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Router Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Output Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Security Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Input Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:36:45 --> Language Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Loader Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Controller Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:36:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:36:45 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Model Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:36:45 --> Session Class Initialized
DEBUG - 2014-01-28 18:36:45 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:36:45 --> Session routines successfully run
DEBUG - 2014-01-28 18:36:45 --> Helper loaded: url_helper
ERROR - 2014-01-28 18:36:45 --> 404 Page Not Found --> admin/processLogin
DEBUG - 2014-01-28 18:38:18 --> Config Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:38:18 --> URI Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Router Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Output Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Security Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Input Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:38:18 --> Language Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Loader Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Controller Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:38:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:38:18 --> Model Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Model Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Model Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:38:18 --> Session Class Initialized
DEBUG - 2014-01-28 18:38:18 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:38:18 --> Session routines successfully run
DEBUG - 2014-01-28 18:38:18 --> Helper loaded: url_helper
ERROR - 2014-01-28 18:38:18 --> 404 Page Not Found --> admin/processLogin
DEBUG - 2014-01-28 18:52:03 --> Config Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:52:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:52:03 --> URI Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Router Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Output Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Security Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Input Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:52:03 --> Language Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Loader Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Controller Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:52:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:52:03 --> Session Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:52:03 --> Session routines successfully run
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:52:03 --> Config Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:52:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:52:03 --> URI Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Router Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Output Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Security Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Input Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:52:03 --> Language Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Loader Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Controller Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:52:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:52:03 --> Session Class Initialized
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:52:03 --> Session routines successfully run
DEBUG - 2014-01-28 18:52:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:52:03 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:52:03 --> Final output sent to browser
DEBUG - 2014-01-28 18:52:03 --> Total execution time: 0.0090
DEBUG - 2014-01-28 18:52:04 --> Config Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:52:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:52:04 --> URI Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Router Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Output Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Security Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Input Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:52:04 --> Language Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Loader Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Controller Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:52:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:52:04 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Model Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:52:04 --> Session Class Initialized
DEBUG - 2014-01-28 18:52:04 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:52:04 --> Session routines successfully run
DEBUG - 2014-01-28 18:52:04 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:52:04 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:52:04 --> Final output sent to browser
DEBUG - 2014-01-28 18:52:04 --> Total execution time: 0.0130
DEBUG - 2014-01-28 18:56:57 --> Config Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:56:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:56:57 --> URI Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Router Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Output Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Security Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Input Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:56:57 --> Language Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Loader Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Controller Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:56:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:56:57 --> Model Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Model Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Model Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:56:57 --> Session Class Initialized
DEBUG - 2014-01-28 18:56:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:56:57 --> Session routines successfully run
DEBUG - 2014-01-28 18:56:57 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:56:57 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:56:57 --> Final output sent to browser
DEBUG - 2014-01-28 18:56:57 --> Total execution time: 0.0160
DEBUG - 2014-01-28 18:57:15 --> Config Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Hooks Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Utf8 Class Initialized
DEBUG - 2014-01-28 18:57:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 18:57:15 --> URI Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Router Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Output Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Security Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Input Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 18:57:15 --> Language Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Loader Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Controller Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 18:57:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 18:57:15 --> Model Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Model Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Database Driver Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Model Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 18:57:15 --> Session Class Initialized
DEBUG - 2014-01-28 18:57:15 --> Helper loaded: string_helper
DEBUG - 2014-01-28 18:57:15 --> Session routines successfully run
DEBUG - 2014-01-28 18:57:15 --> Helper loaded: url_helper
DEBUG - 2014-01-28 18:57:15 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 18:57:15 --> Final output sent to browser
DEBUG - 2014-01-28 18:57:15 --> Total execution time: 0.0190
DEBUG - 2014-01-28 19:16:41 --> Config Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:16:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:16:41 --> URI Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Router Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Output Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Security Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Input Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:16:41 --> Language Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Loader Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Controller Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:16:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:16:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:16:41 --> Session Class Initialized
DEBUG - 2014-01-28 19:16:41 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:16:41 --> Session routines successfully run
DEBUG - 2014-01-28 19:16:41 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:16:41 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:16:41 --> Final output sent to browser
DEBUG - 2014-01-28 19:16:41 --> Total execution time: 0.0190
DEBUG - 2014-01-28 19:21:50 --> Config Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:21:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:21:50 --> URI Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Router Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Output Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Security Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Input Class Initialized
DEBUG - 2014-01-28 19:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:21:50 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:54 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:54 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:54 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:54 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:54 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:54 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:48:54 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:48:54 --> Final output sent to browser
DEBUG - 2014-01-28 19:48:54 --> Total execution time: 0.0180
DEBUG - 2014-01-28 19:48:55 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:55 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:55 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:55 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:55 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:55 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:55 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:48:55 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:48:56 --> Final output sent to browser
DEBUG - 2014-01-28 19:48:56 --> Total execution time: 0.0180
DEBUG - 2014-01-28 19:48:57 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:57 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:57 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:57 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:57 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:48:57 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:48:57 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:57 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:57 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:57 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:57 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:57 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:48:57 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:48:57 --> Final output sent to browser
DEBUG - 2014-01-28 19:48:57 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:48:58 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:58 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:58 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:58 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:58 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:58 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:48:58 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:48:58 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:58 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:58 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:58 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:58 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:58 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:58 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:48:58 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:48:58 --> Final output sent to browser
DEBUG - 2014-01-28 19:48:58 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:48:59 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:59 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:59 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:59 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:59 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:59 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:48:59 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:48:59 --> Config Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:48:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:48:59 --> URI Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Router Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Output Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Security Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Input Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:48:59 --> Language Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Loader Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Controller Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:48:59 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Model Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:48:59 --> Session Class Initialized
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:48:59 --> Session routines successfully run
DEBUG - 2014-01-28 19:48:59 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:48:59 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:48:59 --> Final output sent to browser
DEBUG - 2014-01-28 19:48:59 --> Total execution time: 0.0170
DEBUG - 2014-01-28 19:49:23 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:23 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:23 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:23 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:23 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:23 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:23 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:23 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:49:23 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:49:23 --> Final output sent to browser
DEBUG - 2014-01-28 19:49:23 --> Total execution time: 0.0190
DEBUG - 2014-01-28 19:49:38 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:38 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:38 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:38 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:38 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:38 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:38 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:38 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:38 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:49:38 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:49:38 --> Final output sent to browser
DEBUG - 2014-01-28 19:49:38 --> Total execution time: 0.0110
DEBUG - 2014-01-28 19:49:40 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:40 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:40 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:40 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:40 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:40 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:49:40 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:49:40 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:40 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:40 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:40 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:40 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:40 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:40 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:49:40 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:49:40 --> Final output sent to browser
DEBUG - 2014-01-28 19:49:40 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:49:43 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:43 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:43 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:43 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:43 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:49:43 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:49:43 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:43 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:43 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:43 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:43 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:43 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:49:43 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:49:43 --> Final output sent to browser
DEBUG - 2014-01-28 19:49:43 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:49:44 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:44 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:44 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:44 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:44 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:44 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:49:44 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:49:44 --> Config Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:49:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:49:44 --> URI Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Router Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Output Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Security Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Input Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:49:44 --> Language Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Loader Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Controller Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:49:44 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Model Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:49:44 --> Session Class Initialized
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:49:44 --> Session routines successfully run
DEBUG - 2014-01-28 19:49:44 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:49:44 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:49:44 --> Final output sent to browser
DEBUG - 2014-01-28 19:49:44 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:50:03 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:03 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:03 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:03 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:03 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:03 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:03 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:03 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:03 --> Total execution time: 0.0120
DEBUG - 2014-01-28 19:50:05 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:05 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:05 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:05 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:05 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:05 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:05 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:05 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:05 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:05 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:05 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:05 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:05 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:05 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:05 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:05 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:05 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:50:07 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:07 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:07 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:07 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:07 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:07 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:07 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:07 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:07 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:07 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:07 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:07 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:07 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:07 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:07 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:07 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:07 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:07 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:50:08 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:08 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:08 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:08 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:08 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:08 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:08 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:08 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:08 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:08 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:08 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:08 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:08 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:08 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:08 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:08 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:08 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:50:09 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:09 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:09 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:09 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:09 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:09 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:09 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:09 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:10 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:10 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:10 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:10 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:10 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:10 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:10 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:10 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:10 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:10 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:10 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:10 --> Total execution time: 0.1500
DEBUG - 2014-01-28 19:50:51 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:51 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:51 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:51 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:51 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:51 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:51 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:51 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:51 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:51 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:51 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:51 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:51 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:51 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:51 --> Total execution time: 0.0170
DEBUG - 2014-01-28 19:50:52 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:52 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:52 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:52 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:52 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:52 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:52 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:52 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:52 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:52 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:52 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:52 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:52 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:52 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:52 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:50:53 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:53 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:53 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:53 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:53 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:53 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:53 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:53 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:53 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:53 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:53 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:53 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:53 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:53 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:53 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:50:55 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:55 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:55 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:55 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:55 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: url_helper
ERROR - 2014-01-28 19:50:55 --> Severity: Notice  --> Undefined variable: username F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php 42
DEBUG - 2014-01-28 19:50:55 --> Config Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:50:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:50:55 --> URI Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Router Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Output Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Security Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Input Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:50:55 --> Language Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Loader Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Controller Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:50:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Model Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:50:55 --> Session Class Initialized
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:50:55 --> Session routines successfully run
DEBUG - 2014-01-28 19:50:55 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:50:55 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:50:55 --> Final output sent to browser
DEBUG - 2014-01-28 19:50:55 --> Total execution time: 0.0110
DEBUG - 2014-01-28 19:51:21 --> Config Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:51:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:51:21 --> URI Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Router Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Output Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Security Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Input Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:51:21 --> Language Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Loader Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Controller Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:51:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:51:21 --> Model Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Model Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Model Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:51:21 --> Session Class Initialized
DEBUG - 2014-01-28 19:51:21 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:51:21 --> Session routines successfully run
DEBUG - 2014-01-28 19:51:21 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:41 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:41 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:41 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:41 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:41 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:41 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:41 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:41 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:41 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:41 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:41 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:41 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:41 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:41 --> Total execution time: 0.0180
DEBUG - 2014-01-28 19:52:42 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:42 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:42 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:42 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:42 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:42 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:42 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:42 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:42 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:42 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:42 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:42 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:42 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:42 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:42 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:42 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:52:43 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:43 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:43 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:43 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:43 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:43 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:43 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:43 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:43 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:43 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:43 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:43 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:43 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:43 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:52:49 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:49 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:49 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:49 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:49 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:49 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:49 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:49 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:49 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:49 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:49 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:49 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:49 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:49 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:49 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:49 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:52:50 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:50 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:50 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:50 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:50 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:50 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:50 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:50 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:50 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:50 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:50 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:50 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:50 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:50 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:50 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:50 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:52:53 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:53 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:53 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:53 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:53 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:53 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:53 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:53 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:53 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:53 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:53 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:53 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:53 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:53 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:52:54 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:54 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:54 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:54 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:54 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:54 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:54 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:54 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:54 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:54 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:54 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:54 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:54 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:54 --> Total execution time: 0.0110
DEBUG - 2014-01-28 19:52:57 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:57 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:57 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:57 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:57 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:57 --> Config Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:52:57 --> URI Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Router Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Output Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Security Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Input Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:52:57 --> Language Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Loader Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Controller Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:52:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Model Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:52:57 --> Session Class Initialized
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:52:57 --> Session routines successfully run
DEBUG - 2014-01-28 19:52:57 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:52:57 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:52:57 --> Final output sent to browser
DEBUG - 2014-01-28 19:52:57 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:53:00 --> Config Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:53:00 --> URI Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Router Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Output Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Security Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Input Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:53:00 --> Language Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Loader Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Controller Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:53:00 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:53:00 --> Session Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:53:00 --> Session routines successfully run
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:53:00 --> Config Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:53:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:53:00 --> URI Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Router Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Output Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Security Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Input Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:53:00 --> Language Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Loader Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Controller Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:53:00 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:53:00 --> Session Class Initialized
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:53:00 --> Session routines successfully run
DEBUG - 2014-01-28 19:53:00 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:53:00 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:53:00 --> Final output sent to browser
DEBUG - 2014-01-28 19:53:00 --> Total execution time: 0.0100
DEBUG - 2014-01-28 19:53:09 --> Config Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:53:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:53:09 --> URI Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Router Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Output Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Security Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Input Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:53:09 --> Language Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Loader Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Controller Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:53:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:53:09 --> Session Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:53:09 --> Session routines successfully run
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:53:09 --> Config Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:53:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:53:09 --> URI Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Router Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Output Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Security Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Input Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:53:09 --> Language Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Loader Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Controller Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:53:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:53:09 --> Session Class Initialized
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: string_helper
DEBUG - 2014-01-28 19:53:09 --> Session routines successfully run
DEBUG - 2014-01-28 19:53:09 --> Helper loaded: url_helper
DEBUG - 2014-01-28 19:53:09 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 19:53:09 --> Final output sent to browser
DEBUG - 2014-01-28 19:53:09 --> Total execution time: 0.0090
DEBUG - 2014-01-28 19:53:31 --> Config Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Hooks Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Utf8 Class Initialized
DEBUG - 2014-01-28 19:53:31 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 19:53:31 --> URI Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Router Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Output Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Security Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Input Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 19:53:31 --> Language Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Loader Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Controller Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 19:53:31 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 19:53:31 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Database Driver Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Helper loaded: email_helper
DEBUG - 2014-01-28 19:53:31 --> Model Class Initialized
DEBUG - 2014-01-28 19:53:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 19:53:37 --> Final output sent to browser
DEBUG - 2014-01-28 19:53:37 --> Total execution time: 6.2944
DEBUG - 2014-01-28 20:02:17 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:17 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:17 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:17 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:17 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:17 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:17 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:17 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:17 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:17 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:17 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:17 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:17 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:17 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 20:02:17 --> Final output sent to browser
DEBUG - 2014-01-28 20:02:17 --> Total execution time: 0.0170
DEBUG - 2014-01-28 20:02:39 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:39 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:39 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:39 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:39 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:39 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:39 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:39 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:39 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:39 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:39 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:39 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:39 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:39 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 20:02:39 --> Final output sent to browser
DEBUG - 2014-01-28 20:02:39 --> Total execution time: 0.0150
DEBUG - 2014-01-28 20:02:45 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:45 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:45 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:45 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:45 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:45 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:45 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:45 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:45 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:45 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:45 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:45 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:45 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:45 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 20:02:45 --> Final output sent to browser
DEBUG - 2014-01-28 20:02:45 --> Total execution time: 0.0090
DEBUG - 2014-01-28 20:02:54 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:54 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:54 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:54 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:54 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:54 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:54 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:54 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:54 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:54 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:54 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:54 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:54 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:54 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:54 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:54 --> Helper loaded: url_helper
ERROR - 2014-01-28 20:02:54 --> 404 Page Not Found --> admin/dashboard
DEBUG - 2014-01-28 20:02:58 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:58 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:58 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:58 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:58 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:58 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:58 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:58 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:58 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:58 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:02:58 --> Config Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:02:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:02:58 --> URI Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Router Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Output Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Security Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Input Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:02:58 --> Language Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Loader Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Controller Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Model Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:02:58 --> Session Class Initialized
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:02:58 --> Session routines successfully run
DEBUG - 2014-01-28 20:02:58 --> Helper loaded: url_helper
ERROR - 2014-01-28 20:02:58 --> 404 Page Not Found --> admin/dashboard
DEBUG - 2014-01-28 20:06:21 --> Config Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:06:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:06:21 --> URI Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Router Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Output Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Security Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Input Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:06:21 --> Language Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Loader Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Controller Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:06:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:06:21 --> Model Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Model Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Model Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:06:21 --> Session Class Initialized
DEBUG - 2014-01-28 20:06:21 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:06:21 --> Session routines successfully run
DEBUG - 2014-01-28 20:06:21 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:06:21 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 20:06:21 --> Final output sent to browser
DEBUG - 2014-01-28 20:06:21 --> Total execution time: 0.0140
DEBUG - 2014-01-28 20:06:22 --> Config Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Hooks Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Utf8 Class Initialized
DEBUG - 2014-01-28 20:06:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 20:06:22 --> URI Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Router Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Output Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Security Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Input Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 20:06:22 --> Language Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Loader Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Controller Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 20:06:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 20:06:22 --> Model Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Model Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Database Driver Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Model Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 20:06:22 --> Session Class Initialized
DEBUG - 2014-01-28 20:06:22 --> Helper loaded: string_helper
DEBUG - 2014-01-28 20:06:22 --> Session routines successfully run
DEBUG - 2014-01-28 20:06:22 --> Helper loaded: url_helper
DEBUG - 2014-01-28 20:06:22 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 20:06:22 --> Final output sent to browser
DEBUG - 2014-01-28 20:06:22 --> Total execution time: 0.0190
DEBUG - 2014-01-28 21:26:01 --> Config Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:26:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:26:01 --> URI Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Router Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Output Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Security Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Input Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:26:01 --> Language Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Loader Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Controller Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:26:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:26:01 --> Model Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Model Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Model Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:26:01 --> Session Class Initialized
DEBUG - 2014-01-28 21:26:01 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:26:01 --> Session routines successfully run
DEBUG - 2014-01-28 21:26:01 --> Helper loaded: url_helper
ERROR - 2014-01-28 21:26:01 --> Severity: Notice  --> Undefined variable: page_title F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\common\header.php 7
ERROR - 2014-01-28 21:26:01 --> Severity: Notice  --> Undefined variable: session F:\ZServer61\Apache2\htdocs\mantrackr_service\application\views\admin\common\header.php 67
DEBUG - 2014-01-28 21:26:01 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:26:01 --> Final output sent to browser
DEBUG - 2014-01-28 21:26:01 --> Total execution time: 0.0240
DEBUG - 2014-01-28 21:28:41 --> Config Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:28:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:28:41 --> URI Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Router Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Output Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Security Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Input Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:28:41 --> Language Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Loader Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Controller Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:28:41 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:28:41 --> Model Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Model Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Model Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:28:41 --> Session Class Initialized
DEBUG - 2014-01-28 21:28:41 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:28:41 --> Session routines successfully run
DEBUG - 2014-01-28 21:28:41 --> Helper loaded: url_helper
ERROR - 2014-01-28 21:28:41 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in F:\ZServer61\Apache2\htdocs\mantrackr_service\application\controllers\admin.php on line 79 and defined F:\ZServer61\Apache2\htdocs\mantrackr_service\system\libraries\Session.php 431
ERROR - 2014-01-28 21:28:41 --> Severity: Notice  --> Undefined variable: item F:\ZServer61\Apache2\htdocs\mantrackr_service\system\libraries\Session.php 433
DEBUG - 2014-01-28 21:28:41 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:28:41 --> Final output sent to browser
DEBUG - 2014-01-28 21:28:41 --> Total execution time: 0.0180
DEBUG - 2014-01-28 21:30:33 --> Config Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:30:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:30:33 --> URI Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Router Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Output Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Security Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Input Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:30:33 --> Language Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Loader Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Controller Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:30:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:30:33 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:30:33 --> Session Class Initialized
DEBUG - 2014-01-28 21:30:33 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:30:33 --> Session routines successfully run
DEBUG - 2014-01-28 21:30:33 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:30:34 --> Config Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:30:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:30:34 --> URI Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Router Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Output Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Security Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Input Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:30:34 --> Language Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Loader Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Controller Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:30:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:30:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:30:34 --> Session Class Initialized
DEBUG - 2014-01-28 21:30:34 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:30:34 --> Session routines successfully run
DEBUG - 2014-01-28 21:30:34 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:30:50 --> Config Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:30:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:30:50 --> URI Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Router Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Output Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Security Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Input Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:30:50 --> Language Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Loader Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Controller Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:30:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:30:50 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Model Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:30:50 --> Session Class Initialized
DEBUG - 2014-01-28 21:30:50 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:30:50 --> Session routines successfully run
DEBUG - 2014-01-28 21:30:50 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:30:50 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:30:50 --> Final output sent to browser
DEBUG - 2014-01-28 21:30:50 --> Total execution time: 0.0170
DEBUG - 2014-01-28 21:31:12 --> Config Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:31:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:31:12 --> URI Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Router Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Output Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Security Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Input Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:31:12 --> Language Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Loader Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Controller Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:31:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:31:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:12 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:31:13 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:31:13 --> Session Class Initialized
DEBUG - 2014-01-28 21:31:13 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:31:13 --> Session routines successfully run
DEBUG - 2014-01-28 21:31:13 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:31:13 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:31:13 --> Final output sent to browser
DEBUG - 2014-01-28 21:31:13 --> Total execution time: 0.0200
DEBUG - 2014-01-28 21:31:14 --> Config Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:31:14 --> URI Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Router Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Output Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Security Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Input Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:31:14 --> Language Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Loader Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Controller Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:31:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:31:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:31:14 --> Session Class Initialized
DEBUG - 2014-01-28 21:31:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:31:14 --> Session routines successfully run
DEBUG - 2014-01-28 21:31:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:31:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:31:14 --> Final output sent to browser
DEBUG - 2014-01-28 21:31:14 --> Total execution time: 0.0180
DEBUG - 2014-01-28 21:31:29 --> Config Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:31:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:31:29 --> URI Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Router Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Output Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Security Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Input Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:31:29 --> Language Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Loader Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Controller Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:31:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:31:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:31:29 --> Session Class Initialized
DEBUG - 2014-01-28 21:31:29 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:31:29 --> Session routines successfully run
DEBUG - 2014-01-28 21:31:29 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:31:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:31:29 --> Final output sent to browser
DEBUG - 2014-01-28 21:31:29 --> Total execution time: 0.0200
DEBUG - 2014-01-28 21:32:51 --> Config Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:32:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:32:51 --> URI Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Router Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Output Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Security Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Input Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:32:51 --> Language Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Loader Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Controller Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:32:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:32:51 --> Model Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Model Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Model Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:32:51 --> Session Class Initialized
DEBUG - 2014-01-28 21:32:51 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:32:51 --> Session routines successfully run
DEBUG - 2014-01-28 21:32:51 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:32:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:32:51 --> Final output sent to browser
DEBUG - 2014-01-28 21:32:51 --> Total execution time: 0.0130
DEBUG - 2014-01-28 21:32:55 --> Config Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:32:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:32:55 --> URI Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Router Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Output Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Security Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Input Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:32:55 --> Language Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Loader Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Controller Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:32:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:32:55 --> Model Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Model Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Model Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:32:55 --> Session Class Initialized
DEBUG - 2014-01-28 21:32:55 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:32:55 --> Session routines successfully run
DEBUG - 2014-01-28 21:32:55 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:32:55 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:32:55 --> Final output sent to browser
DEBUG - 2014-01-28 21:32:55 --> Total execution time: 0.0170
DEBUG - 2014-01-28 21:33:02 --> Config Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:33:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:33:02 --> URI Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Router Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Output Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Security Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Input Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:33:02 --> Language Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Loader Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Controller Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:33:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:33:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:33:02 --> Session Class Initialized
DEBUG - 2014-01-28 21:33:02 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:33:02 --> Session routines successfully run
DEBUG - 2014-01-28 21:33:02 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:33:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:33:02 --> Final output sent to browser
DEBUG - 2014-01-28 21:33:02 --> Total execution time: 0.0170
DEBUG - 2014-01-28 21:33:20 --> Config Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:33:20 --> URI Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Router Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Output Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Security Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Input Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:33:20 --> Language Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Loader Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Controller Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:33:20 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:33:20 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:33:20 --> Session Class Initialized
DEBUG - 2014-01-28 21:33:20 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:33:20 --> Session routines successfully run
DEBUG - 2014-01-28 21:33:20 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:33:20 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:33:20 --> Final output sent to browser
DEBUG - 2014-01-28 21:33:20 --> Total execution time: 0.0200
DEBUG - 2014-01-28 21:33:22 --> Config Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:33:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:33:22 --> URI Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Router Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Output Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Security Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Input Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:33:22 --> Language Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Loader Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Controller Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:33:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:33:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:33:22 --> Session Class Initialized
DEBUG - 2014-01-28 21:33:22 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:33:22 --> Session routines successfully run
DEBUG - 2014-01-28 21:33:22 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:33:22 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:33:22 --> Final output sent to browser
DEBUG - 2014-01-28 21:33:22 --> Total execution time: 0.0170
DEBUG - 2014-01-28 21:36:01 --> Config Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:36:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:36:01 --> URI Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Router Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Output Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Security Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Input Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:36:01 --> Language Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Loader Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Controller Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:36:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:36:01 --> Model Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Model Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Model Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:36:01 --> Session Class Initialized
DEBUG - 2014-01-28 21:36:01 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:36:01 --> Session routines successfully run
DEBUG - 2014-01-28 21:36:01 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:36:01 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:36:01 --> Final output sent to browser
DEBUG - 2014-01-28 21:36:01 --> Total execution time: 0.0210
DEBUG - 2014-01-28 21:36:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:36:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:36:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:36:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:36:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:36:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:36:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:36:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:36:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:36:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:36:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:36:03 --> Final output sent to browser
DEBUG - 2014-01-28 21:36:03 --> Total execution time: 0.0210
DEBUG - 2014-01-28 21:40:58 --> Config Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:40:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:40:58 --> URI Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Router Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Output Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Security Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Input Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:40:58 --> Language Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Loader Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Controller Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:40:58 --> Model Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Model Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Model Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:40:58 --> Session Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:40:58 --> Session routines successfully run
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:40:58 --> Config Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:40:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:40:58 --> URI Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Router Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Output Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Security Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Input Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:40:58 --> Language Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Loader Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Controller Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:40:58 --> Model Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Model Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Model Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:40:58 --> Session Class Initialized
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:40:58 --> Session routines successfully run
DEBUG - 2014-01-28 21:40:58 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:40:58 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:40:58 --> Final output sent to browser
DEBUG - 2014-01-28 21:40:58 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:41:02 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:02 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:02 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:02 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:02 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:02 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:02 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:03 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:03 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:03 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:41:06 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:06 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:06 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:06 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:06 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:06 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:06 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:06 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:06 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:06 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:06 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:06 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:06 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:06 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:06 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:06 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:06 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:06 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:06 --> Total execution time: 0.0090
DEBUG - 2014-01-28 21:41:09 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:09 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:09 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:09 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:09 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:09 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:09 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:09 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:09 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:10 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:10 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:10 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:10 --> No URI present. Default controller set.
DEBUG - 2014-01-28 21:41:10 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:10 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:10 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:10 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-01-28 21:41:10 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:10 --> Total execution time: 0.0050
DEBUG - 2014-01-28 21:41:12 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:12 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:12 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:12 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:12 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:12 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:12 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:12 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:12 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:12 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:12 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:12 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:12 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:12 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:12 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:41:14 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:14 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:14 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:14 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:14 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:14 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:14 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:14 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:14 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:14 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:14 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:14 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:14 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:41:17 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:17 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:17 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:17 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:17 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:17 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:17 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:17 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:17 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:18 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:18 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:18 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:18 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:18 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:18 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:18 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:18 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:18 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:18 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:18 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:18 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:18 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:18 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:41:21 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:21 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:21 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:21 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:21 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:21 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:21 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:21 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:21 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:21 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:22 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:22 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:22 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:22 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:22 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:22 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:22 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:22 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:22 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:22 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:22 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:22 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:22 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:22 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:22 --> Total execution time: 0.0090
DEBUG - 2014-01-28 21:41:25 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:25 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:25 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:25 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:25 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:25 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:25 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:25 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:26 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:26 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:26 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:26 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:26 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:26 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:26 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:26 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:26 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:26 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:26 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:26 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:26 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:26 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:26 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:26 --> Total execution time: 0.0090
DEBUG - 2014-01-28 21:41:29 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:29 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:29 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:29 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:29 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:29 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:29 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:29 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:29 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:29 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:29 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:29 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:29 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:29 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:29 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:29 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:41:29 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:29 --> Total execution time: 0.0110
DEBUG - 2014-01-28 21:41:34 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:34 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:34 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:34 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:34 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:34 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:34 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:34 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:34 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:34 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:34 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:34 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:41:34 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:34 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:41:35 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:35 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:35 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:35 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:35 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:35 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:35 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:35 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:35 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:35 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:35 --> Config Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:41:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:41:35 --> URI Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Router Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Output Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Security Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Input Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:41:35 --> Language Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Loader Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Controller Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Model Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:41:35 --> Session Class Initialized
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:41:35 --> Session routines successfully run
DEBUG - 2014-01-28 21:41:35 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:41:35 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:41:35 --> Final output sent to browser
DEBUG - 2014-01-28 21:41:35 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:42:15 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:15 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:15 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:15 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:15 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:15 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:15 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:15 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:15 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:15 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:15 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:15 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:15 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:42:15 --> Final output sent to browser
DEBUG - 2014-01-28 21:42:15 --> Total execution time: 0.0110
DEBUG - 2014-01-28 21:42:18 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:18 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:18 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:18 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:18 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:18 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:18 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:18 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:18 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:18 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:18 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:18 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:18 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 21:42:18 --> Final output sent to browser
DEBUG - 2014-01-28 21:42:18 --> Total execution time: 0.0110
DEBUG - 2014-01-28 21:42:23 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:23 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:23 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:23 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:23 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:23 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:23 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:23 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:23 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:23 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:23 --> Config Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:42:23 --> URI Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Router Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Output Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Security Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Input Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:42:23 --> Language Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Loader Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Controller Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:42:23 --> Session Class Initialized
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:42:23 --> Session routines successfully run
DEBUG - 2014-01-28 21:42:23 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:42:23 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:42:23 --> Final output sent to browser
DEBUG - 2014-01-28 21:42:23 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:51:05 --> Config Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:51:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:51:05 --> URI Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Router Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Output Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Security Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Input Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:51:05 --> Language Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Loader Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Controller Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:51:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:51:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:51:05 --> Session Class Initialized
DEBUG - 2014-01-28 21:51:05 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:51:05 --> Session routines successfully run
DEBUG - 2014-01-28 21:51:05 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:51:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:51:05 --> Final output sent to browser
DEBUG - 2014-01-28 21:51:05 --> Total execution time: 0.0200
DEBUG - 2014-01-28 21:53:05 --> Config Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:53:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:53:05 --> URI Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Router Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Output Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Security Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Input Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:53:05 --> Language Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Loader Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Controller Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:53:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:53:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:53:05 --> Session Class Initialized
DEBUG - 2014-01-28 21:53:05 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:53:05 --> Session routines successfully run
DEBUG - 2014-01-28 21:53:05 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:53:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:53:05 --> Final output sent to browser
DEBUG - 2014-01-28 21:53:05 --> Total execution time: 0.0150
DEBUG - 2014-01-28 21:53:23 --> Config Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:53:23 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:53:23 --> URI Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Router Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Output Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Security Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Input Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:53:23 --> Language Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Loader Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Controller Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:53:23 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:53:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:53:23 --> Session Class Initialized
DEBUG - 2014-01-28 21:53:23 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:53:23 --> Session routines successfully run
DEBUG - 2014-01-28 21:53:23 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:53:23 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:53:23 --> Final output sent to browser
DEBUG - 2014-01-28 21:53:23 --> Total execution time: 0.0140
DEBUG - 2014-01-28 21:53:25 --> Config Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:53:25 --> URI Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Router Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Output Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Security Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Input Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:53:25 --> Language Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Loader Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Controller Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:53:25 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:53:25 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:53:25 --> Session Class Initialized
DEBUG - 2014-01-28 21:53:25 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:53:25 --> Session routines successfully run
DEBUG - 2014-01-28 21:53:25 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:53:25 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:53:25 --> Final output sent to browser
DEBUG - 2014-01-28 21:53:25 --> Total execution time: 0.0160
DEBUG - 2014-01-28 21:53:28 --> Config Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:53:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:53:28 --> URI Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Router Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Output Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Security Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Input Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:53:28 --> Language Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Loader Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Controller Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:53:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:53:28 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Model Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:53:28 --> Session Class Initialized
DEBUG - 2014-01-28 21:53:28 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:53:28 --> Session routines successfully run
DEBUG - 2014-01-28 21:53:28 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:53:28 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:53:28 --> Final output sent to browser
DEBUG - 2014-01-28 21:53:28 --> Total execution time: 0.0150
DEBUG - 2014-01-28 21:54:28 --> Config Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:54:28 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:54:28 --> URI Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Router Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Output Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Security Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Input Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:54:28 --> Language Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Loader Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Controller Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:54:28 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:54:28 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:54:28 --> Session Class Initialized
DEBUG - 2014-01-28 21:54:28 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:54:28 --> Session routines successfully run
DEBUG - 2014-01-28 21:54:28 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:54:28 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:54:28 --> Final output sent to browser
DEBUG - 2014-01-28 21:54:28 --> Total execution time: 0.0240
DEBUG - 2014-01-28 21:54:30 --> Config Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:54:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:54:30 --> URI Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Router Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Output Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Security Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Input Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:54:30 --> Language Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Loader Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Controller Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:54:30 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:54:30 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:54:30 --> Session Class Initialized
DEBUG - 2014-01-28 21:54:30 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:54:30 --> Session routines successfully run
DEBUG - 2014-01-28 21:54:30 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:54:30 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:54:30 --> Final output sent to browser
DEBUG - 2014-01-28 21:54:30 --> Total execution time: 0.0110
DEBUG - 2014-01-28 21:54:48 --> Config Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:54:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:54:48 --> URI Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Router Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Output Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Security Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Input Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:54:48 --> Language Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Loader Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Controller Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:54:48 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:54:48 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Model Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:54:48 --> Session Class Initialized
DEBUG - 2014-01-28 21:54:48 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:54:48 --> Session routines successfully run
DEBUG - 2014-01-28 21:54:48 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:54:48 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:54:48 --> Final output sent to browser
DEBUG - 2014-01-28 21:54:48 --> Total execution time: 0.0160
DEBUG - 2014-01-28 21:55:49 --> Config Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:55:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:55:49 --> URI Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Router Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Output Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Security Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Input Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:55:49 --> Language Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Loader Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Controller Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:55:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:55:49 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:55:49 --> Session Class Initialized
DEBUG - 2014-01-28 21:55:49 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:55:49 --> Session routines successfully run
DEBUG - 2014-01-28 21:55:49 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:55:49 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:55:49 --> Final output sent to browser
DEBUG - 2014-01-28 21:55:49 --> Total execution time: 0.0120
DEBUG - 2014-01-28 21:55:59 --> Config Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:55:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:55:59 --> URI Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Router Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Output Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Security Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Input Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:55:59 --> Language Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Loader Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Controller Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:55:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:55:59 --> Session Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:55:59 --> Session routines successfully run
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:55:59 --> Config Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:55:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:55:59 --> URI Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Router Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Output Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Security Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Input Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:55:59 --> Language Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Loader Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Controller Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:55:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:55:59 --> Session Class Initialized
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:55:59 --> Session routines successfully run
DEBUG - 2014-01-28 21:55:59 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:55:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:55:59 --> Final output sent to browser
DEBUG - 2014-01-28 21:55:59 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:56:02 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:02 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:02 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:02 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:02 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:02 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:02 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:02 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:02 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:02 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:02 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:56:02 --> Final output sent to browser
DEBUG - 2014-01-28 21:56:02 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:56:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:56:03 --> Final output sent to browser
DEBUG - 2014-01-28 21:56:03 --> Total execution time: 0.0110
DEBUG - 2014-01-28 21:56:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:03 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:03 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:03 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:03 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:03 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:56:03 --> Final output sent to browser
DEBUG - 2014-01-28 21:56:03 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:56:04 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:04 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:04 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:04 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:04 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:04 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:04 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:04 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:04 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:04 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:04 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:04 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:04 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:04 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:56:04 --> Final output sent to browser
DEBUG - 2014-01-28 21:56:04 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:56:05 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:05 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:05 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:05 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:05 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:05 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:05 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:05 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:05 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:05 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:05 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:05 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:56:05 --> Final output sent to browser
DEBUG - 2014-01-28 21:56:05 --> Total execution time: 0.0100
DEBUG - 2014-01-28 21:56:59 --> Config Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Hooks Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Utf8 Class Initialized
DEBUG - 2014-01-28 21:56:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 21:56:59 --> URI Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Router Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Output Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Security Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Input Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 21:56:59 --> Language Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Loader Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Controller Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 21:56:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 21:56:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Database Driver Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Model Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 21:56:59 --> Session Class Initialized
DEBUG - 2014-01-28 21:56:59 --> Helper loaded: string_helper
DEBUG - 2014-01-28 21:56:59 --> Session routines successfully run
DEBUG - 2014-01-28 21:56:59 --> Helper loaded: url_helper
DEBUG - 2014-01-28 21:56:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 21:56:59 --> Final output sent to browser
DEBUG - 2014-01-28 21:56:59 --> Total execution time: 0.0140
DEBUG - 2014-01-28 22:35:29 --> Config Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:35:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:35:29 --> URI Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Router Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Output Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Security Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Input Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:35:29 --> Language Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Loader Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Controller Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:35:29 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:35:29 --> Model Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Model Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Model Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:35:29 --> Session Class Initialized
DEBUG - 2014-01-28 22:35:29 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:35:29 --> Session routines successfully run
DEBUG - 2014-01-28 22:35:29 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:35:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:35:29 --> Final output sent to browser
DEBUG - 2014-01-28 22:35:29 --> Total execution time: 0.0140
DEBUG - 2014-01-28 22:37:40 --> Config Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:37:40 --> URI Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Router Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Output Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Security Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Input Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:37:40 --> Language Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Loader Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Controller Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:37:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:37:40 --> Model Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Model Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Model Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:37:40 --> Session Class Initialized
DEBUG - 2014-01-28 22:37:40 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:37:40 --> Session routines successfully run
DEBUG - 2014-01-28 22:37:40 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:37:40 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:37:40 --> Final output sent to browser
DEBUG - 2014-01-28 22:37:40 --> Total execution time: 0.0190
DEBUG - 2014-01-28 22:38:34 --> Config Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:38:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:38:34 --> URI Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Router Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Output Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Security Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Input Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:38:34 --> Language Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Loader Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Controller Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:38:34 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:38:34 --> Model Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Model Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Model Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:38:34 --> Session Class Initialized
DEBUG - 2014-01-28 22:38:34 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:38:34 --> Session routines successfully run
DEBUG - 2014-01-28 22:38:34 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:38:34 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:38:34 --> Final output sent to browser
DEBUG - 2014-01-28 22:38:34 --> Total execution time: 0.0170
DEBUG - 2014-01-28 22:43:11 --> Config Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:43:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:43:11 --> URI Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Router Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Output Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Security Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Input Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:43:11 --> Language Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Loader Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Controller Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:43:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:43:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:43:11 --> Session Class Initialized
DEBUG - 2014-01-28 22:43:11 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:43:11 --> Session routines successfully run
DEBUG - 2014-01-28 22:43:11 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:43:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:43:11 --> Final output sent to browser
DEBUG - 2014-01-28 22:43:11 --> Total execution time: 0.0120
DEBUG - 2014-01-28 22:45:19 --> Config Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:45:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:45:19 --> URI Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Router Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Output Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Security Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Input Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:45:19 --> Language Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Loader Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Controller Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:45:19 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:45:19 --> Model Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Model Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Model Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:45:19 --> Session Class Initialized
DEBUG - 2014-01-28 22:45:19 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:45:19 --> Session routines successfully run
DEBUG - 2014-01-28 22:45:19 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:45:19 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:45:19 --> Final output sent to browser
DEBUG - 2014-01-28 22:45:19 --> Total execution time: 0.0140
DEBUG - 2014-01-28 22:45:40 --> Config Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:45:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:45:40 --> URI Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Router Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Output Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Security Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Input Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:45:40 --> Language Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Loader Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Controller Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:45:40 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:45:40 --> Model Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Model Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Model Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:45:40 --> Session Class Initialized
DEBUG - 2014-01-28 22:45:40 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:45:40 --> Session routines successfully run
DEBUG - 2014-01-28 22:45:40 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:45:40 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:45:40 --> Final output sent to browser
DEBUG - 2014-01-28 22:45:40 --> Total execution time: 0.0210
DEBUG - 2014-01-28 22:50:33 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:33 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:33 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:33 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:33 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:33 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:33 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:33 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:33 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:33 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:33 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:33 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:33 --> Total execution time: 0.0170
DEBUG - 2014-01-28 22:50:44 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:44 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:44 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:44 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:44 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:44 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:44 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:44 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:44 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:44 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:44 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:44 --> Total execution time: 0.0220
DEBUG - 2014-01-28 22:50:45 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:45 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:45 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:45 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:45 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:45 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:45 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:45 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:45 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:45 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:45 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:45 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:45 --> Total execution time: 0.0160
DEBUG - 2014-01-28 22:50:47 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:47 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:47 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:47 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:47 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:47 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:47 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:47 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:47 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:47 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:47 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:47 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:47 --> Total execution time: 0.0210
DEBUG - 2014-01-28 22:50:49 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:49 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:49 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:49 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:49 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:49 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:49 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:49 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:49 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:49 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:49 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:49 --> Total execution time: 0.0180
DEBUG - 2014-01-28 22:50:51 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:51 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:51 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:51 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:51 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:51 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:51 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:51 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:51 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:51 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:51 --> Total execution time: 0.0160
DEBUG - 2014-01-28 22:50:52 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:52 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:52 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:52 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:52 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:52 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:52 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:52 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:52 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:52 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:52 --> Total execution time: 0.0130
DEBUG - 2014-01-28 22:50:57 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:57 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:57 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:57 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:57 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:57 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:57 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:57 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:57 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:57 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:57 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:57 --> Total execution time: 0.0160
DEBUG - 2014-01-28 22:50:58 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:58 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:58 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:58 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:58 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:58 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:58 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:58 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:58 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:58 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:58 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:58 --> Total execution time: 0.0150
DEBUG - 2014-01-28 22:50:59 --> Config Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:50:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:50:59 --> URI Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Router Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Output Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Security Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Input Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:50:59 --> Language Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Loader Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Controller Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:50:59 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:50:59 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Model Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:50:59 --> Session Class Initialized
DEBUG - 2014-01-28 22:50:59 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:50:59 --> Session routines successfully run
DEBUG - 2014-01-28 22:50:59 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:50:59 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:50:59 --> Final output sent to browser
DEBUG - 2014-01-28 22:50:59 --> Total execution time: 0.0130
DEBUG - 2014-01-28 22:51:00 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:00 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:00 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:00 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:00 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:00 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:00 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:00 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:00 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:00 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:00 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:00 --> Total execution time: 0.0120
DEBUG - 2014-01-28 22:51:01 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:01 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:01 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:01 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:01 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:01 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:01 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:01 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:01 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:01 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:01 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:01 --> Total execution time: 0.0120
DEBUG - 2014-01-28 22:51:02 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:02 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:02 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:02 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:02 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:02 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:02 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:02 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:02 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:02 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:02 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:02 --> Total execution time: 0.0120
DEBUG - 2014-01-28 22:51:03 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:03 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:03 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:03 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:03 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:03 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:03 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:03 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:03 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:03 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:03 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:03 --> Total execution time: 0.0180
DEBUG - 2014-01-28 22:51:04 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:04 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:04 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:04 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:04 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:04 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:04 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:04 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:04 --> Total execution time: 0.0120
DEBUG - 2014-01-28 22:51:04 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:04 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:04 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:04 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:04 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:04 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:04 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:04 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:04 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:04 --> Total execution time: 0.0180
DEBUG - 2014-01-28 22:51:06 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:06 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:06 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:06 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:06 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:06 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:06 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:06 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:06 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:06 --> Total execution time: 0.0170
DEBUG - 2014-01-28 22:51:11 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:11 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:11 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:11 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:11 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:11 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:11 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:11 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:11 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:11 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:11 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:11 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:11 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:11 --> Total execution time: 0.0110
DEBUG - 2014-01-28 22:51:14 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:14 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:14 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:14 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:14 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:14 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:14 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:14 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:14 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:14 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:14 --> File loaded: application/views/admin/login.php
DEBUG - 2014-01-28 22:51:14 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:14 --> Total execution time: 0.0100
DEBUG - 2014-01-28 22:51:15 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:15 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:15 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:15 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:15 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:15 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:15 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:15 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:15 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:15 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:15 --> Config Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:51:15 --> URI Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Router Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Output Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Security Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Input Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:51:15 --> Language Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Loader Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Controller Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Model Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:51:15 --> Session Class Initialized
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:51:15 --> Session routines successfully run
DEBUG - 2014-01-28 22:51:15 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:51:15 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:51:15 --> Final output sent to browser
DEBUG - 2014-01-28 22:51:15 --> Total execution time: 0.0100
DEBUG - 2014-01-28 22:53:14 --> Config Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Hooks Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Utf8 Class Initialized
DEBUG - 2014-01-28 22:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 22:53:14 --> URI Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Router Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Output Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Security Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Input Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 22:53:14 --> Language Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Loader Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Controller Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 22:53:14 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 22:53:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Database Driver Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Model Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 22:53:14 --> Session Class Initialized
DEBUG - 2014-01-28 22:53:14 --> Helper loaded: string_helper
DEBUG - 2014-01-28 22:53:14 --> Session routines successfully run
DEBUG - 2014-01-28 22:53:14 --> Helper loaded: url_helper
DEBUG - 2014-01-28 22:53:14 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 22:53:14 --> Final output sent to browser
DEBUG - 2014-01-28 22:53:14 --> Total execution time: 0.0200
DEBUG - 2014-01-28 23:40:32 --> Config Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Hooks Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Utf8 Class Initialized
DEBUG - 2014-01-28 23:40:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 23:40:32 --> URI Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Router Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Output Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Security Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Input Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 23:40:32 --> Language Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Loader Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Controller Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 23:40:32 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 23:40:32 --> Model Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Model Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Database Driver Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Model Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 23:40:32 --> Session Class Initialized
DEBUG - 2014-01-28 23:40:32 --> Helper loaded: string_helper
DEBUG - 2014-01-28 23:40:32 --> Session routines successfully run
DEBUG - 2014-01-28 23:40:32 --> Helper loaded: url_helper
DEBUG - 2014-01-28 23:40:32 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 23:40:32 --> Final output sent to browser
DEBUG - 2014-01-28 23:40:32 --> Total execution time: 0.0210
DEBUG - 2014-01-28 23:54:55 --> Config Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Hooks Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Utf8 Class Initialized
DEBUG - 2014-01-28 23:54:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 23:54:55 --> URI Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Router Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Output Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Security Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Input Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 23:54:55 --> Language Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Loader Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Controller Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 23:54:55 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 23:54:55 --> Model Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Model Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Database Driver Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Model Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 23:54:55 --> Session Class Initialized
DEBUG - 2014-01-28 23:54:55 --> Helper loaded: string_helper
DEBUG - 2014-01-28 23:54:55 --> Session routines successfully run
DEBUG - 2014-01-28 23:54:55 --> Helper loaded: url_helper
DEBUG - 2014-01-28 23:54:55 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 23:54:55 --> Final output sent to browser
DEBUG - 2014-01-28 23:54:55 --> Total execution time: 0.0130
DEBUG - 2014-01-28 23:56:50 --> Config Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Hooks Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Utf8 Class Initialized
DEBUG - 2014-01-28 23:56:50 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 23:56:50 --> URI Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Router Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Output Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Security Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Input Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 23:56:50 --> Language Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Loader Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Controller Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 23:56:50 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 23:56:50 --> Model Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Model Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Database Driver Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Model Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 23:56:50 --> Session Class Initialized
DEBUG - 2014-01-28 23:56:50 --> Helper loaded: string_helper
DEBUG - 2014-01-28 23:56:50 --> Session routines successfully run
DEBUG - 2014-01-28 23:56:50 --> Helper loaded: url_helper
DEBUG - 2014-01-28 23:56:50 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 23:56:50 --> Final output sent to browser
DEBUG - 2014-01-28 23:56:50 --> Total execution time: 0.0120
DEBUG - 2014-01-28 23:57:08 --> Config Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Hooks Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Utf8 Class Initialized
DEBUG - 2014-01-28 23:57:08 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 23:57:08 --> URI Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Router Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Output Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Security Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Input Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 23:57:08 --> Language Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Loader Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Controller Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 23:57:08 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 23:57:08 --> Model Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Model Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Database Driver Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Model Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 23:57:08 --> Session Class Initialized
DEBUG - 2014-01-28 23:57:08 --> Helper loaded: string_helper
DEBUG - 2014-01-28 23:57:08 --> Session routines successfully run
DEBUG - 2014-01-28 23:57:08 --> Helper loaded: url_helper
DEBUG - 2014-01-28 23:57:08 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 23:57:08 --> Final output sent to browser
DEBUG - 2014-01-28 23:57:08 --> Total execution time: 0.0110
DEBUG - 2014-01-28 23:59:06 --> Config Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Hooks Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Utf8 Class Initialized
DEBUG - 2014-01-28 23:59:06 --> UTF-8 Support Enabled
DEBUG - 2014-01-28 23:59:06 --> URI Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Router Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Output Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Security Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Input Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-28 23:59:06 --> Language Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Loader Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Controller Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-01-28 23:59:06 --> Helper loaded: utilities_helper
DEBUG - 2014-01-28 23:59:06 --> Model Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Model Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Database Driver Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Model Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-01-28 23:59:06 --> Session Class Initialized
DEBUG - 2014-01-28 23:59:06 --> Helper loaded: string_helper
DEBUG - 2014-01-28 23:59:06 --> Session routines successfully run
DEBUG - 2014-01-28 23:59:06 --> Helper loaded: url_helper
DEBUG - 2014-01-28 23:59:06 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-01-28 23:59:06 --> Final output sent to browser
DEBUG - 2014-01-28 23:59:06 --> Total execution time: 0.0120
