<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-05-09 00:13:34 --> Config Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:13:34 --> Config Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:13:34 --> URI Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:13:34 --> URI Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Router Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Config Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Output Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Router Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Security Class Initialized
DEBUG - 2014-05-09 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:13:34 --> URI Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Router Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Input Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:13:34 --> Language Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Output Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Output Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Security Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Input Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:13:34 --> Language Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Security Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Input Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:13:34 --> Language Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Loader Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Controller Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:13:34 --> Loader Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Controller Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:13:34 --> Loader Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Controller Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:34 --> Session Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Session Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Session Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:13:34 --> A session cookie was not found.
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:13:34 --> Session routines successfully run
DEBUG - 2014-05-09 00:13:34 --> A session cookie was not found.
DEBUG - 2014-05-09 00:13:34 --> A session cookie was not found.
DEBUG - 2014-05-09 00:13:34 --> Session routines successfully run
DEBUG - 2014-05-09 00:13:34 --> Session routines successfully run
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:13:34 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:34 --> Final output sent to browser
DEBUG - 2014-05-09 00:13:34 --> Final output sent to browser
DEBUG - 2014-05-09 00:13:34 --> Total execution time: 0.0639
DEBUG - 2014-05-09 00:13:34 --> Total execution time: 0.0634
DEBUG - 2014-05-09 00:13:34 --> Final output sent to browser
DEBUG - 2014-05-09 00:13:34 --> Total execution time: 0.0672
DEBUG - 2014-05-09 00:13:34 --> Config Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:13:34 --> URI Class Initialized
DEBUG - 2014-05-09 00:13:34 --> Router Class Initialized
ERROR - 2014-05-09 00:13:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 00:13:35 --> Config Class Initialized
DEBUG - 2014-05-09 00:13:35 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:13:35 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:13:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:13:35 --> URI Class Initialized
DEBUG - 2014-05-09 00:13:35 --> Router Class Initialized
ERROR - 2014-05-09 00:13:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 00:13:56 --> Config Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:13:56 --> URI Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Router Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Output Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Security Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Input Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:13:56 --> Language Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Loader Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Controller Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:13:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:13:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:13:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:13:56 --> Final output sent to browser
DEBUG - 2014-05-09 00:13:56 --> Total execution time: 0.0214
DEBUG - 2014-05-09 00:14:07 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:07 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:07 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:07 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:07 --> Total execution time: 0.0188
DEBUG - 2014-05-09 00:14:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:16 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:16 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:16 --> Total execution time: 0.0408
DEBUG - 2014-05-09 00:14:24 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:24 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:24 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:24 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:24 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:24 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:24 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:24 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:24 --> Total execution time: 0.0355
DEBUG - 2014-05-09 00:14:29 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:29 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:29 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:29 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:29 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:29 --> Total execution time: 0.0159
DEBUG - 2014-05-09 00:14:35 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:35 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:35 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:35 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:35 --> Total execution time: 0.0345
DEBUG - 2014-05-09 00:14:39 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:39 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:39 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:39 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:39 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:39 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:39 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Session Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:14:39 --> Session routines successfully run
DEBUG - 2014-05-09 00:14:39 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:14:39 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:39 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:39 --> Total execution time: 0.0197
DEBUG - 2014-05-09 00:14:40 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:40 --> Session Class Initialized
DEBUG - 2014-05-09 00:14:40 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:14:40 --> Session routines successfully run
DEBUG - 2014-05-09 00:14:40 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:14:40 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:40 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:40 --> Session Class Initialized
DEBUG - 2014-05-09 00:14:40 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:14:40 --> Session routines successfully run
DEBUG - 2014-05-09 00:14:40 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:14:40 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:40 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:40 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:40 --> Total execution time: 0.0175
DEBUG - 2014-05-09 00:14:40 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:40 --> Total execution time: 0.0197
DEBUG - 2014-05-09 00:14:45 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:45 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:45 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:45 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:45 --> Router Class Initialized
ERROR - 2014-05-09 00:14:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 00:14:54 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:54 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:54 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:54 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:54 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Config Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:14:54 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:14:54 --> URI Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Router Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Output Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Security Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Input Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:14:54 --> Language Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Loader Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Controller Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:54 --> Session Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:14:54 --> A session cookie was not found.
DEBUG - 2014-05-09 00:14:54 --> Session routines successfully run
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:54 --> Session Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:14:54 --> A session cookie was not found.
DEBUG - 2014-05-09 00:14:54 --> Session routines successfully run
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:54 --> Total execution time: 0.0153
DEBUG - 2014-05-09 00:14:54 --> Session Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:14:54 --> A session cookie was not found.
DEBUG - 2014-05-09 00:14:54 --> Session routines successfully run
DEBUG - 2014-05-09 00:14:54 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:14:54 --> Model Class Initialized
DEBUG - 2014-05-09 00:14:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:14:54 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:54 --> Total execution time: 0.0150
DEBUG - 2014-05-09 00:14:54 --> Final output sent to browser
DEBUG - 2014-05-09 00:14:54 --> Total execution time: 0.0308
DEBUG - 2014-05-09 00:15:02 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:02 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Output Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Security Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Input Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:15:02 --> Language Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Loader Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Controller Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:15:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:15:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:02 --> Final output sent to browser
DEBUG - 2014-05-09 00:15:02 --> Total execution time: 0.0177
DEBUG - 2014-05-09 00:15:14 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:14 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:14 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Output Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Security Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Input Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:15:14 --> Language Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Loader Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Controller Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:15:14 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:15:14 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Helper loaded: email_helper
DEBUG - 2014-05-09 00:15:14 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:14 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:14 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:14 --> Final output sent to browser
DEBUG - 2014-05-09 00:15:14 --> Total execution time: 0.3802
DEBUG - 2014-05-09 00:15:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Output Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Security Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Input Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:15:16 --> Language Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Loader Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Controller Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Output Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Security Class Initialized
DEBUG - 2014-05-09 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:16 --> Input Class Initialized
DEBUG - 2014-05-09 00:15:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:15:16 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Language Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Output Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Security Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Loader Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Input Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Controller Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:15:16 --> Session Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Language Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:15:16 --> A session cookie was not found.
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Session routines successfully run
DEBUG - 2014-05-09 00:15:16 --> Loader Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:15:16 --> Controller Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Router Class Initialized
ERROR - 2014-05-09 00:15:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 00:15:16 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Final output sent to browser
DEBUG - 2014-05-09 00:15:16 --> Total execution time: 0.0148
DEBUG - 2014-05-09 00:15:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
ERROR - 2014-05-09 00:15:16 --> 404 Page Not Found --> apple-touch-icon-precomposed.png
DEBUG - 2014-05-09 00:15:16 --> Session Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:15:16 --> A session cookie was not found.
DEBUG - 2014-05-09 00:15:16 --> Session routines successfully run
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:16 --> Session Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:15:16 --> A session cookie was not found.
DEBUG - 2014-05-09 00:15:16 --> Session routines successfully run
DEBUG - 2014-05-09 00:15:16 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:15:16 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Final output sent to browser
DEBUG - 2014-05-09 00:15:16 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:16 --> Total execution time: 0.0159
DEBUG - 2014-05-09 00:15:16 --> Final output sent to browser
DEBUG - 2014-05-09 00:15:16 --> Total execution time: 0.0186
DEBUG - 2014-05-09 00:15:16 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:16 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:16 --> Router Class Initialized
ERROR - 2014-05-09 00:15:16 --> 404 Page Not Found --> apple-touch-icon.png
DEBUG - 2014-05-09 00:15:42 --> Config Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:15:42 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:15:42 --> URI Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Router Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Output Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Security Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Input Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:15:42 --> Language Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Loader Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Controller Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:15:42 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:15:42 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Model Class Initialized
DEBUG - 2014-05-09 00:15:42 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:15:42 --> Final output sent to browser
DEBUG - 2014-05-09 00:15:42 --> Total execution time: 0.0145
DEBUG - 2014-05-09 00:16:04 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:04 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:04 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:04 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:04 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:04 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:04 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:04 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:04 --> Total execution time: 0.0182
DEBUG - 2014-05-09 00:16:06 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:06 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:06 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:06 --> Image Lib Class Initialized
DEBUG - 2014-05-09 00:16:07 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:07 --> Total execution time: 0.2060
DEBUG - 2014-05-09 00:16:08 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:08 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:08 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:08 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:08 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:08 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:08 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:08 --> Total execution time: 0.0132
DEBUG - 2014-05-09 00:16:09 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:09 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:09 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:09 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:09 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:09 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:09 --> Total execution time: 0.0238
DEBUG - 2014-05-09 00:16:11 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:11 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:11 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:11 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:11 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:11 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:11 --> Image Lib Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:11 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:11 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:11 --> Total execution time: 0.2375
DEBUG - 2014-05-09 00:16:13 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:13 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:13 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:13 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:13 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:13 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:13 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:13 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:13 --> Total execution time: 0.2087
DEBUG - 2014-05-09 00:16:17 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:17 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:17 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:17 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:17 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:17 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:17 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:17 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:17 --> Total execution time: 0.0304
DEBUG - 2014-05-09 00:16:27 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:27 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:27 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:27 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:27 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:27 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:27 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:27 --> Total execution time: 0.0137
DEBUG - 2014-05-09 00:16:33 --> Config Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:16:33 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:16:33 --> URI Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Router Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Output Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Security Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Input Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:16:33 --> Language Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Loader Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Controller Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:16:33 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:16:33 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Helper loaded: email_helper
DEBUG - 2014-05-09 00:16:33 --> Model Class Initialized
DEBUG - 2014-05-09 00:16:33 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:16:33 --> Final output sent to browser
DEBUG - 2014-05-09 00:16:33 --> Total execution time: 0.0163
DEBUG - 2014-05-09 00:17:02 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:02 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:02 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:02 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Helper loaded: email_helper
DEBUG - 2014-05-09 00:17:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:02 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:02 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:02 --> Total execution time: 0.4858
DEBUG - 2014-05-09 00:17:38 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:38 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:38 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:38 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:38 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Image Lib Class Initialized
DEBUG - 2014-05-09 00:17:38 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:38 --> Total execution time: 0.0934
DEBUG - 2014-05-09 00:17:41 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:41 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:41 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:41 --> Image Lib Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:41 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:41 --> Total execution time: 0.1946
DEBUG - 2014-05-09 00:17:41 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:41 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:41 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:42 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:42 --> Total execution time: 0.1912
DEBUG - 2014-05-09 00:17:56 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:56 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Config Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:56 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:17:56 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:56 --> URI Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:56 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:56 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:56 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:56 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Router Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Output Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Security Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Input Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:17:56 --> Language Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Loader Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Controller Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:56 --> Session Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:17:56 --> Session routines successfully run
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:56 --> Session Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:17:56 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:56 --> Total execution time: 0.0146
DEBUG - 2014-05-09 00:17:56 --> Session routines successfully run
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:56 --> Session Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:17:56 --> Session routines successfully run
DEBUG - 2014-05-09 00:17:56 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:17:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:17:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:17:56 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:56 --> Total execution time: 0.0197
DEBUG - 2014-05-09 00:17:56 --> Final output sent to browser
DEBUG - 2014-05-09 00:17:56 --> Total execution time: 0.0201
DEBUG - 2014-05-09 00:18:05 --> Config Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:18:05 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:18:05 --> URI Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Router Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Output Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Security Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Input Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:18:05 --> Language Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Loader Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Controller Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:18:05 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:18:05 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:05 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:18:05 --> Final output sent to browser
DEBUG - 2014-05-09 00:18:05 --> Total execution time: 0.0149
DEBUG - 2014-05-09 00:18:07 --> Config Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:18:07 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:18:07 --> URI Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Router Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Output Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Security Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Input Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:18:07 --> Language Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Loader Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Controller Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:18:07 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:18:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:18:07 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:18:07 --> Final output sent to browser
DEBUG - 2014-05-09 00:18:07 --> Total execution time: 0.0273
DEBUG - 2014-05-09 00:18:21 --> Config Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:18:21 --> URI Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Router Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Output Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Security Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Input Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:18:21 --> Language Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Loader Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Controller Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:18:21 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:18:21 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Helper loaded: email_helper
DEBUG - 2014-05-09 00:18:21 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:18:21 --> Model Class Initialized
DEBUG - 2014-05-09 00:18:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:18:21 --> Final output sent to browser
DEBUG - 2014-05-09 00:18:21 --> Total execution time: 0.4023
DEBUG - 2014-05-09 00:20:35 --> Config Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:20:35 --> URI Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Router Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Output Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Security Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Input Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:20:35 --> Language Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Loader Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Controller Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:35 --> Session Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:20:35 --> A session cookie was not found.
DEBUG - 2014-05-09 00:20:35 --> Session routines successfully run
DEBUG - 2014-05-09 00:20:35 --> Config Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:20:35 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> URI Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:35 --> Router Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Output Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Security Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Input Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:20:35 --> Language Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Loader Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Controller Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Final output sent to browser
DEBUG - 2014-05-09 00:20:35 --> Total execution time: 0.0166
DEBUG - 2014-05-09 00:20:35 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:35 --> Session Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:20:35 --> A session cookie was not found.
DEBUG - 2014-05-09 00:20:35 --> Session routines successfully run
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:35 --> Final output sent to browser
DEBUG - 2014-05-09 00:20:35 --> Total execution time: 0.0158
DEBUG - 2014-05-09 00:20:35 --> Config Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:20:35 --> URI Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Router Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Output Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Security Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Input Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:20:35 --> Language Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Loader Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Controller Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:35 --> Session Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:20:35 --> A session cookie was not found.
DEBUG - 2014-05-09 00:20:35 --> Session routines successfully run
DEBUG - 2014-05-09 00:20:35 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:20:35 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:35 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:35 --> Final output sent to browser
DEBUG - 2014-05-09 00:20:35 --> Total execution time: 0.0150
DEBUG - 2014-05-09 00:20:38 --> Config Class Initialized
DEBUG - 2014-05-09 00:20:38 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:20:38 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:20:38 --> URI Class Initialized
DEBUG - 2014-05-09 00:20:38 --> Router Class Initialized
ERROR - 2014-05-09 00:20:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 00:20:48 --> Config Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:20:48 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:20:48 --> URI Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Router Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Output Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Security Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Input Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:20:48 --> Language Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Loader Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Controller Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:20:48 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:20:48 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:48 --> Model Class Initialized
DEBUG - 2014-05-09 00:20:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:20:48 --> Final output sent to browser
DEBUG - 2014-05-09 00:20:48 --> Total execution time: 0.1890
DEBUG - 2014-05-09 00:26:27 --> Config Class Initialized
DEBUG - 2014-05-09 00:26:27 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:26:27 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:26:27 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:26:27 --> URI Class Initialized
DEBUG - 2014-05-09 00:26:27 --> Router Class Initialized
ERROR - 2014-05-09 00:26:27 --> 404 Page Not Found --> mantrackr-template
DEBUG - 2014-05-09 00:26:41 --> Config Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:26:41 --> URI Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Router Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Output Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Security Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Input Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:26:41 --> Language Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Loader Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Controller Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:41 --> Session Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:26:41 --> Session routines successfully run
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:41 --> Final output sent to browser
DEBUG - 2014-05-09 00:26:41 --> Total execution time: 0.0152
DEBUG - 2014-05-09 00:26:41 --> Config Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:26:41 --> URI Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Router Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Output Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Security Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Input Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:26:41 --> Language Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Loader Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Controller Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:41 --> Session Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:26:41 --> Session routines successfully run
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:41 --> Final output sent to browser
DEBUG - 2014-05-09 00:26:41 --> Total execution time: 0.0171
DEBUG - 2014-05-09 00:26:41 --> Config Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:26:41 --> URI Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Router Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Output Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Security Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Input Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:26:41 --> Language Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Loader Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Controller Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:41 --> Session Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:26:41 --> Session routines successfully run
DEBUG - 2014-05-09 00:26:41 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:26:41 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:41 --> Final output sent to browser
DEBUG - 2014-05-09 00:26:41 --> Total execution time: 0.0133
DEBUG - 2014-05-09 00:26:58 --> Config Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:26:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:26:58 --> URI Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Router Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Output Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Security Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Input Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:26:58 --> Language Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Loader Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Controller Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:26:58 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:26:58 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:58 --> Model Class Initialized
DEBUG - 2014-05-09 00:26:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:26:58 --> Final output sent to browser
DEBUG - 2014-05-09 00:26:58 --> Total execution time: 0.2147
DEBUG - 2014-05-09 00:27:18 --> Config Class Initialized
DEBUG - 2014-05-09 00:27:18 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:27:18 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:27:18 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:27:18 --> URI Class Initialized
DEBUG - 2014-05-09 00:27:18 --> Router Class Initialized
ERROR - 2014-05-09 00:27:18 --> 404 Page Not Found --> mantracker-template
DEBUG - 2014-05-09 00:27:37 --> Config Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:27:37 --> URI Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Router Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Output Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Security Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Input Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Config Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:27:37 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Language Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:27:37 --> URI Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Loader Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Router Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Controller Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Output Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:27:37 --> Security Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:27:37 --> Input Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:27:37 --> Language Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Loader Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Controller Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Config Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:27:37 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> URI Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Router Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Output Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Security Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Input Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:27:37 --> Language Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Loader Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Controller Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:27:37 --> Session Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:27:37 --> A session cookie was not found.
DEBUG - 2014-05-09 00:27:37 --> Session routines successfully run
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:27:37 --> Session Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:27:37 --> A session cookie was not found.
DEBUG - 2014-05-09 00:27:37 --> Session routines successfully run
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Session Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:27:37 --> A session cookie was not found.
DEBUG - 2014-05-09 00:27:37 --> Session routines successfully run
DEBUG - 2014-05-09 00:27:37 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:27:37 --> Model Class Initialized
DEBUG - 2014-05-09 00:27:37 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:27:37 --> Final output sent to browser
DEBUG - 2014-05-09 00:27:37 --> Total execution time: 0.0149
DEBUG - 2014-05-09 00:27:37 --> Final output sent to browser
DEBUG - 2014-05-09 00:27:37 --> Total execution time: 0.0187
DEBUG - 2014-05-09 00:27:37 --> Final output sent to browser
DEBUG - 2014-05-09 00:27:37 --> Total execution time: 0.0149
DEBUG - 2014-05-09 00:28:08 --> Config Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:28:08 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:28:08 --> URI Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Router Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Output Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Security Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Input Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:28:08 --> Language Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Loader Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Controller Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:28:08 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:28:08 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Helper loaded: email_helper
DEBUG - 2014-05-09 00:28:08 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:08 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:28:08 --> Final output sent to browser
DEBUG - 2014-05-09 00:28:08 --> Total execution time: 0.0127
DEBUG - 2014-05-09 00:28:56 --> Config Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:28:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:28:56 --> URI Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Router Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Output Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Security Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Input Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:28:56 --> Language Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Loader Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Controller Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:28:56 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:28:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:28:58 --> Model Class Initialized
DEBUG - 2014-05-09 00:28:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:28:58 --> Final output sent to browser
DEBUG - 2014-05-09 00:28:58 --> Total execution time: 1.2137
DEBUG - 2014-05-09 00:47:22 --> Config Class Initialized
DEBUG - 2014-05-09 00:47:22 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:47:22 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:47:22 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:47:22 --> URI Class Initialized
DEBUG - 2014-05-09 00:47:22 --> Router Class Initialized
ERROR - 2014-05-09 00:47:22 --> 404 Page Not Found --> mantrackr-template
DEBUG - 2014-05-09 00:47:58 --> Config Class Initialized
DEBUG - 2014-05-09 00:47:58 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:47:58 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:47:58 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:47:58 --> URI Class Initialized
DEBUG - 2014-05-09 00:47:58 --> Router Class Initialized
ERROR - 2014-05-09 00:47:58 --> 404 Page Not Found --> mantrackr-template
DEBUG - 2014-05-09 00:48:06 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:06 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:06 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:06 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:06 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:06 --> Session Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:48:06 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Session routines successfully run
DEBUG - 2014-05-09 00:48:06 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:48:06 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:06 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:06 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Session Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:06 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:48:06 --> Session routines successfully run
DEBUG - 2014-05-09 00:48:06 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:48:06 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:06 --> Total execution time: 0.0172
DEBUG - 2014-05-09 00:48:06 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:06 --> Total execution time: 0.0255
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:06 --> Session Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:48:06 --> Session routines successfully run
DEBUG - 2014-05-09 00:48:06 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:48:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:06 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:06 --> Total execution time: 0.0217
DEBUG - 2014-05-09 00:48:23 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:23 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:23 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:23 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:23 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:23 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:23 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:23 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:23 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:23 --> Total execution time: 0.2292
DEBUG - 2014-05-09 00:48:46 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:46 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:46 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:46 --> Session Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:48:46 --> Session routines successfully run
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:46 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:46 --> Total execution time: 0.0146
DEBUG - 2014-05-09 00:48:46 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:46 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:46 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:46 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Router Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Output Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Security Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Input Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:48:46 --> Language Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Loader Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Controller Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:46 --> Session Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:48:46 --> Session routines successfully run
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:46 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:46 --> Total execution time: 0.0163
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:46 --> Session Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: string_helper
DEBUG - 2014-05-09 00:48:46 --> Session routines successfully run
DEBUG - 2014-05-09 00:48:46 --> Helper loaded: url_helper
DEBUG - 2014-05-09 00:48:46 --> Model Class Initialized
DEBUG - 2014-05-09 00:48:46 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:48:46 --> Final output sent to browser
DEBUG - 2014-05-09 00:48:46 --> Total execution time: 0.0173
DEBUG - 2014-05-09 00:48:47 --> Config Class Initialized
DEBUG - 2014-05-09 00:48:47 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:48:47 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:48:47 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:48:47 --> URI Class Initialized
DEBUG - 2014-05-09 00:48:47 --> Router Class Initialized
ERROR - 2014-05-09 00:48:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 00:49:06 --> Config Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Hooks Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Utf8 Class Initialized
DEBUG - 2014-05-09 00:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 00:49:06 --> URI Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Router Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Output Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Security Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Input Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 00:49:06 --> Language Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Loader Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Controller Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 00:49:06 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 00:49:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Database Driver Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:49:06 --> Model Class Initialized
DEBUG - 2014-05-09 00:49:06 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 00:49:06 --> Final output sent to browser
DEBUG - 2014-05-09 00:49:06 --> Total execution time: 0.1956
DEBUG - 2014-05-09 02:17:31 --> Config Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Hooks Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Utf8 Class Initialized
DEBUG - 2014-05-09 02:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 02:17:31 --> URI Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Router Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Output Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Security Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Input Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 02:17:31 --> Language Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Loader Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Controller Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Database Driver Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Config Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Hooks Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Utf8 Class Initialized
DEBUG - 2014-05-09 02:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 02:17:31 --> URI Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Router Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Output Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Config Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Security Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Hooks Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Input Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Utf8 Class Initialized
DEBUG - 2014-05-09 02:17:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 02:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 02:17:31 --> URI Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Language Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Router Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Loader Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Output Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Security Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Controller Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Input Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 02:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 02:17:31 --> Language Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Loader Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Controller Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Database Driver Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 02:17:31 --> Database Driver Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Session Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: string_helper
DEBUG - 2014-05-09 02:17:31 --> Session routines successfully run
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: url_helper
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 02:17:31 --> Final output sent to browser
DEBUG - 2014-05-09 02:17:31 --> Total execution time: 0.0140
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 02:17:31 --> Session Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: string_helper
DEBUG - 2014-05-09 02:17:31 --> Session routines successfully run
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: url_helper
DEBUG - 2014-05-09 02:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Session Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: string_helper
DEBUG - 2014-05-09 02:17:31 --> Session routines successfully run
DEBUG - 2014-05-09 02:17:31 --> Helper loaded: url_helper
DEBUG - 2014-05-09 02:17:31 --> Model Class Initialized
DEBUG - 2014-05-09 02:17:31 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 02:17:31 --> Final output sent to browser
DEBUG - 2014-05-09 02:17:31 --> Total execution time: 0.0146
DEBUG - 2014-05-09 02:17:31 --> Final output sent to browser
DEBUG - 2014-05-09 02:17:31 --> Total execution time: 0.0176
DEBUG - 2014-05-09 03:06:09 --> Config Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Hooks Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Utf8 Class Initialized
DEBUG - 2014-05-09 03:06:09 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 03:06:09 --> URI Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Router Class Initialized
DEBUG - 2014-05-09 03:06:09 --> No URI present. Default controller set.
DEBUG - 2014-05-09 03:06:09 --> Output Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Security Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Input Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 03:06:09 --> Language Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Loader Class Initialized
DEBUG - 2014-05-09 03:06:09 --> Controller Class Initialized
DEBUG - 2014-05-09 03:06:09 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 03:06:09 --> Final output sent to browser
DEBUG - 2014-05-09 03:06:09 --> Total execution time: 0.0031
DEBUG - 2014-05-09 08:24:01 --> Config Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Hooks Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Utf8 Class Initialized
DEBUG - 2014-05-09 08:24:01 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 08:24:01 --> URI Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Router Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Output Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Security Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Input Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 08:24:01 --> Language Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Loader Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Controller Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 08:24:01 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 08:24:01 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Database Driver Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 08:24:01 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 08:24:01 --> Final output sent to browser
DEBUG - 2014-05-09 08:24:01 --> Total execution time: 0.1147
DEBUG - 2014-05-09 08:24:29 --> Config Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Hooks Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Utf8 Class Initialized
DEBUG - 2014-05-09 08:24:29 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 08:24:29 --> URI Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Router Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Output Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Security Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Input Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 08:24:29 --> Language Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Loader Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Controller Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-05-09 08:24:29 --> Helper loaded: utilities_helper
DEBUG - 2014-05-09 08:24:29 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Database Driver Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 08:24:29 --> Model Class Initialized
DEBUG - 2014-05-09 08:24:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-05-09 08:24:29 --> Final output sent to browser
DEBUG - 2014-05-09 08:24:29 --> Total execution time: 0.0287
DEBUG - 2014-05-09 19:34:31 --> Config Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:34:31 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:34:31 --> URI Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Router Class Initialized
DEBUG - 2014-05-09 19:34:31 --> No URI present. Default controller set.
DEBUG - 2014-05-09 19:34:31 --> Output Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Security Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Input Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 19:34:31 --> Language Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Loader Class Initialized
DEBUG - 2014-05-09 19:34:31 --> Controller Class Initialized
DEBUG - 2014-05-09 19:34:31 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 19:34:31 --> Final output sent to browser
DEBUG - 2014-05-09 19:34:31 --> Total execution time: 0.0028
DEBUG - 2014-05-09 19:34:32 --> Config Class Initialized
DEBUG - 2014-05-09 19:34:32 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:34:32 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:34:32 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:34:32 --> URI Class Initialized
DEBUG - 2014-05-09 19:34:32 --> Router Class Initialized
ERROR - 2014-05-09 19:34:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2014-05-09 19:34:34 --> Config Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:34:34 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:34:34 --> URI Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Router Class Initialized
DEBUG - 2014-05-09 19:34:34 --> No URI present. Default controller set.
DEBUG - 2014-05-09 19:34:34 --> Output Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Security Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Input Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 19:34:34 --> Language Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Loader Class Initialized
DEBUG - 2014-05-09 19:34:34 --> Controller Class Initialized
DEBUG - 2014-05-09 19:34:34 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 19:34:34 --> Final output sent to browser
DEBUG - 2014-05-09 19:34:34 --> Total execution time: 0.0027
DEBUG - 2014-05-09 19:35:16 --> Config Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:35:16 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:35:16 --> URI Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Router Class Initialized
DEBUG - 2014-05-09 19:35:16 --> No URI present. Default controller set.
DEBUG - 2014-05-09 19:35:16 --> Output Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Security Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Input Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 19:35:16 --> Language Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Loader Class Initialized
DEBUG - 2014-05-09 19:35:16 --> Controller Class Initialized
DEBUG - 2014-05-09 19:35:16 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 19:35:16 --> Final output sent to browser
DEBUG - 2014-05-09 19:35:16 --> Total execution time: 0.0047
DEBUG - 2014-05-09 19:37:36 --> Config Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:37:36 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:37:36 --> URI Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Router Class Initialized
DEBUG - 2014-05-09 19:37:36 --> No URI present. Default controller set.
DEBUG - 2014-05-09 19:37:36 --> Output Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Security Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Input Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 19:37:36 --> Language Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Loader Class Initialized
DEBUG - 2014-05-09 19:37:36 --> Controller Class Initialized
DEBUG - 2014-05-09 19:37:36 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 19:37:36 --> Final output sent to browser
DEBUG - 2014-05-09 19:37:36 --> Total execution time: 0.0030
DEBUG - 2014-05-09 19:54:02 --> Config Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:54:02 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:54:02 --> URI Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Router Class Initialized
DEBUG - 2014-05-09 19:54:02 --> No URI present. Default controller set.
DEBUG - 2014-05-09 19:54:02 --> Output Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Security Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Input Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 19:54:02 --> Language Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Loader Class Initialized
DEBUG - 2014-05-09 19:54:02 --> Controller Class Initialized
DEBUG - 2014-05-09 19:54:02 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 19:54:02 --> Final output sent to browser
DEBUG - 2014-05-09 19:54:02 --> Total execution time: 0.0027
DEBUG - 2014-05-09 19:56:56 --> Config Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Hooks Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Utf8 Class Initialized
DEBUG - 2014-05-09 19:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-05-09 19:56:56 --> URI Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Router Class Initialized
DEBUG - 2014-05-09 19:56:56 --> No URI present. Default controller set.
DEBUG - 2014-05-09 19:56:56 --> Output Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Security Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Input Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-05-09 19:56:56 --> Language Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Loader Class Initialized
DEBUG - 2014-05-09 19:56:56 --> Controller Class Initialized
DEBUG - 2014-05-09 19:56:56 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-05-09 19:56:56 --> Final output sent to browser
DEBUG - 2014-05-09 19:56:56 --> Total execution time: 0.0027
