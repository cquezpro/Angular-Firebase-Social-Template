<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-18 07:37:48 --> Config Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:37:48 --> URI Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Router Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Output Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Security Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Input Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:37:48 --> Language Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Loader Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Controller Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:37:48 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Database Driver Class Initialized
ERROR - 2014-02-18 07:37:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-18 07:37:48 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:37:48 --> Session Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:37:48 --> A session cookie was not found.
DEBUG - 2014-02-18 07:37:48 --> Session routines successfully run
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:37:48 --> Config Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:37:48 --> URI Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Router Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Output Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Security Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Input Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:37:48 --> Language Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Loader Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Controller Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:37:48 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Database Driver Class Initialized
ERROR - 2014-02-18 07:37:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-18 07:37:48 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:37:48 --> Session Class Initialized
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:37:48 --> Session routines successfully run
DEBUG - 2014-02-18 07:37:48 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:37:48 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-18 07:37:48 --> Final output sent to browser
DEBUG - 2014-02-18 07:37:48 --> Total execution time: 0.0360
DEBUG - 2014-02-18 07:37:56 --> Config Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:37:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:37:56 --> URI Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Router Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Output Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Security Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Input Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:37:56 --> Language Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Loader Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Controller Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:37:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:37:56 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Database Driver Class Initialized
ERROR - 2014-02-18 07:37:56 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-18 07:37:56 --> Model Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:37:56 --> Session Class Initialized
DEBUG - 2014-02-18 07:37:56 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:37:56 --> Session routines successfully run
DEBUG - 2014-02-18 07:37:56 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:01 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:01 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:01 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:01 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:01 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:01 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:01 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:01 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:01 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:01 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:01 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:01 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:01 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:01 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-18 07:38:01 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:01 --> Total execution time: 0.0670
DEBUG - 2014-02-18 07:38:02 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:02 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:02 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:02 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:02 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:02 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:02 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:02 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:02 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:02 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:02 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:02 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:02 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:02 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:02 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:02 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:02 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:02 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:02 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:02 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:02 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:02 --> Total execution time: 0.0220
DEBUG - 2014-02-18 07:38:02 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:02 --> Total execution time: 0.0320
DEBUG - 2014-02-18 07:38:02 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:02 --> Total execution time: 0.0330
DEBUG - 2014-02-18 07:38:07 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:07 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:07 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:07 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:07 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:07 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:07 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:07 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:07 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:07 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:07 --> Total execution time: 0.0240
DEBUG - 2014-02-18 07:38:07 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:07 --> Total execution time: 0.0330
DEBUG - 2014-02-18 07:38:18 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:18 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:18 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:18 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:18 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:18 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:18 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:18 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:18 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-18 07:38:18 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:18 --> Total execution time: 0.0260
DEBUG - 2014-02-18 07:38:20 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:20 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:20 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:20 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:20 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:20 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:20 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:20 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:20 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-18 07:38:20 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:20 --> Total execution time: 0.0220
DEBUG - 2014-02-18 07:38:22 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:22 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:22 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:22 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:22 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:22 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:22 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:22 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:22 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:22 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-18 07:38:22 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:22 --> Total execution time: 0.0380
DEBUG - 2014-02-18 07:38:28 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:28 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:28 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:28 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:28 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:28 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:28 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:28 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:28 --> File loaded: application/views/admin/mailboard.php
DEBUG - 2014-02-18 07:38:28 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:28 --> Total execution time: 0.0200
DEBUG - 2014-02-18 07:38:29 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:29 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:29 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:29 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:29 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-18 07:38:29 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:29 --> Total execution time: 0.0110
DEBUG - 2014-02-18 07:38:29 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:29 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:29 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:29 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:29 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:29 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:29 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:29 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:29 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:29 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:29 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:29 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:29 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:29 --> Total execution time: 0.0140
DEBUG - 2014-02-18 07:38:29 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:29 --> Total execution time: 0.0180
DEBUG - 2014-02-18 07:38:29 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:29 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:29 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Total execution time: 0.0220
DEBUG - 2014-02-18 07:38:29 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:29 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:29 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:29 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:29 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:29 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:29 --> Total execution time: 0.0190
DEBUG - 2014-02-18 07:38:30 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:30 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:30 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:30 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:30 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:30 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:30 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:30 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:30 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:30 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:30 --> Total execution time: 0.0100
DEBUG - 2014-02-18 07:38:34 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:34 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:34 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:34 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:34 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:34 --> File loaded: application/views/admin/pendingPhotos.php
DEBUG - 2014-02-18 07:38:34 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:34 --> Total execution time: 0.0200
DEBUG - 2014-02-18 07:38:34 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:34 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:34 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:34 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:34 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:34 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:34 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:34 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:34 --> Total execution time: 0.0310
DEBUG - 2014-02-18 07:38:41 --> Config Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Hooks Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Utf8 Class Initialized
DEBUG - 2014-02-18 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 07:38:41 --> URI Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Router Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Output Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Security Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Input Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 07:38:41 --> Language Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Loader Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Controller Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-18 07:38:41 --> Helper loaded: utilities_helper
DEBUG - 2014-02-18 07:38:41 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Database Driver Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Model Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-18 07:38:41 --> Session Class Initialized
DEBUG - 2014-02-18 07:38:41 --> Helper loaded: string_helper
DEBUG - 2014-02-18 07:38:41 --> Session routines successfully run
DEBUG - 2014-02-18 07:38:41 --> Helper loaded: url_helper
DEBUG - 2014-02-18 07:38:41 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-18 07:38:41 --> Final output sent to browser
DEBUG - 2014-02-18 07:38:41 --> Total execution time: 0.0150
DEBUG - 2014-02-18 19:18:58 --> Config Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Hooks Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Utf8 Class Initialized
DEBUG - 2014-02-18 19:18:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-18 19:18:58 --> URI Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Router Class Initialized
DEBUG - 2014-02-18 19:18:58 --> No URI present. Default controller set.
DEBUG - 2014-02-18 19:18:58 --> Output Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Security Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Input Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-18 19:18:58 --> Language Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Loader Class Initialized
DEBUG - 2014-02-18 19:18:58 --> Controller Class Initialized
DEBUG - 2014-02-18 19:18:58 --> File loaded: application/views/welcome_message.php
DEBUG - 2014-02-18 19:18:58 --> Final output sent to browser
DEBUG - 2014-02-18 19:18:58 --> Total execution time: 0.0110
