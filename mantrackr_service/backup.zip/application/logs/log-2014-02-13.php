<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-13 06:26:32 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:32 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:32 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:32 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Database Driver Class Initialized
ERROR - 2014-02-13 06:26:32 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-13 06:26:32 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:32 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:32 --> A session cookie was not found.
DEBUG - 2014-02-13 06:26:32 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:32 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:32 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:32 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:32 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Database Driver Class Initialized
ERROR - 2014-02-13 06:26:32 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-13 06:26:32 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:32 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:32 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:32 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:32 --> File loaded: application/views/admin/login.php
DEBUG - 2014-02-13 06:26:32 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:32 --> Total execution time: 0.0130
DEBUG - 2014-02-13 06:26:34 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:34 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:34 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:34 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Database Driver Class Initialized
ERROR - 2014-02-13 06:26:34 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-13 06:26:34 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:34 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:34 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:34 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:34 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:34 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:34 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Database Driver Class Initialized
ERROR - 2014-02-13 06:26:34 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-13 06:26:34 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:34 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:34 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:34 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:39 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:39 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:39 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Database Driver Class Initialized
ERROR - 2014-02-13 06:26:39 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:39 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:39 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-13 06:26:39 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:39 --> Total execution time: 0.0240
DEBUG - 2014-02-13 06:26:39 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:39 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:39 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:39 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:39 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:39 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:39 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:39 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:39 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:39 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:39 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:39 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:39 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:39 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:39 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:39 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:39 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:39 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:39 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:39 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:39 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:39 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:39 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:39 --> Total execution time: 0.0430
DEBUG - 2014-02-13 06:26:39 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:39 --> Total execution time: 0.0400
DEBUG - 2014-02-13 06:26:39 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:39 --> Total execution time: 0.0410
DEBUG - 2014-02-13 06:26:39 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:39 --> Total execution time: 0.0530
DEBUG - 2014-02-13 06:26:44 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:44 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:44 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:44 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:44 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:44 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:44 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:44 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:44 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:44 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:44 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:44 --> Total execution time: 0.0210
DEBUG - 2014-02-13 06:26:54 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:54 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:54 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:54 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:54 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:54 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:54 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:54 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:54 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:54 --> File loaded: application/views/admin/dashboard.php
DEBUG - 2014-02-13 06:26:54 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:54 --> Total execution time: 0.0210
DEBUG - 2014-02-13 06:26:55 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:55 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:55 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:55 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:55 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:55 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:55 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:55 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:55 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:55 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:55 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:55 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:55 --> Total execution time: 0.0120
DEBUG - 2014-02-13 06:26:55 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:55 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:55 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:55 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:55 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:55 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:55 --> Total execution time: 0.0200
DEBUG - 2014-02-13 06:26:55 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:55 --> Total execution time: 0.0220
DEBUG - 2014-02-13 06:26:57 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:57 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:57 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:57 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:57 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:57 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:57 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-13 06:26:57 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:57 --> Total execution time: 0.0210
DEBUG - 2014-02-13 06:26:57 --> Config Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:26:57 --> URI Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Router Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Output Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Security Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Input Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:26:57 --> Language Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Loader Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Controller Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:26:57 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Model Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:26:57 --> Session Class Initialized
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:26:57 --> Session routines successfully run
DEBUG - 2014-02-13 06:26:57 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:26:57 --> Final output sent to browser
DEBUG - 2014-02-13 06:26:57 --> Total execution time: 0.0100
DEBUG - 2014-02-13 06:27:00 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:00 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:00 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:00 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:00 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:00 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:00 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:00 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:00 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:00 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:00 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:00 --> Total execution time: 0.0140
DEBUG - 2014-02-13 06:27:00 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:00 --> Total execution time: 0.0250
DEBUG - 2014-02-13 06:27:09 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:09 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:09 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:09 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:09 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:09 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:09 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:09 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:09 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:09 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-13 06:27:09 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:09 --> Total execution time: 0.0140
DEBUG - 2014-02-13 06:27:48 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:48 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:48 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:48 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:48 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:48 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:48 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-13 06:27:48 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:48 --> Total execution time: 0.0210
DEBUG - 2014-02-13 06:27:48 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:48 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:48 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:48 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:48 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:48 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:48 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:48 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:48 --> Total execution time: 0.0100
DEBUG - 2014-02-13 06:27:50 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:50 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:50 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:50 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:50 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:50 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:50 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:50 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:50 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:50 --> File loaded: application/views/admin/flaggedMembers.php
DEBUG - 2014-02-13 06:27:50 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:50 --> Total execution time: 0.0170
DEBUG - 2014-02-13 06:27:53 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:53 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:53 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:53 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:53 --> File loaded: application/views/admin/visitorStats.php
DEBUG - 2014-02-13 06:27:53 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:53 --> Total execution time: 0.0200
DEBUG - 2014-02-13 06:27:53 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:53 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:53 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:53 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:53 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:53 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:53 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:53 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:53 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:53 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:53 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:53 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:53 --> Total execution time: 0.0260
DEBUG - 2014-02-13 06:27:53 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:53 --> Total execution time: 0.0350
DEBUG - 2014-02-13 06:27:53 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:53 --> Total execution time: 0.0370
DEBUG - 2014-02-13 06:27:53 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:53 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:53 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:53 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:53 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:53 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:53 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:53 --> File loaded: application/views/admin/adalertManage.php
DEBUG - 2014-02-13 06:27:53 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:53 --> Total execution time: 0.0200
DEBUG - 2014-02-13 06:27:58 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Config Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:27:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:58 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:27:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:27:58 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:58 --> URI Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Router Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Output Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Security Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Input Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:27:58 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Language Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Loader Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Controller Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:58 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Session Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:27:58 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:58 --> Session routines successfully run
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:58 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Model Class Initialized
DEBUG - 2014-02-13 06:27:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:58 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:27:58 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:58 --> Total execution time: 0.0140
DEBUG - 2014-02-13 06:27:58 --> Final output sent to browser
DEBUG - 2014-02-13 06:27:58 --> Total execution time: 0.0290
DEBUG - 2014-02-13 06:28:19 --> Config Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:28:19 --> URI Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Router Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Output Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Security Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Input Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:28:19 --> Language Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Loader Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Controller Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:28:19 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:28:19 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:28:19 --> Session Class Initialized
DEBUG - 2014-02-13 06:28:19 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:28:19 --> Session routines successfully run
DEBUG - 2014-02-13 06:28:19 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:28:19 --> File loaded: application/views/admin/members.php
DEBUG - 2014-02-13 06:28:19 --> Final output sent to browser
DEBUG - 2014-02-13 06:28:19 --> Total execution time: 0.0190
DEBUG - 2014-02-13 06:28:20 --> Config Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:28:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:28:20 --> URI Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Router Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Output Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Security Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Input Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:28:20 --> Language Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Loader Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Controller Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:28:20 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:28:20 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:28:20 --> Session Class Initialized
DEBUG - 2014-02-13 06:28:20 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:28:20 --> Session routines successfully run
DEBUG - 2014-02-13 06:28:20 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:28:20 --> Final output sent to browser
DEBUG - 2014-02-13 06:28:20 --> Total execution time: 0.0100
DEBUG - 2014-02-13 06:28:21 --> Config Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Hooks Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Utf8 Class Initialized
DEBUG - 2014-02-13 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-13 06:28:21 --> URI Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Router Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Output Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Security Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Input Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-13 06:28:21 --> Language Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Loader Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Controller Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-13 06:28:21 --> Helper loaded: utilities_helper
DEBUG - 2014-02-13 06:28:21 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Database Driver Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Model Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-13 06:28:21 --> Session Class Initialized
DEBUG - 2014-02-13 06:28:21 --> Helper loaded: string_helper
DEBUG - 2014-02-13 06:28:21 --> Session routines successfully run
DEBUG - 2014-02-13 06:28:21 --> Helper loaded: url_helper
DEBUG - 2014-02-13 06:28:21 --> File loaded: application/views/admin/member.php
DEBUG - 2014-02-13 06:28:21 --> Final output sent to browser
DEBUG - 2014-02-13 06:28:21 --> Total execution time: 0.0180
