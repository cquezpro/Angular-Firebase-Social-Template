<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-24 20:58:45 --> Config Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Hooks Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Utf8 Class Initialized
DEBUG - 2014-02-24 20:58:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 20:58:45 --> URI Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Router Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Output Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Security Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Input Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 20:58:45 --> Language Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Loader Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Controller Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 20:58:45 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 20:58:45 --> Model Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Model Class Initialized
DEBUG - 2014-02-24 20:58:45 --> Database Driver Class Initialized
ERROR - 2014-02-24 20:58:47 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-02-24 20:58:47 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-02-24 20:58:47 --> Unable to connect to the database
DEBUG - 2014-02-24 20:58:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-24 20:59:18 --> Config Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Hooks Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Utf8 Class Initialized
DEBUG - 2014-02-24 20:59:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 20:59:18 --> URI Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Router Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Output Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Security Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Input Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 20:59:18 --> Language Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Loader Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Controller Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 20:59:18 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 20:59:18 --> Model Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Model Class Initialized
DEBUG - 2014-02-24 20:59:18 --> Database Driver Class Initialized
ERROR - 2014-02-24 20:59:20 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: [2002] No connection could be made because the target machine actively refused it.
 (trying to connect via tcp://localhost:3306) F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-02-24 20:59:20 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: No connection could be made because the target machine actively refused it.
 F:\ZServer61\Apache2\htdocs\mantrackr_service\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-02-24 20:59:20 --> Unable to connect to the database
DEBUG - 2014-02-24 20:59:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-24 20:59:26 --> Config Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Hooks Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Utf8 Class Initialized
DEBUG - 2014-02-24 20:59:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 20:59:26 --> URI Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Router Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Output Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Security Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Input Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 20:59:26 --> Language Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Loader Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Controller Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 20:59:26 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 20:59:26 --> Model Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Model Class Initialized
DEBUG - 2014-02-24 20:59:26 --> Database Driver Class Initialized
ERROR - 2014-02-24 20:59:27 --> 404 Page Not Found --> member/index
DEBUG - 2014-02-24 20:59:28 --> Config Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Hooks Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Utf8 Class Initialized
DEBUG - 2014-02-24 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 20:59:28 --> URI Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Router Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Output Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Security Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Input Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 20:59:28 --> Language Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Loader Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Controller Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 20:59:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 20:59:28 --> Model Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Model Class Initialized
DEBUG - 2014-02-24 20:59:28 --> Database Driver Class Initialized
ERROR - 2014-02-24 20:59:28 --> 404 Page Not Found --> member/index
DEBUG - 2014-02-24 21:01:28 --> Config Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Hooks Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Utf8 Class Initialized
DEBUG - 2014-02-24 21:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 21:01:28 --> URI Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Router Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Output Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Security Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Input Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 21:01:28 --> Language Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Loader Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Controller Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Config Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Database Driver Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Hooks Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Utf8 Class Initialized
DEBUG - 2014-02-24 21:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 21:01:28 --> URI Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Router Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Output Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Security Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Input Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 21:01:28 --> Language Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Loader Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:28 --> Controller Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Database Driver Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:28 --> Session Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Session Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: string_helper
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: string_helper
DEBUG - 2014-02-24 21:01:28 --> A session cookie was not found.
DEBUG - 2014-02-24 21:01:28 --> A session cookie was not found.
DEBUG - 2014-02-24 21:01:28 --> Session routines successfully run
DEBUG - 2014-02-24 21:01:28 --> Session routines successfully run
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: url_helper
DEBUG - 2014-02-24 21:01:28 --> Helper loaded: url_helper
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:28 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:29 --> Final output sent to browser
DEBUG - 2014-02-24 21:01:29 --> Final output sent to browser
DEBUG - 2014-02-24 21:01:29 --> Total execution time: 0.9491
DEBUG - 2014-02-24 21:01:29 --> Total execution time: 0.9411
DEBUG - 2014-02-24 21:01:29 --> Config Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Hooks Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Utf8 Class Initialized
DEBUG - 2014-02-24 21:01:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 21:01:29 --> URI Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Router Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Output Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Security Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Input Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 21:01:29 --> Language Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Loader Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Controller Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 21:01:29 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 21:01:29 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Database Driver Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:29 --> Session Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Helper loaded: string_helper
DEBUG - 2014-02-24 21:01:29 --> A session cookie was not found.
DEBUG - 2014-02-24 21:01:29 --> Session routines successfully run
DEBUG - 2014-02-24 21:01:29 --> Helper loaded: url_helper
DEBUG - 2014-02-24 21:01:29 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:29 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:29 --> Final output sent to browser
DEBUG - 2014-02-24 21:01:29 --> Total execution time: 0.1120
DEBUG - 2014-02-24 21:01:43 --> Config Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Hooks Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Utf8 Class Initialized
DEBUG - 2014-02-24 21:01:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 21:01:43 --> URI Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Router Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Output Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Security Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Input Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 21:01:43 --> Language Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Loader Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Controller Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 21:01:43 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 21:01:43 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Database Driver Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Helper loaded: email_helper
DEBUG - 2014-02-24 21:01:43 --> Model Class Initialized
DEBUG - 2014-02-24 21:01:43 --> Phpfirebase class already loaded. Second attempt ignored.
DEBUG - 2014-02-24 21:01:50 --> Final output sent to browser
DEBUG - 2014-02-24 21:01:50 --> Total execution time: 6.8674
DEBUG - 2014-02-24 21:03:56 --> Config Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Hooks Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Utf8 Class Initialized
DEBUG - 2014-02-24 21:03:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-24 21:03:56 --> URI Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Router Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Output Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Security Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Input Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-24 21:03:56 --> Language Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Loader Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Controller Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Helper loaded: service_errorcodes_helper
DEBUG - 2014-02-24 21:03:56 --> Helper loaded: utilities_helper
DEBUG - 2014-02-24 21:03:56 --> Model Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Model Class Initialized
DEBUG - 2014-02-24 21:03:56 --> Database Driver Class Initialized
DEBUG - 2014-02-24 21:03:58 --> Model Class Initialized
DEBUG - 2014-02-24 21:03:58 --> Phpfirebase class already loaded. Second attempt ignored.
